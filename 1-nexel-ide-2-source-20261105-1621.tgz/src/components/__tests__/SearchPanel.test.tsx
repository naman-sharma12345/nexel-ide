import { webcrypto } from 'node:crypto';
import { beforeEach as beforeFingerprintTest, vi as fingerprintVi } from 'vitest';
beforeFingerprintTest(() => fingerprintVi.stubGlobal('crypto', webcrypto));
import {describe,it,expect,vi,afterEach} from 'vitest';import {render,screen,fireEvent,cleanup,waitFor} from '@testing-library/react';import {SearchPanel} from '../SearchPanel';
afterEach(()=>{cleanup();vi.unstubAllGlobals();});
describe('workspace search',()=>{it('contains keyboard focus and restores previous control',()=>{const previous=document.createElement('button');document.body.append(previous);previous.focus();const close=vi.fn();const r=render(<SearchPanel files={[]} onOpen={vi.fn()} onClose={close}/>);expect(document.activeElement).toBe(screen.getByRole('combobox'));fireEvent.keyDown(screen.getByRole('combobox'),{key:'Escape'});expect(close).toHaveBeenCalledOnce();const first=screen.getByRole('button',{name:'Close find in files'});first.focus();fireEvent.keyDown(first,{key:'Tab',shiftKey:true});expect(document.activeElement).toBe(screen.getByRole('textbox',{name:'Replace with'}));r.unmount();expect(document.activeElement).toBe(previous);previous.remove();});});

it('distinguishes duplicate result basenames by path and opens the selected file',async()=>{window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE = 1\n');const open=vi.fn();render(<SearchPanel files={[{path:'/work/api/config.py',name:'config.py'},{path:'/work/web/config.py',name:'config.py'}]} onOpen={open} onClose={vi.fn()}/>);const input=screen.getByRole('combobox');fireEvent.change(input,{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getAllByRole('option')).toHaveLength(2));expect(screen.getByText('/work/api')).toBeInTheDocument();expect(screen.getByText('/work/web')).toBeInTheDocument();fireEvent.keyDown(input,{key:'ArrowDown'});expect(screen.getByRole('option',{name:/web\/config.py, line 1/})).toHaveAttribute('aria-selected','true');fireEvent.keyDown(input,{key:'Enter'});expect(open).toHaveBeenCalledWith('/work/web/config.py',1,1);});
it('cancels replacement without writes and returns focus to the search',async()=>{window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE = 1\n');const write=vi.fn();window.nexelAPI.writeFileContent=write;const close=vi.fn();render(<SearchPanel files={[{path:'/work/api/config.py',name:'config.py'}]} onOpen={vi.fn()} onClose={close}/>);const input=screen.getByRole('combobox');fireEvent.change(input,{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getAllByRole('option')).toHaveLength(1));fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'CHANGED'}});fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});expect(screen.getByRole('alertdialog',{name:'Confirm replace all'})).toBeInTheDocument();expect(document.activeElement).toBe(screen.getByRole('button',{name:'Replace'}));fireEvent.keyDown(document.activeElement!,{key:'Tab',shiftKey:true});expect(document.activeElement).toBe(screen.getByRole('button',{name:'Cancel'}));fireEvent.keyDown(document.activeElement!,{key:'Escape'});expect(screen.queryByRole('alertdialog')).toBeNull();expect(document.activeElement).toBe(input);expect(write).not.toHaveBeenCalled();expect(close).not.toHaveBeenCalled();fireEvent.keyDown(input,{key:'Escape'});expect(close).toHaveBeenCalledOnce();});
it('ignores an old workspace read completing after the file set changes',async()=>{
 let finishOld!:(value:string)=>void;
 const old=new Promise<string>(r=>{finishOld=r;});
 window.nexelAPI.readFileContent=vi.fn(path=>path.startsWith('/old/')?old:Promise.resolve('VALUE = 2\n'));
 const open=vi.fn(),close=vi.fn();
 const view=render(<SearchPanel files={[{path:'/old/old.py',name:'old.py'}]} onOpen={open} onClose={close}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});
 await waitFor(()=>expect(window.nexelAPI.readFileContent).toHaveBeenCalledWith('/old/old.py'));
 view.rerender(<SearchPanel files={[{path:'/new/current.py',name:'current.py'}]} onOpen={open} onClose={close}/>);
 await waitFor(()=>expect(screen.getByRole('option')).toHaveAccessibleName(/new\/current.py/));
 finishOld('VALUE = old\n');await new Promise(r=>setTimeout(r,30));
 expect(screen.getAllByRole('option')).toHaveLength(1);expect(screen.getByRole('option')).toHaveAccessibleName(/new\/current.py/);
 fireEvent.keyDown(screen.getByRole('combobox'),{key:'Enter'});expect(open).toHaveBeenCalledWith('/new/current.py',1,1);
});
it('does not overwrite an open editor buffer during bulk disk replacement',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});s.getState().openFile('/work/open.py','open.py','VALUE = disk\n');s.getState().updateTabContent('/work/open.py','VALUE = unsaved\n');
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE = disk\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/open.py',name:'open.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());
 fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});fireEvent.click(screen.getByRole('button',{name:'Replace'}));
 await new Promise(r=>setTimeout(r,30));expect(write).not.toHaveBeenCalled();expect(s.getState().tabs[0].content).toBe('VALUE = unsaved\n');s.setState({tabs:[]});
});
it('skips a file whose disk contents changed between read and write instead of clobbering it',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE = 1\n');
 const write=vi.fn(async():Promise<'written'|'conflict'>=>'conflict');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/race.py',name:'race.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());
 fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'CHANGED'}});
 fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});fireEvent.click(screen.getByRole('button',{name:'Replace'}));
 await waitFor(()=>expect(write).toHaveBeenCalled());expect(write).toHaveBeenCalledWith('/work/race.py','CHANGED = 1\n','VALUE = 1\n');
 await waitFor(()=>expect(screen.getByText(/Replaced 0 in 0 files.*1 skipped/)).toBeInTheDocument());
});
it('cannot start two replacement writes from repeated confirmation clicks',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE = disk\n');let finish!:(ok:'written'|'conflict')=>void;const write=vi.fn(()=>new Promise<'written'|'conflict'>(r=>{finish=r;}));window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/closed.py',name:'closed.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});const confirm=screen.getByRole('button',{name:'Replace'});fireEvent.click(confirm);fireEvent.click(confirm);await waitFor(()=>expect(write).toHaveBeenCalled());expect(write).toHaveBeenCalledTimes(1);finish('written');
});
it('reports failed writes rather than counting them as replaced',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');window.nexelAPI.writeFileIfBaseline=vi.fn(async()=>{throw new Error('write denied');});
 render(<SearchPanel files={[{path:'/work/fails.py',name:'fails.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(screen.getByText(/Replaced 0 in 0 files.*1 failed/)).toBeInTheDocument());
});
it('does not start a write after the search is unmounted during its read',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});let finish!:(v:string)=>void;
 window.nexelAPI.readFileContent=vi.fn().mockResolvedValueOnce('VALUE\n').mockImplementationOnce(()=>new Promise<string>(r=>{finish=r;}));const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 const view=render(<SearchPanel files={[{path:'/work/unmount.py',name:'unmount.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog',{name:'Confirm replace all'});fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(finish).toBeDefined());view.unmount();finish('VALUE\n');await new Promise(r=>setTimeout(r,30));expect(write).not.toHaveBeenCalled();
});
it('skips alternate paths with the same open file identity and shows exclusions',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});s.getState().openFile('/work/original.py','original.py','VALUE');s.getState().updateTabContent('/work/original.py','unsaved');
 const originalIdentity=window.nexelAPI.fileIdentity;window.nexelAPI.fileIdentity=vi.fn(async()=> 'same-device:inode');
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/alias.py',name:'alias.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));const dialog=await screen.findByRole('alertdialog');expect(dialog).toHaveTextContent('1 open file path');fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(screen.getByText(/1 skipped/)).toBeInTheDocument());expect(write).not.toHaveBeenCalled();window.nexelAPI.fileIdentity=originalIdentity;s.setState({tabs:[]});
});
it('does not replace the same closed filesystem identity twice through aliases',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});const identity=window.nexelAPI.fileIdentity;window.nexelAPI.fileIdentity=vi.fn(async()=> 'same-inode');
 window.nexelAPI.readFileContent=vi.fn(async()=> 'a\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/a.py',name:'a.py'},{path:'/work/alias.py',name:'alias.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'a'}});fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'aa'}});await waitFor(()=>expect(screen.getAllByRole('option')).toHaveLength(2));fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(screen.queryByRole('alertdialog')).toBeNull());expect(write).toHaveBeenCalledTimes(1);window.nexelAPI.fileIdentity=identity;
});
it('refuses confirmation and writes when file identity is unavailable',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});const identity=window.nexelAPI.fileIdentity;window.nexelAPI.fileIdentity=vi.fn(async()=>{throw Error('identity unsupported');});
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/unknown.py',name:'unknown.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await waitFor(()=>expect(screen.getByText(/Cannot replace: file identity/)).toBeInTheDocument());expect(screen.queryByRole('alertdialog')).toBeNull();expect(write).not.toHaveBeenCalled();window.nexelAPI.fileIdentity=identity;
});
it('does not broaden confirmed scope if an excluded open tab closes',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});s.getState().openFile('/work/open-scope.py','open-scope.py','VALUE');
 window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/open-scope.py',name:'open-scope.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');s.setState({tabs:[]});fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(screen.getByText(/1 skipped/)).toBeInTheDocument());expect(write).not.toHaveBeenCalled();
});
it('requires new confirmation after replacement text changes',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/query.py',name:'query.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'new unconfirmed value'}});fireEvent.click(screen.getByRole('button',{name:'Replace'}));expect(write).not.toHaveBeenCalled();expect(screen.queryByRole('alertdialog')).toBeNull();
});
it('highlights a distant long-line match but opens its original column',async()=>{
 window.nexelAPI.readFileContent=vi.fn(async()=> 'x'.repeat(600)+'TARGET'+'z'.repeat(200));const open=vi.fn();
 render(<SearchPanel files={[{path:'/work/long.py',name:'long.py'}]} onOpen={open} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'TARGET'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());expect(screen.getByRole('option').querySelector('mark')).toHaveTextContent('TARGET');fireEvent.keyDown(screen.getByRole('combobox'),{key:'Enter'});expect(open).toHaveBeenCalledWith('/work/long.py',1,601);
});
it('returns to Edit after its palette input has been removed',()=>{
 const edit=document.createElement('button');edit.className='nx-menu-trigger-btn';edit.textContent='Edit';const input=document.createElement('input');document.body.append(edit,input);input.focus();
 const view=render(<SearchPanel files={[]} onOpen={vi.fn()} onClose={vi.fn()}/>);input.remove();view.unmount();expect(edit).toHaveFocus();edit.remove();
});
class InlineWorker {
 onmessage:((e:{data:unknown})=>void)|null=null;onerror:(()=>void)|null=null;terminate=()=>{};
 constructor(){queueMicrotask(()=>this.onmessage?.({data:{ready:true}}));}
 postMessage(d:{id:number;content:string;source:string;flags:string;cap:number;maxLineChars:number}){const re=new RegExp(d.source,d.flags);const lines=d.content.split('\n');const matches:unknown[]=[];lines.forEach((t,i)=>{re.lastIndex=0;let m;while((m=re.exec(t))&&matches.length<d.cap){if(!m[0].length){re.lastIndex++;continue;}matches.push({line:i+1,col:m.index+1,length:m[0].length,text:t,previewOffset:0});}});queueMicrotask(()=>this.onmessage?.({data:{id:d.id,matches}}));}
}
it('reports an invalid regex without reading files or enabling replacement, then recovers',async()=>{
 vi.stubGlobal('Worker',InlineWorker);
 const read=vi.fn(async()=> 'VALUE');window.nexelAPI.readFileContent=read;
 render(<SearchPanel files={[{path:'/work/a.py',name:'a.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.click(screen.getByRole('button',{name:'Regular expression'}));const field=screen.getByRole('combobox');
 fireEvent.change(field,{target:{value:'['}});
 expect(field).toHaveAttribute('aria-invalid','true');expect(screen.getByRole('alert')).toHaveTextContent('Invalid regular expression');
 await new Promise(r=>setTimeout(r,220));expect(read).not.toHaveBeenCalled();expect(screen.getByRole('button',{name:'Replace all'})).toBeDisabled();
 fireEvent.change(field,{target:{value:'VALUE'}});await waitFor(()=>expect(screen.getByRole('option')).toBeInTheDocument());
 expect(field).toHaveAttribute('aria-invalid','false');expect(screen.queryByRole('alert')).toBeNull();
});
it('blocks replacement when the visible result set is capped',async()=>{
 window.nexelAPI.readFileContent=vi.fn(async()=> 'TARGET\n'.repeat(510));const write=vi.fn();window.nexelAPI.writeFileContent=write;
 render(<SearchPanel files={[{path:'/work/many.py',name:'many.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'TARGET'}});
 await screen.findByText('Results are limited. Narrow your search before using Replace all.');expect(screen.getByRole('button',{name:'Replace all'})).toBeDisabled();
 fireEvent.keyDown(screen.getByRole('textbox',{name:'Replace with'}),{key:'Enter',ctrlKey:true});expect(screen.queryByRole('alertdialog')).toBeNull();expect(write).not.toHaveBeenCalled();
});
it('reports incomplete search rather than plain no results when a read fails',async()=>{
 window.nexelAPI.readFileContent=vi.fn(async()=>{throw Error('denied');});render(<SearchPanel files={[{path:'/work/denied.py',name:'denied.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'TARGET'}});await screen.findByText('1 file could not be read. Search is incomplete.');expect(screen.getByText('No matches in readable files.')).toBeInTheDocument();
});
it('recovers confirmation controls after another file operation blocks replacement',async()=>{
 const{reserveBulkReplacement}=await import('../../lib/documentWriteLock');window.nexelAPI.readFileContent=vi.fn(async()=> 'VALUE\n');const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/locked.py',name:'locked.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await screen.findByRole('option');fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');const release=reserveBulkReplacement();try{fireEvent.click(screen.getByRole('button',{name:'Replace'}));await screen.findByText(/Replacement not started: another file operation/);expect(write).not.toHaveBeenCalled();expect(screen.queryByRole('alertdialog')).toBeNull();}finally{release();}fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));await waitFor(()=>expect(write).toHaveBeenCalledOnce());
});

describe('risky regex', () => {
  it('does not read files and explains the refusal', async () => {
    const read = vi.fn(async () => 'aaaa\n');
    window.nexelAPI.readFileContent = read;
    render(<SearchPanel files={[{ path: '/w/a.py', name: 'a.py' }]} onOpen={vi.fn()} onClose={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Regular expression' }));
    fireEvent.change(screen.getByRole('combobox'), { target: { value: '(a+)+$' } });
    expect(await screen.findByRole('alert')).toHaveTextContent(/can freeze the app/);
    await new Promise(r => setTimeout(r, 50));
    expect(read).not.toHaveBeenCalled();
  });
});

describe('regex without Worker support', () => {
  it('refuses to run the pattern and says so', async () => {
    const read = vi.fn(async () => 'aaaa\n');
    window.nexelAPI.readFileContent = read;
    render(<SearchPanel files={[{ path: '/w/a.py', name: 'a.py' }]} onOpen={vi.fn()} onClose={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Regular expression' }));
    fireEvent.change(screen.getByRole('combobox'), { target: { value: 'a+' } });
    expect(await screen.findByRole('alert')).toHaveTextContent(/unavailable here/);
    await new Promise(r => setTimeout(r, 300));
    expect(read).not.toHaveBeenCalled();
  });
});

it('notes that unsaved edits are excluded while a dirty tab exists',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});s.getState().openFile('/work/dirty.py','dirty.py','x = 1\n');s.getState().updateTabContent('/work/dirty.py','x = 2\n');
 const view=render(<SearchPanel files={[]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 expect(screen.getByText(/unsaved edits in 1 file not included/)).toBeInTheDocument();
 s.setState({tabs:[]});view.rerender(<SearchPanel files={[]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 expect(screen.queryByText(/unsaved edits/)).toBeNull();
});
it('skips disk edits since preview instead of replacing additional unseen matches',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});
 window.nexelAPI.readFileContent=vi.fn().mockResolvedValueOnce('VALUE = shown\n').mockResolvedValue('VALUE = shown\nVALUE = added later\n');
 const write=vi.fn(async():Promise<'written'|'conflict'>=>'written');window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/preview.py',name:'preview.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'VALUE'}});await screen.findByRole('option');
 fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));
 await screen.findByText(/Replaced 0 in 0 files.*1 skipped/);expect(write).not.toHaveBeenCalled();
});
it('refreshes after replacement without removing meaningful trailing query spaces',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});let disk='foo foo';
 window.nexelAPI.readFileContent=vi.fn(async()=>disk);window.nexelAPI.writeFileIfBaseline=vi.fn(async(_path:string,text:string):Promise<'written'|'conflict'>=>{disk=text;return 'written';});
 render(<SearchPanel files={[{path:'/work/spaces.py',name:'spaces.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'foo '}});fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'X'}});await screen.findByRole('option');
 fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));
 await screen.findByText('Replaced 1 in 1 file');await new Promise(r=>setTimeout(r,220));
 expect(screen.getByRole('combobox')).toHaveValue('foo ');expect(screen.queryByRole('option')).toBeNull();expect(disk).toBe('Xfoo');
});
it('shows the new search count rather than feedback from an earlier replacement',async()=>{
 const {useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});let disk='VALUE';window.nexelAPI.readFileContent=vi.fn(async()=>disk);window.nexelAPI.writeFileIfBaseline=vi.fn(async(_path:string,text:string):Promise<'written'|'conflict'>=>{disk=text;return 'written';});
 render(<SearchPanel files={[{path:'/work/count.py',name:'count.py'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);const query=screen.getByRole('combobox');fireEvent.change(query,{target:{value:'VALUE'}});fireEvent.change(screen.getByRole('textbox',{name:'Replace with'}),{target:{value:'NEXT NEXT'}});await screen.findByRole('option');fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));await screen.findByText('Replaced 1 in 1 file');fireEvent.change(query,{target:{value:'NEXT'}});await screen.findByText('2 matches · 1 file');expect(screen.queryByText('Replaced 1 in 1 file')).toBeNull();
});
it('composition navigation keys neither open/close search nor start replace confirmation',async()=>{
 window.nexelAPI.readFileContent=vi.fn(async()=>'VALUE');const open=vi.fn(),close=vi.fn();render(<SearchPanel files={[{path:'/work/a.txt',name:'a.txt'}]} onOpen={open} onClose={close}/>);const input=screen.getByRole('combobox');fireEvent.change(input,{target:{value:'VALUE'}});await screen.findByRole('option');
 fireEvent.keyDown(input,{key:'Enter',isComposing:true});fireEvent.keyDown(input,{key:'Escape',keyCode:229});expect(open).not.toHaveBeenCalled();expect(close).not.toHaveBeenCalled();
 fireEvent.keyDown(screen.getByRole('textbox',{name:'Replace with'}),{key:'Enter',ctrlKey:true,isComposing:true});await new Promise(r=>setTimeout(r,15));expect(screen.queryByRole('alertdialog')).toBeNull();
 fireEvent.keyDown(input,{key:'Enter'});expect(open).toHaveBeenCalledWith('/work/a.txt',1,1);
});
it('does not show an old confirmation failure over a newer query',async()=>{
 const identity=window.nexelAPI.fileIdentity;let reject!:(error:Error)=>void;
 window.nexelAPI.readFileContent=vi.fn(async()=>'VALUE OTHER');window.nexelAPI.fileIdentity=vi.fn(()=>new Promise<string>((_r,j)=>{reject=j;}));
 render(<SearchPanel files={[{path:'/work/a.txt',name:'a.txt'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);const input=screen.getByRole('combobox');fireEvent.change(input,{target:{value:'VALUE'}});await screen.findByRole('option');fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await waitFor(()=>expect(reject).toBeDefined());
 fireEvent.change(input,{target:{value:'OTHER'}});await waitFor(()=>expect(screen.getByRole('option')).toHaveTextContent('OTHER'));reject(Error('old identity failure'));await new Promise(r=>setTimeout(r,20));expect(screen.queryByText(/Cannot replace: file identity/)).toBeNull();window.nexelAPI.fileIdentity=identity;
});
it('explains unavailable replacement matching without writing or claiming a disk failure',async()=>{
 const{useEditorStore:s}=await import('../../stores/useEditorStore');s.setState({tabs:[]});let disk='foo\r\nfoo';
 class SearchWorker{onmessage:((e:{data:unknown})=>void)|null=null;onerror:null=null;constructor(){queueMicrotask(()=>this.onmessage?.({data:{ready:true}}));}terminate(){}postMessage(msg:{id:number;kind:string}){if(msg.kind==='replace')throw Error('dispatch refused');queueMicrotask(()=>this.onmessage?.({data:{id:msg.id,matches:[{line:1,col:1,length:3,text:'foo'},{line:2,col:1,length:3,text:'foo'}]}}));}}
 vi.stubGlobal('Worker',SearchWorker);window.nexelAPI.readFileContent=vi.fn(async()=>disk);const write=vi.fn(async(_path:string,text:string):Promise<'written'|'conflict'>=>{disk=text;return 'written';});window.nexelAPI.writeFileIfBaseline=write;
 render(<SearchPanel files={[{path:'/work/refusal.txt',name:'refusal.txt'}]} onOpen={vi.fn()} onClose={vi.fn()}/>);fireEvent.click(screen.getByRole('button',{name:'Regular expression'}));fireEvent.change(screen.getByRole('combobox'),{target:{value:'foo'}});await screen.findAllByRole('option');fireEvent.click(screen.getByRole('button',{name:'Replace all'}));await screen.findByRole('alertdialog');fireEvent.click(screen.getByRole('button',{name:'Replace'}));await screen.findByText(/1 left unchanged: background matching unavailable/);expect(write).not.toHaveBeenCalled();expect(disk).toBe('foo\r\nfoo');expect(screen.queryByText(/1 failed/)).toBeNull();
});

it('keeps primary code fonts ahead of the offline emoji fallback in search result text', async()=>{
 const {readFileSync}=await import('node:fs');const css=readFileSync('src/components/SearchPanel.css','utf8');const rule=css.split('}').find(rule=>/\.sf-hit code\s*\{/.test(rule));
 expect(rule).toContain("'JetBrains Mono', ui-monospace, 'Nexel Emoji', 'Apple Color Emoji', 'Segoe UI Emoji', monospace");
});
