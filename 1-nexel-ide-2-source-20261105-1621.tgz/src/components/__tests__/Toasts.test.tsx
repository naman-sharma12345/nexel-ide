import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { Toasts } from '../Toasts';
import { useStatusStore } from '../../stores/useStatusStore';
afterEach(() => { cleanup(); useStatusStore.setState({ toasts: [] }); });
it('announces failures, retains readable text and has a real dismiss button', () => {
  useStatusStore.setState({ toasts: [{ id: 1, kind: 'error', message: 'Could not save request_authentication_middleware.py' }, { id: 2, kind: 'info', message: 'Workspace refreshed' }] });
  render(<Toasts />); expect(screen.getByRole('alert')).toHaveTextContent('Could not save'); expect(screen.getByRole('status')).toHaveTextContent('Workspace refreshed');
  fireEvent.click(screen.getByRole('button', { name: 'Dismiss: Could not save request_authentication_middleware.py' })); expect(screen.queryByRole('alert')).toBeNull(); expect(screen.getByRole('status')).toBeInTheDocument();
});

it('publishes occupied lane height and clears it on unmount',()=>{let notify=()=>{};const disconnect=vi.fn();vi.stubGlobal('ResizeObserver',class{constructor(callback:()=>void){notify=callback;}observe(){}disconnect=disconnect;});vi.stubGlobal('requestAnimationFrame',(callback:FrameRequestCallback)=>{callback(0);return 0;});const view=render(<Toasts/>);notify();expect(document.documentElement.style.getPropertyValue('--nx-notification-height')).toBe('0px');view.unmount();expect(disconnect).toHaveBeenCalled();expect(document.documentElement.style.getPropertyValue('--nx-notification-height')).toBe('');vi.unstubAllGlobals();});


it('moves keyboard dismissal to the remaining notification and then its prior control',()=>{const prior=document.createElement('button');document.body.append(prior);const view=render(<Toasts/>);prior.focus();useStatusStore.setState({toasts:[{id:31,kind:'info',message:'First'},{id:32,kind:'info',message:'Second'}]});view.rerender(<Toasts/>);const first=screen.getByRole('button',{name:'Dismiss: First'});first.focus();fireEvent.click(first);expect(screen.getByRole('button',{name:'Dismiss: Second'})).toHaveFocus();fireEvent.click(document.activeElement!);expect(prior).toHaveFocus();prior.remove();});


it('returns focus when a focused notification expires but never steals moved focus',()=>{const prior=document.createElement('button');const other=document.createElement('button');document.body.append(prior,other);render(<Toasts/>);prior.focus();act(()=>{useStatusStore.setState({toasts:[{id:51,kind:'info',message:'Expires'}]});});screen.getByRole('button',{name:'Dismiss: Expires'}).focus();act(()=>{useStatusStore.getState().dismissToast(51);});expect(prior).toHaveFocus();act(()=>{useStatusStore.setState({toasts:[{id:52,kind:'info',message:'Later'}]});});screen.getByRole('button',{name:'Dismiss: Later'}).focus();other.focus();act(()=>{useStatusStore.getState().dismissToast(52);});expect(other).toHaveFocus();prior.remove();other.remove();});

it('keeps a replacement queue item focused when a burst evicts the focused oldest toast',()=>{render(<Toasts/>);act(()=>{for(let i=0;i<4;i++)useStatusStore.getState().pushToast('Queue '+i,'info',0);});screen.getByRole('button',{name:'Dismiss: Queue 0'}).focus();act(()=>{useStatusStore.getState().pushToast('Queue 4','info',0);});expect(screen.queryByRole('button',{name:'Dismiss: Queue 0'})).not.toBeInTheDocument();expect(screen.getByRole('button',{name:'Dismiss: Queue 1'})).toHaveFocus();});
it('makes long notifications keyboard readable and restores focus when that reader expires',()=>{
 const prior=document.createElement('button');document.body.append(prior);render(<Toasts/>);prior.focus();
 act(()=>{useStatusStore.setState({toasts:[{id:81,kind:'error',message:'Long failure '.repeat(50)}]});});
 const reader=screen.getByRole('region',{name:'Notification details'});expect(reader).toHaveAttribute('tabindex','0');reader.focus();
 act(()=>{useStatusStore.getState().dismissToast(81);});expect(prior).toHaveFocus();prior.remove();
});
it('bounds medium-length notification text too because narrow wrapping can exceed the compact lane',()=>{
 useStatusStore.setState({toasts:[{id:91,kind:'error',message:'Could not rename "cancelled.py": Rename or move was cancelled because its input or workspace changed.'}]});render(<Toasts/>);expect(screen.getByRole('region',{name:'Notification details'})).toHaveAttribute('data-toast-reader');expect(screen.getByRole('region',{name:'Notification details'})).toHaveAttribute('tabindex','0');
});

it('pins identity-based arrivals at capacity but respects reading, focus and dismissals',()=>{
 const {container}=render(<Toasts/>);const stack=container.querySelector('.tz-stack') as HTMLElement;
 let height=240;Object.defineProperty(stack,'scrollHeight',{get:()=>height});Object.defineProperty(stack,'clientHeight',{value:96});
 const set=(ids:number[])=>act(()=>{useStatusStore.setState({toasts:ids.map(id=>({id,kind:'info',message:'Item '+id}))});});
 set([101,102,103,104]);expect(stack.scrollTop).toBe(240);
 // At capacity a newly identified arrival must still scroll.
 height=280;set([102,103,104,105]);expect(stack.scrollTop).toBe(280);
 stack.scrollTop=0;fireEvent.scroll(stack);set([103,104,105,106]);expect(stack.scrollTop).toBe(0);
 set([103,104,105]);expect(stack.scrollTop).toBe(0);
 stack.scrollTop=184;fireEvent.scroll(stack);
 screen.getByRole('button',{name:'Dismiss: Item 104'}).focus();
 height=320;set([103,104,105,107]);expect(stack.scrollTop).toBe(184);expect(screen.getByRole('button',{name:'Dismiss: Item 104'})).toHaveFocus();
 // Emptying the lane resets stale scroll intent for the next burst.
 set([]);set([108]);expect(stack.scrollTop).toBe(320);
});

it('keeps the existing sans fonts before offline emoji fallback for Git filenames and notification text', async()=>{
 const {readFileSync}=await import('node:fs');const css=readFileSync('src/styles/original-glass.css','utf8');
 const rule=css.split('}').find(rule=>rule.includes('.nx-git-file-name, .tz-toast > span[data-toast-reader]'));
 expect(rule).toContain("font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Nexel Emoji','Apple Color Emoji','Segoe UI Emoji',sans-serif");
});
