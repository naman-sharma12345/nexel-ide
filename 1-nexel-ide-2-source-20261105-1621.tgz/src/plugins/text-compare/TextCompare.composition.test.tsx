import {render,screen,fireEvent,cleanup,act} from '@testing-library/react';
import {it,expect,afterEach} from 'vitest';
import TextCompare from './TextCompare';
import {useEditorStore} from '../../stores/useEditorStore';
afterEach(cleanup);
it('does not compare or navigate during composing CtrlEnter or arrow keys',()=>{
 render(<TextCompare/>);const input=screen.getByRole('textbox',{name:'After text'});fireEvent.change(input,{target:{value:'नाम'}});fireEvent.keyDown(input,{key:'Enter',ctrlKey:true,isComposing:true});expect(screen.getByRole('textbox',{name:'After text'})).toHaveValue('नाम');
 fireEvent.keyDown(screen.getByRole('tab',{name:'Inputs'}),{key:'ArrowRight',keyCode:229});expect(screen.getByRole('tab',{name:'Inputs'})).toHaveAttribute('aria-selected','true');
 fireEvent.keyDown(input,{key:'Enter',ctrlKey:true});expect(screen.queryByRole('textbox',{name:'After text'})).toBeNull();expect(screen.getByRole('tab',{name:'Changes'})).toHaveAttribute('aria-selected','true');
});

it('makes retained carriage returns visible without changing exact comparison',()=>{
 useEditorStore.setState({tabs:[],activeTabPath:null});
 useEditorStore.getState().openFile('/before.txt','before.txt','same\r\n');
 render(<TextCompare/>);
 fireEvent.click(screen.getByRole('tab',{name:'Inputs'}));
 fireEvent.click(screen.getByRole('button',{name:'Load focused file into Before'}));
 act(()=>useEditorStore.getState().openFile('/after.txt','after.txt','same\n'));
 fireEvent.click(screen.getByRole('button',{name:'Load focused file into After'}));
 fireEvent.click(screen.getByRole('button',{name:'Compare'}));
 expect(screen.getByText('+1 added')).toBeInTheDocument();
 expect(screen.getByText('-1 removed')).toBeInTheDocument();
 expect(screen.getByLabelText('Carriage return')).toHaveTextContent('CR');
 expect(screen.getByText('CR marks a carriage return; line endings are compared exactly.')).toBeInTheDocument();
 expect(useEditorStore.getState().tabs.find(t=>t.filePath==='/before.txt')?.content).toBe('same\r\n');
});
