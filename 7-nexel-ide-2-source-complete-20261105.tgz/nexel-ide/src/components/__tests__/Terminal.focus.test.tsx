import{render,cleanup,act} from '@testing-library/react';
import{afterEach,it,expect,vi} from 'vitest';
const mocks=vi.hoisted(()=>({focusCount:0}));
vi.mock('xterm',()=>({Terminal:class{options={};cols=80;rows=20;loadAddon(){}attachCustomKeyEventHandler(){}open(){}focus(){mocks.focusCount++;}onData(){return{dispose(){}};}write(_t:string,cb?:()=>void){cb?.();}reset(){}dispose(){}}}));
vi.mock('xterm-addon-fit',()=>({FitAddon:class{fit(){}}}));
import {Terminal} from '../Terminal';
afterEach(()=>{cleanup();vi.restoreAllMocks();mocks.focusCount=0;});
function boot(){vi.stubGlobal('ResizeObserver',class{observe(){}disconnect(){}});window.nexelAPI={createTerminal:async()=>true,onTerminalData:()=>()=>{},resizeTerminal:vi.fn(),writeTerminal:vi.fn()} as any;}
async function ready(){await act(async()=>{await Promise.resolve();await Promise.resolve();});}

it('focuses the shell on the first deliberate open so typed input reaches it',async()=>{
 boot();
 const view=render(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(mocks.focusCount).toBe(0);
 view.rerender(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(mocks.focusCount).toBe(1);
 view.unmount();
});

it('does not steal focus when the panel was restored visible at startup',async()=>{
 boot();
 render(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(mocks.focusCount).toBe(0);
});

it('refocuses the shell each time the panel is reopened',async()=>{
 boot();
 const view=render(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 view.rerender(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 view.rerender(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 view.rerender(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(mocks.focusCount).toBe(2); // first open + reopen
 view.unmount();
});

it('hiding the panel while focus is inside moves focus to the status-bar toggle (hidden xterm must not swallow keys)',async()=>{
 boot();
 const toggle=document.createElement('button');toggle.className='sb-terminal-toggle';document.body.append(toggle);
 const view=render(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 view.rerender(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 // put focus on a real element inside the panel (the mocked xterm has no DOM focus)
 const inside=view.container.querySelector('button') as HTMLElement;inside.focus();
 expect(view.container.contains(document.activeElement)).toBe(true);
 view.rerender(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(document.activeElement).toBe(toggle);
 toggle.remove();view.unmount();
});

it('hiding the panel while focus is elsewhere leaves focus alone',async()=>{
 boot();
 const elsewhere=document.createElement('button');document.body.append(elsewhere);
 const view=render(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 view.rerender(<Terminal visible={true} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 elsewhere.focus();
 view.rerender(<Terminal visible={false} onClose={()=>{}} sidebarCollapsed={false}/>);
 await ready();
 expect(document.activeElement).toBe(elsewhere);
 elsewhere.remove();view.unmount();
});
