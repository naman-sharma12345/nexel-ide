import { normalizeJudgeOutput } from '../../lib/judgeOutput';
import { spawn } from 'child_process';
import * as path from 'path';
import * as fs from 'fs/promises';
import * as os from 'os';
import { fetchContestProblems, type PageLoader } from './cfProblems';
import { LocalSandboxExecutor } from '../../judge-backend/LocalSandboxExecutor';

export interface TestCase {
  id: number;
  input: string;
  expected: string;
}

export interface JudgeResult {
  id: number;
  verdict: 'AC' | 'WA' | 'TLE' | 'MLE' | 'RE' | 'CE' | 'CANCELLED';
  metrics: { time: number; memory: number; memoryMeasured?: boolean; exitCode: number | null };
  actual: string;
  diff: string;
  expected?: string;
  passed?: boolean;
}

export interface Contest {
  id: number;
  name: string;
  type: string;
  phase: string;
  frozen: boolean;
  durationSeconds: number;
  startTimeSeconds: number;
  relativeTimeSeconds: number;
}

export interface ContestsData {
  active: Contest[];
  upcoming: Contest[];
  passed: Contest[];
}

/**
 * JSDoc:
 * Orchestration service for compiling programs and running them via a Sandbox Executor.
 * 
 * To migrate to Docker/WebAssembly, create a new class implementing ISandboxExecutor,
 * inject/swap it in place of LocalSandboxExecutor here. No other changes required.
 */
export class JudgeService {
  private baseTempDir = path.join(os.tmpdir(), 'nexel-judge');

  private async createIsolatedWorkspace(): Promise<string> {
    const workspaceId = `run_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const workspaceDir = path.join(this.baseTempDir, workspaceId);
    await fs.mkdir(workspaceDir, { recursive: true });
    return workspaceDir;
  }

  private async cleanupWorkspace(dir: string): Promise<void> {
    try {
      await fs.rm(dir, { recursive: true, force: true });
    } catch (e) {
      console.warn(`Warning: failed to clean up judge workspace at ${dir}:`, e);
    }
  }

  private compile(command: string, args: string[], compileTimeout: number): Promise<void> {
    return new Promise((resolve, reject) => {
      const compiler = spawn(command, args, { detached: process.platform !== 'win32', stdio: ['ignore', 'ignore', 'pipe'] });
      let diagnostics = '', finished = false;
      const finish = (error?: Error) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        if (error) reject(error); else resolve();
      };
      const timer = setTimeout(() => {
        // Compilers can spawn assembler/linker children. Kill the group on Unix,
        // rather than leaving those children running after the timeout.
        try {
          if (process.platform !== 'win32' && compiler.pid) process.kill(-compiler.pid, 'SIGKILL');
          else compiler.kill('SIGKILL');
        } catch { try { compiler.kill('SIGKILL'); } catch { /* already exited */ } }
        finish(new Error(`Compilation timed out after ${compileTimeout}ms`));
      }, compileTimeout);
      compiler.stderr?.on('data', data => {
        // Bound diagnostics so a noisy compiler cannot fill the main process.
        if (diagnostics.length < 256 * 1024) diagnostics += data.toString().slice(0, 256 * 1024 - diagnostics.length);
      });
      compiler.on('error', error => finish(new Error(`Could not start ${command}: ${error.message}`)));
      compiler.on('close', code => finish(code === 0 ? undefined : new Error(diagnostics || `Compilation failed with exit code ${code}`)));
    });
  }

  private compileCpp(src: string, dest: string, compileTimeout: number): Promise<void> {
    return this.compile('g++', ['-std=c++17', src, '-o', dest], compileTimeout);
  }

  private compileJava(src: string, destDir: string, compileTimeout: number): Promise<void> {
    return this.compile('javac', ['-d', destDir, src], compileTimeout);
  }

  private activeRun: { runId: string; controller: AbortController } | null = null;

  /** Cancel the in-flight run. Only the current runId can cancel; stale ids are ignored. */
  cancel(runId: string): void {
    if (this.activeRun?.runId === runId) this.activeRun.controller.abort();
  }

  async run(filePath: string, testCases: TestCase[], timeLimit: number, memoryLimit: number, runId?: string): Promise<JudgeResult[]> {
    const controller = new AbortController();
    if (runId) this.activeRun = { runId, controller };
    const isWin = process.platform === 'win32';
    const ext = path.extname(filePath);
    const baseName = path.basename(filePath, ext);

    let executablePath = filePath;
    let runClassName = baseName;
    let compileError: string | null = null;
    let workspaceDir: string | null = null;

    // Phase 1: Compilation Phase. No compiled-binary reuse: the true compile
    // input set (headers, toolchain identity, macro-expanded includes,
    // __DATE__/__TIME__/__FILE__ semantics, classpath) cannot be established
    // cheaply enough for a cache key, so every run compiles fresh.
    workspaceDir = await this.createIsolatedWorkspace();
    try {
      if (ext === '.cpp' || ext === '.cc') {
        const outBinName = isWin ? `${baseName}.exe` : baseName;
        const outExe = path.join(workspaceDir, outBinName);
        await this.compileCpp(filePath, outExe, 15000);
        executablePath = outExe;
      } else if (ext === '.java') {
        try {
          const content = await fs.readFile(filePath, 'utf8');
          const classMatch = content.match(/public\s+class\s+(\w+)/);
          if (classMatch) runClassName = classMatch[1];
        } catch (e) {}
        const copiedJavaFile = path.join(workspaceDir, `${runClassName}.java`);
        await fs.copyFile(filePath, copiedJavaFile);
        await this.compileJava(copiedJavaFile, workspaceDir, 15000);
        executablePath = workspaceDir;
      }
    } catch (err: any) {
      compileError = err.message || String(err);
    }

    if (compileError) {
      if (workspaceDir) await this.cleanupWorkspace(workspaceDir);
      return testCases.map(tc => ({
        id: tc.id,
        verdict: 'CE',
        metrics: { time: 0, memory: 0.1, exitCode: 1 },
        actual: compileError || '',
        diff: `Compilation Error:\n${compileError}`
      }));
    }

    // Phase 2: Execution Phase via Sandbox
    const sandbox = new LocalSandboxExecutor();
    const results: JudgeResult[] = [];

    for (const tc of testCases) {
      if (controller.signal.aborted) {
        results.push({ id: tc.id, verdict: 'CANCELLED', metrics: { time: 0, memory: 0, memoryMeasured: false, exitCode: null }, actual: '', diff: 'Canceled by user', expected: tc.expected, passed: false });
        continue;
      }
      const sandboxRes = await sandbox.execute({
        executablePath,
        extension: ext,
        javaClassName: runClassName,
        input: tc.input,
        timeLimitMs: timeLimit,
        memoryLimitMb: memoryLimit,
        signal: controller.signal
      });

      const normalizedActual = normalizeJudgeOutput(sandboxRes.stdout);
      const normalizedExpected = normalizeJudgeOutput(tc.expected);
      const passed = sandboxRes.verdict === 'AC' && normalizedActual === normalizedExpected;

      results.push({
        id: tc.id,
        verdict: passed ? 'AC' : (sandboxRes.verdict === 'AC' ? 'WA' : sandboxRes.verdict),
        metrics: {
          time: sandboxRes.timeMs,
          memory: sandboxRes.memoryMb,
          memoryMeasured: sandboxRes.memoryMeasured === true,
          exitCode: sandboxRes.exitCode ?? 1
        },
        actual: sandboxRes.stdout,
        diff: sandboxRes.stderr || (passed ? '' : `Expected:\n${tc.expected}\n\nActual:\n${sandboxRes.stdout}`),
        expected: tc.expected,
        passed
      });
    }

    // Clean up the temporary workspace.
    if (workspaceDir) await this.cleanupWorkspace(workspaceDir);
    if (runId && this.activeRun?.runId === runId) this.activeRun = null;
    return results;
  }

  private contestsCache: { at: number; data: ContestsData } | null = null;

  async fetchContests(): Promise<ContestsData> {
    // TTL cache (5 min) avoids hammering the API; stale data served if network fails.
    if (this.contestsCache && Date.now() - this.contestsCache.at < 300_000) return this.contestsCache.data;
    try {
      let response: Response | undefined;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const ctl = new AbortController();
          const timer = setTimeout(() => ctl.abort(), 8000);
          try {
            response = await fetch('https://codeforces.com/api/contest.list?gym=false', { signal: ctl.signal });
          } finally { clearTimeout(timer); }
          if (response.ok) break;
        } catch (e) {
          if (attempt === 2) throw e;
        }
        await new Promise((r) => setTimeout(r, 400 * 2 ** attempt)); // exponential backoff
      }
      if (!response || !response.ok) {
        throw new Error(`HTTP error! status: ${response?.status}`);
      }
      const data = (await response.json()) as { status: string; comment?: string; result: Contest[] };
      if (data.status !== 'OK') {
        throw new Error(`API error: ${data.comment || 'Unknown error'}`);
      }
      const contests = data.result;
      const active = contests.filter((c: Contest) => c.phase === 'CODING');
      const passed = contests
        .filter((c: Contest) => c.phase === 'FINISHED')
        .sort((a: Contest, b: Contest) => b.startTimeSeconds - a.startTimeSeconds)
        .slice(0, 2);
      const upcomingCount = active.length > 0 ? 2 : 3;
      const upcoming = contests
        .filter((c: Contest) => c.phase === 'BEFORE')
        .sort((a: Contest, b: Contest) => a.startTimeSeconds - b.startTimeSeconds)
        .slice(0, upcomingCount);

      const result = { active, upcoming, passed };
      this.contestsCache = { at: Date.now(), data: result };
      return result;
    } catch (err) {
      console.error("Failed to fetch contests in main process:", err);
      if (this.contestsCache) return this.contestsCache.data;
      throw err;
    }
  }

  private pageLoader?: PageLoader;
  /** Real-browser page loader (Electron) used when Codeforces' Cloudflare blocks plain HTTP. */
  setPageLoader(loader: PageLoader) { this.pageLoader = loader; }

  async fetchProblems(contestId: number): Promise<unknown> {
    return fetchContestProblems(contestId, undefined, undefined, this.pageLoader);
  }
}
