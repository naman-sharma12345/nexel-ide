// @vitest-environment node
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { spawn } from 'child_process';
import * as fs from 'fs/promises';
import { JudgeService } from '../JudgeService';
import { EventEmitter } from 'events';

// Mock child_process partially
vi.mock('child_process', async (importOriginal) => {
  const original = await importOriginal<typeof import('child_process')>();
  return {
    ...original,
    spawn: vi.fn(),
  };
});

// Mock fs/promises partially
vi.mock('fs/promises', async (importOriginal) => {
  const original = await importOriginal<typeof import('fs/promises')>();
  return {
    ...original,
    mkdir: vi.fn().mockResolvedValue(undefined),
    rm: vi.fn().mockResolvedValue(undefined),
    // The compile-cache key read must not hit real I/O under fake timers;
    // rejecting makes runs fall through to the uncached path these tests drive.
    readFile: vi.fn().mockRejectedValue(Object.assign(new Error('ENOENT'), { code: 'ENOENT' })),
  };
});

interface MockSpawnProcess extends EventEmitter {
  stderr: EventEmitter;
  kill: ReturnType<typeof vi.fn>;
}

describe('JudgeService compilation isolation', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.restoreAllMocks();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('proves compilation hangs are aborted via SIGKILL and temporary workspaces are cleaned up (Test A)', async () => {
    const mockSpawn = spawn as unknown as ReturnType<typeof vi.fn>;
    const mockRm = fs.rm as unknown as ReturnType<typeof vi.fn>;

    const gppMock = new EventEmitter() as unknown as MockSpawnProcess;
    gppMock.stderr = new EventEmitter();
    gppMock.kill = vi.fn();

    mockSpawn.mockReturnValue(gppMock);

    const judgeService = new JudgeService();

    const testCases = [
      { id: 1, input: '1\n', expected: '2\n' },
      { id: 2, input: '2\n', expected: '4\n' }
    ];

    const runPromise = judgeService.run('C:/user/project/solution.cpp', testCases, 2000, 256);

    // Advance timers past the 15,000ms compilation timeout limit
    await vi.advanceTimersByTimeAsync(16000);

    const results = await runPromise;

    // Verify compilation process was aggressively killed
    expect(gppMock.kill).toHaveBeenCalledWith('SIGKILL');

    // Verify compilation failures are not labeled runtime errors
    expect(results.length).toBe(2);
    expect(results[0].verdict).toBe('CE');
    expect(results[0].diff).toContain('Compilation timed out');
    expect(results[1].verdict).toBe('CE');

    // Verify the temporary workspace folder was deleted to prevent disk leaks
    expect(mockRm).toHaveBeenCalledWith(
      expect.stringContaining('run_'),
      expect.objectContaining({ recursive: true, force: true })
    );
  });
  it('returns a compiler-start error and cleans the workspace without waiting for timeout', async () => {
    const child = new EventEmitter() as unknown as MockSpawnProcess;
    child.stderr = new EventEmitter(); child.kill = vi.fn();
    (spawn as unknown as ReturnType<typeof vi.fn>).mockReturnValue(child);
    const promise = new JudgeService().run('/work/main.cpp', [{id:1,input:'',expected:''}], 2000,256);
    await vi.advanceTimersByTimeAsync(0);
    child.emit('error', new Error('spawn g++ ENOENT'));
    child.emit('close', -2);
    const result = await promise;
    expect(result[0].verdict).toBe('CE');
    expect(result[0].diff).toContain('Could not start g++: spawn g++ ENOENT');
    expect(fs.rm).toHaveBeenCalledWith(expect.stringContaining('run_'),expect.objectContaining({recursive:true,force:true}));
    expect(vi.getTimerCount()).toBe(0);
  });

});

describe('JudgeService cancel scoping', () => {
  it('cancel with an unknown or finished runId is a no-op and never throws', () => {
    const svc = new JudgeService();
    expect(() => svc.cancel('run-never-started')).not.toThrow();
    expect(() => svc.cancel('')).not.toThrow();
  });
});
