// Disposable native input probe: select the supported pipe fallback only.
const Module=require('module'),original=Module._load;
Module._load=function(name){if(name==='node-pty')throw Error('fixture pipe fallback');return original.apply(this,arguments);};
