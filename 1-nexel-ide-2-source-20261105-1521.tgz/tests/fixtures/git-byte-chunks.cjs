// Disposable transport probe. Real git runs; split its stream at every byte.
const cp=require('child_process'),original=cp.spawn;
cp.spawn=function(command,...args){
 const child=original.call(this,command,...args);
 if(command==='git')for(const stream of [child.stdout,child.stderr])if(stream){
  const emit=stream.emit;
  stream.emit=function(event,data,...rest){
   if(event==='data'&&Buffer.isBuffer(data)){for(const byte of data)emit.call(this,event,Buffer.from([byte]),...rest);return true;}
   return emit.call(this,event,data,...rest);
  };
 }
 return child;
};
