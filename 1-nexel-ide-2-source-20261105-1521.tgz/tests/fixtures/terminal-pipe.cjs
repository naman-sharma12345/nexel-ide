const Module=require('module'),original=Module._load,cp=require('child_process'),spawn=cp.spawn;let first=true;
cp.spawn=function(command,args,opts){if(command==='bash'&&first){first=false;return spawn.call(this,'/nonexistent/nexel-shell-fixture',args,opts);}return spawn.apply(this,arguments);};
Module._load=function(name){if(name==='node-pty')throw Error('fixture pipe fallback');return original.apply(this,arguments);};
