const { contextBridge, ipcRenderer, clipboard } = require('electron');

// Expose safe system APIs to the React frontend
contextBridge.exposeInMainWorld('nexelAPI', {
  // Window controls for a custom title bar
  minimizeWindow: () => ipcRenderer.send('window-control', 'minimize'),
  maximizeWindow: () => ipcRenderer.send('window-control', 'maximize'),
  closeWindow: () => ipcRenderer.send('window-control', 'close'),

  // App-close guard: main intercepts window close; the renderer confirms when no unsaved tabs remain.
  onAppCloseRequested: (callback) => { ipcRenderer.removeAllListeners('app:close-requested'); ipcRenderer.on('app:close-requested', () => callback()); },
  confirmAppClose: () => ipcRenderer.send('app:confirm-close'),

  // Text-only clipboard operations for explicit editor menu commands.
  readClipboardText: () => clipboard.readText(),
  writeClipboardText: (text) => { if (typeof text !== 'string') throw new TypeError('Clipboard text required'); clipboard.writeText(text); },

  // Workspace File System triggers
  openWorkspaceDir: () => ipcRenderer.invoke('fs:open-dir'),
  readWorkspaceFiles: (dirPath) => ipcRenderer.invoke('fs:read-files', dirPath),
  createFile: (parentPath, fileName) => ipcRenderer.invoke('fs:create-file', parentPath, fileName),
  createFolder: (parentPath, folderName) => ipcRenderer.invoke('fs:create-folder', parentPath, folderName),
  renameNode: (oldPath, newPath) => ipcRenderer.invoke('fs:rename', oldPath, newPath),
  deleteNode: (targetPath) => ipcRenderer.invoke('fs:delete', targetPath),
  readFileContent: (filePath) => ipcRenderer.invoke('fs:read-file-content', filePath),
  fileIdentity: (filePath) => ipcRenderer.invoke('fs:file-identity', filePath),
  realPath: (filePath) => ipcRenderer.invoke('fs:realpath', filePath),
  writeFileContent: (filePath, content) => ipcRenderer.invoke('fs:write-file-content', filePath, content),
  writeFileIfBaseline: (filePath, content, baseline) => ipcRenderer.invoke('fs:write-file-if-baseline', filePath, content, baseline),

  // clangd bridge (main validates every message)
  lspStart: (root, opts) => ipcRenderer.invoke('lsp:start', root, opts),
  lspSend: (msg) => ipcRenderer.invoke('lsp:send', msg),
  lspRestart: () => ipcRenderer.invoke('lsp:restart'),
  lspStop: () => ipcRenderer.invoke('lsp:stop'),
  onLspMessage: (cb) => { ipcRenderer.removeAllListeners('lsp:message'); ipcRenderer.on('lsp:message', (e, m) => cb(m)); },
  onLspStatus: (cb) => { ipcRenderer.removeAllListeners('lsp:status'); ipcRenderer.on('lsp:status', (e, s) => cb(s)); },

  // Terminal PTY integration
  createTerminal: (cwd) => ipcRenderer.invoke('terminal:create', cwd),
  writeTerminal: (data) => ipcRenderer.send('terminal:write', data),
  resizeTerminal: (cols, rows) => ipcRenderer.send('terminal:resize', cols, rows),
  onTerminalData: (callback) => {
    // Clear previous listeners to avoid double listener leaks
    ipcRenderer.removeAllListeners('terminal:data');
    const listener = (_event, data) => callback(data);
    ipcRenderer.on('terminal:data', listener);
    return () => ipcRenderer.removeListener('terminal:data', listener);
  },

  // Competitive Programming Judge Integration
  runJudge: (filePath, testCases, timeLimit, memoryLimit, runId) => 
    ipcRenderer.invoke('judge:run', filePath, testCases, timeLimit, memoryLimit, runId),
  cancelJudge: (runId) => ipcRenderer.invoke('judge:cancel', runId),
  fetchContests: (workspaceDir) =>
    ipcRenderer.invoke('judge:fetch-contests', workspaceDir),
  fetchContestProblems: (contestId) =>
    ipcRenderer.invoke('judge:fetch-problems', contestId),
  // Opens a Codeforces window (persistent session) to sign in, register, or pass a Cloudflare check.
  openCodeforcesSession: (url) =>
    ipcRenderer.invoke('cf:open-session', url),

  // Git integration (Source Control panel). Every action runs only on explicit user click.
  gitStatus: (root) => ipcRenderer.invoke('git:status', root),
  gitInit: (root) => ipcRenderer.invoke('git:init', root),
  gitStage: (root, paths) => ipcRenderer.invoke('git:stage', root, paths),
  gitUnstage: (root, paths) => ipcRenderer.invoke('git:unstage', root, paths),
  gitCommit: (root, message) => ipcRenderer.invoke('git:commit', root, message),
  gitBranches: (root) => ipcRenderer.invoke('git:branches', root),
  gitDiff: (root, path, staged, origPath) => ipcRenderer.invoke('git:diff', root, path, staged, origPath),
  gitSwitch: (root, branch) => ipcRenderer.invoke('git:switch', root, branch),
  gitFetch: (root) => ipcRenderer.invoke('git:fetch', root),
  gitPull: (root) => ipcRenderer.invoke('git:pull', root),
  gitLog: (root, limit) => ipcRenderer.invoke('git:log', root, limit),
  gitPush: (root) => ipcRenderer.invoke('git:push', root),
  gitRemotes: (root) => ipcRenderer.invoke('git:remotes', root),
  gitPublish: (root, remote, branch) => ipcRenderer.invoke('git:publish', root, remote, branch),
  gitCreateBranch: (root, name) => ipcRenderer.invoke('git:create-branch', root, name),
  gitWatch: (root) => ipcRenderer.invoke('git:watch', root),
  onGitExternalChange: (cb) => {
    const l = (_e, root) => cb(root);
    ipcRenderer.on('git:externally-changed', l);
    return () => ipcRenderer.removeListener('git:externally-changed', l);
  },

  // Competitive Companion (browser extension -> IDE). Callback receives an already-validated problem.
  onCompanionProblem: (callback) => {
    ipcRenderer.removeAllListeners('companion:problem');
    const listener = (_event, problem) => callback(problem);
    ipcRenderer.on('companion:problem', listener);
    return () => ipcRenderer.removeListener('companion:problem', listener);
  },

  // Secure Electron Store bindings
  getStoreSync: (key) => ipcRenderer.sendSync('store:get-sync', key),
  setStoreSync: (key, value) => ipcRenderer.sendSync('store:set-sync', key, value),
  deleteStoreSync: (key) => ipcRenderer.sendSync('store:delete-sync', key)
});
