import '@testing-library/jest-dom';
import './src/__mocks__/setup';

// jsdom gaps hit by the full-shell smoke test
if (typeof document !== 'undefined' && !document.queryCommandSupported) {
  (document as any).queryCommandSupported = () => false;
}
if (typeof document !== 'undefined' && !document.execCommand) {
  (document as any).execCommand = () => false;
}

// jsdom has no matchMedia; real monaco standalone services (pulled in via
// monacoSetup when the shell renders with tabs) construct StandaloneThemeService
// on a timer and throw asynchronously without it.
if (typeof window !== 'undefined' && typeof window.matchMedia !== 'function') {
  (window as any).matchMedia = (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addEventListener() {},
    removeEventListener() {},
    addListener() {},
    removeListener() {},
    dispatchEvent: () => false,
  });
}
