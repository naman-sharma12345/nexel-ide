import { spawn, exec, execSync } from 'child_process';
import { StringDecoder } from 'string_decoder';
import * as path from 'path';
import * as fs from 'fs';
import { sampleProcessGroupRss } from './processMemory';
import type { ISandboxExecutor, SandboxConfig, SandboxResult } from './SandboxExecutor';

/**
 * JSDoc:
 * Robust Sandbox Executor implementing ISandboxExecutor.
 * 
 * Security Boundaries:
 * - On Unix/Linux: Executes binaries inside a Bubblewrap (bwrap) sandbox, unsharing namespaces
 *   (IPC, Network, PID, UTS, Mount) to isolate the runtime. It bind-mounts necessary system library paths
 *   (/usr, /lib, /lib64, /bin) and the source directory as Read-Only. Process execution drops privileges
 *   to uid/gid 1000. Falls back to ulimit + SIGKILL process group teardown if bwrap is missing.
 * - On Windows: Attempts to restrict child processes using Windows Job Objects via win32-job if installed.
 *   Enforces strict memory checks and kills the process tree recursively using taskkill & WMIC query loops.
 * - Under all platforms: Strictly enforces a 5MB standard output capping to prevent disk/memory bloating.
 */
/**
 * Builds argv for `sh` that applies POSIX resource limits (the setrlimit(2) family) then execs the target:
 *  -v address space, -t CPU seconds, -u max processes (fork-bomb guard), -f max written file size, -c no core dumps.
 * User-controlled values only appear as positional parameters ($1, $2...), which the shell never re-parses.
 */
export function buildUlimitFallback(
  config: Pick<SandboxConfig, 'extension' | 'executablePath' | 'javaClassName'>,
  memoryLimitKb: number,
  timeLimitSec: number
): string[] {
  const kb = Math.max(1, Math.floor(Number(memoryLimitKb)) || 262144);
  const sec = Math.max(1, Math.floor(Number(timeLimitSec)) || 1);
  // Java reserves a huge virtual address range, so -v would kill the JVM at startup; cap CPU/procs instead.
  const vLimit = config.extension === '.java' ? '' : `ulimit -v ${kb} 2>/dev/null; `;
  const limits = `${vLimit}ulimit -t ${sec} 2>/dev/null; ulimit -u 256 2>/dev/null; ulimit -f 65536 2>/dev/null; ulimit -c 0 2>/dev/null; `;
  if (config.extension === '.py') return ['-c', `${limits}exec python3 "$1"`, 'nexel-sandbox', config.executablePath];
  if (config.extension === '.java' && config.javaClassName)
    return ['-c', `${limits}exec java -cp "$1" "$2"`, 'nexel-sandbox', config.executablePath, config.javaClassName];
  return ['-c', `${limits}exec "$1"`, 'nexel-sandbox', config.executablePath];
}

export class LocalSandboxExecutor implements ISandboxExecutor {
  private hasBwrap: boolean | null = null;

  private checkBwrapAvailability(): boolean {
    if (this.hasBwrap !== null) return this.hasBwrap;
    try {
      execSync(process.platform === 'win32' ? 'where bwrap' : 'which bwrap', { stdio: 'ignore' });
      this.hasBwrap = true;
    } catch {
      this.hasBwrap = false;
      if (process.platform !== 'win32') {
        console.warn("\x1b[33m%s\x1b[0m", "SECURITY WARNING: Bubblewrap (bwrap) was not found on this system.");
        console.warn("\x1b[33m%s\x1b[0m", "Production judge environments must install 'bwrap' for secure execution sandboxing.");
        console.warn("\x1b[33m%s\x1b[0m", "Falling back to basic ulimit constraints.");
      }
    }
    return this.hasBwrap;
  }

  async execute(config: SandboxConfig): Promise<SandboxResult> {
    return new Promise((resolve) => {
      const isWin = process.platform === 'win32';
      const startTime = process.hrtime();
      const timeLimitSec = Math.ceil(config.timeLimitMs / 1000);
      const memoryLimitKb = config.memoryLimitMb * 1024;
      const maxOutputBytes = 5 * 1024 * 1024; // 5MB Limit

      // Sandbox environment lockdown - only permit basic PATH
      const sanitizedEnv = {
        PATH: process.env.PATH || '',
      };

      const spawnOpts = {
        detached: !isWin, // Detach process group on Unix for process-tree killing
        stdio: 'pipe' as const,
        env: sanitizedEnv,
      };

      let child: any;
      let memoryTimer: any = null;

      // Select execution environment
      if (isWin) {
        if (config.extension === '.py') {
          child = spawn('python', [config.executablePath], spawnOpts);
        } else if (config.extension === '.java' && config.javaClassName) {
          child = spawn('java', ['-cp', config.executablePath, config.javaClassName], spawnOpts);
        } else {
          child = spawn(config.executablePath, [], spawnOpts);
        }

        // Apply Windows Job Object limits dynamically if win32-job is available
        try {
          // eslint-disable-next-line @typescript-eslint/no-require-imports
          const win32Job = require('win32-job');
          if (win32Job && win32Job.JobObject && child.pid) {
            const job = new win32Job.JobObject();
            job.setLimits({
              limitFlags: win32Job.JobObject.LIMIT_PROCESS_MEMORY,
              maxProcessMemory: config.memoryLimitMb * 1024 * 1024
            });
            job.associate(child.pid);
          }
        } catch {
          // Fall back gracefully to tasklist monitoring and process-tree killer
        }
      } else {
        // Unix execution path
        const parentDir = path.dirname(config.executablePath);
        const hasBwrap = this.checkBwrapAvailability();

        if (hasBwrap) {
          // Build secure Bubblewrap arguments
          const bwrapArgs: string[] = [
            '--unshare-all',
            '--ro-bind', '/usr', '/usr',
            '--ro-bind', '/lib', '/lib',
            '--proc', '/proc',
            '--dev', '/dev',
            '--ro-bind', parentDir, parentDir,
            '--chdir', parentDir,
            '--uid', '1000',
            '--gid', '1000'
          ];

          // Mount architecture-specific lib directories if present on system
          if (fs.existsSync('/lib64')) {
            bwrapArgs.push('--ro-bind', '/lib64', '/lib64');
          }
          if (fs.existsSync('/bin')) {
            bwrapArgs.push('--ro-bind', '/bin', '/bin');
          }

          // Bubblewrap isolates namespaces, but has no --timeout option. Apply
          // resource limits inside the sandbox, with the outer wall timer still
          // responsible for killing the entire detached process group.
          bwrapArgs.push('--', 'sh', ...buildUlimitFallback(config, memoryLimitKb, timeLimitSec));

          child = spawn('bwrap', bwrapArgs, spawnOpts);
        } else {
          // Fallback to ulimit constraints. Paths travel as positional args ("$@"), never interpolated
          // into the shell string, so a file name containing quotes or $() cannot inject commands.
          const fb = buildUlimitFallback(config, memoryLimitKb, timeLimitSec);
          child = spawn('sh', fb, spawnOpts);
        }
      }

      let stdout = '';
      let stderr = '';
      const stdoutDecoder = new StringDecoder('utf8');
      const stderrDecoder = new StringDecoder('utf8');
      let outputFlushed = false;
      const flushOutput = () => {
        if (outputFlushed) return;
        outputFlushed = true;
        stdout += stdoutDecoder.end();
        stderr += stderrDecoder.end();
      };
      let isFinished = false;
      let peakMemoryMb = 0;
      let memoryMeasured = false;
      let samplingMemory = false;
      let totalOutputSize = 0;

      // Pipe inputs
      if (child.stdin) {
        if (typeof child.stdin.on === 'function') child.stdin.on('error', () => { /* EPIPE: program exited before reading all input */ });
        child.stdin.write(config.input || '');
        child.stdin.end();
      }

      // Safe Windows process tree termination helper
      const killWindowsProcessTree = (parentPid: number) => {
        try {
          spawn('taskkill', ['/F', '/T', '/PID', parentPid.toString()]);
        } catch {}

        const queryCmd = `wmic process where "ParentProcessId=${parentPid}" get ProcessId /format:list`;
        exec(queryCmd, (err, stdoutStr) => {
          if (err || !stdoutStr) {
            // Fall back to PowerShell query since wmic is deprecated/disabled on modern Windows 11
            const psQueryCmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"ParentProcessId = ${parentPid}\\" | Select-Object -ExpandProperty ProcessId"`;
            exec(psQueryCmd, (psErr, psStdoutStr) => {
              if (psErr || !psStdoutStr) return;
              const childPids = psStdoutStr
                .split(/\r?\n/)
                .map(line => parseInt(line.trim(), 10))
                .filter(pid => !isNaN(pid));

              for (const pid of childPids) {
                killWindowsProcessTree(pid);
              }
            });
            return;
          }

          const childPids = stdoutStr
            .split(/\r?\n/)
            .map(line => line.match(/ProcessId=(\d+)/))
            .filter((m): m is RegExpMatchArray => m !== null)
            .map(m => parseInt(m[1], 10));

          for (const pid of childPids) {
            killWindowsProcessTree(pid); // Recursive descend
          }
        });
      };

      // Cleanly kill the entire process tree/group to prevent fork-bombs and zombie leaks
      const killProcessTree = () => {
        if (!child.pid) return;
        if (isWin) {
          killWindowsProcessTree(child.pid);
        } else {
          try {
            process.kill(-child.pid, 'SIGKILL'); // Kill entire Unix process group
          } catch {
            try { child.kill('SIGKILL'); } catch {}
          }
        }
      };

      const handleOutputLimit = (dataSize: number): boolean => {
        if (isFinished) return true;
        totalOutputSize += dataSize;
        if (totalOutputSize > maxOutputBytes && !isFinished) {
          isFinished = true;
          clearTimeout(timeoutTimer);
          if (memoryTimer) clearInterval(memoryTimer);
          killProcessTree();
          
          const [sec, nsec] = process.hrtime(startTime);
          const elapsedMs = Math.round(sec * 1000 + nsec / 1000000);

          flushOutput();
        resolve({
            stdout: stdout.substring(0, 1000) + '\n... [TRUNCATED - EXCEEDED 5MB LIMIT] ...',
            stderr: stderr.substring(0, 1000) + '\n... [TRUNCATED - EXCEEDED 5MB LIMIT] ...',
            exitCode: null,
            timeMs: elapsedMs,
            memoryMb: Math.round(peakMemoryMb * 10) / 10,
            memoryMeasured,
            verdict: 'RE'
          });
          return true;
        }
        return false;
      };

      if (child.stdout) {
        child.stdout.on('data', (data: Buffer) => {
          if (handleOutputLimit(data.length)) return;
          stdout += stdoutDecoder.write(data);
        });
      }

      if (child.stderr) {
        child.stderr.on('data', (data: Buffer) => {
          if (handleOutputLimit(data.length)) return;
          stderr += stderrDecoder.write(data);
        });
      }

      // Cooperative cancellation: same tree-kill path as TLE, distinct verdict.
      if (config.signal) {
        if (config.signal.aborted) {
          flushOutput();
        resolve({ stdout: '', stderr: '', exitCode: null, timeMs: 0, memoryMb: 0, memoryMeasured: false, verdict: 'CANCELLED' });
          return;
        }
        config.signal.addEventListener('abort', () => {
          if (isFinished) return;
          isFinished = true;
          clearTimeout(timeoutTimer);
          if (memoryTimer) clearInterval(memoryTimer);
          killProcessTree();
          const [sec, nsec] = process.hrtime(startTime);
          const elapsedMs = Math.round(sec * 1000 + nsec / 1000000);
          flushOutput();
        resolve({ stdout, stderr, exitCode: null, timeMs: elapsedMs, memoryMb: Math.round(peakMemoryMb * 10) / 10, memoryMeasured, verdict: 'CANCELLED' });
        }, { once: true });
      }

      // Time Limit Timeout Enforcer
      const timeoutTimer = setTimeout(() => {
        if (isFinished) return;
        isFinished = true;
        
        killProcessTree();
        
        const [sec, nsec] = process.hrtime(startTime);
        const elapsedMs = Math.round(sec * 1000 + nsec / 1000000);

        flushOutput();
        resolve({
          stdout,
          stderr,
          exitCode: null,
          timeMs: elapsedMs,
          memoryMb: Math.round(peakMemoryMb * 10) / 10,
            memoryMeasured,
          verdict: 'TLE'
        });
      }, config.timeLimitMs);

      // Linux samples every member of the detached process group, including
      // bwrap descendants. Reads are async, bounded and never overlap. Fast runs
      // can finish between samples; they must remain explicitly unmeasured.
      const sampleMemory = async () => {
        if (isFinished || !child.pid || samplingMemory || process.platform !== 'linux') return;
        samplingMemory = true;
        try {
          const currentMemory = await sampleProcessGroupRss(child.pid);
          if (isFinished || currentMemory === null) return;
          memoryMeasured = true;
          peakMemoryMb = Math.max(peakMemoryMb, currentMemory);
          if (peakMemoryMb > config.memoryLimitMb) {
            isFinished = true;
            clearTimeout(timeoutTimer);
            if (memoryTimer) clearInterval(memoryTimer);
            killProcessTree();
            const [sec, nsec] = process.hrtime(startTime);
            flushOutput();
            resolve({ stdout, stderr, exitCode: null, timeMs: Math.round(sec * 1000 + nsec / 1000000),
              memoryMb: Math.round(peakMemoryMb * 10) / 10, memoryMeasured, verdict: 'MLE' });
          }
        } finally { samplingMemory = false; }
      };
      if (process.platform === 'linux') {
        memoryTimer = setInterval(() => void sampleMemory(), 100);
        void sampleMemory();
      }

      child.on('close', async (code: number | null, signal: string | null) => {
        if (isFinished) return;
        isFinished = true;
        clearTimeout(timeoutTimer);
        if (memoryTimer) clearInterval(memoryTimer);

        const [sec, nsec] = process.hrtime(startTime);
        const elapsedMs = Math.round(sec * 1000 + nsec / 1000000);

        // Handle Unix signals
        if (signal === 'SIGXCPU') {
          flushOutput();
        resolve({
            stdout,
            stderr,
            exitCode: null,
            timeMs: elapsedMs,
            memoryMb: Math.round(peakMemoryMb * 10) / 10,
            memoryMeasured,
            verdict: 'TLE'
          });
          return;
        }

        // Non-zero exit code indicates runtime error
        if (code !== 0 || signal) {
          const isOom = (code === 137 || signal === 'SIGKILL' || stderr.toLowerCase().includes('out of memory'));
          flushOutput();
        resolve({
            stdout,
            stderr,
            exitCode: code,
            timeMs: elapsedMs,
            memoryMb: Math.round(peakMemoryMb * 10) / 10,
            memoryMeasured,
            verdict: isOom ? 'MLE' : 'RE'
          });
          return;
        }

        // Verify outputs
        flushOutput();
        resolve({
          stdout,
          stderr,
          exitCode: code,
          timeMs: elapsedMs,
          memoryMb: Math.round(peakMemoryMb * 10) / 10,
            memoryMeasured,
          verdict: 'AC'
        });
      });

      child.on('error', (err: Error) => {
        if (isFinished) return;
        isFinished = true;
        clearTimeout(timeoutTimer);
        if (memoryTimer) clearInterval(memoryTimer);
        flushOutput();
        resolve({
          stdout,
          stderr: err.message,
          exitCode: 1,
          timeMs: 0,
          memoryMb: 0,
          verdict: 'RE'
        });
      });
    });
  }
}
