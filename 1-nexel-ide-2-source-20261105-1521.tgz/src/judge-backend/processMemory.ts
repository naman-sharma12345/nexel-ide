import { readdir, readFile } from 'node:fs/promises';

/** Linux process-group RSS, sampled without spawning ps or blocking the event loop.
 * Shared pages may be counted in several processes. This is a sampled group high
 * water mark, not an exact kernel peak or a hard cgroup memory quota.
 */
export async function sampleProcessGroupRss(group: number, procRoot = '/proc'): Promise<number | null> {
  let entries: string[];
  try { entries = (await readdir(procRoot)).filter(name => /^\d+$/.test(name)); }
  catch { return null; }
  let next = 0, kb = 0, sampled = false;
  const worker = async () => {
    while (next < entries.length) {
      const pid = entries[next++];
      try {
        const stat = await readFile(`${procRoot}/${pid}/stat`, 'utf8');
        // comm may contain spaces or parentheses. Fields after the final ')' are
        // state, parent PID, process group, and the remaining proc stat fields.
        const fields = stat.slice(stat.lastIndexOf(')') + 1).trim().split(/\s+/);
        if (Number(fields[2]) !== group) continue;
        const status = await readFile(`${procRoot}/${pid}/status`, 'utf8');
        const match = status.match(/^VmRSS:\s+(\d+)\s+kB$/m);
        if (match) { kb += Number(match[1]); sampled = true; }
      } catch { /* Process exits while scanning: not a zero-memory measurement. */ }
    }
  };
  await Promise.all(Array.from({ length: Math.min(8, entries.length) }, worker));
  return sampled ? kb / 1024 : null;
}
