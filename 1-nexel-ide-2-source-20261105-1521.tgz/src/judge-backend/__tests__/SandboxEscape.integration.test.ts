import { describe, it, expect } from 'vitest';
import { execFileSync } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { LocalSandboxExecutor } from '../LocalSandboxExecutor';

const hasGpp = (() => { try { execFileSync('which', ['g++'], { stdio: 'pipe' }); return true; } catch { return false; } });

describe.skipIf(!hasGpp)('sandbox timeout behavior (real compile + run)', () => {
  it('infinite loop gets TLE and leaves no process running', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nx-sbx-'));
    const src = path.join(dir, 'loop.cpp');
    fs.writeFileSync(src, 'int main(){ while(true){} return 0; }\n');
    const bin = path.join(dir, 'loop');
    execFileSync('g++', ['-std=c++17', src, '-o', bin], { stdio: 'pipe' });
    const ex = new LocalSandboxExecutor();
    const r = await ex.execute({ executablePath: bin, extension: '.cpp', input: '', timeLimitMs: 800, memoryLimitMb: 256 });
    expect(r.verdict).toBe('TLE');
    let alive = true;
    try { execFileSync('pgrep', ['-f', bin], { stdio: 'pipe' }); } catch { alive = false; }
    expect(alive).toBe(false);
    fs.rmSync(dir, { recursive: true, force: true });
  }, 30000);

  it('documents current platform behavior for a setsid + sleep escape (TLE verdict; process may survive)', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nx-sbx-'));
    const src = path.join(dir, 'esc.cpp');
    fs.writeFileSync(src, '#include <unistd.h>\nint main(){ if (setsid() < 0) return 2; sleep(30); return 0; }\n');
    const bin = path.join(dir, 'esc');
    execFileSync('g++', ['-std=c++17', src, '-o', bin], { stdio: 'pipe' });
    const ex = new LocalSandboxExecutor();
    const r = await ex.execute({ executablePath: bin, extension: '.cpp', input: '', timeLimitMs: 800, memoryLimitMb: 256 });
    expect(r.verdict).toBe('TLE');
    await new Promise((res) => setTimeout(res, 300));
    let alive = true;
    try { execFileSync('pgrep', ['-f', bin], { stdio: 'pipe' }); } catch { alive = false; }
    // Honest platform record, not an assertion of desired behavior:
    console.log('SETSID_SURVIVED=' + alive);
    if (alive) { try { execFileSync('pkill', ['-9', '-f', bin], { stdio: 'pipe' }); } catch { /* cleanup */ } }
    fs.rmSync(dir, { recursive: true, force: true });
  }, 30000);
});

describe.skipIf(!hasGpp)('sandbox cooperative cancellation (real compile + run)', () => {
  it('abort kills the run fast with CANCELLED and leaves no process running', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nx-sbx-cancel-'));
    const src = path.join(dir, 'loop.cpp');
    fs.writeFileSync(src, 'int main(){ while(true){} return 0; }\n');
    const bin = path.join(dir, 'loop');
    execFileSync('g++', ['-std=c++17', src, '-o', bin], { stdio: 'pipe' });
    const ex = new LocalSandboxExecutor();
    const controller = new AbortController();
    const started = Date.now();
    const promise = ex.execute({ executablePath: bin, extension: '.cpp', input: '', timeLimitMs: 30000, memoryLimitMb: 256, signal: controller.signal });
    setTimeout(() => controller.abort(), 300);
    const r = await promise;
    expect(r.verdict).toBe('CANCELLED');
    expect(Date.now() - started).toBeLessThan(5000); // nowhere near the 30s timeout
    let alive = true;
    try { execFileSync('pgrep', ['-f', bin], { stdio: 'pipe' }); } catch { alive = false; }
    expect(alive).toBe(false);
    fs.rmSync(dir, { recursive: true, force: true });
  }, 30000);
});
