// @vitest-environment node
import { afterAll, beforeAll, expect, it } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { LocalSandboxExecutor } from '../LocalSandboxExecutor';
import { JudgeService } from '../../main/services/JudgeService';

// Explicit opt-in: these exercise the real Linux sandbox/compiler, not mocks.
const native = process.env.NEXEL_NATIVE_JUDGE === '1';
let dir = '';
beforeAll(() => { if (native) dir = mkdtempSync(join(tmpdir(), 'nexel-native-judge-')); });
afterAll(() => { if (dir) rmSync(dir, { recursive: true, force: true }); });
it.skipIf(!native)('runs Python with stdin and rejects a sleeping program on wall time', async () => {
  const source = join(dir, 'echo.py');
  writeFileSync(source, 'print(int(input()) * 2)\n');
  const executor = new LocalSandboxExecutor();
  const config = { executablePath: source, extension: '.py', input: '21\n', timeLimitMs: 2000, memoryLimitMb: 256 };
  const result = await executor.execute(config);
  expect(result, result.stderr).toMatchObject({ verdict: 'AC', stdout: '42\n', exitCode: 0 });
  writeFileSync(source, 'import time\ntime.sleep(10)\n');
  const timeout = await executor.execute({ ...config, timeLimitMs: 150 });
  expect(timeout.verdict).toBe('TLE');
  expect(timeout.timeMs).toBeLessThan(2000);
});
it.skipIf(!native)('compiles a real C++ program and distinguishes AC from WA', async () => {
  execFileSync('g++', ['--version']);
  const source = join(dir, 'sum.cpp');
  writeFileSync(source, '#include <iostream>\nint main(){int a,b;std::cin>>a>>b;std::cout<<a+b<<"\\n";}\n');
  const results = await new JudgeService().run(source, [{ id: 1, input: '2 3\n', expected: '5\n' }, { id: 2, input: '2 3\n', expected: '6\n' }], 2000, 256);
  expect(results.map(r => r.verdict), JSON.stringify(results)).toEqual(['AC', 'WA']);
}, 20000);
it.skipIf(!native)('samples real resident memory and enforces the aggregate process-group budget', async () => {
  const source = join(dir, 'memory.py');
  writeFileSync(source, 'import time\na=bytearray(32*1024*1024)\nprint("allocated",flush=True)\ntime.sleep(0.5)\n');
  const executor = new LocalSandboxExecutor();
  const config = { executablePath: source, extension: '.py', input: '', timeLimitMs: 3000, memoryLimitMb: 256 };
  const measured = await executor.execute(config);
  expect(measured, measured.stderr).toMatchObject({ verdict: 'AC', memoryMeasured: true });
  expect(measured.memoryMb).toBeGreaterThan(30);
  writeFileSync(source, 'import subprocess,time\nfor _ in range(4): subprocess.Popen(["python3","-c","import time; a=bytearray(16*1024*1024); time.sleep(10)"])\ntime.sleep(10)\n');
  const overBudget = await executor.execute({ ...config, memoryLimitMb: 64 });
  expect(overBudget, JSON.stringify(overBudget)).toMatchObject({ verdict: 'MLE', memoryMeasured: true });
  expect(overBudget.memoryMb).toBeGreaterThan(64);
  expect(overBudget.timeMs).toBeLessThan(2500);
});

it.skipIf(!native)('streams real byte-sized UTF-8 stdout and stderr without losing split characters', async () => {
  const source = join(dir, 'unicode.py');
  const text = 'नमस्ते 🌐\n';
  writeFileSync(source, 'import os,time\nfor byte in "नमस्ते 🌐\\n".encode("utf-8"):\n for stream in (1,2): os.write(stream,bytes([byte]))\n time.sleep(0.015)\n');
  const result = await new LocalSandboxExecutor().execute({ executablePath: source, extension: '.py', input: '', timeLimitMs: 3000, memoryLimitMb: 256 });
  expect(result, JSON.stringify(result)).toMatchObject({ verdict: 'AC', stdout: text, stderr: text, exitCode: 0 });
});
