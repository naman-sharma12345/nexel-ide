// @vitest-environment node
import { afterEach, expect, it } from 'vitest';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { sampleProcessGroupRss } from '../processMemory';
let root = '';
afterEach(async () => { if (root) await rm(root, { recursive: true, force: true }); });
it('sums only the selected group and handles spaces/parentheses in process names', async () => {
  root = await mkdtemp(join(tmpdir(), 'nexel-proc-test-'));
  for (const [pid, group, rss] of [[1, 55, 1024], [2, 55, 2048], [3, 99, 8192]]) {
    await mkdir(join(root, String(pid)));
    await writeFile(join(root, String(pid), 'stat'), `${pid} (name (with) spaces) S 0 ${group} 0`);
    await writeFile(join(root, String(pid), 'status'), `VmRSS:\t${rss} kB\n`);
  }
  expect(await sampleProcessGroupRss(55, root)).toBe(3);
  expect(await sampleProcessGroupRss(123, root)).toBeNull();
});
it('reports unavailable rather than zero on a missing source', async () => {
  expect(await sampleProcessGroupRss(123, '/no-such-nexel-proc-source')).toBeNull();
});
