import './plugins/color-lab';
import './plugins/time-lab';
import './plugins/regex-lab';
import './plugins/document-insights';
import './plugins/text-compare';
import './plugins/document-navigator';
import './plugins/data-tools';
import {createOpenRequestGuard} from './lib/openRequest';
import {fileOpenError} from './lib/fileOpenError';
import {requestDocumentEditorFocus} from './lib/editorMenu';
import { requestDocumentReveal } from './lib/documentReveal';
import { readDocumentForOpen } from './lib/documentWriteLock';
import { type CSSProperties, useState, useEffect, useMemo, useRef, Suspense } from 'react';
import { getClangd } from './lib/clangd/session';
import { useUIStore } from './stores/useUIStore';
import { useEditorStore } from './stores/useEditorStore';
import { NavDock } from './components/NavDock';
import { WorkspaceResize, DEFAULT_WORKSPACE_WIDTH } from './components/WorkspaceResize';
import { Explorer } from './components/Explorer';
import { Editor } from './components/Editor';
import { TitleBar } from './components/TitleBar';
import { Terminal } from './components/Terminal';
import { useWorkspaceStore, type FileNode } from './stores/useWorkspaceStore';
import { StatusBar } from './components/StatusBar';
import { Toasts } from './components/Toasts';
import { CommandPalette } from './components/CommandPalette';
import { ShortcutsSheet } from './components/ShortcutsSheet';
import { PluginErrorBoundary } from './components/PluginErrorBoundary';
import { SettingsPanel } from './components/SettingsPanel';
import { useSettingsStore } from './stores/useSettingsStore';
import { useStatusStore } from './stores/useStatusStore';
import { applyTheme, THEMES } from './lib/themes';
import { switchTheme } from './lib/themeTransition';
import { SearchPanel } from './components/SearchPanel';
import { clearSessionForRoot, loadSession, saveSession, sessionForRoot, shouldClearSession } from './lib/session';
import { findAliasedTab } from './lib/aliasedTab';
import { listPlugins, pluginEnabled } from './plugins/registry';
import type { NexelPlugin } from './plugins/registry';
import './plugins/competitive-programming';
import './plugins/source-control';
import './App.css';
import {TemplateDialog} from './components/TemplateDialog';
import { AppCloseGuard } from './components/AppCloseGuard';

/** Runs one plugin's activation hook; isolated per plugin so a throwing hook hits the boundary, not the shell. */
function PluginActivation({ plugin, enabled }: { plugin: NexelPlugin; enabled: boolean }) {
  plugin.useActivation?.(enabled);
  return null;
}

function App() {
  const {
    currentSection,
    sidebarCollapsed,
    isHoverRevealed,
    terminalVisible,
    templateModalVisible,
    setSection,
    toggleSidebar,
    setTerminalVisible,
    openTemplateModal,
    setIsHoverRevealed,
  } = useUIStore();

  const {
    activeTabPath,
    focusedTabPath,
    cppTemplate,
    openFile,
    setCppTemplate,
    tabs,
  } = useEditorStore();

  const [terminalHeight, setTerminalHeight] = useState(240);
  const [workspaceWidth, setWorkspaceWidth] = useState(DEFAULT_WORKSPACE_WIDTH);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [quickOpen, setQuickOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [zen, setZen] = useState(false);
  useEffect(() => { document.documentElement.classList.toggle('nx-zen', zen); return () => document.documentElement.classList.remove('nx-zen'); }, [zen]);
  const tree = useWorkspaceStore(s => s.tree);
  const themeId = useSettingsStore(s => s.theme);
  const pluginPrefs = useSettingsStore(s => s.plugins);
  const enabledPlugins = listPlugins().filter(pl => pluginEnabled(pl, pluginPrefs));
  const pluginSections = new Set(enabledPlugins.flatMap(pl => pl.sections));
  const pluginCommands = new Set(enabledPlugins.flatMap(pl => pl.commandIds));
  const pluginNavItems = enabledPlugins.flatMap(pl => pl.navItems);
  // Disabled-plugin section still active (e.g. just toggled off): fall back to workspace.
  useEffect(() => {
    const owned = listPlugins().some(pl => pl.sections.includes(currentSection));
    if (owned && !pluginSections.has(currentSection)) setSection('workspace');
  }, [currentSection, pluginPrefs]);
  const firstTheme = useRef(true);
  useEffect(() => { applyTheme(themeId, document.documentElement, !firstTheme.current); firstTheme.current = false; }, [themeId]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      // A modal owns its keyboard. Do not stack another overlay or trigger the
      // workbench underneath it; explicit palette commands can still hand off.
      if (e.defaultPrevented || document.querySelector('[aria-modal="true"]')) return;
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'f') { e.preventDefault(); setPaletteOpen(false); setQuickOpen(false); setSearchOpen(o => !o); }
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'p') { e.preventDefault(); setQuickOpen(false); setPaletteOpen(o => !o); }
      else if ((e.ctrlKey || e.metaKey) && e.key === '/' && !(e.target as HTMLElement)?.closest?.('.monaco-editor')) { e.preventDefault(); setShortcutsOpen(o => !o); }
      else if ((e.ctrlKey || e.metaKey) && e.altKey && e.key.toLowerCase() === 'z') { e.preventDefault(); setZen(z => !z); }
      else if (e.key === 'Escape' && document.documentElement.classList.contains('nx-zen') && !(e.target as HTMLElement)?.closest?.('.monaco-editor')) setZen(false);
      else if ((e.ctrlKey || e.metaKey) && e.key === ',') { e.preventDefault(); const st = useSettingsStore.getState(); st.openSettings(!st.settingsOpen); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'p') { e.preventDefault(); setPaletteOpen(false); setQuickOpen(o => !o); }
      else if ((e.ctrlKey || e.metaKey) && e.key === '`') { e.preventDefault(); useUIStore.getState().toggleTerminal(); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'b') { e.preventDefault(); useUIStore.getState().toggleSidebar(); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  // Session restore: reopen last workspace's tabs once, then keep the session saved (debounced).
  const restored = useRef(false);
  const prevSessionRoot = useRef<string | null>(null);
  const hadInRootTabs = useRef(false);
  const rootPath = useWorkspaceStore(s => s.rootPath);
  // Compact fresh launch: an empty workspace drawer must not cover the welcome actions.
  // Collapses on mount without a workspace and when a workspace closes, never while one
  // is open; the dock trigger still reopens the drawer, and nothing here is persisted.
  const prevCompactRoot = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const collapseEmptyCompactDrawer = () => {
      if (typeof window.matchMedia !== 'function') return;
      if (!window.matchMedia('(max-width: 600px)').matches) return;
      if (useWorkspaceStore.getState().rootPath) return;
      if (!useUIStore.getState().sidebarCollapsed) useUIStore.getState().setSidebarCollapsed(true);
    };
    const enteredEmpty = prevCompactRoot.current === undefined || (prevCompactRoot.current != null && !rootPath);
    prevCompactRoot.current = rootPath;
    if (enteredEmpty) collapseEmptyCompactDrawer();
    if (typeof window.matchMedia !== 'function') return;
    const mq = window.matchMedia('(max-width: 600px)');
    mq.addEventListener('change', collapseEmptyCompactDrawer);
    return () => mq.removeEventListener('change', collapseEmptyCompactDrawer);
  }, [rootPath]);
  const sessionMounted = useRef(false);
  const sessionContentVersion = useRef(0);
  const sessionRestoreActive = useRef(false);
  useEffect(() => {
    sessionMounted.current = true;
    // Track changes, not just the current dirty flag: undo is newer intent too.
    const stopWatching = useEditorStore.subscribe((state, previous) => {
      if (!sessionRestoreActive.current || state.tabs === previous.tabs) return;
      if (state.tabs.some(tab => {
        const old = previous.tabs.find(before => before.filePath === tab.filePath);
        return old && old.content !== tab.content;
      })) sessionContentVersion.current++;
    });
    return () => { sessionMounted.current = false; stopWatching(); };
  }, []);
  useEffect(() => {
    if (restored.current || !rootPath) return;
    restored.current = true;
    if (useEditorStore.getState().tabs.length) return;
    const sess = loadSession(rootPath);
    if (!sess) return;
    sessionRestoreActive.current = true;
    void (async () => {
      // Count files that actually opened, and classify the rest honestly:
      // only ENOENT/ENOTDIR means "no longer on disk" - encoding refusals,
      // permission errors and other read failures are "couldn't be reopened".
      const isGone = (e: unknown) => {
        if (typeof e === 'object' && e !== null && 'code' in e) return e.code === 'ENOENT' || e.code === 'ENOTDIR';
        const message = e instanceof Error ? e.message.replace(/^Error invoking remote method '[^']+': (?:Error: )?/, '') : '';
        return /^(?:ENOENT|ENOTDIR)(?=:|$)/.test(message);
      };
      let opened = 0, gone = 0, failed = 0;
      const restoreGuard = createOpenRequestGuard();
      let current = restoreGuard.begin(rootPath);
      const contentVersion = sessionContentVersion.current;
      const stillCurrent = () => contentVersion === sessionContentVersion.current && sessionMounted.current && current(useWorkspaceStore.getState().rootPath);
      const tryOpen = async (p: string) => {
        if (!stillCurrent()) return false;
        try {
          const content = await readDocumentForOpen(p);
          if (!stillCurrent()) return false;
          useEditorStore.getState().openFile(p, p.split(/[\\/]/).pop() ?? p, content); opened++;
          // Our own sequential restore is navigation too. Capture its new
          // generation, without letting a later explicit navigation revive us.
          current = restoreGuard.begin(rootPath);
        } catch (e) { if (!stillCurrent()) return false; if (isGone(e)) gone++; else failed++; }
        return true;
      };
      try {
        for (const p of sess.paths.filter(x => x !== sess.active)) if (!await tryOpen(p)) return;
        if (sess.active && !await tryOpen(sess.active)) return;
        if (!stillCurrent()) return;
        const parts: string[] = [];
        if (gone) parts.push(`${gone} no longer on disk`);
        if (failed) parts.push(`${failed} couldn't be reopened`);
        useStatusStore.getState().pushToast(
          opened === sess.paths.length
            ? `Restored ${opened} tab${opened === 1 ? '' : 's'}`
            : opened > 0
              ? `Restored ${opened} of ${sess.paths.length} tabs (${parts.join(', ')})`
              : `None of the previously open files could be restored (${parts.join(', ')})`,
          'info', 2500);
      } finally { sessionRestoreActive.current = false; }
    })();
  }, [rootPath]);
  useEffect(() => {
    if (!rootPath || !restored.current) return;
    const sess = sessionForRoot(rootPath, tabs.map(x => x.filePath), activeTabPath);
    // Clear decisions and the prev-root tracking are committed-transition work,
    // so they run in the effect body, not inside the save debounce: a debounce
    // cancellation (a root switch landing within the debounce window right after
    // the last in-root tab closed) would otherwise drop a pending
    // deliberate-emptying clear while the earlier debounced save had already
    // landed. StrictMode's extra effect invocation re-evaluates the same commit
    // against the already-advanced refs (a no-op), and clearSessionForRoot is
    // idempotent. Only the storage write of a non-empty session stays debounced.
    if (!sess && shouldClearSession(prevSessionRoot.current, hadInRootTabs.current, rootPath, tabs.length)) clearSessionForRoot(rootPath);
    prevSessionRoot.current = rootPath;
    hadInRootTabs.current = !!sess;
    if (!sess) return;
    const t = window.setTimeout(() => saveSession(sess), 400);
    return () => window.clearTimeout(t);
  }, [tabs, activeTabPath, rootPath]);
  // clangd IntelliSense follows the workspace root and the IntelliSense settings (restarts only when they change).
  const clangdEnabled = useSettingsStore(s => s.clangdEnabled);
  const cppStd = useSettingsStore(s => s.cppStd);
  const clangdFlags = useSettingsStore(s => s.clangdFlags);
  useEffect(() => {
    void getClangd((m, k, ttl) => useStatusStore.getState().pushToast(m, k, ttl))
      .configure({ root: rootPath, enabled: clangdEnabled, std: cppStd, extraFlags: clangdFlags.split(' ').filter(Boolean) });
  }, [rootPath, clangdEnabled, cppStd, clangdFlags]);
  // Go to Definition into another file (clangd): open it as a tab, then reveal the line.
  useEffect(() => {
    const onOpenAt = (e: Event) => {
      const { path: p, line, col } = (e as CustomEvent<{ path: string; line: number; col: number }>).detail ?? {};
      if (typeof p !== 'string') return;
      void handleFileSelect(p).then(opened => { if (opened) requestDocumentReveal({path:p,line,col}); });
    };
    window.addEventListener('nexel:open-at', onOpenAt);
    return () => window.removeEventListener('nexel:open-at', onOpenAt);
  });
  // Plugin activation hooks (e.g. the CP companion listener attaches only while its plugin is on)
  const pluginsAll = useMemo(() => listPlugins(), []);
  const enabledPluginIds = new Set(enabledPlugins.map(pl => pl.id));
  const paletteCommands = [
    { id: 'ws', label: 'Go to Workspace', run: () => setSection('workspace') },
    { id: 'judge', label: 'Go to Judge', run: () => setSection('judge') },
    { id: 'contests', label: 'Go to Contests', run: () => setSection('contests') },
    { id: 'zen', label: 'Toggle Zen Mode', hint: 'Ctrl+Alt+Z', run: () => setZen(z => !z) },
    { id: 'sidebar', label: 'Toggle Sidebar', hint: 'Ctrl+B', run: () => toggleSidebar() },
    { id: 'term', label: 'Toggle Terminal', run: () => setTerminalVisible(!terminalVisible) },
    { id: 'tpl', label: 'Edit C++ Template', run: () => openTemplateModal(true) },
    { id: 'findfiles', label: 'Find in Files', hint: 'Ctrl+Shift+F', run: () => setSearchOpen(true) },
    { id: 'shortcuts', label: 'Keyboard Shortcuts', hint: 'Ctrl+/', run: () => setShortcutsOpen(true) },
    { id: 'settings', label: 'Open Settings', hint: 'Ctrl+,', run: () => useSettingsStore.getState().openSettings(true) },
    ...THEMES.map(t => ({ id: 'theme-' + t.id, label: `Theme: ${t.name}`, run: () => switchTheme(t.id) })),
    { id: 'minimap', label: 'Toggle Minimap', run: () => useSettingsStore.getState().toggle('minimap') },
    { id: 'wrap', label: 'Toggle Word Wrap', run: () => useSettingsStore.getState().toggle('wordWrap') },
  ].filter(c => {
    const owner = listPlugins().find(pl => pl.commandIds.includes(c.id));
    return !owner || pluginCommands.has(c.id);
  });

  const flatFiles = (nodes: FileNode[]): FileNode[] => nodes.flatMap(n => n.type === 'file' ? [n] : flatFiles(n.children ?? []));
  const workspaceFiles = useMemo(() => flatFiles(tree), [tree]);
  // Stable identity across renders: on a multi-thousand-file workspace, rebuilding
  // one command object + closure per file on EVERY App render is pure churn.
  // handleFileSelect itself is re-created per render, so the closures go through
  // a ref that always points at the current render's implementation.
  // Declared here, assigned right after handleFileSelect below (declaration order);
  // the memoized closures only read it when invoked, always after assignment.
  const handleFileSelectRef = useRef<(filePath: string) => Promise<boolean>>(() => Promise.resolve(false));
  const fileCommands = useMemo(() => workspaceFiles.map(n => ({ id: n.path, label: n.name, detail: rootPath && n.path.startsWith(rootPath + '/') ? n.path.slice(rootPath.length + 1) : n.path, run: () => { void handleFileSelectRef.current(n.path).then(opened => {
    // Failed/refused opens resolve after showing their error; never retain a
    // focus request for a document that did not become the selected pane.
    if (opened) requestDocumentEditorFocus(n.path);
  }); } })), [workspaceFiles, rootPath]);



  useEffect(() => {
    const dismissDrawer = (event: KeyboardEvent) => {
      if (event.key !== 'Escape' || event.defaultPrevented || !window.matchMedia('(max-width: 600px)').matches || useUIStore.getState().sidebarCollapsed || document.querySelector('[aria-modal="true"]')) return;
      event.preventDefault();
      const section = useUIStore.getState().currentSection;
      useUIStore.getState().setSidebarCollapsed(true);
      // Return to the drawer's own trigger so Enter reopens the same tool.
      const triggers = Array.from(document.querySelectorAll<HTMLButtonElement>('.nd-item-row'));
      (triggers.find(button => button.dataset.navId === section) ?? triggers.find(button => button.dataset.navId === 'workspace'))?.focus();
    };
    window.addEventListener('keydown', dismissDrawer);
    return () => window.removeEventListener('keydown', dismissDrawer);
  }, []);

  const openRequests = useRef(createOpenRequestGuard());
  const handleFileSelect = async (filePath: string): Promise<boolean> => {
    const current = openRequests.current.begin(useWorkspaceStore.getState().rootPath);
    let existing = tabs.find((t) => t.filePath === filePath);
    if (!existing && typeof window.nexelAPI?.realPath === 'function') {
      // Alias dedupe: one file can be spelled through a symlinked ancestor (a
      // clangd definition path, or this workspace previously opened under a
      // different spelling). Focus the existing tab under ITS spelling instead
      // of opening a second buffer of the same file. No path canonicalization
      // and no model merge; unresolvable paths fall through to a normal open.
      existing = await findAliasedTab(useEditorStore.getState().tabs, filePath, window.nexelAPI.realPath) ?? undefined;
      if (existing && !current(useWorkspaceStore.getState().rootPath)) return false;
    }
    if (existing) {
      useEditorStore.getState().openFile(existing.filePath, existing.name, existing.content);
      return useEditorStore.getState().focusedTabPath === existing.filePath;
    }
    if (false) {
    } else {
      try {
        const content = await readDocumentForOpen(filePath);
        if (!current(useWorkspaceStore.getState().rootPath)) return false;
        const name = filePath.split(/[\\/]/).pop() || filePath;
        openFile(filePath, name, content);
      } catch (err) {
        if (!current(useWorkspaceStore.getState().rootPath)) return false;
        console.error("Failed to read selected file:", err);
        useStatusStore.getState().pushToast(fileOpenError(filePath, err), 'error', 5000);
        return false;
      }
    }
    return useEditorStore.getState().focusedTabPath === filePath;
  };
  handleFileSelectRef.current = handleFileSelect;

  const handleCloseFile = () => {
    // Setting activeTabPath to null or managing it via editor store
    useEditorStore.setState({ activeTabPath: null });
  };

  const handleSelectSection = (id: string) => {
    if (id === 'workspace' || pluginSections.has(id)) {
      if (currentSection === id) {
        toggleSidebar();
      } else {
        setSection(id);
        useUIStore.setState({ sidebarCollapsed: false });
      }
    } else {
      setSection(id);
    }
  };

  return (
    <div style={{
      '--nx-workspace-width': `${workspaceWidth}px`,
      '--nx-terminal-height': `${terminalHeight}px`,
      display: 'flex',
      flexDirection: 'column',
      width: '100vw',
      height: '100vh',
      overflow: 'hidden',
      backgroundColor: 'var(--nx-bg-0)'
    } as CSSProperties}>
      {pluginsAll.map(pl => pl.useActivation ? (
        <PluginErrorBoundary key={pl.id} name={pl.name} variant="notice" resetKey={enabledPluginIds.has(pl.id)} onDisable={() => useSettingsStore.getState().togglePlugin(pl.id)}>
          <PluginActivation plugin={pl} enabled={enabledPluginIds.has(pl.id)} />
        </PluginErrorBoundary>
      ) : null)}
      {shortcutsOpen && <ShortcutsSheet onClose={() => setShortcutsOpen(false)} />}
      {paletteOpen && <CommandPalette commands={paletteCommands} onClose={() => setPaletteOpen(false)} />}
      {searchOpen && <SearchPanel files={workspaceFiles} onClose={() => setSearchOpen(false)} onOpen={async (p, line, col) => { if (await handleFileSelect(p)) requestDocumentReveal({path:p,line,col}); }} />}
      {quickOpen && <CommandPalette commands={fileCommands} placeholder="Go to file…" label="Quick open" onClose={() => setQuickOpen(false)} />}
      <TitleBar />

      <div style={{
        flexGrow: 1,
        width: '100vw',
        minHeight: 0,
        display: 'flex',
        flexDirection: 'row',
        overflow: 'hidden',
        position: 'relative'
      }}>
        {/* Invisible Hover Trigger zone at absolute left edge when NavDock is collapsed */}
        {sidebarCollapsed && (
          <div
            className="nx-navdock-hover-trigger"
            onMouseEnter={() => setIsHoverRevealed(true)}
            style={{
              position: 'fixed',
              left: 0,
              top: '34px',
              width: '24px',
              height: 'calc(100vh - 34px - var(--nx-status-h))',
              zIndex: 9999,
              background: 'transparent'
            }}
          />
        )}

        {/* Floating high-fidelity glass dock layer (collapses off-screen, reveals on hover) */}
        <div
          className={`nx-navdock-wrapper-container ${sidebarCollapsed ? 'collapsed' : ''} ${isHoverRevealed ? 'hover-revealed' : ''}`}
          onMouseLeave={() => setIsHoverRevealed(false)}
          style={{
            height: 'calc(100vh - 34px - var(--nx-status-h))',
            zIndex: 10000,
            position: 'fixed',
            top: '34px',
            transition: 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
          }}
        >
          <NavDock
            activeSection={currentSection}
            onSelect={handleSelectSection}
            pluginItems={pluginNavItems}
            sidebarCollapsed={sidebarCollapsed}
          />
        </div>

        {/* Workspace Panel Stream (Collapses completely on toggle, no hover reveal) */}
        <div
          className={`nx-sidebar-container ${sidebarCollapsed ? 'collapsed' : ''}`}
          data-active-section={currentSection}
          style={{
            display: (currentSection === 'workspace' || pluginSections.has(currentSection)) ? 'flex' : 'none',
            transition: 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
            height: '100%'
          }}
        >
          <div style={{ display: currentSection === 'workspace' ? 'flex' : 'none', height: '100%', width: '100%' }}>
            <Explorer
              onFileSelect={async path => {
                await handleFileSelect(path);
                if (window.matchMedia('(max-width: 600px)').matches && useEditorStore.getState().activeTabPath === path) useUIStore.getState().setSidebarCollapsed(true);
              }}
              activeFilePath={focusedTabPath || activeTabPath}
            />
          </div>
          {/* Plugin-owned dock sections render their panels from the registry; the shell imports no plugin modules */}
          {pluginsAll.flatMap(pl => (pl.sections ?? []).filter(sec => pluginSections.has(sec) && pl.panels?.[sec]).map(sec => {
            const Panel = pl.panels![sec];
            return (
              <div key={sec} style={{ display: currentSection === sec ? 'flex' : 'none', height: '100%', width: '100%' }}>
                <PluginErrorBoundary name={pl.name} onDisable={() => useSettingsStore.getState().togglePlugin(pl.id)}>
                  <Suspense fallback={<div className="nx-skeleton" style={{flex:1,margin:12,borderRadius:12}} />}><Panel activeFilePath={focusedTabPath || activeTabPath} /></Suspense>
                </PluginErrorBoundary>
              </div>
            );
          }))}
        </div>

        {!sidebarCollapsed && currentSection === 'workspace' && <WorkspaceResize width={workspaceWidth} onChange={setWorkspaceWidth} />}

        {/* Main UI Text Editor Core Canvas */}
        <div className={terminalVisible ? 'nx-editor-with-terminal' : undefined} style={{
          flexGrow: 1,
          minWidth: 0,
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          boxSizing: 'border-box',
          background: 'var(--nx-bg-0)',
          position: 'relative'
        }}>
          {/* Editor panel is always mounted but toggled using CSS to prevent vanishing tabs */}
          <div style={{ display: (currentSection === 'workspace' || pluginSections.has(currentSection)) ? 'flex' : 'none', width: '100%', height: '100%' }}>
            <Editor
              activeFilePath={activeTabPath}
              onFileSelect={handleFileSelect}
              onCloseFile={handleCloseFile}
              zen={zen}
              onQuickOpen={() => { setPaletteOpen(false); setQuickOpen(true); }}
            />
          </div>
        </div>
      </div>

      <AppCloseGuard />
      <Toasts />
      <StatusBar />
      <SettingsPanel />
      <Terminal
        visible={terminalVisible}
        onClose={() => setTerminalVisible(false)}
        sidebarCollapsed={sidebarCollapsed}
        height={terminalHeight}
        onHeightChange={setTerminalHeight}
      />

      {templateModalVisible && <TemplateDialog initialValue={cppTemplate} onCancel={() => openTemplateModal(false)} onSave={value => {setCppTemplate(value);openTemplateModal(false);}} />}

    </div>
  );
}

export default App;
