/** Shortest distinct parent suffix for duplicate tab names. Parse/group once
 * rather than rescanning and splitting every open path for every tab. */
export function tabPathLabels(tabs: readonly {name:string;filePath:string}[]): Map<string,string> {
  const groups=new Map<string,{path:string;parts:string[]}[]>();
  for(const tab of tabs){
    const group=groups.get(tab.name)??[];
    group.push({path:tab.filePath,parts:tab.filePath.replace(/\\/g,'/').split('/').slice(0,-1).filter(Boolean)});
    groups.set(tab.name,group);
  }
  const labels=new Map<string,string>();
  for(const group of groups.values()){
    if(group.length<2)continue;
    const counts=new Map<string,number>();
    for(const {parts} of group){
      // Include depth: two shorter paths can have the same suffix at several depths.
      for(let depth=1;depth<=parts.length;depth++){
        const key=depth+':'+parts.slice(-depth).join('/');
        counts.set(key,(counts.get(key)??0)+1);
      }
    }
    for(const {path,parts} of group){
      let depth=1;
      while(depth<parts.length&&(counts.get(depth+':'+parts.slice(-depth).join('/'))??0)>1)depth++;
      labels.set(path,parts.slice(-depth).join('/')||'root');
    }
  }
  return labels;
}
