import {describe, it, expect} from 'vitest';
import {clampSuggestionOffset, completionDetailsAnchor, completionDetailsHeight, completionDetailsTop} from './suggestViewport';
describe('completion card viewport offset', () => {
  it('moves the complete short-pane card below the clipped header', () => {
    expect(clampSuggestionOffset(106, 202, 154, 440)).toBe(48);
  });
  it('keeps fitting cards unchanged and shifts lower overflow upward', () => {
    expect(clampSuggestionOffset(192, 202, 154, 847)).toBe(0);
    expect(clampSuggestionOffset(350, 202, 154, 440)).toBe(-112);
  });
  it('aligns oversized cards at the start rather than hiding their first rows', () => {
    expect(clampSuggestionOffset(106, 500, 154, 440)).toBe(48);
  });
});

import {vi} from 'vitest';
import {keepSuggestionsInViewport} from './suggestViewport';
it('coalesces observer work, stops cleanly and replaces an existing owner', async () => {
  const mutations: {callback: (records: MutationRecord[]) => void; disconnect: ReturnType<typeof vi.fn>}[] = [];
  const sizes: {disconnect: ReturnType<typeof vi.fn>}[] = [];
  vi.stubGlobal('MutationObserver', class {
    disconnect = vi.fn(); observe = vi.fn();
    constructor(callback: (records: MutationRecord[]) => void) {mutations.push({callback, disconnect:this.disconnect});}
  });
  vi.stubGlobal('ResizeObserver', class {
    disconnect = vi.fn(); observe = vi.fn();
    constructor() {sizes.push({disconnect:this.disconnect});}
  });
  try {
    const root = document.createElement('div');
    const widget = document.createElement('div');widget.className='suggest-widget visible';root.append(widget);
    root.getBoundingClientRect = vi.fn(() => ({left:0,right:300,top:154,bottom:440}) as DOMRect);
    widget.getBoundingClientRect = vi.fn(() => ({left:0,top:106,width:200,height:202}) as DOMRect);
    const first = keepSuggestionsInViewport(root);
    mutations[0].callback([{target: widget,type:'attributes'} as unknown as MutationRecord]);mutations[0].callback([{target: widget,type:'attributes'} as unknown as MutationRecord]);
    await Promise.resolve();
    expect(widget.getBoundingClientRect).toHaveBeenCalledTimes(1);
    expect(widget.style.translate).toBe('0px 48px');
    mutations[0].callback([{target: root,type:'attributes'} as unknown as MutationRecord]);await Promise.resolve();
    expect(widget.getBoundingClientRect).toHaveBeenCalledTimes(1);
    const second = keepSuggestionsInViewport(root);
    expect(mutations[0].disconnect).toHaveBeenCalledOnce();
    expect(sizes[0].disconnect).toHaveBeenCalledOnce();
    second();await Promise.resolve();
    expect(widget.getBoundingClientRect).toHaveBeenCalledTimes(1);
    expect(widget.style.translate).toBe('');
    first();expect(mutations[0].disconnect).toHaveBeenCalledOnce();
  } finally {vi.unstubAllGlobals();}
});

it('keeps the selected row visible when the whole card is taller than its pane', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div');const widget=document.createElement('div');const row=document.createElement('div');
    widget.className='suggest-widget visible';row.className='monaco-list-row focused';widget.append(row);root.append(widget);
    root.getBoundingClientRect=()=>({left:0,right:300,top:149,bottom:294,height:145}) as DOMRect;
    widget.getBoundingClientRect=()=>({left:0,top:149,width:200,height:202}) as DOMRect;
    row.getBoundingClientRect=()=>({top:282,height:22}) as DOMRect;
    const stop=keepSuggestionsInViewport(root);await Promise.resolve();
    expect(widget.style.translate).toBe('0px -10px');stop();
  }finally{vi.unstubAllGlobals();}
});

describe('completion documentation geometry', () => {
  const pane = {top:149,bottom:294,width:308,height:145};
  const card = {top:244,bottom:460,width:261,height:216};
  const selected = {top:244,bottom:266,width:259,height:22};
  it('anchors oversized cards to selected rows, not clipped full-list bounds', () => {
    expect(completionDetailsAnchor(pane,card,selected)).toBe(selected);
    expect(completionDetailsHeight(pane,selected)).toBe(91);
    expect(completionDetailsTop(149,308,93,pane,selected)).toBe(151);
  });
  it('stacks short docs below a fitting card without losing the first result', () => {
    const tall={top:154,bottom:440,width:308,height:286};
    const list={top:154,bottom:356,width:261,height:202};
    expect(completionDetailsAnchor(tall,list,selected)).toBe(list);
    expect(completionDetailsTop(154,308,32,tall,list)).toBe(356);
  });
  it('uses the pane without an anchor and bounds height to a readable minimum', () => {
    expect(completionDetailsHeight(pane)).toBe(141);
    expect(completionDetailsHeight({top:0,bottom:20,width:100,height:20})).toBe(24);
  });
});

describe('short-pane clamping for parameter hints and hover', () => {
  const observers = () => {
    vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
    vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  };
  const paneRect = () => ({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;

  it('caps and repositions an overflowing hints widget, then restores styles on stop', async () => {
    observers();
    try {
      const root=document.createElement('div');
      const widget=document.createElement('div');widget.className='parameter-hints-widget visible';
      const wrapper=document.createElement('div');wrapper.className='phwrapper';
      const sc=document.createElement('div');sc.className='monaco-scrollable-element';
      widget.append(wrapper);wrapper.append(sc);root.append(widget);
      root.getBoundingClientRect=paneRect;
      widget.getBoundingClientRect=()=>({left:100,top:-25,width:147,height:252}) as DOMRect;
      const stop=keepSuggestionsInViewport(root);await Promise.resolve();
      expect(widget.style.maxHeight).toBe('145px');
      expect(widget.style.overflowY).toBe('hidden');
      expect(wrapper.style.maxHeight).toBe('145px');
      expect(sc.style.maxHeight).toBe('145px');
      expect(sc.style.overflowY).toBe('auto');
      expect(widget.style.translate).toBe('0px 174px');
      stop();
      expect(widget.style.maxHeight).toBe('');
      expect(widget.style.translate).toBe('');
      expect(wrapper.style.maxHeight).toBe('');
    } finally {vi.unstubAllGlobals();}
  });

  it('lets full-content hover scroll natively inside the cap', async () => {
    observers();
    try {
      const root=document.createElement('div');
      const hov=document.createElement('div');hov.className='monaco-hover';
      const sc=document.createElement('div');sc.className='monaco-scrollable-element';
      const content=document.createElement('div');content.className='monaco-hover-content';
      sc.append(content);hov.append(sc);root.append(hov);
      root.getBoundingClientRect=paneRect;
      hov.getBoundingClientRect=()=>({left:60,top:200,width:259,height:250}) as DOMRect;
      const stop=keepSuggestionsInViewport(root);await Promise.resolve();
      expect(hov.style.maxHeight).toBe('145px');
      expect(content.style.height).toBe('auto');
      expect(content.style.maxHeight).toBe('none');
      stop();
      expect(hov.style.maxHeight).toBe('');
      expect(content.style.height).toBe('');
    } finally {vi.unstubAllGlobals();}
  });

  it('bridges wheel scrolling on clamped widgets and leaves other wheel events alone', async () => {
    observers();
    try {
      const root=document.createElement('div');
      const hov=document.createElement('div');hov.className='monaco-hover';
      const sc=document.createElement('div');sc.className='monaco-scrollable-element';
      hov.append(sc);root.append(hov);
      const outside=document.createElement('div');root.append(outside);
      root.getBoundingClientRect=paneRect;
      hov.getBoundingClientRect=()=>({left:60,top:200,width:259,height:250}) as DOMRect;
      Object.defineProperty(sc,'scrollHeight',{value:600,configurable:true});
      Object.defineProperty(sc,'clientHeight',{value:145,configurable:true});
      const stop=keepSuggestionsInViewport(root);await Promise.resolve();
      const evt=new WheelEvent('wheel',{deltaY:120,bubbles:true,cancelable:true});
      sc.dispatchEvent(evt);
      expect(sc.scrollTop).toBe(120);
      expect(evt.defaultPrevented).toBe(true);
      const evt2=new WheelEvent('wheel',{deltaY:120,bubbles:true,cancelable:true});
      outside.dispatchEvent(evt2);
      expect(evt2.defaultPrevented).toBe(false);
      stop();
      const evt3=new WheelEvent('wheel',{deltaY:50,bubbles:true,cancelable:true});
      sc.dispatchEvent(evt3);
      expect(evt3.defaultPrevented).toBe(false);
      expect(sc.scrollTop).toBe(120);
    } finally {vi.unstubAllGlobals();}
  });
});

it('lets wheel events bubble at the scroll boundaries', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div');
    const hov=document.createElement('div');hov.className='monaco-hover';
    const sc=document.createElement('div');sc.className='monaco-scrollable-element';
    hov.append(sc);root.append(hov);
    root.getBoundingClientRect=()=>({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;
    hov.getBoundingClientRect=()=>({left:60,top:200,width:259,height:250}) as DOMRect;
    Object.defineProperty(sc,'scrollHeight',{value:600,configurable:true});
    Object.defineProperty(sc,'clientHeight',{value:145,configurable:true});
    const stop=keepSuggestionsInViewport(root);await Promise.resolve();
    const up=new WheelEvent('wheel',{deltaY:-120,bubbles:true,cancelable:true});
    sc.dispatchEvent(up);
    expect(up.defaultPrevented).toBe(false); // already at top: bubbles
    expect(sc.scrollTop).toBe(0);
    sc.scrollTop=455; // at the end (600-145)
    const down=new WheelEvent('wheel',{deltaY:120,bubbles:true,cancelable:true});
    sc.dispatchEvent(down);
    expect(down.defaultPrevented).toBe(false); // at the end: bubbles
    expect(sc.scrollTop).toBe(455);
    stop();
  } finally {vi.unstubAllGlobals();}
});

describe('popup-over-header marker lifecycle', () => {
  const observers = () => {
    const mutations: {callback: (records: MutationRecord[]) => void; disconnect: ReturnType<typeof vi.fn>}[] = [];
    vi.stubGlobal('MutationObserver', class {
      disconnect = vi.fn(); observe = vi.fn();
      constructor(callback: (records: MutationRecord[]) => void) {mutations.push({callback, disconnect:this.disconnect});}
    });
    vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
    return mutations;
  };
  const buildPane = () => {
    const pane = document.createElement('div');pane.className='nx-editor-split-pane right';
    const header = document.createElement('div');header.className='nx-right-pane-header';
    const root = document.createElement('div');root.className='monaco-editor';
    pane.append(root, header);
    header.getBoundingClientRect = () => ({left:956,right:980,top:154,bottom:178,width:24,height:24}) as DOMRect;
    root.getBoundingClientRect = () => ({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;
    return { pane, header, root };
  };
  const popup = (root: HTMLElement, rect: Partial<DOMRect>) => {
    const w = document.createElement('div');w.className='suggest-widget visible';
    w.getBoundingClientRect = () => ({left:728,top:149,width:262,height:216,right:990,bottom:365,...rect}) as DOMRect;
    root.append(w);
    return w;
  };

  it.each(['suggest-widget visible', 'quick-input-widget'])('sets the marker only while a visible %s intersects the chip', async (popupClass) => {
    const mutations = observers();
    try {
      const { root } = buildPane();
      const w = popup(root, {});
      w.className = popupClass;
      const stop = keepSuggestionsInViewport(root);
      mutations[0].callback([{target: w, type:'attributes'} as unknown as MutationRecord]);
      await Promise.resolve();
      expect(root.hasAttribute('data-nx-popup-over-header')).toBe(true);
      // popup moves away from the chip
      w.getBoundingClientRect = () => ({left:100,top:500,width:262,height:50,right:362,bottom:550}) as DOMRect;
      mutations[0].callback([{target: w, type:'attributes'} as unknown as MutationRecord]);
      await Promise.resolve();
      expect(root.hasAttribute('data-nx-popup-over-header')).toBe(false);
      // popup disappears entirely
      w.remove();
      mutations[0].callback([{target: root, type:'childList', addedNodes:[], removedNodes:[w]} as unknown as MutationRecord]);
      await Promise.resolve();
      expect(root.hasAttribute('data-nx-popup-over-header')).toBe(false);
      stop();
    } finally {vi.unstubAllGlobals();}
  });

  it('never marks without a header and clears the marker on disposal', async () => {
    const mutations = observers();
    try {
      const { root, header } = buildPane();
      const w = popup(root, {});
      const stop = keepSuggestionsInViewport(root);
      mutations[0].callback([{target: w, type:'attributes'} as unknown as MutationRecord]);
      await Promise.resolve();
      expect(root.hasAttribute('data-nx-popup-over-header')).toBe(true);
      stop();
      expect(root.hasAttribute('data-nx-popup-over-header')).toBe(false);
      // no header anywhere: no marker
      const bare = document.createElement('div');bare.className='monaco-editor';
      bare.getBoundingClientRect = () => ({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;
      const w2 = popup(bare, {});
      const stop2 = keepSuggestionsInViewport(bare);
      mutations[1].callback([{target: w2, type:'attributes'} as unknown as MutationRecord]);
      await Promise.resolve();
      expect(bare.hasAttribute('data-nx-popup-over-header')).toBe(false);
      stop2();
      void header;
    } finally {vi.unstubAllGlobals();}
  });
});

it('restores a preexisting popup-over-header marker on disposal', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div');root.className='monaco-editor';
    root.setAttribute('data-nx-popup-over-header','');
    root.getBoundingClientRect=()=>({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;
    const stop=keepSuggestionsInViewport(root);
    await Promise.resolve();
    // no header in the pane: the module does not manage the marker at all
    expect(root.hasAttribute('data-nx-popup-over-header')).toBe(true);
    stop();
    expect(root.hasAttribute('data-nx-popup-over-header')).toBe(true);
  } finally {vi.unstubAllGlobals();}
});

it('clears a preexisting marker during operation when a header exists, restoring it on disposal', async () => {
  const mutations: {callback: (records: MutationRecord[]) => void; disconnect: ReturnType<typeof vi.fn>}[] = [];
  vi.stubGlobal('MutationObserver', class {
    disconnect = vi.fn(); observe = vi.fn();
    constructor(callback: (records: MutationRecord[]) => void) {mutations.push({callback, disconnect:this.disconnect});}
  });
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const pane = document.createElement('div');pane.className='nx-editor-split-pane right';
    const header = document.createElement('div');header.className='nx-right-pane-header';
    const root = document.createElement('div');root.className='monaco-editor';
    pane.append(root, header);
    header.getBoundingClientRect = () => ({left:956,right:980,top:154,bottom:178,width:24,height:24}) as DOMRect;
    root.getBoundingClientRect = () => ({left:0,right:300,top:149,bottom:294,height:145,width:300}) as DOMRect;
    root.setAttribute('data-nx-popup-over-header','');
    const stop = keepSuggestionsInViewport(root);
    mutations[0].callback([{target: root, type:'attributes'} as unknown as MutationRecord]);
    await Promise.resolve();
    // header exists but no popup overlaps it: actively managed, cleared
    expect(root.hasAttribute('data-nx-popup-over-header')).toBe(false);
    stop();
    // disposal restores the pre-install value
    expect(root.hasAttribute('data-nx-popup-over-header')).toBe(true);
  } finally {vi.unstubAllGlobals();}
});

it('fits Rename inside the actual scrolled code viewport and restores its width', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div');
    const sc=document.createElement('div');sc.className='editor-scrollable';
    const widget=document.createElement('div');widget.className='rename-box';widget.style.minWidth='200px';
    sc.append(widget);root.append(sc);document.body.append(root);
    root.getBoundingClientRect=()=>({left:95,right:231,top:154,bottom:560,width:136,height:406}) as DOMRect;
    sc.getBoundingClientRect=()=>({left:144,right:231,top:154,bottom:560,width:87,height:406}) as DOMRect;
    widget.getBoundingClientRect=()=>({left:-35+(parseFloat(widget.style.translate)||0),top:214,width:parseFloat(widget.style.width)||202,height:32}) as DOMRect;
    const stop=keepSuggestionsInViewport(root);await Promise.resolve();
    expect(widget.style.minWidth).toBe('0px');
    expect(widget.style.width).toBe('85px');
    expect(widget.style.translate).toBe('179px 0px');
    widget.style.display='none';root.dispatchEvent(new Event('scroll'));await Promise.resolve();
    expect(widget.style.translate).toMatch(/^0px( 0px)?$/);
    widget.style.display='block';root.dispatchEvent(new Event('scroll'));await Promise.resolve();
    expect(widget.style.translate).toBe('179px 0px');
    stop();expect(widget.style.minWidth).toBe('200px');expect(widget.style.width).toBe('');expect(widget.style.translate).toBe('');root.remove();
  } finally {vi.unstubAllGlobals();}
});

it('gives narrow symbol pickers pane width and restores native layout when widened', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div');const widget=document.createElement('div');widget.className='quick-input-widget';
    const category=document.createElement('div');category.className='quick-input-list-separator';category.textContent='symbols (1)';const entry=document.createElement('div');entry.className='quick-input-list-entry';const keybinding=document.createElement('div');keybinding.className='quick-input-list-entry-keybinding';keybinding.style.display='flex';entry.append(category,keybinding);widget.append(entry);root.append(widget);document.body.append(root);
    widget.style.width='84px';widget.style.left='26px';let width=136;
    root.getBoundingClientRect=()=>({left:0,right:width,top:0,bottom:400,width,height:400}) as DOMRect;
    const stop=keepSuggestionsInViewport(root);await Promise.resolve();
    expect(widget.style.width).toBe('128px');expect(widget.style.left).toBe('4px');expect(category.style.display).toBe('none');expect(keybinding.style.display).toBe('none');
    width=250;root.dispatchEvent(new Event('scroll'));await Promise.resolve();expect(widget.style.width).toBe('242px');expect(category.style.display).toBe('');expect(keybinding.style.display).toBe('flex');
    width=600;root.dispatchEvent(new Event('scroll'));await Promise.resolve();expect(widget.style.width).toBe('84px');expect(widget.style.left).toBe('26px');
    stop();root.remove();
  } finally {vi.unstubAllGlobals();}
});

it('fits compact Find/Replace fields without losing actions and restores native widths', async () => {
  vi.stubGlobal('MutationObserver', class {observe(){} disconnect(){}});
  vi.stubGlobal('ResizeObserver', class {observe(){} disconnect(){}});
  try {
    const root=document.createElement('div'),widget=document.createElement('div');widget.className='find-widget visible';
    widget.style.width='419px';widget.style.right='16px';
    const part=document.createElement('div');part.className='find-part';
    const replacePart=document.createElement('div');replacePart.className='replace-part';
    const input=document.createElement('div');input.className='monaco-findInput';input.style.width='100px';
    const controls=document.createElement('div');controls.className='controls';input.append(controls);
    const next=document.createElement('div');next.className='codicon-find-next-match';
    const replace=document.createElement('div');replace.className='codicon-find-replace-all';part.append(input,next,replace);widget.append(part,replacePart);root.append(widget);document.body.append(root);
    let width=136;root.getBoundingClientRect=()=>({left:0,right:width,top:0,bottom:400,width,height:400}) as DOMRect;
    const stop=keepSuggestionsInViewport(root);await Promise.resolve();
    expect(widget.style.width).toBe('128px');expect(widget.style.right).toBe('4px');expect(input.style.minWidth).toBe('0px');
    expect(next.style.display).toBe('none');expect(controls.style.display).toBe('none');expect(replace.style.display).toBe('');expect(part.style.marginRight).toBe('25px');expect(replacePart.style.marginRight).toBe('0px');
    width=250;root.dispatchEvent(new Event('scroll'));await Promise.resolve();expect(widget.style.width).toBe('242px');expect(next.style.display).toBe('');expect(part.style.marginRight).toBe('');expect(replacePart.style.marginRight).toBe('');
    width=600;root.dispatchEvent(new Event('scroll'));await Promise.resolve();expect(widget.style.width).toBe('419px');expect(widget.style.right).toBe('16px');expect(input.style.width).toBe('100px');expect(input.style.flex).toBe('');
    width=136;root.dispatchEvent(new Event('scroll'));await Promise.resolve();stop();expect(widget.style.width).toBe('419px');expect(input.style.width).toBe('100px');expect(next.style.display).toBe('');root.remove();
  } finally {vi.unstubAllGlobals();}
});
