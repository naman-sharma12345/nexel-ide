/** View snapshots only, never Monaco editors/models. Entries live while a tab is open. */
export function createDocumentViewStates() {
  const states = new Map<string, unknown>();
  return {
    save(path: string, state: unknown) { if (state != null) states.set(path, state); },
    get(path: string) { return states.get(path); },
    retain(paths: string[]) {
      const open = new Set(paths);
      for (const path of states.keys()) if (!open.has(path)) states.delete(path);
    },
    clear() { states.clear(); },
  };
}
