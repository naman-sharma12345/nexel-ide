import { uriKey } from './clangd/uri';

interface Model {
  uri: { toString(): string };
  getValue(): string;
  onDidChangeContent(cb: () => void): { dispose(): void };
  onWillDispose(cb: () => void): { dispose(): void };
}
interface Tab { filePath: string; content: string }

/** A model can change without a mounted editor (for example multi-file rename).
 * Keep existing buffers current; never create a tab or write a file here. */
export function syncOpenModelBuffers(
  editor: { getModels(): Model[]; onDidCreateModel(cb: (model: Model) => void): { dispose(): void } },
  getTabs: () => Tab[],
  update: (path: string, text: string) => void,
) {
  const subscriptions = new Map<Model, () => void>();
  const track = (model: Model) => {
    if (subscriptions.has(model)) return;
    const change = model.onDidChangeContent(() => {
      const tab = getTabs().find(tab => uriKey(tab.filePath) === uriKey(model.uri.toString()));
      if (!tab) return;
      const text = model.getValue();
      if (text !== tab.content) update(tab.filePath, text);
    });
    const dispose = () => {
      change.dispose();
      end.dispose();
      subscriptions.delete(model);
    };
    const end = model.onWillDispose(dispose);
    subscriptions.set(model, dispose);
  };
  editor.getModels().forEach(track);
  const created = editor.onDidCreateModel(track);
  return () => {
    created.dispose();
    [...subscriptions.values()].forEach(dispose => dispose());
  };
}
