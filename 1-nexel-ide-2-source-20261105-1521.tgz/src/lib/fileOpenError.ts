/** Keep expected filesystem failures readable; unexpected diagnostics stay visible. */
export function fileOpenError(path: string, error: unknown): string {
 const name=path.split(/[\\/]/).pop()||path;
 // Electron wraps invoke() rejections as "Error invoking remote method 'x': Error: msg" - show msg.
 const message=(error instanceof Error?error.message:'').replace(/^Error invoking remote method '[^']+': (Error: )?/,'');
 const code=typeof error==='object'&&error!==null&&'code' in error?String(error.code):message.match(/^(ENOENT|EACCES|EPERM|EISDIR)(?=:|$)/)?.[1];
 if(code==='ENOENT')return `Could not open ${name}. The file was moved or deleted. Refresh Explorer and try again.`;
 if(code==='EACCES'||code==='EPERM')return `Could not open ${name}. Access was denied. Check the file permissions and try again.`;
 if(code==='EISDIR')return `Could not open ${name}. This path is a folder, not a file. Refresh Explorer and choose a file.`;
 if(message.startsWith('File is being replaced.')||message.startsWith('File changed during opening.'))return `${name}: ${message}`;
 return message?`Could not open ${name}: ${message}`:`Could not open ${name}. Try again.`;
}
