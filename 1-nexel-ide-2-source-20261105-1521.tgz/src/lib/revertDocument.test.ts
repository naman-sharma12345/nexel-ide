import {it,expect,vi,afterEach} from 'vitest';
import {useEditorStore} from '../stores/useEditorStore';
import {revertDocument} from './revertDocument';
afterEach(()=>vi.restoreAllMocks());
it.each(['normal','typing','undo','reopened','closed'] as const)('revert applies only to the unchanged tab: %s',async mode=>{
 useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});const store=useEditorStore.getState();store.openFile('/a.txt','a.txt','baseline');store.updateTabContent('/a.txt','dirty');let finish!:(s:string)=>void;vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(()=>new Promise<string>(r=>finish=r));const task=revertDocument('/a.txt');
 if(mode==='typing'||mode==='undo'){store.updateTabContent('/a.txt','newer');if(mode==='undo')store.updateTabContent('/a.txt','dirty');}else if(mode==='reopened'||mode==='closed'){store.closeTab('/a.txt');if(mode==='reopened')store.openFile('/a.txt','a.txt','reopened bytes');}finish('external');const result=await task;
 const tab=useEditorStore.getState().tabs[0];expect(result).toBe(mode==='normal'?'reverted':'changed');if(mode==='normal'){expect(tab.content).toBe('external');expect(tab.isDirty).toBe(false);}else if(mode==='closed')expect(tab).toBeUndefined();else expect(tab.content).toBe(mode==='typing'?'newer':mode==='undo'?'dirty':'reopened bytes');
});
it('keeps a dirty buffer and baseline when disk cannot be read',async()=>{
 useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});const store=useEditorStore.getState();store.openFile('/revert-fail.txt','revert-fail.txt','baseline');store.updateTabContent('/revert-fail.txt','dirty');const before=useEditorStore.getState().tabs[0];vi.spyOn(window.nexelAPI,'readFileContent').mockRejectedValue(new Error('EACCES'));
 await expect(revertDocument('/revert-fail.txt')).rejects.toThrow('EACCES');expect(useEditorStore.getState().tabs[0]).toBe(before);
});
it('applies a pending Revert without moving a newer focused document',async()=>{
 useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});const store=useEditorStore.getState();store.openFile('/revert-focus.txt','revert-focus.txt','baseline');store.updateTabContent('/revert-focus.txt','dirty');let finish!:(s:string)=>void;vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(()=>new Promise<string>(r=>finish=r));const task=revertDocument('/revert-focus.txt');store.openFile('/b.txt','b.txt','other');finish('disk');await expect(task).resolves.toBe('reverted');expect(useEditorStore.getState().focusedTabPath).toBe('/b.txt');expect(useEditorStore.getState().tabs[0]).toMatchObject({content:'disk',isDirty:false});
});
