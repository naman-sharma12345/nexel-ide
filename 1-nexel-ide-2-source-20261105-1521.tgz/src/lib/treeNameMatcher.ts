import { isRiskyRegex } from './searchInFiles';

export interface TreeNameMatcher {
  test: (name: string) => boolean;
  error: string | null;
}

const NEVER = () => false;

/** Compile the Explorer find-in-tree query once. Invalid regex reports an error instead of silently matching nothing. */
export function createTreeNameMatcher(query: string, isRegex: boolean, matchCase: boolean): TreeNameMatcher {
  if (!query) return { test: NEVER, error: null };
  if (isRegex) {
    if (isRiskyRegex(query)) return { test: NEVER, error: 'nested repeat can freeze the app' };
    try {
      const reg = new RegExp(query, matchCase ? '' : 'i');
      return { test: (name) => reg.test(name), error: null };
    } catch (e) {
      const msg = e instanceof Error ? e.message.replace(/^Invalid regular expression:\s*/, '').replace(/^\/.*\/[a-z]*:\s*/s, '') : 'Invalid pattern';
      return { test: NEVER, error: msg };
    }
  }
  const q = matchCase ? query : query.toLowerCase();
  return { test: (name) => (matchCase ? name : name.toLowerCase()).includes(q), error: null };
}
