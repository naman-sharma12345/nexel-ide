import { webcrypto } from 'node:crypto';
import { beforeEach as beforeFingerprintTest, vi as fingerprintVi } from 'vitest';
beforeFingerprintTest(() => fingerprintVi.stubGlobal('crypto', webcrypto));
import { describe, it, expect } from 'vitest';
import { buildMatcher, searchText, searchFiles, DEFAULT_LIMITS } from './searchInFiles';

describe('searchInFiles', () => {
  it('escapes literals and rejects bad regex', () => {
    expect(buildMatcher('a.b')!.test('a.b')).toBe(true);
    expect(buildMatcher('a.b')!.test('axb')).toBe(false);
    expect(buildMatcher('(', { regex: true })).toBeNull();
    expect(buildMatcher('')).toBeNull();
  });
  it('finds positions, honours case and whole word', () => {
    const ms = searchText('int Foo;\nfoo foobar', buildMatcher('foo', { wholeWord: true })!, 10);
    expect(ms.map(m => [m.line, m.col])).toEqual([[1, 5], [2, 1]]);
    expect(searchText('Foo foo', buildMatcher('foo', { caseSensitive: true })!, 10)).toHaveLength(1);
  });
  it('does not hang on zero-width regex', () => {
    expect(searchText('abc', buildMatcher('x*', { regex: true })!, 10)).toHaveLength(0);
  });
  it('searches many files with caps, skips binary and aborts', async () => {
    const files = [{ path: '/b.cpp', name: 'b.cpp' }, { path: '/a.cpp', name: 'a.cpp' }, { path: '/x.png', name: 'x.png' }, { path: '/bin.dat', name: 'bin.dat' }];
    const data: Record<string, string> = { '/a.cpp': 'vector<int> v;', '/b.cpp': 'vector<long> w;\nvector<x>', '/x.png': 'vector', '/bin.dat': 'vec\u0000tor vector' };
    const r = await searchFiles(files, async p => data[p], 'vector');
    expect(r.results.map(x => x.name)).toEqual(['a.cpp', 'b.cpp']);
    expect(r.total).toBe(3);
    const capped = await searchFiles(files, async p => data[p], 'vector', {}, undefined, { ...DEFAULT_LIMITS, maxMatches: 1, concurrency: 1 });
    expect(capped.truncated).toBe(true);
    const ac = new AbortController(); ac.abort();
    expect((await searchFiles(files, async p => data[p], 'vector', {}, ac.signal)).results).toHaveLength(0);
  });
});
it('keeps absolute columns separate from bounded long-line preview coordinates',()=>{
 const [match]=searchText('x'.repeat(600)+'TARGET'+'z'.repeat(300),buildMatcher('TARGET')!,10);
 expect(match.col).toBe(601);expect(match.text.length).toBeLessThanOrEqual(DEFAULT_LIMITS.maxLineChars);
 const local=match.col-1-(match.previewOffset??0);expect(match.text.slice(local,local+match.length)).toBe('TARGET');
});
it('counts unreadable and large/binary content instead of hiding incomplete coverage',async()=>{
 const files=['bad','large','binary','good'].map(name=>({path:'/'+name,name}));
 const r=await searchFiles(files,async path=>{if(path==='/bad')throw Error('denied');return path==='/large'?'x'.repeat(100):path==='/binary'?'\0':'TARGET';},'TARGET',{},undefined,{...DEFAULT_LIMITS,maxFileBytes:20});
 expect(r.unreadable).toBe(1);expect(r.skippedContent).toBe(2);expect(r.total).toBe(1);
});
it('does not collect results or start another read after cancellation during a read',async()=>{
 const ac=new AbortController();let finish!:(text:string)=>void;const calls:string[]=[];
 const pending=searchFiles([{path:'/one',name:'one'},{path:'/two',name:'two'}],path=>{calls.push(path);return new Promise(r=>{finish=r;});},'TARGET',{},ac.signal,{...DEFAULT_LIMITS,concurrency:1});
 ac.abort();finish('TARGET');const result=await pending;expect(calls).toEqual(['/one']);expect(result.total).toBe(0);
});

import { isRiskyRegex, buildMatcher as _bm } from './searchInFiles';
import { describe as _d, it as _it, expect as _e } from 'vitest';
_d('isRiskyRegex', () => {
  _it('flags nested unbounded quantifiers', () => {
    for (const q of ['(a+)+', '(.*)*', '(\\w+\\s*)+$', '(a{2,})+']) _e(isRiskyRegex(q)).toBe(true);
  });
  _it('allows ordinary patterns', () => {
    for (const q of ['foo\\d+', '(foo|bar)+', '(ab)*c', '\\(a+\\)+', '[(a+)+]', 'x+y*']) _e(isRiskyRegex(q)).toBe(false);
  });
  _it('buildMatcher refuses risky regex but not the same text as a literal', () => {
    _e(_bm('(a+)+', { regex: true })).toBeNull();
    _e(_bm('(a+)+', {})).not.toBeNull();
  });
});

it('fingerprints exact preview text and keeps concurrent results inside the cap',async()=>{
 const {sourceFingerprint}=await import('./searchInFiles');
 expect(await sourceFingerprint('VALUE\r\n')).not.toBe(await sourceFingerprint('VALUE\n'));
 expect(await sourceFingerprint('\ud800')).not.toBe(await sourceFingerprint('\ufffd'));
 const files=Array.from({length:8},(_,i)=>({path:'/work/'+i,name:String(i)}));
 const result=await searchFiles(files,async()=> 'VALUE VALUE','VALUE',{},undefined,{...DEFAULT_LIMITS,maxMatches:3});
 expect(result.total).toBe(3);expect(result.results.reduce((n,f)=>n+f.matches.length,0)).toBe(3);expect(result.truncated).toBe(true);
 expect(result.results[0].sourceFingerprint).toBe(await sourceFingerprint('VALUE VALUE'));
});
it('keeps search readable without crypto while leaving replacement fingerprints absent',async()=>{
 fingerprintVi.stubGlobal('crypto',{});
 const result=await searchFiles([{path:'/work/a',name:'a'}],async()=> 'VALUE','VALUE');
 expect(result.total).toBe(1);expect(result.results[0].sourceFingerprint).toBeUndefined();
});
