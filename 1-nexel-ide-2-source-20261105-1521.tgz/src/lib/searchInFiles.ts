/**
 * Find-in-files engine. Pure + dependency-injected so it is unit-testable and the
 * renderer never gains new filesystem powers: it reuses the already-validated
 * readFileContent IPC. Bounded on every axis (files, bytes, matches, concurrency)
 * and cancellable through an AbortSignal — a "bounded buffer + worker pool" shape.
 */
export interface SearchOptions { caseSensitive?: boolean; regex?: boolean; wholeWord?: boolean; }
export interface SearchMatch { line: number; col: number; length: number; text: string; previewOffset?: number; }
export interface FileResult { path: string; name: string; matches: SearchMatch[]; sourceFingerprint?: string; }
export interface SearchReport { results: FileResult[]; total:number; truncated:boolean; unreadable:number; skippedContent:number; timedOut?:number; regexUnavailable?:boolean; }
export interface SearchLimits { maxMatches: number; maxFiles: number; maxFileBytes: number; concurrency: number; maxLineChars: number; }
export const DEFAULT_LIMITS: SearchLimits = { maxMatches: 500, maxFiles: 2000, maxFileBytes: 1_000_000, concurrency: 8, maxLineChars: 240 };
const SKIP_EXT = /\.(png|jpe?g|gif|webp|ico|exe|dll|so|o|obj|bin|zip|7z|gz|mp4|mp3|pdf|woff2?|ttf)$/i;

/**
 * Heuristic guard for catastrophic backtracking: a quantified group whose body itself
 * contains an unbounded quantifier, e.g. (a+)+, (.*)*, (\w+\s*)+. A synchronous regex
 * exec cannot be aborted, so such a pattern would freeze the renderer. Heuristic only:
 * it does not catch every ReDoS shape (e.g. overlapping alternation like (a|a)*).
 */
export function isRiskyRegex(query: string): boolean {
  const src = query.replace(/\\./g, '_').replace(/\[[^\]]*\]/g, '_');
  return /\((?:[^()]*[*+]|[^()]*\{\d+,\d*\})[^()]*\)(?:[*+]|\{\d+,\d*\})/.test(src);
}

/** Builds a safe global RegExp, or null if the pattern is invalid / empty. Escapes literals so users can't ReDoS themselves by accident. */
export function buildMatcher(query: string, opts: SearchOptions = {}): RegExp | null {
  if (!query) return null;
  if (opts.regex && isRiskyRegex(query)) return null;
  try {
    let src = opts.regex ? query : query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (opts.wholeWord) src = `\\b(?:${src})\\b`;
    return new RegExp(src, 'g' + (opts.caseSensitive ? '' : 'i'));
  } catch { return null; }
}

export function searchText(content: string, re: RegExp, cap: number, maxLineChars = 240): SearchMatch[] {
  const out: SearchMatch[] = [];
  const lines = content.split(/\r?\n/);
  for (let i = 0; i < lines.length && out.length < cap; i++) {
    const line = lines[i];
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line)) && out.length < cap) {
      if (m[0].length === 0) { re.lastIndex++; continue; } // avoid infinite loop on zero-width matches
      const previewOffset = line.length > maxLineChars ? Math.max(0, m.index - 60) : 0;
      out.push({ line: i + 1, col: m.index + 1, length: m[0].length, text: line.slice(previewOffset, previewOffset + maxLineChars), previewOffset });
    }
  }
  return out;
}

/** SHA-256 of exact UTF-16 units. Bounded digest avoids retaining every source
 * file in the result list; missing crypto leaves search usable but fails closed for replacement. */
export async function sourceFingerprint(content: string): Promise<string> {
  const units = new Uint8Array(content.length * 2);
  for (let i = 0; i < content.length; i++) {
    const unit = content.charCodeAt(i);
    units[2 * i] = unit & 255; units[2 * i + 1] = unit >>> 8;
  }
  const digest = await crypto.subtle.digest('SHA-256', units);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

export async function searchFiles(
  files: Array<{ path: string; name: string }>,
  read: (path: string) => Promise<string>,
  query: string,
  opts: SearchOptions = {},
  signal?: AbortSignal,
  limits: SearchLimits = DEFAULT_LIMITS,
  onProgress?: (results: FileResult[], done: number, total: number) => void,
  runner?: import('./regexRunner').RegexRunner,
): Promise<SearchReport> {
  const re = buildMatcher(query, opts);
  const results: FileResult[] = [];
  if (!re) return { results, total:0,truncated:false,unreadable:0,skippedContent:0 };
  // Regex execution cannot be interrupted, so it is only allowed through an isolated runner.
  if (opts.regex && !runner) return { results, total:0,truncated:true,unreadable:0,skippedContent:0,timedOut:0,regexUnavailable:true };
  const queue = files.filter(f => !SKIP_EXT.test(f.name)).slice(0, limits.maxFiles);
  let unreadable=0,skippedContent=0,timedOut=0,unavailable=false;
  let total = 0, next = 0, done = 0, truncated = files.length > limits.maxFiles;
  const worker = async () => {
    while (!signal?.aborted && !unavailable && total < limits.maxMatches) {
      const f = queue[next++]; if (!f) return;
      try {
        const content = await read(f.path);
        if(signal?.aborted) return;
        if (content.length > limits.maxFileBytes || content.includes('\u0000')) { skippedContent++;continue; } // skip huge / binary files
        let ms: SearchMatch[];
        if (runner && opts.regex) {
          const r = await runner.run(content, re.source, re.flags, limits.maxMatches - total, limits.maxLineChars, signal);
          if (signal?.aborted) return;
          if (r === 'unavailable') { unavailable = true; return; }
          if (r === 'timeout') { timedOut++; done++; onProgress?.(results, done, queue.length); continue; }
          ms = r;
        } else ms = searchText(content, new RegExp(re.source, re.flags), limits.maxMatches - total, limits.maxLineChars);
        if (ms.length) {
          let fingerprint: string | undefined;
          try { fingerprint = await sourceFingerprint(content); } catch { /* search remains usable; replacement refuses */ }
          if (signal?.aborted) return;
          // Other files may have completed while the digest/worker was pending.
          ms = ms.slice(0, Math.max(0, limits.maxMatches - total));
          if (!ms.length) continue;
          total += ms.length; results.push({ path: f.path, name: f.name, matches: ms, sourceFingerprint: fingerprint });
        }
      } catch { if(signal?.aborted) return;unreadable++; }
      done++; onProgress?.(results, done, queue.length);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limits.concurrency, queue.length) }, worker));
  if (total >= limits.maxMatches || timedOut > 0) truncated = true;
  if (unavailable) return { results: [], total: 0, truncated: true, unreadable, skippedContent, timedOut, regexUnavailable: true };
  results.sort((a, b) => a.path.localeCompare(b.path));
  return { results, total, truncated,unreadable,skippedContent,timedOut };
}
