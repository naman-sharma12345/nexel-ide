let navigationVersion=0;
/** Explicit navigation invalidates pending reads even when the path is unchanged. */
export function invalidateDocumentOpen(){navigationVersion++;}
/** A late document read must not replace a newer navigation or workspace. */
export function createOpenRequestGuard(){
 let latest=0;
 return {begin(workspace:string|null){invalidateDocumentOpen();const navigation=navigationVersion,request=++latest;return(currentWorkspace:string|null)=>request===latest&&navigation===navigationVersion&&workspace===currentWorkspace;}};
}
