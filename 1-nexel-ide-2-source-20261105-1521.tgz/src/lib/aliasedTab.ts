import type { EditorTab } from '../stores/useEditorStore';

/**
 * Finds an already-open tab for the same file spelled differently (e.g. through
 * a symlinked ancestor: a clangd definition path, or this workspace previously
 * opened under another spelling), so the caller can focus that tab instead of
 * opening a second buffer of one file. Comparison is by resolved path only:
 * no canonicalization, no model merge, and unresolvable paths (new/gone files)
 * simply produce no match. `realPath` is injectable for tests.
 */
export async function findAliasedTab(
  tabs: EditorTab[],
  filePath: string,
  realPath: (p: string) => Promise<string>,
): Promise<EditorTab | null> {
  let resolved: string;
  try {
    resolved = await realPath(filePath);
  } catch {
    return null;
  }
  for (const tab of tabs) {
    if (tab.filePath === filePath) return tab;
    try {
      if (await realPath(tab.filePath) === resolved) return tab;
    } catch { /* tab file unreadable/gone: not a match */ }
  }
  return null;
}
