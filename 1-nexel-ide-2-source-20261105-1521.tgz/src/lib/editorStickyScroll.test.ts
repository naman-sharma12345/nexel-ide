import { expect, it, vi } from 'vitest';
import type { editor } from 'monaco-editor';
import { resetStickyScrollOnModelChange } from './editorStickyScroll';
function setup(enabled?: boolean) {
  let change = () => {}, dispose = () => {};
  const unsubscribe = vi.fn(), unregister = vi.fn();
  const instance = {
    getRawOptions: () => ({ stickyScroll: { enabled, maxLineCount: 3 } }),
    updateOptions: vi.fn(),
    onDidChangeModel: (cb: () => void) => { change = cb; return { dispose: unsubscribe }; },
    onDidDispose: (cb: () => void) => { dispose = cb; return { dispose: unregister }; },
  };
  resetStickyScrollOnModelChange(instance as unknown as editor.IStandaloneCodeEditor);
  return { instance, change: () => change(), dispose: () => dispose(), unsubscribe, unregister };
}
it('resets enabled sticky rows synchronously on every model swap without replacing models', () => {
  const f = setup(); f.change(); f.change();
  expect(f.instance.updateOptions.mock.calls).toEqual([
    [{ stickyScroll: { enabled: false, maxLineCount: 3 } }], [{ stickyScroll: { enabled: true, maxLineCount: 3 } }],
    [{ stickyScroll: { enabled: false, maxLineCount: 3 } }], [{ stickyScroll: { enabled: true, maxLineCount: 3 } }],
  ]);
});
it('honors disabled sticky scroll and cleans up listeners on disposal', () => {
  const f = setup(false); f.change(); expect(f.instance.updateOptions).not.toHaveBeenCalled();
  f.dispose(); expect(f.unsubscribe).toHaveBeenCalledOnce(); expect(f.unregister).toHaveBeenCalledOnce();
});
