import { buildMatcher, type SearchOptions } from './searchInFiles';
/** Replace all matches in text. Literal mode treats `$` in the replacement literally; regex mode supports $1 groups. */
function replaceLineWithRegExp(content: string, re: RegExp, replacement: string, regexMode: boolean): { text: string; count: number } {
  let count = 0;
  const text = content.replace(re, (...args) => {
    const m = args[0] as string;
    if (m.length === 0) return m;
    count++;
    if (!regexMode) return replacement;
    const hasNamed = typeof args[args.length - 1] === 'object';
    const groups = args.slice(1, hasNamed ? -3 : -2) as Array<string | undefined>;
    return replacement.replace(/\$(\d{1,2}|&|\$)/g, (token, k: string) => {
      if (k === '$') return '$';
      if (k === '&') return m;
      const index = Number(k);
      if (index > 0 && index <= groups.length) return groups[index - 1] ?? '';
      const first = Number(k[0]);
      if (k.length === 2 && first > 0 && first <= groups.length) return (groups[first - 1] ?? '') + k[1];
      return token; // nonexistent captures are literal, never silent deletion
    });
  });
  return { text, count };
}

/** Preview searches each line independently. Replacement must have the same
 * scope, including anchors and whitespace classes, and retain original EOLs. */
export function replaceWithRegExp(content: string, re: RegExp, replacement: string, regexMode: boolean): { text: string; count: number } {
  let count = 0;
  const parts = content.split(/(\r?\n)/);
  for (let i = 0; i < parts.length; i += 2) {
    re.lastIndex = 0;
    const result = replaceLineWithRegExp(parts[i], re, replacement, regexMode);
    parts[i] = result.text;
    count += result.count;
  }
  return { text: parts.join(''), count };
}

export function replaceInText(content: string, query: string, replacement: string, opts: SearchOptions = {}): { text: string; count: number } {
  const re = buildMatcher(query, opts);
  if (!re) return { text: content, count: 0 };
  return replaceWithRegExp(content, re, replacement, Boolean(opts.regex));
}
