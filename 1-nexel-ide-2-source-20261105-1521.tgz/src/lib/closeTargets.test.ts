import {expect,it} from 'vitest';
import {closeTargets} from './closeTargets';
it('uses focused right document rather than left active document',()=>{
  const paths=['left','right','third'];expect(closeTargets(paths,'right','others')).toEqual(['left','third']);expect(closeTargets(paths,'right','left')).toEqual(['left']);expect(closeTargets(paths,'right','right')).toEqual(['third']);
});
it('returns independent snapshots and no arbitrary target for missing focus',()=>{
  const paths=['left','right'];const targets=closeTargets(paths,'right','others');paths.push('new');expect(targets).toEqual(['left']);expect(closeTargets(paths,null,'others')).toEqual([]);expect(closeTargets(paths,null,'all')).toEqual(paths);expect(closeTargets(paths,null,'one','right')).toEqual(['right']);
});
