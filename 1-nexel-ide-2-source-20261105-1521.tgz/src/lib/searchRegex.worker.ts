import { searchText } from './searchInFiles';
import { replaceWithRegExp } from './replaceInText';
self.postMessage({ ready: true });
type Msg = { id: number; kind?: 'search' | 'replace' | 'names'; names?: string[]; content: string; source: string; flags: string; cap: number; maxLineChars: number; replacement?: string; regexMode?: boolean };
self.onmessage = ({ data }: { data: Msg }) => {
  try {
    const re = new RegExp(data.source, data.flags);
    if (data.kind === 'names') self.postMessage({ id: data.id, matchedNames: (data.names ?? []).filter(n => re.test(n)) });
    else if (data.kind === 'replace') self.postMessage({ id: data.id, replaced: replaceWithRegExp(data.content, re, data.replacement ?? '', Boolean(data.regexMode)) });
    else self.postMessage({ id: data.id, matches: searchText(data.content, re, data.cap, data.maxLineChars) });
  } catch (e) {
    self.postMessage({ id: data.id, error: e instanceof Error ? e.message : 'failed' });
  }
};
