import { beforeEach, expect, it, vi } from 'vitest';
import { useEditorStore } from '../stores/useEditorStore';
import { saveDocument } from './saveDocument';
beforeEach(() => { useEditorStore.getState().closeAllTabs(); useEditorStore.getState().openFile('/work/a.py','a.py','original'); });
it('keeps typing dirty while an older snapshot finishes saving', async () => {
  let finish!: (v: boolean) => void;
  window.nexelAPI.writeFileContent = vi.fn(() => new Promise<boolean>(r => { finish = r; }));
  useEditorStore.getState().updateTabContent('/work/a.py','first');
  const saved = saveDocument('/work/a.py','first'); await new Promise(r=>setTimeout(r,0));
  useEditorStore.getState().updateTabContent('/work/a.py','second'); finish(true); await saved;
  expect(useEditorStore.getState().tabs[0]).toMatchObject({content:'second',originalContent:'first',isDirty:true});
});
it('orders concurrent saves and never clears dirty state on false or rejected writes', async () => {
  let finish!: (v: boolean) => void;
  const write = vi.fn().mockImplementationOnce(() => new Promise<boolean>(r => { finish = r; })).mockResolvedValueOnce(true).mockResolvedValueOnce(false);
  window.nexelAPI.writeFileContent = write;
  useEditorStore.getState().updateTabContent('/work/a.py','second');
  const first=saveDocument('/work/a.py','first'), second=saveDocument('/work/a.py','second');
  await new Promise(r=>setTimeout(r,0)); expect(write).toHaveBeenCalledTimes(1);
  finish(true); await first; await second;
  expect(write.mock.calls.map(c=>c[1])).toEqual(['first','second']);
  expect(useEditorStore.getState().tabs[0].isDirty).toBe(false);
  useEditorStore.getState().updateTabContent('/work/a.py','third');
  await expect(saveDocument('/work/a.py','third')).rejects.toThrow('not confirmed');
  expect(useEditorStore.getState().tabs[0].isDirty).toBe(true);
});
