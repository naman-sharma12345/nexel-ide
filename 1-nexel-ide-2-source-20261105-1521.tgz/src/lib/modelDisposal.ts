import { monaco } from './monacoSetup';
import { pathToUri } from './clangd/uri';

/**
 * Monaco's loader keeps a model alive after its last tab closes (cached by
 * URI), so every activated-then-closed document would otherwise retain its
 * full text for the rest of the session. This module bounds that: the most
 * recent closed documents keep their models (a quick accidental close+reopen
 * restores the document with its undo history), older ones are disposed.
 *
 * Ownership rules: never dispose a model whose path is open again, that a
 * mounted editor still holds, or a virtual document (nexel://, cf://). If an
 * editor holds the model when cleanup runs (React mid-swap), disposal waits
 * for that editor's model change instead of being dropped. Disposal is
 * deferred a tick so React can settle after the store update.
 */
export const MAX_RETAINED_CLOSED_MODELS = 3;

const retainedClosed: string[] = [];

function liveModel(uri: string) {
  return monaco.editor.getModels().find(m => m.uri.toString() === uri);
}

function disposeIfOrphaned(path: string, uri: string, openPaths: () => string[]) {
  if (openPaths().includes(path)) return;
  const model = liveModel(uri);
  if (!model) return;
  const holder = monaco.editor.getEditors().find(e => e.getModel() === model);
  if (holder) {
    const sub = holder.onDidChangeModel(() => {
      sub.dispose();
      disposeIfOrphaned(path, uri, openPaths);
    });
    return;
  }
  model.dispose();
}

export function disposeModelsForClosedPaths(closedPaths: string[], openPaths: () => string[]) {
  for (const path of closedPaths) {
    if (path.startsWith('nexel://') || path.startsWith('cf://')) continue;
    const uri = pathToUri(path).toString();
    setTimeout(() => {
      if (openPaths().includes(path)) return;
      if (!liveModel(uri)) return;
      const idx = retainedClosed.indexOf(path);
      if (idx !== -1) retainedClosed.splice(idx, 1);
      retainedClosed.push(path);
      while (retainedClosed.length > MAX_RETAINED_CLOSED_MODELS) {
        const evict = retainedClosed.shift()!;
        disposeIfOrphaned(evict, pathToUri(evict).toString(), openPaths);
      }
    }, 0);
  }
}

/** Test hook: reset the retention FIFO between tests. */
export function __resetClosedModelRetention() {
  retainedClosed.length = 0;
}
