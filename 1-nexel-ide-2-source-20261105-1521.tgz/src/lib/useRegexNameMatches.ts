import { useEffect, useState } from 'react';
import { createWorkerRegexRunner, regexIsolationAvailable } from './regexRunner';

export interface NameMatchState { matched: Set<string>; error: string | null; pending: boolean; }
const IDLE: NameMatchState = { matched: new Set(), error: null, pending: false };

/**
 * Regex find-in-tree matching off the UI thread. Runs only when `active`; a pattern that
 * exceeds the worker budget is killed and reported instead of freezing the window.
 * Results are keyed to the inputs so a stale answer is never shown for a newer query.
 */
export function useRegexNameMatches(names: string[], source: string, flags: string, active: boolean): NameMatchState {
  const key = JSON.stringify([names, source, flags]);
  const [out, setOut] = useState<{ key: string; matched: Set<string>; error: string | null } | null>(null);
  useEffect(() => {
    if (!active || !regexIsolationAvailable()) return;
    const ac = new AbortController();
    const runner = createWorkerRegexRunner();
    const t = window.setTimeout(async () => {
      const r = await runner.matchNames(names, source, flags, ac.signal);
      if (ac.signal.aborted) return;
      setOut(r === 'timeout' || r === 'unavailable'
        ? { key, matched: new Set(), error: r === 'unavailable' ? 'regex find unavailable here' : 'too slow (750ms)' }
        : { key, matched: new Set(r), error: null });
    }, 120);
    return () => { ac.abort(); window.clearTimeout(t); runner.dispose(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, active]);
  if (!active) return IDLE;
  if (!regexIsolationAvailable()) return { matched: new Set(), error: 'regex find unavailable here', pending: false };
  if (out?.key !== key) return { matched: new Set(), error: null, pending: true };
  return { matched: out.matched, error: out.error, pending: false };
}
