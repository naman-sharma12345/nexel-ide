/** Bundled code face: identical metrics online and offline on every supported OS. */
export const CODE_FONT_FAMILY = '"JetBrains Mono", "Nexel Emoji", "Apple Color Emoji", "Segoe UI Emoji", ui-monospace, Consolas, monospace';
export const CODE_LINE_HEIGHT = 22;
