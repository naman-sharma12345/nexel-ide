import {describe, it, expect} from 'vitest';
import {createDocumentViewStates} from './documentViewState';
describe('document view snapshot lifetime', () => {
  it('keeps independent split states and replaces the latest snapshot', () => {
    const views = createDocumentViewStates();
    views.save('/left', {line: 2}); views.save('/right', {line: 80});
    views.save('/left', {line: 7});
    expect(views.get('/right')).toEqual({line: 80});
    expect(views.get('/left')).toEqual({line: 7});
  });
  it('bounds snapshots to open documents and clears teardown state', () => {
    const views = createDocumentViewStates();
    for (let i = 0; i < 1000; i++) {views.save(`/closed-${i}`, {});views.retain(['/keep']);}
    expect(views.get('/closed-999')).toBeUndefined();
    views.save('/keep', {line: 80}); views.save('/keep', null);
    expect(views.get('/keep')).toEqual({line: 80});
    views.clear(); expect(views.get('/keep')).toBeUndefined();
  });
});
