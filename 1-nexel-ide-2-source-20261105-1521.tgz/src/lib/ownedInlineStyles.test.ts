import {it, expect} from 'vitest';
import {ownInlineStyles} from './ownedInlineStyles';
it('restores preexisting values and priority, removes only newly owned declarations', () => {
  const node=document.createElement('div');node.style.setProperty('max-width','330px','important');
  const owner=ownInlineStyles();owner.set(node,'max-width','306px');owner.set(node,'translate','0px 48px');owner.restore();
  expect(node.style.maxWidth).toBe('330px');expect(node.style.getPropertyPriority('max-width')).toBe('important');expect(node.style.translate).toBe('');
});
it('leaves newer external writes alone on cleanup', () => {
  const node=document.createElement('div');const owner=ownInlineStyles();owner.set(node,'animation','none');node.style.animation='new-animation 1s';owner.restore();
  expect(node.style.animation).toBe('new-animation 1s');
});
it('adopts a newer external value when it needs to write again', () => {
  const node=document.createElement('div');node.style.maxHeight='200px';const owner=ownInlineStyles();owner.set(node,'max-height','90px');node.style.maxHeight='150px';owner.set(node,'max-height','80px');owner.restore();
  expect(node.style.maxHeight).toBe('150px');owner.restore();expect(node.style.maxHeight).toBe('150px');
});

it('releases 1000 removed widget declarations before whole-editor teardown', () => {
  const root=document.createElement('div'),owner=ownInlineStyles();
  for(let i=0;i<1000;i++){
    const node=document.createElement('div');node.style.maxWidth='330px';root.append(node);
    owner.set(node,'max-width','306px');node.remove();owner.retain(root);
    expect(node.style.maxWidth).toBe('330px');
    // A subsequent write is no longer ours, even after the original value recurs.
    node.style.maxWidth='306px';owner.restore();expect(node.style.maxWidth).toBe('306px');
  }
});
it('retains a moved-but-still-owned child and preserves newer writes on removal', () => {
  const root=document.createElement('div'),child=document.createElement('div');root.append(child);const owner=ownInlineStyles();
  owner.set(child,'animation','none');owner.retain(root);expect(child.style.animation).toBe('none');
  child.style.animation='new-animation 1s';child.remove();owner.retain(root);expect(child.style.animation).toBe('new-animation 1s');
});
