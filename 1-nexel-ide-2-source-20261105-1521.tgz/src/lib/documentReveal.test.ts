import {expect,it} from 'vitest';
import {requestDocumentReveal,takeDocumentReveal,onDocumentReveal} from './documentReveal';
it('retains navigation through mount delay and refuses a different document',()=>{
 requestDocumentReveal({path:'/work/new.py',line:20,col:601});expect(takeDocumentReveal('/work/old.py')).toBeNull();
 expect(takeDocumentReveal('/work/new.py')).toEqual({path:'/work/new.py',line:20,col:601});expect(takeDocumentReveal('/work/new.py')).toBeNull();
});
it('only latest navigation is pending and subscriptions release',()=>{
 let calls=0;const off=onDocumentReveal(()=>calls++);requestDocumentReveal({path:'/a',line:1,col:1});requestDocumentReveal({path:'/b',line:2,col:3});off();expect(calls).toBe(2);expect(takeDocumentReveal('/a')).toBeNull();expect(takeDocumentReveal('/b')?.col).toBe(3);requestDocumentReveal({path:'/c',line:1,col:1});expect(calls).toBe(2);takeDocumentReveal('/c');
});
