/** Restore only declarations that still carry our last write. */
export function ownInlineStyles() {
  const nodes = new Map<HTMLElement, Map<string, {value: string; priority: string; written: string; writtenPriority: string}>>();
  const restoreNode = (node: HTMLElement, properties: Map<string, {value: string; priority: string; written: string; writtenPriority: string}>) => {
    for (const [property, previous] of properties) {
      if (node.style.getPropertyValue(property) !== previous.written || node.style.getPropertyPriority(property) !== previous.writtenPriority) continue;
      if (previous.value) node.style.setProperty(property, previous.value, previous.priority);
      else node.style.removeProperty(property);
    }
  };
  return {
    /** Release removed widgets without waiting for the whole editor to close. */
    retain(root: HTMLElement) {
      for (const [node, properties] of nodes) if (!root.contains(node)) {restoreNode(node, properties);nodes.delete(node);}
    },
    set(node: HTMLElement, property: string, value: string, priority = '') {
      let properties = nodes.get(node);
      if (!properties) {properties = new Map();nodes.set(node, properties);}
      let previous = properties.get(property);
      const current = node.style.getPropertyValue(property), currentPriority = node.style.getPropertyPriority(property);
      if (!previous || current !== previous.written || currentPriority !== previous.writtenPriority) {
        previous = {value: current, priority: currentPriority, written: value, writtenPriority: priority};
        properties.set(property, previous);
      }
      previous.written = value;previous.writtenPriority = priority;
      if (current !== value || currentPriority !== priority) node.style.setProperty(property, value, priority);
    },
    restore() {
      for (const [node, properties] of nodes) restoreNode(node, properties);
      nodes.clear();
    },
  };
}
