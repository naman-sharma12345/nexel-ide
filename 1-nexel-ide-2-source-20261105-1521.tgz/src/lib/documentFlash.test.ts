import {afterEach,expect,it,vi} from 'vitest';
import {createDocumentFlash} from './documentFlash';
afterEach(()=>vi.useRealTimers());
it('keeps a second jump highlighted for its full interval',()=>{
 vi.useFakeTimers();let count=0;const delta=vi.fn((_old:string[],decorations:unknown[])=>decorations.length?[String(++count)]:[]);
 const flash=createDocumentFlash({deltaDecorations:delta});flash.show(1);vi.advanceTimersByTime(850);flash.show(2);const before=delta.mock.calls.length;vi.advanceTimersByTime(650);expect(delta.mock.calls.length).toBe(before);vi.advanceTimersByTime(750);expect(delta).toHaveBeenLastCalledWith(['2'],[]);
});
it('keeps editor ownership separate and cancels timers on disposal',()=>{
 vi.useFakeTimers();const a=vi.fn((_ids:string[],d:unknown[])=>d.length?['a']:[]),b=vi.fn((_ids:string[],d:unknown[])=>d.length?['b']:[]);
 const left=createDocumentFlash({deltaDecorations:a}),right=createDocumentFlash({deltaDecorations:b});left.show(1);right.show(2);left.dispose();const calls=a.mock.calls.length;vi.advanceTimersByTime(1400);expect(a.mock.calls.length).toBe(calls);expect(b).toHaveBeenLastCalledWith(['b'],[]);
});
