import {it,expect,vi} from 'vitest';import {syncOpenModelBuffers} from './modelBufferSync';
it('syncs inactive model changes to existing buffers only, including undo, and disposes listeners',()=>{
 let value='old',change=()=>{};const remove=vi.fn();const model={uri:{toString:()=> 'file:///tmp/a.cpp'},getValue:()=>value,onDidChangeContent:(cb:()=>void)=>{change=cb;return{dispose:remove};},onWillDispose:()=>({dispose:remove})};
 let tabs=[{filePath:'/tmp/a.cpp',content:'old'}];const update=vi.fn((path,text)=>{tabs=[{filePath:path,content:text}];});const created=vi.fn();const dispose=syncOpenModelBuffers({getModels:()=>[model],onDidCreateModel:()=>({dispose:created})},()=>tabs,update);
 change();expect(update).not.toHaveBeenCalled();value='renamed';change();expect(update).toHaveBeenLastCalledWith('/tmp/a.cpp','renamed');value='old';change();expect(tabs[0].content).toBe('old');tabs=[];value='closed';change();expect(update).toHaveBeenCalledTimes(2);dispose();expect(remove).toHaveBeenCalledTimes(2);expect(created).toHaveBeenCalledOnce();
});

it('subscribes to later models and stops observing them when disposed',()=>{
 let created!:(model:Parameters<Parameters<typeof syncOpenModelBuffers>[0]['onDidCreateModel']>[0] extends (model:infer M)=>void?M:never)=>void,changed=()=>{},destroy=()=>{};
 const off=vi.fn(),update=vi.fn();
 const model={uri:{toString:()=> 'file:///tmp/later.cpp'},getValue:()=> 'edited',onDidChangeContent:(cb:()=>void)=>{changed=cb;return{dispose:off};},onWillDispose:(cb:()=>void)=>{destroy=cb;return{dispose:off};}};
 const stop=syncOpenModelBuffers({getModels:()=>[],onDidCreateModel:cb=>{created=cb;return{dispose:vi.fn()};}},()=>[{filePath:'/tmp/later.cpp',content:'initial'}],update);
 created(model);changed();expect(update).toHaveBeenCalledWith('/tmp/later.cpp','edited');destroy();expect(off).toHaveBeenCalledTimes(2);stop();expect(off).toHaveBeenCalledTimes(2);
});
