export interface DocumentReveal { path: string; line: number; col: number; }
let pending: DocumentReveal | null = null;
const listeners = new Set<() => void>();
const norm = (path: string) => path.replace(/\\/g, '/');
/** Latest navigation waits for its own editor/model, not a guessed mount delay. */
export function requestDocumentReveal(request: DocumentReveal) {
  pending = request;
  for (const listener of listeners) listener();
}
export function takeDocumentReveal(path: string): DocumentReveal | null {
  if (!pending || norm(pending.path) !== norm(path)) return null;
  const request = pending; pending = null; return request;
}
export function onDocumentReveal(listener: () => void): () => void {
  listeners.add(listener); return () => { listeners.delete(listener); };
}
