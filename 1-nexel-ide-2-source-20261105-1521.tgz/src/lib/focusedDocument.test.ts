import {expect,it} from 'vitest';
import {focusedDocument,visibleDocumentPaths} from './focusedDocument';
import type {EditorTab} from '../stores/useEditorStore';
const tabs:EditorTab[]=['/left','/right','/hidden'].map(filePath=>({filePath,name:filePath,content:'',originalContent:'',isDirty:true}));
const state={tabs,activeTabPath:'/left',focusedTabPath:'/right',isSplit:true,rightTabPath:'/right'};
it('targets the focused right pane without changing the left document',()=>{expect(focusedDocument(state)?.filePath).toBe('/right');expect(focusedDocument({...state,focusedTabPath:'/left'})?.filePath).toBe('/left');});
it('refuses stale hidden or removed focused documents',()=>{expect(focusedDocument({...state,isSplit:false})?.filePath).toBe('/left');expect(focusedDocument({...state,focusedTabPath:'/hidden'})?.filePath).toBe('/left');expect(focusedDocument({...state,tabs:tabs.slice(0,1)})?.filePath).toBe('/left');});

it('cycles from focused right and keeps a right-owned target out of the left pane',async()=>{
 const {cycleDocument}=await import('./focusedDocument');
 expect(cycleDocument({...state,tabs:tabs.slice(0,2)},1)).toEqual({activeTabPath:'/left',focusedTabPath:'/left'});
 expect(cycleDocument({...state,focusedTabPath:'/left'},1)).toEqual({activeTabPath:'/left',focusedTabPath:'/right'});
 expect(cycleDocument(state,-1)).toEqual({activeTabPath:'/left',focusedTabPath:'/left'});
 expect(cycleDocument({...state,tabs:[]},1)).toBeNull();
});

it('only exposes current panes for native focus synchronization',()=>{expect(visibleDocumentPaths(state)).toEqual(['/left','/right']);expect(visibleDocumentPaths({...state,isSplit:false})).toEqual(['/left']);expect(visibleDocumentPaths({activeTabPath:null,isSplit:false,rightTabPath:'/right'})).toEqual([]);});
