// @vitest-environment node
import { describe, it, expect } from 'vitest';
import { withSaveLock, withGitOp, isGitOpActive } from '../gitOpLock';

const deferred = <T>() => {
  let resolve!: (v: T) => void;
  const promise = new Promise<T>((r) => { resolve = r; });
  return { promise, resolve };
};

describe('gitOpLock serialization', () => {
  it('git op waits for an inflight save before mutating', async () => {
    const order: string[] = [];
    const save = deferred<string>();
    const saveDone = withSaveLock(async () => { const v = await save.promise; order.push('save-write'); return v; });
    const opDone = withGitOp(async () => { order.push('git-op'); });
    save.resolve('ok');
    await Promise.all([saveDone, opDone]);
    expect(order).toEqual(['save-write', 'git-op']);
  });

  it('save started during a git op waits for the op to finish', async () => {
    const order: string[] = [];
    const op = deferred<void>();
    const opDone = withGitOp(async () => { order.push('git-op-start'); await op.promise; order.push('git-op-end'); });
    await new Promise((r) => setTimeout(r, 10)); // let the op get in
    const saveDone = withSaveLock(async () => { order.push('save-write'); });
    op.resolve();
    await Promise.all([opDone, saveDone]);
    expect(order).toEqual(['git-op-start', 'git-op-end', 'save-write']);
  });

  it('saves serialize among themselves', async () => {
    const order: string[] = [];
    const a = deferred<void>(); const b = deferred<void>();
    const d1 = withSaveLock(async () => { order.push('a-start'); await a.promise; order.push('a-end'); });
    const d2 = withSaveLock(async () => { order.push('b-start'); await b.promise; order.push('b-end'); });
    b.resolve(); a.resolve(); // even if the second would finish first
    await Promise.all([d1, d2]);
    expect(order).toEqual(['a-start', 'a-end', 'b-start', 'b-end']);
  });

  it('git ops serialize among themselves and isGitOpActive tracks them', async () => {
    const order: string[] = [];
    const a = deferred<void>();
    const d1 = withGitOp(async () => { expect(isGitOpActive()).toBe(true); order.push('op1'); await a.promise; });
    const d2 = withGitOp(async () => { order.push('op2'); });
    a.resolve();
    await Promise.all([d1, d2]);
    expect(order).toEqual(['op1', 'op2']);
    expect(isGitOpActive()).toBe(false);
  });
});
