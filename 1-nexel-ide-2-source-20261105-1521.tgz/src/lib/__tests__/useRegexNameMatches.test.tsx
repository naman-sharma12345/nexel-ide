import { describe, it, expect, vi, afterEach } from 'vitest';
import { renderHook, act, cleanup } from '@testing-library/react';
import { useRegexNameMatches } from '../useRegexNameMatches';
import { REGEX_FILE_TIMEOUT_MS } from '../regexRunner';

class W {
  static all: W[] = [];
  onmessage: ((e: { data: any }) => void) | null = null;
  onerror: (() => void) | null = null;
  terminate = vi.fn();
  postMessage = vi.fn();
  constructor() { W.all.push(this); queueMicrotask(() => this.onmessage?.({ data: { ready: true } })); }
}
afterEach(() => { cleanup(); vi.useRealTimers(); vi.unstubAllGlobals(); W.all = []; });

describe('useRegexNameMatches', () => {
  it('returns matched names from the worker and hides stale results on a new query', async () => {
    vi.useFakeTimers(); vi.stubGlobal('Worker', W);
    const r = renderHook(({ src }) => useRegexNameMatches(['a.py', 'b.py'], src, 'i', true), { initialProps: { src: '^a' } });
    expect(r.result.current.pending).toBe(true);
    await act(async () => { await vi.advanceTimersByTimeAsync(130); });
    const msg = W.all[0].postMessage.mock.calls[0][0];
    expect(msg).toMatchObject({ kind: 'names', names: ['a.py', 'b.py'] });
    await act(async () => { W.all[0].onmessage!({ data: { id: msg.id, matchedNames: ['a.py'] } }); });
    expect(r.result.current.matched.has('a.py')).toBe(true);
    r.rerender({ src: '^b' });
    expect(r.result.current.matched.size).toBe(0);
    expect(r.result.current.pending).toBe(true);
  });
  it('reports a timeout error without matches', async () => {
    vi.useFakeTimers(); vi.stubGlobal('Worker', W);
    const r = renderHook(() => useRegexNameMatches(['x'], '(a|a)*$', 'i', true));
    await act(async () => { await vi.advanceTimersByTimeAsync(130); });
    await act(async () => { await vi.advanceTimersByTimeAsync(REGEX_FILE_TIMEOUT_MS + 5); });
    expect(r.result.current.error).toMatch(/750ms/);
    expect(r.result.current.matched.size).toBe(0);
    expect(W.all[0].terminate).toHaveBeenCalled();
  });
  it('does nothing when inactive', () => {
    vi.stubGlobal('Worker', W);
    renderHook(() => useRegexNameMatches(['x'], 'x', 'i', false));
    expect(W.all).toHaveLength(0);
  });
});
