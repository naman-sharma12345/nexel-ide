import { describe, it, expect } from 'vitest';
import { escapeSequenceLength } from '../terminalInput';

describe('escapeSequenceLength', () => {
  it('measures CSI sequences up to and including the final byte', () => {
    expect(escapeSequenceLength('\x1b[A', 0)).toBe(3);      // Up
    expect(escapeSequenceLength('\x1b[3~', 0)).toBe(4);     // Delete
    expect(escapeSequenceLength('\x1b[1;5D', 0)).toBe(6);   // Ctrl+Left
  });
  it('measures SS3 and Alt-style sequences', () => {
    expect(escapeSequenceLength('\x1bOP', 0)).toBe(3);      // F1
    expect(escapeSequenceLength('\x1bx', 0)).toBe(2);       // Alt+x
  });
  it('forwards a lone ESC immediately (never stashed)', () => {
    expect(escapeSequenceLength('\x1b', 0)).toBe(1);
  });
  it('reports chunk-ended CSI/SS3 as incomplete for stashing', () => {
    expect(escapeSequenceLength('\x1b[', 0)).toBe('incomplete');
    expect(escapeSequenceLength('\x1b[1;5', 0)).toBe('incomplete');
    expect(escapeSequenceLength('\x1bO', 0)).toBe('incomplete');
  });
  it('degrades malformed CSI to the lone ESC so parsing resumes after it', () => {
    expect(escapeSequenceLength('\x1b[\x01A', 0)).toBe(1);
  });
  it('measures a sequence at a non-zero offset inside a mixed chunk', () => {
    expect(escapeSequenceLength('ab\x1b[Dcd', 2)).toBe(3);
  });
});
