import { describe, it, expect } from 'vitest';
import { createTreeNameMatcher } from '../treeNameMatcher';

describe('createTreeNameMatcher', () => {
  it('matches substrings case-insensitively by default', () => {
    const m = createTreeNameMatcher('READ', false, false);
    expect(m.test('readme.md')).toBe(true);
    expect(m.error).toBeNull();
  });
  it('respects match case', () => {
    expect(createTreeNameMatcher('READ', false, true).test('readme.md')).toBe(false);
  });
  it('compiles regex and respects flags', () => {
    expect(createTreeNameMatcher('^src\\d$', true, false).test('SRC1')).toBe(true);
    expect(createTreeNameMatcher('^src\\d$', true, true).test('SRC1')).toBe(false);
  });
  it('reports invalid regex without throwing or matching', () => {
    const m = createTreeNameMatcher('(', true, false);
    expect(m.error).toBeTruthy();
    expect(m.test('(')).toBe(false);
  });
  it('empty query matches nothing and has no error', () => {
    const m = createTreeNameMatcher('', true, false);
    expect(m.test('a')).toBe(false);
    expect(m.error).toBeNull();
  });
});

describe('error message', () => {
  it('drops the echoed pattern prefix', () => {
    const m = createTreeNameMatcher('al(', true, false);
    expect(m.error).not.toMatch(/al\(/);
  });
});

describe('risky regex', () => {
  it('refuses nested-quantifier patterns without executing them', () => {
    const m = createTreeNameMatcher('(a+)+$', true, false);
    expect(m.error).toMatch(/freeze/);
    expect(m.test('a'.repeat(40) + '!')).toBe(false);
  });
  it('still treats the same text literally when regex is off', () => {
    expect(createTreeNameMatcher('(a+)+', false, false).test('x(a+)+y')).toBe(true);
  });
});
