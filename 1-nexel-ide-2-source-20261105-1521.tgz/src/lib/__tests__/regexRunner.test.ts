import { webcrypto } from 'node:crypto';
import { beforeEach as beforeFingerprintTest, vi as fingerprintVi } from 'vitest';
beforeFingerprintTest(() => fingerprintVi.stubGlobal('crypto', webcrypto));
import { describe, it, expect, vi, afterEach } from 'vitest';
import { createWorkerRegexRunner, REGEX_FILE_TIMEOUT_MS } from '../regexRunner';
import { searchFiles } from '../searchInFiles';

class W {
  static all: W[] = [];
  onmessage: ((e: { data: any }) => void) | null = null;
  onerror: (() => void) | null = null;
  terminate = vi.fn();
  postMessage = vi.fn();
  constructor() { W.all.push(this); queueMicrotask(() => this.onmessage?.({ data: { ready: true } })); }
}
afterEach(() => { vi.useRealTimers(); W.all = []; });
const mk = () => createWorkerRegexRunner(() => new W() as unknown as Worker);

describe('regex runner', () => {
  it('returns worker matches', async () => {
    const r = mk();
    const p = r.run('aaa', 'a', 'g', 10, 240);
    await vi.waitFor(() => expect(W.all[0].postMessage).toHaveBeenCalled());
    const { id } = W.all[0].postMessage.mock.calls[0][0];
    W.all[0].onmessage!({ data: { id, matches: [{ line: 1, col: 1, length: 1, text: 'a' }] } });
    expect(await p).toHaveLength(1);
    r.dispose();
  });
  it('times out, terminates, and uses a fresh worker for the next call', async () => {
    vi.useFakeTimers();
    const r = mk();
    const p = r.run('x', '(a|a)*$', 'g', 10, 240);
    await vi.advanceTimersByTimeAsync(10);
    await vi.advanceTimersByTimeAsync(REGEX_FILE_TIMEOUT_MS + 1);
    expect(await p).toBe('timeout');
    expect(W.all[0].terminate).toHaveBeenCalled();
    const p2 = r.run('x', 'a', 'g', 10, 240);
    await vi.advanceTimersByTimeAsync(10);
    expect(W.all).toHaveLength(2);
    r.dispose();
    void p2;
  });
  it('searchFiles marks a timed-out file, blocks replace via truncated, and keeps other files', async () => {
    const runner = { run: vi.fn(async (c: string) => (c === 'slow' ? 'timeout' as const : [{ line: 1, col: 1, length: 1, text: 'a' }])), replace: vi.fn(), dispose: vi.fn() } as any;
    const rep = await searchFiles([{ path: '/a', name: 'a' }, { path: '/b', name: 'b' }], async p => (p === '/a' ? 'slow' : 'fast'), 'a', { regex: true }, undefined, undefined, undefined, runner);
    expect(rep.timedOut).toBe(1);
    expect(rep.truncated).toBe(true);
    expect(rep.results.map(x => x.path)).toEqual(['/b']);
  });
  it('literal searches never use the runner', async () => {
    const runner = { run: vi.fn(), dispose: vi.fn() };
    await searchFiles([{ path: '/a', name: 'a' }], async () => 'aaa', 'a', {}, undefined, undefined, undefined, runner as any);
    expect(runner.run).not.toHaveBeenCalled();
  });
});

describe('replace through the runner', () => {
  it('returns replaced text, and times out like search', async () => {
    vi.useFakeTimers();
    const r = mk();
    const p = r.replace('aaa', 'a', 'g', 'b', true);
    await vi.advanceTimersByTimeAsync(10);
    const msg = W.all[0].postMessage.mock.calls[0][0];
    expect(msg).toMatchObject({ kind: 'replace', replacement: 'b', regexMode: true });
    W.all[0].onmessage!({ data: { id: msg.id, replaced: { text: 'bbb', count: 3 } } });
    expect(await p).toEqual({ text: 'bbb', count: 3 });
    const p2 = r.replace('x', '(a|a)*$', 'g', 'b', true);
    await vi.advanceTimersByTimeAsync(10);
    await vi.advanceTimersByTimeAsync(REGEX_FILE_TIMEOUT_MS + 1);
    expect(await p2).toBe('timeout');
    r.dispose();
  });
});

describe('missing isolation', () => {
  it('searchFiles refuses regex without a runner and reads nothing', async () => {
    const read = vi.fn(async () => 'aaa');
    const rep = await searchFiles([{ path: '/a', name: 'a' }], read, 'a+', { regex: true });
    expect(rep.regexUnavailable).toBe(true);
    expect(read).not.toHaveBeenCalled();
  });
  it('a worker that never starts reports unavailable, not a pattern timeout', async () => {
    vi.useFakeTimers();
    const r = createWorkerRegexRunner(() => { throw new Error('no worker'); });
    const rep = await searchFiles([{ path: '/a', name: 'a' }], async () => 'aaa', 'a+', { regex: true }, undefined, undefined, undefined, r);
    expect(rep.regexUnavailable).toBe(true);
    expect(rep.timedOut).toBe(0);
  });
});

it('settles active and queued calls immediately on dispose',async()=>{
 vi.useFakeTimers();const r=mk();const running=r.run('aaa','a','g',10,240);const queued=r.replace('aaa','a','g','b',true);
 await vi.advanceTimersByTimeAsync(1);expect(W.all[0].postMessage).toHaveBeenCalledTimes(1);
 r.dispose();expect(await running).toEqual([]);expect(await queued).toBe('timeout');
 expect(vi.getTimerCount()).toBe(0);expect(W.all[0].terminate).toHaveBeenCalled();
});
it('settles startup on dispose without waiting five seconds',async()=>{
 vi.useFakeTimers();const worker={onmessage:null,onerror:null,terminate:vi.fn(),postMessage:vi.fn()};
 const r=createWorkerRegexRunner(()=>worker as unknown as Worker);const p=r.run('aaa','a','g',10,240);
 await vi.advanceTimersByTimeAsync(1);r.dispose();expect(await p).toEqual([]);expect(worker.postMessage).not.toHaveBeenCalled();expect(vi.getTimerCount()).toBe(0);
});
it('does not post a job whose signal was aborted during startup',async()=>{
 vi.useFakeTimers();let onmessage:((e:any)=>void)|null=null;const worker={get onmessage(){return onmessage;},set onmessage(v){onmessage=v;},onerror:null,terminate:vi.fn(),postMessage:vi.fn()};
 const r=createWorkerRegexRunner(()=>worker as unknown as Worker);const ac=new AbortController();const p=r.run('aaa','a','g',10,240,ac.signal);
 await vi.advanceTimersByTimeAsync(1);ac.abort();worker.onmessage?.({data:{ready:true}});
 expect(await p).toEqual([]);expect(worker.postMessage).not.toHaveBeenCalled();r.dispose();expect(vi.getTimerCount()).toBe(0);
});
it('settles failed worker dispatch as unavailable and recreates a worker for the next call',async()=>{
 vi.useFakeTimers();const r=mk();const first=r.run('aaa','a','g',10,240);await Promise.resolve();await Promise.resolve();W.all[0].postMessage.mockImplementationOnce(()=>{throw new Error('dispatch refused');});
 expect(await first).toBe('unavailable');expect(W.all[0].terminate).toHaveBeenCalled();expect(vi.getTimerCount()).toBe(0);
 const second=r.run('bbb','b','g',10,240);await vi.advanceTimersByTimeAsync(1);expect(W.all).toHaveLength(2);const msg=W.all[1].postMessage.mock.calls[0][0];W.all[1].onmessage!({data:{id:msg.id,matches:[{line:1,col:1,length:1,text:'b'}]}});expect(await second).toHaveLength(1);r.dispose();expect(vi.getTimerCount()).toBe(0);
});
it('refuses replacement dispatch failure without returning writable text',async()=>{
 vi.useFakeTimers();const r=mk();const pending=r.replace('aaa','a','g','b',true);await Promise.resolve();await Promise.resolve();W.all[0].postMessage.mockImplementationOnce(()=>{throw new Error('replacement dispatch refused');});expect(await pending).toBe('unavailable');expect(W.all[0].terminate).toHaveBeenCalled();expect(vi.getTimerCount()).toBe(0);r.dispose();
});
