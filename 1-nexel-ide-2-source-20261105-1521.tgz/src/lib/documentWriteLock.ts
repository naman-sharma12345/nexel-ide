// Local bulk-write reservation. Opening a document while replacement owns its
// disk snapshot is refused rather than creating a stale editor buffer.
const reserved = new Set<string>();
let bulkVersion = 0;
let bulkActive = false;
export function reserveBulkReplacement(): () => void {
  if (bulkActive) throw new Error('Another file operation is running. Try again when it finishes.');
  bulkActive = true; bulkVersion++;
  return () => { bulkActive = false; };
}
export const isDocumentWriteReserved = (path: string) => bulkActive || reserved.has(path);
export function reserveDocumentWrite(path: string): () => void {
  if (reserved.has(path)) throw new Error('Document is already being changed');
  reserved.add(path);
  versions.set(path, (versions.get(path) ?? 0) + 1);
  return () => { reserved.delete(path); };
}
const versions = new Map<string, number>();
export async function readDocumentForOpen(path: string): Promise<string> {
  const version = versions.get(path) ?? 0;
  const bulk = bulkVersion;
  if (bulkActive || reserved.has(path)) throw new Error('A file operation is running. Try opening this file again afterward.');
  const content = await window.nexelAPI.readFileContent(path);
  if (bulkActive || bulk !== bulkVersion || reserved.has(path) || (versions.get(path) ?? 0) !== version) {
    throw new Error('File changed during opening. Try opening it again.');
  }
  return content;
}
