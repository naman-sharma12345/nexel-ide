// Diagnostic-only test hook. Installed solely when the bundle is built with
// VITE_NX_TESTHOOK=1 (the call site is dead-code-eliminated in ordinary builds,
// so this module is not emitted or loaded there). Exposes just enough for the
// native perf probes to drive the production bundle; no credentials or private
// data beyond what the app itself holds.
import { useEditorStore } from '../stores/useEditorStore';
import { monaco } from './monacoSetup';

export function installTestHook() {
  (window as unknown as { __nxTest?: unknown }).__nxTest = { useEditorStore, monaco };
}
