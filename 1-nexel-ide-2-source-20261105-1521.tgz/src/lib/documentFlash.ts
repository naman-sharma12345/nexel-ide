interface FlashEditor {
  deltaDecorations(oldIds: string[], decorations: unknown[]): string[];
}
/** One highlight owner/timer per editor. A prior timeout cannot erase a newer jump. */
export function createDocumentFlash(editor: FlashEditor, duration = 1400) {
  let ids: string[] = [];
  let timer: ReturnType<typeof setTimeout> | undefined;
  const clear = () => {
    if (timer !== undefined) clearTimeout(timer);
    timer = undefined;
    ids = editor.deltaDecorations(ids, []);
  };
  return {
    show(line: number) {
      clear();
      ids = editor.deltaDecorations([], [{ range: { startLineNumber: line, startColumn: 1, endLineNumber: line, endColumn: 1 }, options: { isWholeLine: true, className: 'nx-line-flash' } }]);
      timer = setTimeout(clear, duration);
    },
    clear,
    dispose: clear,
  };
}
