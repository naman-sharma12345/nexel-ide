import { it, expect } from 'vitest';
import { removeLastTerminalGrapheme, terminalBackspaceCells } from './terminalDelete';
it('removes graphemes including accents, flags and joined emoji',()=>{
 for(const suffix of ['🌐','e\u0301','🇮🇳','👩‍💻','界']) expect(removeLastTerminalGrapheme('A'+suffix)).toBe('A');
 expect(removeLastTerminalGrapheme('')).toBe('');
});
it('uses actual xterm cell width including a wide trailing placeholder',()=>{
 const term=(width:number)=>({buffer:{active:{cursorX:4,cursorY:1,baseY:0,getLine:()=>({getCell:(x:number)=>({getWidth:()=>x===3?width:2})})}}});
 expect(terminalBackspaceCells(term(0))).toBe(2);expect(terminalBackspaceCells(term(1))).toBe(1);
});

it('counts all rendered cells of a joined grapheme',()=>{
 const cells=[{text:'A',width:1},{text:'👩‍',width:2},{text:'',width:0},{text:'💻',width:2},{text:'',width:0}];
 const term={buffer:{active:{cursorX:5,cursorY:0,baseY:0,getLine:()=>({getCell:(x:number)=>({getWidth:()=>cells[x].width,getChars:()=>cells[x].text})})}}};
 expect(terminalBackspaceCells(term,'👩‍💻')).toBe(4);
});
it('erases the final cell instead of the preceding cell when wrap is pending',async()=>{
 const {terminalBackspaceSequence}=await import('./terminalDelete');
 const term={cols:4,buffer:{active:{cursorX:4,cursorY:0,baseY:0,getLine:()=>({getCell:()=>({getWidth:()=>1,getChars:()=> 'Z'})})}}};
 expect(terminalBackspaceSequence(term,'Z')).toBe('\x1b[4G \x1b[4G');
});

it('crosses only an actual soft-wrapped row when deleting from column zero',async()=>{
 const {terminalBackspaceSequence}=await import('./terminalDelete');
 let wrapped=true;
 const term={cols:4,buffer:{active:{cursorX:0,cursorY:1,baseY:0,getLine:(y:number)=>({isWrapped:y===1&&wrapped,getCell:()=>({getWidth:()=>1,getChars:()=> 'Z'})})}}};
 expect(terminalBackspaceSequence(term,'Z')).toBe('\x1b[A\x1b[4G \x1b[4G');
 wrapped=false;expect(terminalBackspaceSequence(term,'Z')).toBe('\b \b');
});

it('reads previous-row wide cells through prototype-backed xterm coordinates',async()=>{
 const {terminalBackspaceSequence}=await import('./terminalDelete');
 class Buffer { get baseY(){return 5;} get cursorY(){return 1;} get cursorX(){return 0;}
 getLine(y:number){return {isWrapped:y===6,getCell:(x:number)=>({getWidth:()=>y===5&&x===3?0:2,getChars:()=>y===5&&x===2?'界':''})};}}
 expect(terminalBackspaceSequence({cols:4,buffer:{active:new Buffer()}},'界')).toBe('\x1b[A\x1b[3G  \x1b[3G');
});
