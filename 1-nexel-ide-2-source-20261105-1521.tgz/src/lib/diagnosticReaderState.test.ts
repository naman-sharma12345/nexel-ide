import {it,expect} from 'vitest';
import {explainStaleDiagnostic} from './diagnosticReaderState';
it('labels stale readers, preserves fresh titles, restores owned state on cleanup', async () => {
  const root=document.createElement('div');
  root.innerHTML='<div class="peekview-widget"><div class="peekview-title"><span class="dirname">1 of 1 problem</span></div><div class="marker-widget"><div class="stale">Old error</div></div></div>';
  const title=root.querySelector('.dirname')!,message=root.querySelector('.stale')!;
  const stop=explainStaleDiagnostic(root);expect(title.textContent).toBe('Outdated diagnostic');
  message.classList.remove('stale');await new Promise(r=>setTimeout(r,0));expect(title.textContent).toBe('1 of 1 problem');
  message.classList.add('stale');await new Promise(r=>setTimeout(r,0));expect(title.textContent).toBe('Outdated diagnostic');
  title.textContent='2 of 3 problems';message.classList.remove('stale');await new Promise(r=>setTimeout(r,0));expect(title.textContent).toBe('2 of 3 problems');
  message.classList.add('stale');await new Promise(r=>setTimeout(r,0));stop();expect(title.textContent).toBe('2 of 3 problems');
  message.classList.remove('stale');message.classList.add('stale');await new Promise(r=>setTimeout(r,0));expect(title.textContent).toBe('2 of 3 problems');
});
