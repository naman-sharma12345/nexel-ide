/** Views backed by app data are not files and have no file cursor or encoding. */
export function utilityTabLabel(path?: string): string | null {
  if (path === 'nexel://snippets') return 'Snippet library';
  if (path?.startsWith('cf://')) return 'Problem statement';
  return null;
}
