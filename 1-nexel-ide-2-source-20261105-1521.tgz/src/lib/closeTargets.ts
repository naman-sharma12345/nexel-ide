export type CloseKind = 'one' | 'all' | 'others' | 'right' | 'left';
/** Snapshot exact paths before any confirmation or async save. */
export function closeTargets(paths: string[], focused: string | null, kind: CloseKind, path?: string): string[] {
  if (kind === 'one') return paths.filter(p => p === path);
  if (kind === 'all') return [...paths];
  const index = paths.indexOf(focused ?? '');
  if (index < 0) return [];
  if (kind === 'others') return paths.filter(p => p !== focused);
  return kind === 'right' ? paths.slice(index + 1) : paths.slice(0, index);
}
