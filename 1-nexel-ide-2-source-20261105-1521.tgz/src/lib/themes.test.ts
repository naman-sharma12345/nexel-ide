import { describe, it, expect } from 'vitest';
import { getTheme, monacoThemeData } from './themes';
describe('working code material',()=>{
 it('keeps the original near-black material and legible line numbers in signature theme',()=>{const t=getTheme('nexel'),m=monacoThemeData(t);expect(m.colors['editor.background']).toBe('#08080a');expect(m.colors['editorLineNumber.foreground']).toBe('#758198');expect(m.colors['editor.selectionBackground']).toBe('#8ba8ff2b');});
 it('authors a complete bracket palette for ink and paper only',()=>{for(const id of ['nexel','light']){const m=monacoThemeData(getTheme(id));for(let i=1;i<=6;i++)expect(m.colors).toHaveProperty('editorBracketHighlight.foreground'+i);}expect(monacoThemeData(getTheme('dusk')).colors).not.toHaveProperty('editorBracketHighlight.foreground1');});
});

it('gives signature sticky context the same material without stock black shadows',()=>{for(const id of ['nexel','light']){const m=monacoThemeData(getTheme(id));expect(m.colors['editorStickyScroll.shadow']).toBe('#00000000');expect(m.colors['editorStickyScroll.background']).toBeTruthy();expect(m.colors['editorGutter.background']).toBe(getTheme(id).editorBg);}});

it('uses regular-weight signature syntax and an ink-blue paper keyword',()=>{for(const id of ['nexel','light']){const m=monacoThemeData(getTheme(id));expect(m.rules.find(r=>r.token==='keyword')?.fontStyle).toBe('');}expect(getTheme('light').syntax.keyword).toBe('375D93');expect(monacoThemeData(getTheme('dusk')).rules.find(r=>r.token==='keyword')?.fontStyle).toBe('bold');});
