const segmenter = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
/** Delete one user-perceived character, never half a surrogate/combining group. */
export function removeLastTerminalGrapheme(text: string): string {
  const parts = [...segmenter.segment(text)];
  return parts.length ? text.slice(0, parts[parts.length - 1].index) : text;
}

/** Read xterm's rendered cell width, not a second Unicode width table. */
export function terminalBackspaceCells(term: { buffer?: { active: { cursorX: number; cursorY: number; baseY: number; getLine(y: number): { isWrapped?: boolean; getCell(x: number): { getWidth(): number; getChars?(): string } | undefined } | undefined } } }, removed = ''): number {
  const buffer = term.buffer?.active;
  if (!buffer || buffer.cursorX === 0) return 1;
  const line = buffer.getLine(buffer.baseY + buffer.cursorY);
  let text = '', cells = 0;
  for (let x = buffer.cursorX - 1; x >= 0; x--) {
    const cell = line?.getCell(x);
    cells++;
    if (cell?.getWidth() === 0) continue;
    text = (cell?.getChars?.() ?? '') + text;
    if (!removed || !text || text === removed || !removed.endsWith(text)) return cells;
  }
  return cells || 1;
}

/** xterm keeps cursorX=cols while final-column wrap is pending. A raw BS
 * then skips that final cell. Explicit column movement cancels pending wrap. */
export function terminalBackspaceSequence(term: Parameters<typeof terminalBackspaceCells>[0] & { cols?: number }, removed: string): string {
  const buffer = term.buffer?.active;
  if (buffer && term.cols && buffer.cursorX === 0 && buffer.cursorY > 0 && buffer.getLine(buffer.baseY + buffer.cursorY)?.isWrapped) {
    const previous = { buffer: { active: { baseY: buffer.baseY, cursorX: term.cols, cursorY: buffer.cursorY - 1, getLine: (y: number) => buffer.getLine(y) } } };
    const width = terminalBackspaceCells(previous, removed);
    const column = Math.max(1, term.cols - width + 1);
    return `\x1b[A\x1b[${column}G` + ' '.repeat(width) + `\x1b[${column}G`;
  }
  const cells = terminalBackspaceCells(term, removed);
  const x = buffer?.cursorX;
  if (x !== undefined && term.cols && x >= term.cols) {
    const column = Math.max(1, term.cols - cells + 1);
    return `\x1b[${column}G` + ' '.repeat(cells) + `\x1b[${column}G`;
  }
  return '\b'.repeat(cells) + ' '.repeat(cells) + '\b'.repeat(cells);
}
