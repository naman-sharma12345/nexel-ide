import { describe, it, expect } from 'vitest';
import { genArrayCase, firstDiff } from './stress';
describe('stress', () => {
  it('is deterministic and bounded', () => {
    const o = { maxN: 5, maxV: 9 };
    expect(genArrayCase(7, o)).toBe(genArrayCase(7, o));
    const [n, row] = genArrayCase(7, o).split('\n');
    expect(row.split(' ').length).toBe(+n);
    expect(+n).toBeLessThanOrEqual(5);
  });
  it('finds first diff', () => {
    expect(firstDiff('1\n2\n', '1\n3')).toEqual({ line: 2, a: '2', b: '3' });
    expect(firstDiff('a \n', 'a')).toBeNull();
  });
});

import { runStress } from './stress';
describe('runStress', () => {
  it('passes when both programs agree', async () => {
    const run = async (_f: string, input: string) => ({ out: input.length + '\n', verdict: 'AC' });
    const r = await runStress(run, { solution: 'a', brute: 'b', iterations: 5, maxN: 5, maxV: 9 });
    expect(r.ok).toBe(true); expect(r.ran).toBe(5);
  });
  it('stops at the first mismatch and returns the failing input', async () => {
    let calls = 0;
    const run = async (f: string) => { calls++; return { out: f === 'a' && calls > 4 ? 'X\n' : '1\n', verdict: 'AC' }; };
    const r = await runStress(run, { solution: 'a', brute: 'b', iterations: 50, maxN: 5, maxV: 9 });
    expect(r.ok).toBe(false); expect(r.failure?.verdict).toBe('WA'); expect(r.failure?.diff?.line).toBe(1);
  });
  it('honours abort', async () => {
    const ac = new AbortController(); ac.abort();
    const r = await runStress(async () => ({ out: '', verdict: 'AC' }), { solution: 'a', brute: 'b', iterations: 9, maxN: 5, maxV: 9 }, ac.signal);
    expect(r.stopped).toBe(true);
  });
});

it('stops between brute and solution when cancellation happens during brute execution', async () => {
  const ac = new AbortController();
  const calls: string[] = [];
  const result = await runStress(async file => { calls.push(file); ac.abort(); return { out: '1', verdict: 'AC' }; }, { solution: 'solution', brute: 'brute', iterations: 5, maxN: 5, maxV: 9 }, ac.signal);
  expect(calls).toEqual(['brute']);
  expect(result.stopped).toBe(true);
  expect(result.failure).toBeUndefined();
});

it('keeps compilation failures distinct and never runs the solution after a brute compile failure', async () => {
  const calls:string[]=[];const r=await runStress(async f=>{calls.push(f);return{out:'syntax error',verdict:'CE'};},{solution:'a',brute:'b',iterations:5,maxN:2,maxV:2});
  expect(calls).toEqual(['b']);expect(r.failure?.verdict).toBe('BRUTE-CE');
});


it('retains program diagnostics separately from valid brute stdout', async () => {
  const r=await runStress(async f=>f==='b'?{out:'expected\n',verdict:'AC'}:{out:'partial stdout',verdict:'RE',diagnostics:'RuntimeError: trace'}, {solution:'a',brute:'b',iterations:2,maxN:2,maxV:2});
  expect(r.failure).toMatchObject({expected:'expected\n',actual:'partial stdout',diagnostics:'RuntimeError: trace',verdict:'RE'});
});


it('compares Stress outputs using the existing Judge whitespace policy', () => {
  expect(firstDiff(' 42\n', '42\n')).toBeNull();
  expect(firstDiff('\r\n42 \r\n7\r\n', '42\n7\n')).toBeNull();
  expect(firstDiff(' \n\t', '')).toBeNull();
  expect(firstDiff('42\n 7\n', '42\n7\n')).toEqual({line:2,a:' 7',b:'7'});
  expect(firstDiff('42\n7\n', '42\n8\n')).toEqual({line:2,a:'7',b:'8'});
});
it('does not report an unreproducible mismatch for leading output whitespace', async () => {
  const r=await runStress(async f=>({out:f==='b'?' 42\r\n':'42\n',verdict:'AC'}), {solution:'a',brute:'b',iterations:1,maxN:2,maxV:2});
  expect(r).toMatchObject({ok:true,ran:1});expect(r.failure).toBeUndefined();
});
