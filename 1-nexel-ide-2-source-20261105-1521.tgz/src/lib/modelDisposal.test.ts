import { describe, expect, it, vi, beforeEach } from 'vitest';

type FakeModel = { uri: { toString: () => string }; dispose: () => void; _disposed: boolean };
type FakeEditor = { getModel: () => FakeModel | null; fireModelChange: () => void };
let modelObjs: FakeModel[] = [];
let editorObjs: FakeEditor[] = [];
vi.mock('./monacoSetup', () => ({
  monaco: {
    editor: {
      getModels: () => modelObjs.filter(m => !m._disposed),
      getEditors: () => editorObjs.map(e => ({
        getModel: () => e.getModel(),
        onDidChangeModel: (cb: () => void) => {
          const listeners = (e as unknown as { _ls: (() => void)[] })._ls ??= [];
          listeners.push(cb);
          return { dispose: () => { const i = listeners.indexOf(cb); if (i >= 0) listeners.splice(i, 1); } };
        },
      })),
    },
  },
}));

import { disposeModelsForClosedPaths, __resetClosedModelRetention, MAX_RETAINED_CLOSED_MODELS } from './modelDisposal';
import { useEditorStore, registerModelDisposer } from '../stores/useEditorStore';

const settle = () => new Promise(r => setTimeout(r, 10));
const addModel = (uri: string): FakeModel => {
  const m: FakeModel = { uri: { toString: () => uri }, _disposed: false, dispose() { m._disposed = true; } };
  modelObjs.push(m);
  return m;
};
const addEditor = (model: FakeModel | null): FakeEditor => {
  const listeners: (() => void)[] = [];
  const e: FakeEditor & { _ls?: (() => void)[] } = {
    _ls: listeners,
    getModel: () => model,
    fireModelChange: () => { model = null; listeners.slice().forEach(l => l()); },
  };
  editorObjs.push(e);
  return e;
};

beforeEach(() => {
  modelObjs = [];
  editorObjs = [];
  __resetClosedModelRetention();
});

describe('disposeModelsForClosedPaths (bounded retention)', () => {
  it('retains the most recent closed models within the bound', async () => {
    const m = addModel('file:///ws/a.py');
    disposeModelsForClosedPaths(['/ws/a.py'], () => []);
    await settle();
    expect(m._disposed).toBe(false);
  });
  it('disposes the oldest closed model once the bound is exceeded', async () => {
    const paths = ['a', 'b', 'c', 'd'].map(n => '/ws/' + n + '.py');
    const ms = paths.map(p => addModel('file://' + p));
    disposeModelsForClosedPaths(paths, () => []);
    await settle();
    expect(ms[0]._disposed).toBe(true);
    expect(ms.slice(1).every(m => !m._disposed)).toBe(true);
    expect(MAX_RETAINED_CLOSED_MODELS).toBe(3);
  });
  it('keeps the model when the path was reopened during the settle window', async () => {
    const m = addModel('file:///ws/a.py');
    disposeModelsForClosedPaths(['/ws/a.py'], () => ['/ws/a.py']);
    await settle();
    expect(m._disposed).toBe(false);
  });
  it('eviction never disposes a model whose path is open again', async () => {
    const first = ['a', 'b', 'c'].map(n => '/ws/' + n + '.py');
    const ms = first.map(p => addModel('file://' + p));
    disposeModelsForClosedPaths(first, () => []);
    await settle(); // FIFO [a,b,c], all retained
    const d = addModel('file:///ws/d.py');
    disposeModelsForClosedPaths(['/ws/d.py'], () => ['/ws/a.py']); // 'a' has been reopened
    await settle(); // 'd' joins -> bound exceeded -> 'a' evicted from FIFO but spared (open)
    expect(ms[0]._disposed).toBe(false);
    expect(ms[1]._disposed).toBe(false);
    expect(ms[2]._disposed).toBe(false);
    expect(d._disposed).toBe(false);
    // next close evicts 'b' (oldest still tracked and closed)
    const e = addModel('file:///ws/e.py');
    disposeModelsForClosedPaths(['/ws/e.py'], () => ['/ws/a.py']);
    await settle();
    expect(ms[1]._disposed).toBe(true);
    expect(d._disposed).toBe(false);
    expect(e._disposed).toBe(false);
  });
  it('waits for an editor holding the model, then disposes after detach', async () => {
    const m = addModel('file:///ws/a.py');
    const ed = addEditor(m);
    ['b', 'c', 'd'].forEach(n => addModel('file:///ws/' + n + '.py'));
    disposeModelsForClosedPaths(['/ws/a.py', '/ws/b.py', '/ws/c.py', '/ws/d.py'], () => []);
    await settle();
    expect(m._disposed).toBe(false); // held by editor: not dropped, waiting on detach
    ed.fireModelChange();
    await settle();
    expect(m._disposed).toBe(true);  // eventual cleanup after detach
  });
  it('ignores virtual documents', async () => {
    disposeModelsForClosedPaths(['nexel://snippets', 'cf://{"x":1}'], () => []);
    await settle();
    expect(modelObjs.every(m => !m._disposed)).toBe(true);
  });
});

describe('store wiring', () => {
  const tab = (filePath: string) => ({ filePath, name: filePath.split('/').pop()!, content: '', originalContent: '', isDirty: false });
  it('closeTab reports the closed path to the registered disposer', () => {
    const calls: string[][] = [];
    registerModelDisposer((closed) => { calls.push(closed); });
    useEditorStore.setState({ tabs: [tab('/ws/a.py'), tab('/ws/b.py')], activeTabPath: '/ws/a.py', focusedTabPath: '/ws/a.py', isSplit: false, rightTabPath: null });
    useEditorStore.getState().closeTab('/ws/a.py');
    expect(calls).toEqual([['/ws/a.py']]);
    registerModelDisposer(() => {});
  });
  it('closeAllTabs reports every closed path', () => {
    const calls: string[][] = [];
    registerModelDisposer((closed) => { calls.push(closed); });
    useEditorStore.setState({ tabs: [tab('/ws/a.py'), tab('/ws/b.py')], activeTabPath: '/ws/a.py', focusedTabPath: '/ws/a.py', isSplit: false, rightTabPath: null });
    useEditorStore.getState().closeAllTabs();
    expect(calls).toEqual([['/ws/a.py', '/ws/b.py']]);
    registerModelDisposer(() => {});
  });
});
