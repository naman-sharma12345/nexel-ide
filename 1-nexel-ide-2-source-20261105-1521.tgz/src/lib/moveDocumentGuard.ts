import { useEditorStore } from '../stores/useEditorStore';
import { waitForAllDocumentWrites } from './saveDocument';
import { reserveBulkReplacement } from './documentWriteLock';

/** Until tab/save/LSP identities move together, never leave a buffer on the old path. */
export async function reserveFileMove(
  path: string,
  stillCurrent: () => boolean = () => true,
): Promise<() => void> {
  // Reserve before waiting so a late read cannot open a buffer in the wait gap.
  const release = reserveBulkReplacement();
  try {
    await waitForAllDocumentWrites();
    if (!stillCurrent()) {
      throw new Error('Rename or move was cancelled because its input or workspace changed.');
    }
    const normalized = path.replace(/\\/g, '/').replace(/\/+$/, '');
    const windows = /^[A-Za-z]:\//.test(normalized) || normalized.startsWith('//');
    const fold = (value: string) => windows ? value.toLowerCase() : value;
    const source = fold(normalized);
    const affected = useEditorStore.getState().tabs.filter(tab => {
      const candidate = fold(tab.filePath.replace(/\\/g, '/'));
      return candidate === source || candidate.startsWith(source + '/');
    });
    if (affected.length) {
      throw new Error(`Close ${affected.length === 1 ? 'the open tab' : 'the open tabs'} for this file or folder before renaming or moving it. Save any changes first.`);
    }
    // Alias pass: an open tab may spell the same entry through a symlinked
    // ancestor (e.g. a clangd-returned path), invisible to the lexical check;
    // renaming the source would leave that buffer on a dangling path. Resolve
    // both sides and compare resolved paths. A hardlinked second name resolves
    // to a DIFFERENT path that stays valid after the rename, so inode identity
    // (fileIdentity) is deliberately not used here. Unresolvable paths (gone
    // source/tab file) fall back to the lexical result above.
    const realPath = window.nexelAPI?.realPath;
    if (typeof realPath === 'function') {
      let resolvedSource: string | null = null;
      try { resolvedSource = fold((await realPath(path)).replace(/\\/g, '/').replace(/\/+$/, '')); } catch { resolvedSource = null; }
      if (resolvedSource) {
        for (const tab of useEditorStore.getState().tabs) {
          let resolvedTab: string | null = null;
          try { resolvedTab = fold((await realPath(tab.filePath)).replace(/\\/g, '/').replace(/\/+$/, '')); } catch { continue; }
          if (resolvedTab === resolvedSource || resolvedTab.startsWith(resolvedSource + '/')) {
            throw new Error('Close the open tab for this file or folder before renaming or moving it. Save any changes first.');
          }
        }
      }
    }
    // Revalidate after the realpath IPC awaits: a workspace switch (or an
    // invalidated input) landing during them must not let the caller commit a
    // rename validated against a stale context. New TABS cannot have appeared
    // during the awaits (opens are refused while this reservation is held).
    if (!stillCurrent()) {
      throw new Error('Rename or move was cancelled because its input or workspace changed.');
    }
    return release;
  } catch (error) {
    release();
    throw error;
  }
}
