import {it,expect} from 'vitest';
import {countDocumentLines} from './documentStats';
it('matches existing newline semantics including empty/trailing/CRLF/unicode',()=>{for(const content of ['', 'one','one\n','\n\n','one\r\ntwo\r\n','one\rtwo','one\u2028two','😀\nβ'])expect(countDocumentLines(content)).toBe(content.split('\n').length);});
it('handles large documents without changing count',()=>{expect(countDocumentLines('line\n'.repeat(100000))).toBe(100001);});
