import {expect,it} from 'vitest';
import {tabPathLabels} from './tabPathLabels';
const labels=(paths:string[])=>tabPathLabels(paths.map(filePath=>({filePath,name:filePath.replace(/\\/g,'/').split('/').at(-1)!})));
it('only labels duplicate names and distinguishes matching leaf folders',()=>{
 const result=labels(['/work/api/src/main.py','/work/web/src/main.py','/work/config.py']);
 expect([...result]).toEqual([['/work/api/src/main.py','api/src'],['/work/web/src/main.py','web/src']]);
});
it('handles Windows paths, root files, and unequal parent depths',()=>{
 const result=labels(['C:\\work\\src\\main.py','/work/src/main.py','/main.py']);
 expect(result.get('C:\\work\\src\\main.py')).toBe('C:/work/src');
 expect(result.get('/work/src/main.py')).toBe('work/src');
 expect(result.get('/main.py')).toBe('root');
});
it('does not mutate the tabs and handles an empty list',()=>{
 const tabs=Object.freeze([{name:'a.py',filePath:'/a.py'}]);expect(tabPathLabels(tabs).size).toBe(0);expect(tabPathLabels([]).size).toBe(0);
});
