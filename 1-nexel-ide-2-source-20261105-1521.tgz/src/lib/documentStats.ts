/** Same newline semantics as split('\n').length, without allocating every line. */
export function countDocumentLines(content:string):number {
 let lines=1;
 for(let index=content.indexOf('\n');index!==-1;index=content.indexOf('\n',index+1))lines++;
 return lines;
}
