import type { editor } from 'monaco-editor';

/** Clear the previous document's sticky rows before its new outline is ready.
 * Reuse the editor and its models so cursor, undo and per-file view state survive.
 * Only public options are used; a disabled preference remains disabled.
 */
export function resetStickyScrollOnModelChange(instance: editor.IStandaloneCodeEditor) {
  const subscription = instance.onDidChangeModel(() => {
    const options = instance.getRawOptions().stickyScroll;
    if (options?.enabled === false) return;
    instance.updateOptions({ stickyScroll: { ...options, enabled: false } });
    instance.updateOptions({ stickyScroll: { ...options, enabled: true } });
  });
  const disposal = instance.onDidDispose(() => { subscription.dispose(); disposal.dispose(); });
}
