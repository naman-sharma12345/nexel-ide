/** Session restore: remembers which files were open (paths only, never contents). Single storage slot: the most recent workspace with open files wins. */
export interface Session { root: string; paths: string[]; active: string | null }
const KEY = 'nexel-session-v1';
const MAX_TABS = 24;
const slash = (path:string) => path.replace(/\\/g, '/');
const windowsPath = (path:string) => /^[A-Za-z]:\//.test(slash(path)) || slash(path).startsWith('//');
const norm = (path:string, windows:boolean) => {
  const normalized=slash(path).replace(/\/+$/, '');
  return windows?normalized.toLowerCase():normalized;
};
const invalidPath = (path:string) => path.includes('\0') || slash(path).split('/').some(part=>part==='..'||part==='.');

/** Lexical containment only, not symlink resolution. POSIX paths are case-sensitive. */
export const isInside = (root: string, path: string) => {
  if(invalidPath(root)||invalidPath(path))return false;
  const windows=windowsPath(root),r=norm(root,windows),q=norm(path,windows);
  return q.startsWith(r + '/');
};

/** Validates untrusted JSON from storage: strings only, bounded, and every path must live inside the workspace root. */
export function sanitizeSession(raw: unknown, root: string): Session | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.root !== 'string' || invalidPath(root) || invalidPath(r.root) || norm(r.root,windowsPath(root)) !== norm(root,windowsPath(root)) || !Array.isArray(r.paths)) return null;
  const seen = new Set<string>();
  const paths = r.paths.filter((p): p is string => typeof p === 'string' && p.length < 1024 && isInside(root, p))
    .filter(p => !seen.has(norm(p,windowsPath(root))) && !!seen.add(norm(p,windowsPath(root)))).slice(0, MAX_TABS);
  const active = typeof r.active === 'string'
    ? paths.find(path=>norm(path,windowsPath(root))===norm(r.active as string,windowsPath(root))) ?? paths[0] ?? null
    : paths[0] ?? null;
  return paths.length ? { root, paths, active } : null;
}

/** Builds the session to persist for a root, or null when no open path belongs
    to it. Never stamp a root onto files outside it: with another workspace's
    tabs still open, saving here would clobber the stored session with paths
    that restore as foreign (rejected by sanitizeSession) for this root and
    destroy the previous root's entry. */
export function sessionForRoot(root: string, paths: string[], active: string | null): Session | null {
  const inRoot = paths.filter(p => isInside(root, p));
  if (!inRoot.length) return null;
  return { root, paths: inRoot.slice(0, MAX_TABS), active: active && isInside(root, active) ? active : inRoot[0] };
}

export function saveSession(s: Session, storage: Pick<Storage, 'setItem'> = localStorage) {
  try { storage.setItem(KEY, JSON.stringify({ root: s.root, paths: s.paths.slice(0, MAX_TABS), active: s.active })); } catch { /* quota/private mode: non-fatal */ }
}
export function loadSession(root: string, storage: Pick<Storage, 'getItem'> = localStorage): Session | null {
  try { const t = storage.getItem(KEY); return t ? sanitizeSession(JSON.parse(t), root) : null; } catch { return null; }
}

/** Clears the stored session only when it belongs to this root: the user
    deliberately closed every tab in this workspace, so nothing may resurrect
    on the next launch. A stored session for a DIFFERENT root is left alone
    (all-foreign tab sets must not destroy another workspace's entry). */
export function clearSessionForRoot(root: string, storage: Pick<Storage, 'getItem' | 'removeItem'> = localStorage) {
  try {
    const t = storage.getItem(KEY); if (!t) return;
    const raw = JSON.parse(t) as Record<string, unknown>;
    if (typeof raw.root === 'string' && !invalidPath(raw.root) && !invalidPath(root)
        && norm(raw.root, windowsPath(root)) === norm(root, windowsPath(root))) storage.removeItem(KEY);
  } catch { /* unreadable storage: leave it */ }
}

/** Whether the stored session for `root` may be cleared: only when the SAME
    root stayed current (a root switch into an all-foreign tab set is not the
    user emptying this workspace) AND either in-root tabs were open and are now
    gone (deliberate close of the last in-root tab, even while foreign tabs
    remain) or no tabs are open at all. */
export function shouldClearSession(prevRoot: string | null, hadInRoot: boolean, root: string, tabCount: number): boolean {
  return prevRoot === root && (hadInRoot || tabCount === 0);
}
