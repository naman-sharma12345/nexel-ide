import { beforeEach, describe, expect, it, vi } from 'vitest';
vi.mock('../../stores/electronStorage', () => ({ electronStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} } }));
import { useEditorStore as store } from '../../stores/useEditorStore';
import { captureRenameWorkspace, requirePreviousRenameSaved } from './renameWorkspace';
import { reserveDocumentWrite } from '../documentWriteLock';

function setup() {
  const models = new Map<string, ReturnType<typeof model>>();
  const uri = (path: string) => ({ scheme: 'file', toString: () => 'file://' + path });
  function model(text: string, path: string) {
    return { uri: uri(path), version: 1, getVersionId() { return this.version; }, getValue: () => text, isDisposed: () => false };
  }
  const M = { editor: { getModels: () => [...models.values()], getModel: (u: ReturnType<typeof uri>) => models.get(u.toString()),
    createModel: vi.fn((text: string, _lang: string, u: ReturnType<typeof uri>) => { const m = model(text, u.toString().slice(7)); models.set(u.toString(), m); return m; }) } };
  const edit = (...paths: string[]) => ({ edits: paths.map(p => ({ resource: uri(p), textEdit: { text: 'renamed' }, versionId: undefined as number | undefined })) });
  const read = vi.fn(async () => 'disk');
  const realPath = vi.fn(async (p: string) => p);
  Object.assign(window, { nexelAPI: { readFileContent: read, realPath } });
  return { models, model, M, edit, read, realPath };
}
beforeEach(() => store.setState({ tabs: [], activeTabPath: null, focusedTabPath: null }));
describe('rename staging', () => {
  it('stages unopened targets with clean baselines and preserves dirty open content and focus', async () => {
    const f = setup(); store.getState().openFile('/repo/main.cpp', 'main.cpp', 'original');
    store.getState().updateTabContent('/repo/main.cpp', 'dirty');
    f.models.set('file:///repo/main.cpp', f.model('dirty', '/repo/main.cpp'));
    const result = await captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/main.cpp', '/repo/other.cpp'));
    expect(store.getState().tabs.map(t => [t.content,t.originalContent,t.isDirty])).toEqual([['dirty','original',true],['disk','disk',false]]);
    expect(store.getState().focusedTabPath).toBe('/repo/main.cpp');
    expect(f.read).toHaveBeenCalledTimes(1); expect(result.edits.map(e => e.versionId)).toEqual([1,1]);
  });
  it('does not create models or tabs if any read fails', async () => {
    const f = setup(); f.read.mockRejectedValueOnce(new Error('unreadable'));
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('unreadable');
    expect(f.M.editor.createModel).not.toHaveBeenCalled(); expect(store.getState().tabs).toHaveLength(0);
  });
  it('refuses cancellation, root/session change or closed tabs during reads', async () => {
    for (const kind of ['cancel','tabs']) {
      const f = setup(); let valid = true;
      f.read.mockImplementationOnce(async () => { if(kind==='cancel')valid=false;else store.getState().closeAllTabs(); return 'disk'; });
      await expect(captureRenameWorkspace(f.M, () => valid, '/repo').prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('Documents changed');
      expect(f.M.editor.createModel).not.toHaveBeenCalled();
    }
  });
  it('refuses changed model versions before returning edits', async () => {
    const f = setup(); const m = f.model('old','/repo/a.cpp');f.models.set(m.uri.toString(),m);
    const work = captureRenameWorkspace(f.M, () => true, '/repo');m.version++;
    await expect(work.prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('Documents changed');
  });
  it('does not overwrite differing cached models', async () => {
    const f = setup(); f.models.set('file:///repo/a.cpp', f.model('cached','/repo/a.cpp'));
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('cached file differs');
    expect(store.getState().tabs).toHaveLength(0);
  });
  it('refuses reserved files and out-of-workspace or symlink escape targets', async () => {
    const f = setup(); const release = reserveDocumentWrite('/repo/a.cpp');
    try { await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('file operation'); } finally { release(); }
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/outside/a.cpp'))).rejects.toThrow('outside');
    f.realPath.mockImplementation(async p => p==='/repo/a.cpp'?'/outside/a.cpp':p);
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/a.cpp'))).rejects.toThrow('outside');
    expect(f.M.editor.createModel).not.toHaveBeenCalled();
  });
  it('cleans staged models if creating a later target fails without opening tabs', async () => {
    const f = setup(); const dispose = vi.fn();
    f.M.editor.createModel.mockImplementationOnce((text, _lang, uri) => ({ ...f.model(text, uri.toString().slice(7)), dispose }))
      .mockImplementationOnce(() => { throw new Error('model creation failed'); });
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/a.cpp','/repo/b.cpp'))).rejects.toThrow('model creation failed');
    expect(dispose).toHaveBeenCalledOnce();expect(store.getState().tabs).toHaveLength(0);
  });
  it('reuses an open model when an equivalent URI has a different spelling', async () => {
    const f = setup();store.getState().openFile('C:\\repo\\a.cpp','a.cpp','original');
    const m = f.model('original','/C:/repo/a.cpp'); f.models.set(m.uri.toString(), m);
    f.realPath.mockImplementation(async p => p.replace(/\\/g,'/').replace(/^\/C:/,'C:'));
    const edit = f.edit('/C:/repo/a.cpp'); edit.edits[0].resource = {scheme:'file',toString:()=> 'file:///c%3A/repo/a.cpp'};
    const result = await captureRenameWorkspace(f.M, () => true, 'C:/repo').prepare(edit);
    expect(result.edits[0].resource).toBe(m.uri);expect(f.M.editor.createModel).not.toHaveBeenCalled();
  });
  it('refuses an alias of an existing buffer instead of creating a second writable tab', async () => {
    const f = setup();store.getState().openFile('/repo/link.cpp','link.cpp','dirty');
    f.realPath.mockImplementation(async p => p.endsWith('.cpp')?'/repo/real.cpp':p);
    await expect(captureRenameWorkspace(f.M, () => true, '/repo').prepare(f.edit('/repo/real.cpp'))).rejects.toThrow('aliased');
    expect(store.getState().tabs).toHaveLength(1);
  });
});

it('requires prior rename buffers to be saved while allowing unrelated unsaved edits', () => {
  setup();store.getState().openFile('/repo/a.cpp','a.cpp','old');store.getState().updateTabContent('/repo/a.cpp','new');
  expect(() => requirePreviousRenameSaved(new Set(['/repo/b.cpp']))).not.toThrow();
  expect(() => requirePreviousRenameSaved(new Set(['/repo/a.cpp']))).toThrow('Save the files');
  store.getState().saveTabSuccess('/repo/a.cpp');
  expect(() => requirePreviousRenameSaved(new Set(['/repo/a.cpp']))).not.toThrow();
});
