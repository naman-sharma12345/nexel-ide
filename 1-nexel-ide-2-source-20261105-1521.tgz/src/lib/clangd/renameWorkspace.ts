/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEditorStore } from '../../stores/useEditorStore';
import { readDocumentForOpen, isDocumentWriteReserved } from '../documentWriteLock';
import { uriKey, uriToPath, clangdLanguageFor } from './uri';

/** Snapshot before the server request. Stage every target before Monaco's atomic
 * preflight, keeping dirty buffers authoritative and disk writes in normal Save. */
export function captureRenameWorkspace(monaco: any, valid: () => boolean, root: string | null) {
  const tabs = useEditorStore.getState().tabs;
  const initialModels = monaco.editor.getModels();
  const models = new Map<string, { model: any; version: number }>(initialModels.map((model: any) =>
    [uriKey(model.uri.toString()), { model, version: model.getVersionId() }]));
  const check = () => {
    if (!valid() || useEditorStore.getState().tabs !== tabs || monaco.editor.getModels().some((model: any) => !initialModels.includes(model)) || [...models.values()].some(({ model, version }) =>
      model.isDisposed() || model.getVersionId() !== version)) {
      throw new Error('Documents changed while preparing Rename. Try again.');
    }
  };
  return { async prepare(edit: { edits: any[] }) {
    check();
    const api = window.nexelAPI;
    const canonicalRoot = root && await api.realPath(root);
    check();
    const canonicalTabs = await Promise.all(tabs.map(async tab => ({ tab, key: uriKey(await api.realPath(tab.filePath).catch(() => tab.filePath)) })));
    check();
    const canonicalTargets = new Set<string>();
    const targets = new Map<string, { resource: any; path: string; content: string; model: any }>();
    for (const e of edit.edits) {
      const key = uriKey(e.resource.toString());
      const rootKey = root ? uriKey(root).replace(/\/$/, '') : null;
      if (e.resource.scheme !== 'file' || rootKey === null || !key.startsWith(rootKey + '/')) {
        throw new Error('Rename includes a file outside this workspace. No changes applied.');
      }
      if (targets.has(key)) continue;
      const path = uriToPath(e.resource.toString());
      if (isDocumentWriteReserved(path)) throw new Error('A file operation is running. Try Rename again afterward.');
      const canonical = uriKey(await api.realPath(path));
      const boundary = canonicalRoot ? uriKey(canonicalRoot).replace(/\/$/, '') : null;
      if (boundary === null || !canonical.startsWith(boundary + '/')) throw new Error('Rename includes a file outside this workspace. No changes applied.');
      const aliases = canonicalTabs.filter(t => t.key === canonical);
      if (aliases.some(t => uriKey(t.tab.filePath) !== key) || canonicalTargets.has(canonical)) {
        throw new Error('Rename includes an aliased file. Reopen the workspace using its real path, then try again.');
      }
      canonicalTargets.add(canonical);
      check();
      const tab = tabs.find(tab => uriKey(tab.filePath) === key);
      if (tab?.isDirty && !models.has(key)) throw new Error('A changed buffer has no language-server model. Open that file, then try Rename again.');
      const content = tab ? tab.content : await readDocumentForOpen(path);
      check();
      const model = models.get(key)?.model ?? monaco.editor.getModel(e.resource);
      if (model && model.getValue() !== content) {
        throw new Error('A cached file differs from its current buffer or disk. Open that file, then try Rename again.');
      }
      targets.set(key, { resource: e.resource, path: tab?.filePath ?? path, content, model });
    }
    check();
    if ([...targets.values()].some(t => isDocumentWriteReserved(t.path))) throw new Error('A file operation is running. Try Rename again afterward.');
    // No awaits after this point: all target models and saveable tabs exist before
    // returning edits. Monaco checks every version before changing any model.
    const created: any[] = [];
    try {
      for (const target of targets.values()) {
        if (!target.model) {
          target.model = monaco.editor.createModel(target.content, clangdLanguageFor(target.path) ?? 'cpp', target.resource);
          created.push(target.model);
        }
      }
      useEditorStore.getState().openBackgroundFiles([...targets.values()].map(t => ({ filePath: t.path, content: t.content })));
    } catch (error) {
      created.forEach(model => model.dispose());
      throw error;
    }
    for (const e of edit.edits) {
      const target = targets.get(uriKey(e.resource.toString()))!;
      e.resource = target.model.uri;
      e.versionId = target.model.getVersionId();
    }
    return edit;
  } };
}

/** clangd's background index can omit references from a previous unsaved rename.
 * Require its affected buffers to reach disk before starting another refactor. */
export function requirePreviousRenameSaved(paths: Set<string>) {
  if (useEditorStore.getState().tabs.some(tab => tab.isDirty && paths.has(uriKey(tab.filePath)))) {
    throw new Error('Save the files changed by the previous Rename before renaming again.');
  }
}
