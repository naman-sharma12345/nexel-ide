import {describe,it,expect} from 'vitest';
import {currentDocumentQuickFixes} from './quickFix';
const uri={toString:()=> 'file:///ws/main.cpp'};
const model={uri,getVersionId:()=>7,validateRange:(r:unknown)=>r};
const text={range:{start:{line:2,character:9},end:{line:2,character:14}},newText:'value'};
const fix=(edit:unknown)=>({title:'Fix typo',command:'clangd.applyFix',arguments:[edit]});
describe('current-document Quick Fix boundary',()=>{
 it('converts only requesting-model text fixes with Monaco version preflight',()=>{
   const result=currentDocumentQuickFixes([fix({changes:{'file:///ws/main.cpp':[text]}})],model,4);
   expect(result[0]).toMatchObject({title:'Fix typo',kind:'quickfix',edit:{edits:[{resource:uri,versionId:7,textEdit:{text:'value',range:{startLineNumber:3,startColumn:10,endLineNumber:3,endColumn:15}}}]}});
 });
 it('refuses arbitrary commands, disabled fixes, file operations and mixed target edits',()=>{
   const edit={changes:{'file:///ws/main.cpp':[text]}};
   for(const item of [{title:'Run',command:'workspace.run',arguments:[edit]}, {...fix(edit),disabled:{reason:'no'}},fix({documentChanges:[{kind:'rename',oldUri:'a',newUri:'b'}]}),fix({changes:{'file:///ws/main.cpp':[text],'file:///ws/header.h':[text]}}),{title:'Run',command:{command:'evil'},edit}]) expect(currentDocumentQuickFixes([item],model,4)).toEqual([]);
 });
 it('requires explicit LSP versions and valid nonoverlapping ranges',()=>{
   expect(currentDocumentQuickFixes([fix({documentChanges:[{textDocument:{uri:'file:///ws/main.cpp',version:3},edits:[text]}]})],model,4)).toEqual([]);
   expect(currentDocumentQuickFixes([fix({documentChanges:[{textDocument:{uri:'file:///ws/main.cpp',version:4},edits:[text]}]})],model,4)).toHaveLength(1);
   for(const edits of [[text,text],[{...text,range:{start:{line:-1,character:0},end:{line:0,character:1}}}],[{...text,annotationId:'confirm'}]]) expect(currentDocumentQuickFixes([fix({changes:{'file:///ws/main.cpp':edits}})],model,4)).toEqual([]);
   expect(currentDocumentQuickFixes([fix({changes:{'file:///ws/main.cpp':[text]}})],{...model,validateRange:()=>({})},4)).toEqual([]);
 });
 it('accepts literal quick fixes but not refactors or empty edits',()=>{
   expect(currentDocumentQuickFixes([{title:'Fix',kind:'quickfix',edit:{changes:{'file:///ws/main.cpp':[text]}}}],model,4)).toHaveLength(1);
   expect(currentDocumentQuickFixes([{title:'Refactor',kind:'refactor',edit:{changes:{'file:///ws/main.cpp':[text]}}},fix({changes:{}})],model,4)).toEqual([]);
 });
});
