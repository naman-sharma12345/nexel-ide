import { uriKey } from './uri';
import { toMonacoRange } from './convert';
/* eslint-disable @typescript-eslint/no-explicit-any */
/** Only literal text fixes for the requesting model. Never execute LSP commands,
 * load files, apply resource operations, or ignore an explicit server version. */
export function currentDocumentQuickFixes(items: any, model: any, lspVersion: number) {
  if (!Array.isArray(items)) return [];
  return items.flatMap(item => {
    if (!item || typeof item.title !== 'string' || item.disabled || (item.kind && !(item.kind === 'quickfix' || String(item.kind).startsWith('quickfix.')))) return [];
    let edit = item.edit;
    if (!edit && item.command === 'clangd.applyFix' && item.arguments?.length === 1) edit = item.arguments[0];
    // A normal CodeAction with an arbitrary command must not run that command.
    if (item.command && item.command !== 'clangd.applyFix') return [];
    if (!edit || (edit.changes && edit.documentChanges)) return [];
    const targets: { uri: string; version?: number | null; edits: any[] }[] = [];
    if (edit.changes && typeof edit.changes === 'object') for (const [uri, edits] of Object.entries(edit.changes)) targets.push({uri, edits: edits as any[]});
    if (Array.isArray(edit.documentChanges)) for (const change of edit.documentChanges) {
      if (!change?.textDocument || !Array.isArray(change.edits)) return [];
      targets.push({uri: change.textDocument.uri, version: change.textDocument.version, edits: change.edits});
    }
    if (!targets.length || targets.some(t => typeof t.uri !== 'string' || uriKey(t.uri) !== uriKey(model.uri.toString()) || (t.version != null && t.version !== lspVersion) || !Array.isArray(t.edits))) return [];
    const edits: any[] = [];
    for (const target of targets) for (const e of target.edits) {
      const r = e?.range;
      if (typeof e?.newText !== 'string' || e.annotationId || !r || ![r.start?.line, r.start?.character, r.end?.line, r.end?.character].every(n => Number.isInteger(n) && n >= 0)) return [];
      const range = toMonacoRange(r), valid = model.validateRange(range);
      if (Object.keys(range).some(k => range[k as keyof typeof range] !== valid[k])) return [];
      const before = (line: number, column: number, otherLine: number, otherColumn: number) => line < otherLine || (line === otherLine && column < otherColumn);
      if (edits.some(existing => {
        const a = existing.textEdit.range;
        return !before(range.endLineNumber, range.endColumn, a.startLineNumber, a.startColumn) && !before(a.endLineNumber, a.endColumn, range.startLineNumber, range.startColumn);
      })) return [];
      edits.push({resource:model.uri, versionId:model.getVersionId(), textEdit:{range,text:e.newText}});
    }
    return edits.length ? [{title:item.title,kind:'quickfix',edit:{edits}}] : [];
  });
}
