import type {editor, IRange} from 'monaco-editor';
/** Ask Monaco for the length without materializing the selected text. */
export function selectionLength(model: Pick<editor.ITextModel, 'getValueLengthInRange'> | null, selection: (IRange & {isEmpty(): boolean}) | null): number {
  return model && selection && !selection.isEmpty() ? model.getValueLengthInRange(selection) : 0;
}

/** Monaco merges overlapping selections. Sum its normalized selections. */
export function selectionsLength(model: Pick<editor.ITextModel, 'getValueLengthInRange'> | null, selections: (IRange & {isEmpty(): boolean})[] | null): number {
  return selections?.reduce((total, selection) => total + selectionLength(model, selection), 0) ?? 0;
}
