/**
 * Guarded save: the main process writes only when the bytes on disk still match
 * the baseline the tab last opened or saved. A missing file is written (this is
 * the orphan save-to-recreate path). Any other disk state comes back 'conflict'
 * and nothing is written; read failures reject so callers block instead of
 * assuming absence.
 *
 * Not fully atomic: a disk write landing between the main process's read and
 * write can still be overwritten - the read/write race is unclosed, though
 * narrowed from the renderer check-then-write round trip to one main-process turn.
 */
export type GuardedSaveResult = 'written' | 'conflict';

import { withSaveLock } from './gitOpLock';

/** All app saves funnel through here: serialized with each other and with git
    checkout/pull mutations (see gitOpLock). The baseline check stays the
    conflict detector; the lock closes the non-atomic check-then-write race. */
export async function saveIfUnchanged(filePath: string, content: string, baseline: string): Promise<GuardedSaveResult> {
  return withSaveLock(() => window.nexelAPI.writeFileIfBaseline(filePath, content, baseline));
}
