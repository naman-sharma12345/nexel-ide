/**
 * Escape-sequence scanning for the pipe-fallback terminal input path.
 *
 * xterm delivers one key's sequence per onData chunk (key events are atomic in
 * xterm's input model), and a paste arrives as one chunk - but chunking is not
 * a protocol guarantee, so sequences split across chunks are handled via a
 * small caller-held pending buffer (bounded: the caller flushes it raw past
 * MAX_PENDING_ESCAPE bytes).
 *
 * escapeSequenceLength(data, start), where data[start] is ESC, returns:
 *  - the sequence length in chars when a complete sequence occupies
 *    [start, start+length)  (lone ESC = 1, ESC+char = 2, CSI/SS3 = full length)
 *  - 'incomplete' when the chunk ends mid-CSI/SS3 (caller stashes the tail)
 * Malformed CSI (unexpected byte before a final byte) degrades to 1: the ESC is
 * forwarded alone and parsing resumes after it, so no input is swallowed.
 */
export const MAX_PENDING_ESCAPE = 16;

export function escapeSequenceLength(data: string, start: number): number | 'incomplete' {
  const next = data[start + 1];
  if (next === undefined) return 1; // lone ESC key: forward immediately, do not stash
  if (next === '[') {
    // CSI: parameter bytes 0x30-0x3F and intermediates 0x20-0x2F, one final 0x40-0x7E
    for (let j = start + 2; j < data.length; j++) {
      const c = data.charCodeAt(j);
      if (c >= 0x40 && c <= 0x7e) return j - start + 1;
      if (c < 0x20 || c > 0x3f) return 1; // malformed: forward ESC alone, rescan from next char
    }
    return 'incomplete';
  }
  if (next === 'O') {
    // SS3 (e.g. some function keys): ESC O + one final byte
    if (start + 2 >= data.length) return 'incomplete';
    return 3;
  }
  return 2; // ESC + single char (Alt-modified key)
}
