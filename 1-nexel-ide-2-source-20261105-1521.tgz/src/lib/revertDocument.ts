import {useEditorStore} from '../stores/useEditorStore';
import {readDocumentForOpen} from './documentWriteLock';
/** Revert consent covers the tab at click time, not edits made during its read. */
export async function revertDocument(path:string):Promise<'reverted'|'changed'>{
 const tab=useEditorStore.getState().tabs.find(t=>t.filePath===path);
 if(!tab)return 'changed';
 const disk=await readDocumentForOpen(path);
 if(useEditorStore.getState().tabs.find(t=>t.filePath===path)!==tab)return 'changed';
 useEditorStore.getState().updateTabContent(path,disk);
 useEditorStore.getState().saveTabSuccess(path,disk);
 return 'reverted';
}
