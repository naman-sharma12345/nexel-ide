import { describe, it, expect } from 'vitest';
import { sanitizeSession, saveSession, loadSession, sessionForRoot, clearSessionForRoot, shouldClearSession } from './session';

describe('session restore', () => {
  const mem = () => { const m = new Map<string, string>(); return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v) }; };
  it('round-trips and keeps the active tab', () => {
    const st = mem();
    saveSession({ root: 'C:/cp', paths: ['C:/cp/a.cpp', 'C:/cp/b.cpp'], active: 'C:/cp/b.cpp' }, st);
    expect(loadSession('C:\\cp', st)).toEqual({ root: 'C:\\cp', paths: ['C:/cp/a.cpp', 'C:/cp/b.cpp'], active: 'C:/cp/b.cpp' });
  });
  it('rejects other workspaces, traversal, outside paths and junk', () => {
    expect(sanitizeSession({ root: '/x', paths: ['/x/a'] }, '/y')).toBeNull();
    const s = sanitizeSession({ root: '/w', paths: ['/w/a.cpp', '/etc/passwd', '/w/../etc/x', 42, '/w/a.cpp'], active: '/etc/passwd' }, '/w');
    expect(s?.paths).toEqual(['/w/a.cpp']);
    expect(s?.active).toBe('/w/a.cpp');
    expect(sanitizeSession('x', '/w')).toBeNull();
  });
  it('caps the number of tabs', () => {
    const paths = Array.from({ length: 100 }, (_, i) => `/w/f${i}.cpp`);
    expect(sanitizeSession({ root: '/w', paths, active: null }, '/w')?.paths.length).toBe(24);
  });
});

it('does not fold case for POSIX roots or restore another case-distinct folder',()=>{
 expect(sanitizeSession({root:'/Work',paths:['/Work/a.py','/work/b.py']},'/Work')?.paths).toEqual(['/Work/a.py']);
 expect(sanitizeSession({root:'/work',paths:['/work/a.py']},'/Work')).toBeNull();
});
it('accepts literal double dots in filenames but not traversal segments or nulls',()=>{
 expect(sanitizeSession({root:'/work/',paths:['/work/a..b.py','/work/../private/x','/work/./a.py','/work/a\0.py']},'/work')?.paths).toEqual(['/work/a..b.py']);
});
it('deduplicates Windows casing/separators but retains case-distinct POSIX files',()=>{
 expect(sanitizeSession({root:'C:/Work/',paths:['C:/Work/A.py','c:\\work\\a.py','C:/Work/b.py']},'c:\\work')?.paths).toEqual(['C:/Work/A.py','C:/Work/b.py']);
 expect(sanitizeSession({root:'/work',paths:['/work/A.py','/work/a.py']},'/work')?.paths).toEqual(['/work/A.py','/work/a.py']);
});

it('keeps the intended Windows active file after case/separator deduplication',()=>{
 const session=sanitizeSession({root:'C:/Work',paths:['C:/Work/b.py','C:/Work/A.py','c:\\work\\a.py'],active:'c:\\work\\a.py'},'C:/Work');
 expect(session?.active).toBe('C:/Work/A.py');
});

describe('sessionForRoot (workspace-switch clobber guard)',()=>{
 it('drops paths outside the root and keeps in-root ones',()=>{
  const s=sessionForRoot('/B',['/A/alpha.cpp','/B/beta.cpp'],'/A/alpha.cpp');
  expect(s).toEqual({root:'/B',paths:['/B/beta.cpp'],active:'/B/beta.cpp'});
 });
 it('returns null when nothing open belongs to the root (no clobber with foreign paths)',()=>{
  expect(sessionForRoot('/B',['/A/alpha.cpp'],'/A/alpha.cpp')).toBeNull();
 });
 it('keeps the in-root active file when active belongs to the root',()=>{
  const s=sessionForRoot('/B',['/A/alpha.cpp','/B/beta.cpp','/B/gamma.cpp'],'/B/gamma.cpp');
  expect(s?.active).toBe('/B/gamma.cpp');
 });
 it('never stores more than the tab cap',()=>{
  const many=Array.from({length:40},(_,i)=>`/B/f${i}.cpp`);
  expect(sessionForRoot('/B',many,null)?.paths.length).toBe(24);
 });
});

describe('clearSessionForRoot (deliberately empty workspace)',()=>{
 const mem=()=>{const m=new Map<string,string>();return{getItem:(k:string)=>m.get(k)??null,setItem:(k:string,v:string)=>{m.set(k,v)},removeItem:(k:string)=>{m.delete(k)},dump:()=>m.get('nexel-session-v1')??null}};
 it('clears this root own stored session',()=>{
  const st=mem();saveSession({root:'/A',paths:['/A/a.cpp'],active:'/A/a.cpp'},st);
  clearSessionForRoot('/A',st);expect(st.dump()).toBeNull();
 });
 it('leaves a different root session untouched',()=>{
  const st=mem();saveSession({root:'/A',paths:['/A/a.cpp'],active:'/A/a.cpp'},st);
  clearSessionForRoot('/B',st);expect(st.dump()).not.toBeNull();
 });
});
describe('containment boundary',()=>{
 it('rejects sibling-prefix paths (/Work2 is not inside /Work)',()=>{
  expect(sessionForRoot('/Work',['/Work2/a.cpp'],null)).toBeNull();
  expect(sanitizeSession({root:'/Work',paths:['/Work2/a.cpp'],active:null},'/Work')).toBeNull();
 });
 it('the root path itself is not a file inside it',()=>{
  expect(sessionForRoot('/Work',['/Work'],null)).toBeNull();
 });
});

describe('shouldClearSession (deliberate close vs root switch)',()=>{
 it('clears when the last in-root tab closed while foreign tabs remain (same root)',()=>{
  expect(shouldClearSession('/A',true,'/A',1)).toBe(true);
 });
 it('clears when every tab was closed in the same root',()=>{
  expect(shouldClearSession('/A',false,'/A',0)).toBe(true);
 });
 it('does not clear right after switching roots into an all-foreign tab set',()=>{
  expect(shouldClearSession('/A',true,'/B',1)).toBe(false);
 });
 it('does not clear on initial mount before any root was current',()=>{
  expect(shouldClearSession(null,false,'/A',0)).toBe(false);
 });
 it('does not clear for a foreign-tab close with no prior in-root tabs (tab remains)',()=>{
  expect(shouldClearSession('/B',false,'/B',1)).toBe(false);
 });
});
