import {it,expect} from 'vitest';
import {createOpenRequestGuard,invalidateDocumentOpen} from './openRequest';
it('only allows latest request and original workspace',()=>{const guard=createOpenRequestGuard(),old=guard.begin('/one');expect(old('/one')).toBe(true);const current=guard.begin('/one');expect(old('/one')).toBe(false);expect(current('/two')).toBe(false);expect(current('/one')).toBe(true);});
it('new existing-tab navigation also invalidates older pending reads',()=>{const guard=createOpenRequestGuard(),pending=guard.begin(null);guard.begin(null);expect(pending(null)).toBe(false);});

it('explicit same-path navigation and same-root workspace intent cancel pending open',()=>{const guard=createOpenRequestGuard(),pending=guard.begin('/one');invalidateDocumentOpen();expect(pending('/one')).toBe(false);});
