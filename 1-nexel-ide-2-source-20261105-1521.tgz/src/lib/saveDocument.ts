import { useEditorStore } from '../stores/useEditorStore';
import { withSaveLock } from './gitOpLock';

// One ordered writer per document. Captured contents describe the exact bytes
// committed to disk, even when typing or another Save happens during the write.
const pending = new Map<string, Promise<void>>();
export function saveDocument(path: string, content: string, beforeWrite?: () => void): Promise<void> {
  const previous = pending.get(path) ?? Promise.resolve();
  const write = previous.catch(() => {}).then(() => withSaveLock(async () => {
    beforeWrite?.();
    const saved = await window.nexelAPI.writeFileContent(path, content);
    if (saved === false) throw new Error('File write was not confirmed');
    useEditorStore.getState().saveTabSuccess(path, content);
  }));
  pending.set(path, write);
  void write.then(() => { if (pending.get(path) === write) pending.delete(path); }, () => { if (pending.get(path) === write) pending.delete(path); });
  return write;
}
/** Explicit Overwrite after a conflict dialog: the consent-binding re-read and
    comparison run INSIDE the same serialized critical section as the write, so a
    queued git checkout/pull cannot change the disk between the check and the
    write. On any mismatch the caller gets the newly observed bytes and must
    reconfirm with the user; nothing is overwritten. */
export function overwriteDocumentIfUnchanged(path: string, content: string, observed: string | null): Promise<{ status: 'written' } | { status: 'mismatch'; observed: string | null }> {
  const previous = pending.get(path) ?? Promise.resolve();
  const write = previous.catch(() => {}).then(() => withSaveLock(async () => {
    const now = await window.nexelAPI.readFileContent(path).catch(() => null);
    if (now === null || now !== observed) return { status: 'mismatch' as const, observed: now };
    const saved = await window.nexelAPI.writeFileContent(path, content);
    if (saved === false) throw new Error('File write was not confirmed');
    useEditorStore.getState().saveTabSuccess(path, content);
    return { status: 'written' as const };
  }));
  const tracked: Promise<void> = write.then(() => undefined, () => undefined);
  pending.set(path, tracked);
  void tracked.then(() => { if (pending.get(path) === tracked) pending.delete(path); });
  return write;
}
/** Wait for earlier user saves before taking a bulk-operation disk snapshot. */
export async function waitForDocumentWrites(path: string): Promise<void> {
  await pending.get(path)?.catch(() => {});
}
/** A closed tab can still have its last Save queued under an alternate path. */
export async function waitForAllDocumentWrites(): Promise<void> {
  await Promise.all([...pending.values()].map(write => write.catch(() => {})));
}
