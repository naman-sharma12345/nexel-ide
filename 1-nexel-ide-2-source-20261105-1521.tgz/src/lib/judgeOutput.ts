/** Existing Judge comparison policy, shared with Stress so saved failures reproduce. */
export const normalizeJudgeOutput = (value: string): string =>
  (value || '').trim().split(/\r?\n/).map(line => line.trimEnd()).join('\n');
