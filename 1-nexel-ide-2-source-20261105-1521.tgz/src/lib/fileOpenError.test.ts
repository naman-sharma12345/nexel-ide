import {it,expect} from 'vitest';
import {fileOpenError} from './fileOpenError';
it('maps expected filesystem codes including wrapped provider errors',()=>{
 expect(fileOpenError('/work/code.py',new Error("Error invoking remote method 'read': Error: ENOENT: no such file"))).toBe('Could not open code.py. The file was moved or deleted. Refresh Explorer and try again.');
 expect(fileOpenError('C:\\work\\code.py',{code:'EACCES'})).toContain('Access was denied');
 expect(fileOpenError('/work/folder',{code:'EISDIR'})).toContain('folder, not a file');
});
it('keeps write-reservation instructions and unexpected errors honest',()=>{
 expect(fileOpenError('/a',new Error('File is being replaced. Try opening it again afterward.'))).toBe('a: File is being replaced. Try opening it again afterward.');
 expect(fileOpenError('/a',new Error('Unexpected disk failure'))).toBe('Could not open a: Unexpected disk failure');
 expect(fileOpenError('/a',null)).toBe('Could not open a. Try again.');
});

it('unwraps the Electron invoke() prefix so users see the real reason', () => {
  const err = new Error("Error invoking remote method 'fs:read-file-content': Error: file looks binary (it contains NUL bytes) - not opening it in the text editor");
  expect(fileOpenError('/w/img.png', err)).toBe('Could not open img.png: file looks binary (it contains NUL bytes) - not opening it in the text editor');
});
it('does not treat error-code words in filenames as the filesystem failure',()=>{
 const loop=new Error("Error invoking remote method 'fs:read-file-content': Error: ELOOP: too many symbolic links encountered, open '/wk/ENOENT.cpp'");
 expect(fileOpenError('/wk/ENOENT.cpp',loop)).toContain('ELOOP: too many symbolic links encountered');
 expect(fileOpenError('/wk/ENOENT.cpp',loop)).not.toContain('moved or deleted');
 expect(fileOpenError('/wk/EACCES.cpp',new Error("EIO: input/output error, open '/wk/EACCES.cpp'"))).toContain('EIO: input/output error');
 expect(fileOpenError('/wk/ENOENT.cpp',Object.assign(new Error('ENOENT: misleading message'),{code:'ELOOP'}))).not.toContain('moved or deleted');
});
