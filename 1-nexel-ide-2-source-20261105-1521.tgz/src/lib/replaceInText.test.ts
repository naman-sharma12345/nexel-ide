import { describe, it, expect } from 'vitest';
import { buildMatcher, searchText } from './searchInFiles';
import { replaceInText } from './replaceInText';
describe('replaceInText', () => {
  it('literal with $ kept', () => { expect(replaceInText('a.b a.b', 'a.b', '$1')).toEqual({ text: '$1 $1', count: 2 }); });
  it('regex groups', () => { expect(replaceInText('x1 y2', '([a-z])(\\d)', '$2$1', { regex: true })).toEqual({ text: '1x 2y', count: 2 }); });
  it('invalid regex no-op', () => { expect(replaceInText('abc', '(', 'z', { regex: true }).count).toBe(0); });
  it('whole word', () => { expect(replaceInText('cat concat', 'cat', 'dog', { wholeWord: true }).text).toBe('dog concat'); });
});

it('uses the same line-local scope as preview and preserves CRLF bytes',()=>{
 expect(replaceInText('foo\r\nbar\r\nfoo bar','foo\\s+bar','X',{regex:true})).toEqual({text:'foo\r\nbar\r\nX',count:1});
 expect(replaceInText('foo\nfoo','^foo$','X',{regex:true})).toEqual({text:'X\nX',count:2});
});

it('replacement count equals preview count for line-local regex boundaries',()=>{
 const content='foo\r\nbar\nfoo bar\nfoo\r\n';
 for(const query of ['foo\\s+bar','^foo$','foo$','bar|foo','\\s+']) {
  const re=buildMatcher(query,{regex:true})!;
  expect(replaceInText(content,query,'X',{regex:true}).count).toBe(searchText(content,re,100).length);
 }
});

it('does not erase literal dollar-number tokens that have no capture group',()=>{
 expect(replaceInText('a','(a)','$0/$2/$12/$10',{regex:true}).text).toBe('$0/$2/a2/a0');
});
