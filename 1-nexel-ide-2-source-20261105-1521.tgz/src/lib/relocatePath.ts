/** Retarget only the moved path and descendants, preserving sibling boundaries. */
export function relocatePath(path: string, sourcePath: string, targetPath: string): string {
  const source = sourcePath.replace(/\\/g, '/').replace(/\/+$/, '');
  const candidate = path.replace(/\\/g, '/');
  const target = targetPath.replace(/\\/g, '/').replace(/\/+$/, '');
  const windows = /^[A-Za-z]:\//.test(source) || source.startsWith('//');
  const fold = (value: string) => windows ? value.toLowerCase() : value;
  if (fold(candidate) === fold(source)) return target;
  if (fold(candidate).startsWith(fold(source) + '/')) return target + candidate.slice(source.length);
  return path;
}
