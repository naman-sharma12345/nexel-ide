/** Serialization between app saves and git operations that rewrite working-tree
    files (switch/pull). The baseline check in writeFileIfBaseline is not atomic,
    so a save racing a checkout could overwrite the new content after the check:
    this lock removes that race by never letting a save write while a git op is
    between its own check and write.
    - withSaveLock: app saves run one at a time; each waits only for git ops
      that were active or queued at the moment the save was requested
      (call-time capture - lazy reads would deadlock the queue).
    - withGitOp: waits for earlier git ops and for every save queued before it,
      then runs alone.
    isGitOpActive additionally lets the autosave loop skip a tick instead of
    queueing behind a long network pull (it retries on the next tick). */
let saveChain: Promise<void> = Promise.resolve();
let opGate: Promise<void> = Promise.resolve();
let activeOps = 0;

export function withSaveLock<T>(fn: () => Promise<T>): Promise<T> {
  const gate = opGate; // captured now: wait only for ops already queued
  const run = saveChain.then(async () => { await gate; return fn(); });
  saveChain = run.then(() => undefined, () => undefined);
  return run;
}

export async function withGitOp<T>(fn: () => Promise<T>): Promise<T> {
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  const prev = opGate;
  opGate = prev.then(() => gate);
  const savesBefore = saveChain; // captured now: drain only saves queued before this op
  activeOps++;
  try {
    await prev;
    await savesBefore;
    return await fn();
  } finally {
    activeOps--;
    release();
  }
}

export const isGitOpActive = () => activeOps > 0;
