import {expect,it} from 'vitest';
import {relocatePath} from './relocatePath';
it('relocates descendants without touching similar sibling prefixes or POSIX case',()=>{
 expect(relocatePath('/work/src/file.py','/work/src','/work/lib')).toBe('/work/lib/file.py');
 expect(relocatePath('/work/src2/file.py','/work/src','/work/lib')).toBe('/work/src2/file.py');
 expect(relocatePath('/work/Src/file.py','/work/src','/work/lib')).toBe('/work/Src/file.py');
});
it('folds Windows and UNC identity while retaining the descendant suffix',()=>{
 expect(relocatePath('C:\\WORK\\src\\File.py','c:/work/src','C:/work/lib')).toBe('C:/work/lib/File.py');
 expect(relocatePath('\\\\Server\\Share\\src\\File.py','//server/share/src','//server/share/lib')).toBe('//server/share/lib/File.py');
});
