import { describe, it, expect, afterEach } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';
import { findAliasedTab } from './aliasedTab';

const tab = (filePath: string) => ({ filePath, name: filePath.split('/').pop()!, content: '', originalContent: '', isDirty: false });
let fixture: string | null = null;
afterEach(async () => { if (fixture) { await fs.rm(fixture, { recursive: true, force: true }); fixture = null; } });

describe('findAliasedTab', () => {
  it('matches a tab holding the resolved spelling of a symlink-ancestor request', async () => {
    fixture = await fs.mkdtemp(path.join(os.tmpdir(), 'nexel-alias-open-'));
    const real = path.join(fixture, 'real'); await fs.mkdir(real);
    await fs.writeFile(path.join(real, 'a.cpp'), 'x');
    const link = path.join(fixture, 'link'); await fs.symlink(real, link, 'dir');
    const open = tab(path.join(real, 'a.cpp'));
    expect(await findAliasedTab([open], path.join(link, 'a.cpp'), p => fs.realpath(p))).toBe(open);
  });
  it('returns null for a genuinely different file and for an unresolvable request', async () => {
    fixture = await fs.mkdtemp(path.join(os.tmpdir(), 'nexel-alias-open2-'));
    const a = path.join(fixture, 'a.cpp'), b = path.join(fixture, 'b.cpp');
    await fs.writeFile(a, 'x'); await fs.writeFile(b, 'y');
    expect(await findAliasedTab([tab(a)], b, p => fs.realpath(p))).toBeNull();
    expect(await findAliasedTab([tab(a)], path.join(fixture, 'new.cpp'), p => fs.realpath(p))).toBeNull();
  });
  it('a hardlinked second name IS a match for buffer-identity purposes (same file, two spellings)', async () => {
    fixture = await fs.mkdtemp(path.join(os.tmpdir(), 'nexel-alias-open3-'));
    const a = path.join(fixture, 'a.cpp'), b = path.join(fixture, 'b.cpp');
    await fs.writeFile(a, 'x'); await fs.link(a, b);
    // realpath alone does NOT equate hardlinks (different paths): documented scope.
    expect(await findAliasedTab([tab(a)], b, p => fs.realpath(p))).toBeNull();
  });
});
