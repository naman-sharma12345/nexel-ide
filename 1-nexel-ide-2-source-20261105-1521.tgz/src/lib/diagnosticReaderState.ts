/** Monaco retains a dimmed old diagnostic after its marker disappears. Make
 * that state explicit without changing the reader's navigation or dismissal. */
export function explainStaleDiagnostic(root: HTMLElement) {
  const owned = new Map<HTMLElement, string>();
  const label = 'Outdated diagnostic';
  const update = () => {
    for (const [title, previous] of owned) {
      if (!root.contains(title) || !title.closest('.peekview-widget')?.querySelector('.marker-widget .stale')) {
        if (title.textContent === label) title.textContent = previous;
        owned.delete(title);
      }
    }
    for (const widget of root.querySelectorAll<HTMLElement>('.peekview-widget')) {
      if (!widget.querySelector('.marker-widget .stale')) continue;
      const title = widget.querySelector<HTMLElement>('.peekview-title .dirname');
      if (!title || title.textContent === label) continue;
      owned.set(title, title.textContent ?? '');
      title.textContent = label;
    }
  };
  const observer = new MutationObserver(update);
  observer.observe(root, {subtree:true,childList:true,attributes:true,attributeFilter:['class']});
  update();
  return () => {
    observer.disconnect();
    for (const [title, previous] of owned) if (title.textContent === label) title.textContent = previous;
    owned.clear();
  };
}
