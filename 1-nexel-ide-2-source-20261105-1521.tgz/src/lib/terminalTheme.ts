import type { ITheme } from 'xterm';
import type { NexelTheme } from './themes';

/** Apply the whole terminal palette together, including cursor and selection. */
export function terminalTheme(theme: NexelTheme): ITheme {
  return {
    background: theme.bg0,
    foreground: `#${theme.syntax.fg}`,
    cursor: theme.light ? '#2449b5' : '#d8e1f4',
    cursorAccent: theme.bg0,
    selectionBackground: theme.light ? '#2449b530' : '#8ba8ff40',
    black: theme.light ? '#242722' : '#15181e',
    red: theme.light ? '#a62f40' : '#e49a9a',
    green: theme.light ? '#32613f' : '#a3c5b5',
    yellow: theme.light ? '#80620f' : '#d3c1a5',
    blue: theme.light ? '#2449b5' : '#a9c2f6',
    magenta: theme.light ? '#804e98' : '#c9addf',
    cyan: theme.light ? '#24676d' : '#9dc9cf',
    white: theme.light ? '#50584d' : '#e4e5e0',
    brightRed: theme.light ? '#a62f40' : '#f1b0b0',
    brightGreen: theme.light ? '#32613f' : '#b8ddc9',
    brightYellow: theme.light ? '#80620f' : '#e4cfaa',
    brightBlue: theme.light ? '#2449b5' : '#c0d2ff',
    brightMagenta: theme.light ? '#804e98' : '#ddc5ef',
    brightCyan: theme.light ? '#24676d' : '#b7e3e8',
    brightBlack: theme.light ? '#6a7165' : '#7b879a',
    brightWhite: theme.light ? '#242722' : '#ffffff',
  };
}
