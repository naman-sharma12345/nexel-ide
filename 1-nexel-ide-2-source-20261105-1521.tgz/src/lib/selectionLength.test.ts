import {describe, expect, it, vi} from 'vitest';
import {selectionLength, selectionsLength} from './selectionLength';
describe('selection length without copying text', () => {
  const range = {startLineNumber: 1, startColumn: 1, endLineNumber: 100000, endColumn: 2, isEmpty: () => false};
  it('uses the model exact length API once for a large selection', () => {
    const getValueLengthInRange = vi.fn(() => 9000000);
    expect(selectionLength({getValueLengthInRange}, range)).toBe(9000000);
    expect(getValueLengthInRange).toHaveBeenCalledExactlyOnceWith(range);
  });
  it('does not query missing models/selections or empty selections', () => {
    const getValueLengthInRange = vi.fn(() => 10);
    expect(selectionLength(null, range)).toBe(0);
    expect(selectionLength({getValueLengthInRange}, null)).toBe(0);
    expect(selectionLength({getValueLengthInRange}, {...range,isEmpty: () => true})).toBe(0);
    expect(getValueLengthInRange).not.toHaveBeenCalled();
  });
});

describe('multiple selections', () => {
  it('sums nonempty normalized ranges without text copies', () => {
    const model = {getValueLengthInRange: vi.fn(() => 5)};
    const range = {startLineNumber: 1, startColumn: 1, endLineNumber: 1, endColumn: 6, isEmpty: () => false};
    expect(selectionsLength(model, [range, {...range,startLineNumber: 2,endLineNumber: 2}, {...range,isEmpty: () => true}])).toBe(10);
    expect(model.getValueLengthInRange).toHaveBeenCalledTimes(2);
    expect(selectionsLength(model, null)).toBe(0);
  });
});
