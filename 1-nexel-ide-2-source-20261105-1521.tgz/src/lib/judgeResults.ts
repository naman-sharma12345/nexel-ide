export const JUDGE_SOURCE_NOTICE = 'Judge supports .cpp, .cc, .py, and .java source files. Choose one before running.';
export const isJudgeSource = (path: string): boolean => /\.(cpp|cc|py|java)$/.test(path) && !path.includes('\0');

/** IPC is a boundary: incomplete or malformed runs must never look accepted. */
export function readJudgeResults(value: unknown, expectedIds: number[]): Awaited<ReturnType<typeof window.nexelAPI.runJudge>> {
  const fail = () => { throw new Error('Judge returned incomplete or invalid results. Review the output and run again.'); };
  if (!Array.isArray(value) || value.length !== expectedIds.length || !value.length) return fail();
  const seen = new Set<number>();
  for (const entry of value) {
    if (!entry || typeof entry !== 'object') return fail();
    const result = entry as Record<string, unknown>;
    const metrics = result.metrics as Record<string, unknown> | null;
    if (typeof result.id !== 'number' || !expectedIds.includes(result.id) || seen.has(result.id) ||
      !['AC', 'WA', 'TLE', 'MLE', 'RE', 'CE', 'CANCELLED'].includes(String(result.verdict)) || typeof result.actual !== 'string' ||
      (result.diff !== undefined && typeof result.diff !== 'string') || !metrics || typeof metrics !== 'object' ||
      typeof metrics.time !== 'number' || !Number.isFinite(metrics.time) || metrics.time < 0 ||
      typeof metrics.memory !== 'number' || !Number.isFinite(metrics.memory) || metrics.memory < 0 ||
      (metrics.memoryMeasured !== undefined && typeof metrics.memoryMeasured !== 'boolean') ||
      (metrics.exitCode !== null && (typeof metrics.exitCode !== 'number' || !Number.isInteger(metrics.exitCode)))) return fail();
    seen.add(result.id);
  }
  return value;
}

