import {afterEach,it,expect} from 'vitest';
import {reserveFileMove} from './moveDocumentGuard';
import {useEditorStore} from '../stores/useEditorStore';
import {isDocumentWriteReserved} from './documentWriteLock';
const tab=(filePath:string)=>({filePath,name:'file.py',content:'unsaved',originalContent:'',isDirty:true});
afterEach(()=>useEditorStore.setState({tabs:[]}));
it('refuses moving an open file or any folder containing an open file',async()=>{useEditorStore.setState({tabs:[tab('/work/src/file.py')]});await expect(reserveFileMove('/work/src/file.py')).rejects.toThrow('Close the open tab');await expect(reserveFileMove('/work/src')).rejects.toThrow('Save any changes first');expect(isDocumentWriteReserved('/other')).toBe(false);});
it('normalizes Windows casing and separators without confusing POSIX siblings',async()=>{useEditorStore.setState({tabs:[tab('C:\\Work\\src\\file.py')]});await expect(reserveFileMove('c:/work/src')).rejects.toThrow('Close');useEditorStore.setState({tabs:[tab('/work/src2/file.py')]});const release=await reserveFileMove('/work/src');expect(isDocumentWriteReserved('/work/new.py')).toBe(true);release();expect(isDocumentWriteReserved('/work/new.py')).toBe(false);});
it('reserves opens during the move and releases them afterward',async()=>{const release=await reserveFileMove('/work/file.py');useEditorStore.getState().openFile('/work/file.py','file.py','stale');expect(useEditorStore.getState().tabs).toHaveLength(0);release();useEditorStore.getState().openFile('/work/file.py','file.py','fresh');expect(useEditorStore.getState().tabs).toHaveLength(1);});

it('waits for a closed tab save before returning a move reservation',async()=>{
 const{saveDocument}=await import('./saveDocument');const{vi}=await import('vitest');let finish!:(value:boolean)=>void;const write=vi.spyOn(window.nexelAPI,'writeFileContent').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));
 const saving=saveDocument('/work/file.py','queued bytes');await new Promise(r=>setTimeout(r,0));let ready=false;const moving=reserveFileMove('/work/file.py').then(release=>{ready=true;return release;});await Promise.resolve();expect(ready).toBe(false);expect(isDocumentWriteReserved('/late.py')).toBe(true);finish(true);await saving;const release=await moving;expect(ready).toBe(true);release();write.mockRestore();
});
it('releases the reservation and refuses a move when its origin became stale',async()=>{await expect(reserveFileMove('/work/file.py',()=>false)).rejects.toThrow('cancelled');expect(isDocumentWriteReserved('/late.py')).toBe(false);});
it('invalidates a late file-open read that began before the move reservation',async()=>{
 const{readDocumentForOpen}=await import('./documentWriteLock');const{vi}=await import('vitest');let finish!:(text:string)=>void;const read=vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));const opening=readDocumentForOpen('/work/file.py');const rejected=expect(opening).rejects.toThrow('File changed');const release=await reserveFileMove('/work/file.py');release();finish('old snapshot');await rejected;read.mockRestore();
});

describe('filesystem-alias coverage',()=>{
 const fsP=import('fs/promises');const osP=import('os');const pathP=import('path');
 let fixture:string|null=null;
 const setup=async()=>{
  const fs=await fsP,os=await osP,path=await pathP;
  fixture=await fs.mkdtemp(path.join(os.tmpdir(),'nexel-alias-test-'));
  const real=path.join(fixture,'real');await fs.mkdir(real);
  await fs.writeFile(path.join(real,'a.cpp'),'int main(){}\n');
  const link=path.join(fixture,'link');await fs.symlink(real,link,'dir');
  const{vi}=await import('vitest');
  const spy=vi.spyOn(window.nexelAPI,'realPath').mockImplementation((p:string)=>fs.realpath(p));
  return{fs,path,real,link,spy};
 };
 // Never leak a succeeded reservation when an expectation fails: always release
 // before asserting, so one failed test cannot cascade through the bulk lock.
 const attempt=async(p:string)=>{try{const release=await reserveFileMove(p);release();return 'allowed';}catch(e){return String((e as Error).message||e)}};
 afterEach(async()=>{if(fixture){const fs=await fsP;await fs.rm(fixture,{recursive:true,force:true});fixture=null;}(window.nexelAPI.realPath as any).mockRestore?.();});

 it('refuses a rename issued through a symlinked ancestor while a tab holds the resolved spelling',async()=>{
  const{path,real,link}=await setup();
  useEditorStore.setState({tabs:[tab(path.join(real,'a.cpp'))]});
  expect(await attempt(path.join(link,'a.cpp'))).toContain('Close the open tab');
  expect(await attempt(link)).toContain('Close the open tab');
 });

 it('allows renaming a hardlink first name while a tab holds the second name (buffer stays valid)',async()=>{
  const{fs,path,real}=await setup();
  await fs.link(path.join(real,'a.cpp'),path.join(real,'b.cpp'));
  useEditorStore.setState({tabs:[tab(path.join(real,'b.cpp'))]});
  expect(await attempt(path.join(real,'a.cpp'))).toBe('allowed');
 });

 it('refuses a same-spelling rename when the tab path cannot be resolved (lexical fallback preserved)',async()=>{
  const{path,real}=await setup();
  (window.nexelAPI.realPath as any).mockRejectedValue(new Error('gone'));
  useEditorStore.setState({tabs:[tab(path.join(real,'a.cpp'))]});
  expect(await attempt(path.join(real,'a.cpp'))).toContain('Close the open tab');
 });
});

it('revalidates the origin after the realpath awaits, refusing a stale reservation',async()=>{
 const fs=await import('fs/promises'),os=await import('os'),path=await import('path');
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'nexel-stale-test-'));
 await fs.writeFile(path.join(dir,'a.cpp'),'x');
 const{vi}=await import('vitest');
 let current=true;
 // Flip the origin stale INSIDE the realpath await window so the post-await
 // revalidation is what catches it (the pre-await check already ran).
 const spy=vi.spyOn(window.nexelAPI,'realPath').mockImplementation(async(p:string)=>{await new Promise(r=>setTimeout(r,10));current=false;return fs.realpath(p)});
 const pending=reserveFileMove(path.join(dir,'a.cpp'),()=>current).then(release=>{release();return 'allowed'},e=>String((e as Error).message||e));
 expect(await pending).toContain('cancelled');
 spy.mockRestore();await fs.rm(dir,{recursive:true,force:true});
});
