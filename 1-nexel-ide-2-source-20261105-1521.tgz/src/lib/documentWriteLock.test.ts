import {expect,it,vi} from 'vitest';
import {reserveDocumentWrite,reserveBulkReplacement,readDocumentForOpen,isDocumentWriteReserved} from './documentWriteLock';
import {useEditorStore} from '../stores/useEditorStore';
it('refuses open during replacement and releases after completion',async()=>{
 useEditorStore.setState({tabs:[]});const release=reserveDocumentWrite('/locked.py');
 useEditorStore.getState().openFile('/locked.py','locked.py','stale');expect(useEditorStore.getState().tabs).toHaveLength(0);
 await expect(readDocumentForOpen('/locked.py')).rejects.toThrow(/operation is running/);
 release();expect(isDocumentWriteReserved('/locked.py')).toBe(false);
 useEditorStore.getState().openFile('/locked.py','locked.py','current');expect(useEditorStore.getState().tabs[0].content).toBe('current');useEditorStore.setState({tabs:[]});
});
it('rejects a pre-replacement read completing after replacement releases',async()=>{
 let finish!:(v:string)=>void;window.nexelAPI.readFileContent=vi.fn(()=>new Promise<string>(r=>{finish=r;}));
 const read=readDocumentForOpen('/delayed.py');const rejected=expect(read).rejects.toThrow(/changed during opening/);
 const release=reserveDocumentWrite('/delayed.py');release();finish('old snapshot');await rejected;
});

it('bulk replacement blocks alternate-path opens and invalidates all earlier reads',async()=>{
 let finish!:(v:string)=>void;window.nexelAPI.readFileContent=vi.fn(()=>new Promise<string>(r=>{finish=r;}));
 const read=readDocumentForOpen('/alias.py');const rejected=expect(read).rejects.toThrow(/changed during opening/);
 const release=reserveBulkReplacement();expect(isDocumentWriteReserved('/other-alias.py')).toBe(true);
 await expect(readDocumentForOpen('/other-alias.py')).rejects.toThrow(/operation is running/);
 release();finish('old snapshot');await rejected;expect(isDocumentWriteReserved('/other-alias.py')).toBe(false);
});
