import {it,expect} from 'vitest';
import {parentDirectory} from './parentDirectory';
it.each([
 ['/main.py','/'],['C:\\main.py','C:/'],['C:\\work\\src\\main.py','C:/work/src'],
 ['\\\\server\\share\\main.py','//server/share'],['/work/src/main.py','/work/src'],
])('keeps the intended parent for %s',(path,parent)=>expect(parentDirectory(path,'/fallback')).toBe(parent));
it('uses fallback only when a path has no separator',()=>expect(parentDirectory('main.py','/fallback')).toBe('/fallback'));
