import { describe, it, expect, vi, beforeEach } from 'vitest';
import { saveIfUnchanged } from './externalChange';

describe('saveIfUnchanged', () => {
  beforeEach(() => {
    (window as any).nexelAPI = { writeFileIfBaseline: vi.fn() };
  });
  it('forwards path, content and baseline to the guarded main-process write', async () => {
    (window.nexelAPI.writeFileIfBaseline as any).mockResolvedValue('written');
    expect(await saveIfUnchanged('/w/a.py', 'b = 2\n', 'a = 1\n')).toBe('written');
    expect(window.nexelAPI.writeFileIfBaseline).toHaveBeenCalledWith('/w/a.py', 'b = 2\n', 'a = 1\n');
  });
  it('reports conflict without writing', async () => {
    (window.nexelAPI.writeFileIfBaseline as any).mockResolvedValue('conflict');
    expect(await saveIfUnchanged('/w/a.py', 'b = 2\n', 'a = 1\n')).toBe('conflict');
  });
  it('propagates read failures so callers block', async () => {
    (window.nexelAPI.writeFileIfBaseline as any).mockRejectedValue(new Error('EACCES: permission denied'));
    await expect(saveIfUnchanged('/w/a.py', 'b', 'a')).rejects.toThrow('EACCES');
  });
});
