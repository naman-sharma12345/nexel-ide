import {ownInlineStyles} from './ownedInlineStyles';
/** Keep Monaco's full completion list inside a clipped workbench pane.
 * This shifts the card, never crops its list or changes keyboard selection. */
export function clampSuggestionOffset(start: number, size: number, minimum: number, maximum: number): number {
  if (size > maximum - minimum) return minimum - start;
  return Math.min(Math.max(start, minimum), maximum - size) - start;
}
type ViewBounds = Pick<DOMRect, 'top' | 'bottom' | 'width' | 'height'>;
/** Prefer the whole list as anchor; in a tiny pane protect its selected row. */
export function completionDetailsAnchor(viewport: ViewBounds, card?: ViewBounds, selected?: ViewBounds): ViewBounds | undefined {
  return card && card.height > viewport.height ? selected ?? card : card;
}
export function completionDetailsHeight(viewport: ViewBounds, anchor?: ViewBounds): number {
  const freeSpace = anchor ? Math.max(anchor.top - viewport.top, viewport.bottom - anchor.bottom) - 4 : viewport.height - 4;
  return Math.max(24, Math.min(viewport.height - 4, freeSpace));
}
export function completionDetailsTop(top: number, width: number, height: number, viewport: ViewBounds, anchor?: ViewBounds): number {
  let wanted = top;
  if (anchor && width + anchor.width > viewport.width) {
    if (anchor.bottom + height <= viewport.bottom + 2) wanted = anchor.bottom;
    else if (anchor.top - height >= viewport.top - 2) wanted = anchor.top - height;
  }
  return wanted + clampSuggestionOffset(wanted, height, viewport.top, viewport.bottom);
}
const owners = new WeakMap<HTMLElement, () => void>();
export function keepSuggestionsInViewport(root: HTMLElement) {
  owners.get(root)?.();
  const styles = ownInlineStyles();
  const findStyles = ownInlineStyles();
  const findCompactStyles = ownInlineStyles();
  const pickerStyles = ownInlineStyles();
  const pickerCategoryStyles = ownInlineStyles();
  // This module exclusively owns data-nx-popup-over-header while installed, but
  // preserve any value present before install and restore it on disposal.
  const hadMarkerBeforeInstall = root.hasAttribute('data-nx-popup-over-header');
  let scheduled = false;
  let disposed = false;
  let current: HTMLElement | null = null;
  let dx = 0, dy = 0;
  let details: HTMLElement | null = null;
  let detailsDx = 0, detailsDy = 0;
  const layoutDetails = () => {
    const panel = root.querySelector<HTMLElement>('.suggest-details-container');
    if (!panel) return;
    if (panel !== details) {details = panel; detailsDx = 0; detailsDy = 0;}
    const viewport = root.getBoundingClientRect();
    const cardBounds = root.querySelector<HTMLElement>('.suggest-widget.visible')?.getBoundingClientRect();
    const selectedBounds = root.querySelector<HTMLElement>('.suggest-widget.visible .monaco-list-row.focused')?.getBoundingClientRect();
    const anchor = completionDetailsAnchor(viewport, cardBounds, selectedBounds);
    const room = completionDetailsHeight(viewport, anchor);
    for (const node of [panel, ...panel.querySelectorAll<HTMLElement>('.suggest-details, .suggest-details > .monaco-scrollable-element, .suggest-details .body')]) {
      styles.set(node, 'max-height', `${Math.floor(room)}px`, 'important');
      if (node.classList.contains('body')) styles.set(node, 'overflow-y', 'auto', 'important');
      const width = `${Math.floor(viewport.width - 2)}px`;
      styles.set(node, 'max-width', width);
    }
    const r = (panel.querySelector<HTMLElement>('.suggest-details') ?? panel).getBoundingClientRect();
    if (!r.width || !r.height) return;
    const x = Math.round(clampSuggestionOffset(r.left - detailsDx, r.width, viewport.left, viewport.right));
    const baseTop = r.top - detailsDy;
    const y = Math.round(completionDetailsTop(baseTop, r.width, r.height, viewport, anchor) - baseTop);
    if (x === detailsDx && y === detailsDy) return;
    detailsDx = x; detailsDy = y; styles.set(panel, 'translate', `${x}px ${y}px`);
  };
  // Popup-over-chrome coordination: when one of the clamped widgets actually
  // overlaps the split-close header, mark the editor so CSS can drop the
  // header's z-index below the popup. The chip stays fully accessible whenever
  // no popup covers it. (Sticky scroll stays below the chip as before.)
  const headerFor = () => root.closest('.nx-editor-split-pane')?.querySelector<HTMLElement>('.nx-right-pane-header') ?? null;
  const markHeaderOverlap = () => {
    const header = headerFor();
    if (!header) return;
    const hr = header.getBoundingClientRect();
    if (!hr.width) { root.removeAttribute('data-nx-popup-over-header'); return; }
    let overlap = false;
    for (const sel of ['.suggest-widget.visible', '.parameter-hints-widget.visible', '.monaco-hover', '.rename-box', '.quick-input-widget']) {
      const el = root.querySelector<HTMLElement>(sel);
      if (!el || getComputedStyle(el).visibility === 'hidden') continue;
      const r = el.getBoundingClientRect();
      if (r.width && r.left < hr.right && r.right > hr.left && r.top < hr.bottom && r.bottom > hr.top) { overlap = true; break; }
    }
    root.toggleAttribute('data-nx-popup-over-header', overlap);
  };
  const layout = () => {
    scheduled = false;
    if (disposed) return;
    styles.retain(root);
    layoutRename();
    layoutPicker();
    layoutFind();
    markHeaderOverlap();
    if (current && !root.contains(current)) {current = null;dx = 0;dy = 0;}
    if (details && !root.contains(details)) {details = null;detailsDx = 0;detailsDy = 0;}
    const widget = root.querySelector<HTMLElement>('.suggest-widget.visible');
    if (!widget) {layoutDetails();layoutHints();return;}
    if (widget !== current) { current = widget; dx = 0; dy = 0; styles.set(widget, 'animation', 'none'); }
    const r = widget.getBoundingClientRect();
    if (!r.width || !r.height) {layoutHints();return;}
    const viewport = root.getBoundingClientRect();
    const x = Math.round(clampSuggestionOffset(r.left - dx, r.width, viewport.left, viewport.right));
    const selected = widget.querySelector<HTMLElement>('.monaco-list-row.focused');
    const selectedRect = selected?.getBoundingClientRect();
    // In a pane shorter than the card, keep the actual keyboard selection in
    // view. Monaco still owns list scrolling and all result rows.
    const y = Math.round(r.height > viewport.height && selectedRect
      ? dy + clampSuggestionOffset(selectedRect.top, selectedRect.height, viewport.top, viewport.bottom)
      : clampSuggestionOffset(r.top - dy, r.height, viewport.top, viewport.bottom));
    if (x === dx && y === dy) {layoutDetails();layoutHints();return;}
    dx = x; dy = y;
    styles.set(widget, 'translate', `${x}px ${y}px`);
    styles.set(widget, 'transition', 'none', 'important');
    // Monaco can keep re-basing the card after this pass without a mutation,
    // resize or scroll we observe, leaving the correction stale. Verify once
    // after paint; the next pass early-returns when the position has settled.
    requestAnimationFrame(() => { if (!disposed) schedule(); });
    layoutDetails();
  };
  // Monaco floors the parameter-hints max-height at 250px regardless of editor
  // height and always tries ABOVE first, so in a short editor a doc-heavy hint
  // overflows the pane. Cap it to the pane and keep it inside, same mechanism
  // as the completion card; Monaco still owns content and scrolling.
  // Generic clamp: cap a Monaco popup to the pane and translate it fully inside.
  // Used for parameter hints (stock Monaco floors its max-height at 250px
  // regardless of editor height and prefers ABOVE, overflowing short panes) and
  // for long hover cards. Monaco still owns content, anchoring and scrolling.
  type ClampState = { el: HTMLElement | null; dx: number; dy: number };
  const clampIntoViewport = (widget: HTMLElement | null, state: ClampState) => {
    if (!widget || getComputedStyle(widget).visibility === 'hidden') {state.el = null; state.dx = 0; state.dy = 0; return;}
    if (widget !== state.el) {state.el = widget; state.dx = 0; state.dy = 0; styles.set(widget, 'animation', 'none');}
    const viewport = root.getBoundingClientRect();
    const cap = Math.floor(viewport.height);
    if (cap > 0) {
      styles.set(widget, 'max-height', `${cap}px`, 'important');
      styles.set(widget, 'overflow-y', 'hidden', 'important');
      const wrapper = widget.querySelector<HTMLElement>('.phwrapper');
      if (wrapper) styles.set(wrapper, 'max-height', `${cap}px`, 'important');
      // Monaco's own scroll math still believes the pane-height floor (250px),
      // so give the inner scrollable a native overflow fallback: when Monaco
      // sees no scroll range its wheel handler does not consume the event and
      // native scrolling takes over, keeping the tail of long docs reachable.
      for (const sc of widget.querySelectorAll<HTMLElement>('.monaco-scrollable-element')) {
        styles.set(sc, 'max-height', `${cap}px`, 'important');
        styles.set(sc, 'overflow-y', 'auto', 'important');
        // Let the content box grow to its full height so the native overflow
        // fallback has a real scroll range; Monaco's transform scroll stays 0.
        const content = sc.querySelector<HTMLElement>('.monaco-hover-content, .hover-contents');
        if (content) {styles.set(content, 'height', 'auto', 'important'); styles.set(content, 'max-height', 'none', 'important');}
      }
    }
    const r = widget.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const x = Math.round(clampSuggestionOffset(r.left - state.dx, r.width, viewport.left, viewport.right));
    const y = Math.round(clampSuggestionOffset(r.top - state.dy, r.height, viewport.top, viewport.bottom));
    if (x === state.dx && y === state.dy) return;
    state.dx = x; state.dy = y;
    styles.set(widget, 'translate', `${x}px ${y}px`);
    styles.set(widget, 'transition', 'none', 'important');
    requestAnimationFrame(() => { if (!disposed) schedule(); });
  };
  // Standalone quick input uses 62% of its editor width. In a compact
  // split this can leave no room for the actual symbol beside its category.
  // Keep the native layout on wider editors and keep all symbols/keys intact.
  const layoutPicker = () => {
    pickerStyles.retain(root); pickerCategoryStyles.retain(root);
    const width = root.getBoundingClientRect().width;
    if (!width || width >= 320) { pickerStyles.restore(); pickerCategoryStyles.restore(); return; }
    const widget = root.querySelector<HTMLElement>('.quick-input-widget');
    if (!widget) return;
    pickerStyles.set(widget, 'width', `${Math.max(1, Math.floor(width - 8))}px`, 'important');
    pickerStyles.set(widget, 'left', '4px', 'important');
    pickerStyles.set(widget, 'margin-left', '0px', 'important');
    if (width >= 200) { pickerCategoryStyles.restore(); return; }
    for (const category of widget.querySelectorAll<HTMLElement>('.quick-input-list-entry > .quick-input-list-separator, .quick-input-list-entry-keybinding')) {
      pickerCategoryStyles.set(category, 'display', 'none');
    }
  };
  // Monaco's collapsed Find still floors at 170px, wider than a compact
  // split. Preserve Find/Replace and their actions; only duplicate navigation
  // buttons/options use the native compact treatment. Enter/Shift+Enter remain.
  const layoutFind = () => {
    findStyles.retain(root); findCompactStyles.retain(root);
    const width = root.getBoundingClientRect().width;
    if (!width || width >= 320) { findStyles.restore(); findCompactStyles.restore(); return; }
    const widget = root.querySelector<HTMLElement>('.find-widget');
    if (!widget) return;
    const fit = `${Math.max(1, Math.floor(width - 8))}px`;
    findStyles.set(widget, 'width', fit, 'important');
    findStyles.set(widget, 'max-width', fit, 'important');
    findStyles.set(widget, 'right', '4px', 'important');
    for (const input of widget.querySelectorAll<HTMLElement>('.monaco-findInput')) {
      findStyles.set(input, 'width', 'auto', 'important');
      findStyles.set(input, 'min-width', '0px', 'important');
      findStyles.set(input, 'flex', '1 1 0px', 'important');
    }
    if (width >= 200) { findCompactStyles.restore(); return; }
    // The first row still needs Close's reserved space. Without it, the
    // absolute Close button covers Find in Selection. Replace has no Close.
    for (const part of widget.querySelectorAll<HTMLElement>('.find-part')) findCompactStyles.set(part, 'margin-right', '25px', 'important');
    for (const part of widget.querySelectorAll<HTMLElement>('.replace-part')) findCompactStyles.set(part, 'margin-right', '0px', 'important');
    for (const action of widget.querySelectorAll<HTMLElement>('.codicon-find-previous-match, .codicon-find-next-match, .find-part .controls')) findCompactStyles.set(action, 'display', 'none', 'important');
  };
  const renameState: ClampState = { el: null, dx: 0, dy: 0 };
  // Rename lives inside Monaco's horizontally scrolled content, not an
  // overflowing popup. Its hard 200px minimum can exceed the entire code
  // viewport in a compact split. Fit and clamp against that clipping viewport,
  // not the gutter-inclusive editor; Monaco keeps input, keyboard and edits.
  const layoutRename = () => {
    const widget = root.querySelector<HTMLElement>('.rename-box');
    if (!widget || getComputedStyle(widget).display === 'none' || getComputedStyle(widget).visibility === 'hidden') {
      if (renameState.el) styles.set(renameState.el, 'translate', '0px 0px');
      renameState.el = null; renameState.dx = 0; renameState.dy = 0; return;
    }
    if (widget !== renameState.el) { renameState.el = widget; renameState.dx = 0; renameState.dy = 0; }
    const viewport = (widget.closest('.editor-scrollable') ?? root).getBoundingClientRect();
    if (!viewport.width || !viewport.height) return;
    styles.set(widget, 'min-width', '0px', 'important');
    styles.set(widget, 'width', `${Math.max(1, Math.floor(Math.min(200, viewport.width - 2)))}px`);
    const r = widget.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const x = Math.round(clampSuggestionOffset(r.left - renameState.dx, r.width, viewport.left, viewport.right));
    const y = Math.round(clampSuggestionOffset(r.top - renameState.dy, r.height, viewport.top, viewport.bottom));
    if (x === renameState.dx && y === renameState.dy) return;
    renameState.dx = x; renameState.dy = y;
    styles.set(widget, 'translate', `${x}px ${y}px`);
    requestAnimationFrame(() => { if (!disposed) schedule(); });
  };
  const hintsState: ClampState = { el: null, dx: 0, dy: 0 };
  const hoverState: ClampState = { el: null, dx: 0, dy: 0 };
  // Monaco's own wheel handling believes the floored (250px) viewport height and
  // consumes wheel events without scrolling once we cap a short-pane widget, so
  // bridge wheel to native scrolling on the clamped scrollable, capture-phase.
  const onWheel = (e: WheelEvent) => {
    for (const state of [hintsState, hoverState]) {
      const w = state.el;
      if (!w || !(e.target instanceof Node) || !w.contains(e.target)) continue;
      const sc = w.querySelector<HTMLElement>('.monaco-scrollable-element');
      if (sc && sc.scrollHeight > sc.clientHeight + 1) {
        const max = sc.scrollHeight - sc.clientHeight;
        const next = Math.max(0, Math.min(sc.scrollTop + e.deltaY, max));
        // Only consume the event when it actually scrolls; at either end the
        // wheel must bubble so the editor/parent keeps its own scrolling.
        if (next !== sc.scrollTop) {
          sc.scrollTop = next;
          e.preventDefault(); e.stopPropagation();
        }
      }
      return;
    }
  };
  root.addEventListener('wheel', onWheel, { capture: true, passive: false });
  const layoutHints = () => {
    clampIntoViewport(root.querySelector<HTMLElement>('.parameter-hints-widget.visible'), hintsState);
    clampIntoViewport(root.querySelector<HTMLElement>('.monaco-hover'), hoverState);
  };
  const schedule = () => { if (!scheduled) { scheduled = true; queueMicrotask(layout); } };
  const changes = new MutationObserver(records => {
    // Cursor blink, minimap and line rendering are unrelated to this card.
    // Only card/style/selection changes or insertion/removal need a layout.
    const relevant = records.some(record => {
      const target = record.target instanceof Element ? record.target : record.target.parentElement;
      if (target?.closest('.suggest-widget, .suggest-details-container, .parameter-hints-widget, .monaco-hover, .rename-box, .quick-input-widget, .find-widget')) return true;
      return record.type === 'childList' && [...record.addedNodes, ...record.removedNodes].some(node =>
        node instanceof Element && (node.matches('.suggest-widget, .suggest-details-container, .parameter-hints-widget, .monaco-hover, .rename-box, .quick-input-widget, .find-widget') || !!node.querySelector('.suggest-widget, .suggest-details-container, .parameter-hints-widget, .monaco-hover, .rename-box, .quick-input-widget, .find-widget')));
    });
    if (relevant) schedule();
  });
  changes.observe(root, {subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class']});
  const size = new ResizeObserver(schedule); size.observe(root);
  root.addEventListener('scroll', schedule, true);
  schedule();
  const stop = () => {
    if (disposed) return;
    changes.disconnect(); size.disconnect(); root.removeEventListener('scroll', schedule, true); root.removeEventListener('wheel', onWheel, true);
    if (hadMarkerBeforeInstall) root.setAttribute('data-nx-popup-over-header', '');
    else root.removeAttribute('data-nx-popup-over-header');
    disposed = true;
    styles.restore(); pickerStyles.restore(); pickerCategoryStyles.restore(); findStyles.restore(); findCompactStyles.restore();
    if (owners.get(root) === stop) owners.delete(root);
  };
  owners.set(root, stop);
  return stop;
}
