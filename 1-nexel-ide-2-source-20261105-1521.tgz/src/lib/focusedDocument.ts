import type { EditorTab } from '../stores/useEditorStore';
interface DocumentFocus {
  tabs: EditorTab[];
  activeTabPath: string | null;
  focusedTabPath: string | null;
  isSplit: boolean;
  rightTabPath: string | null;
}
/** Document actions follow the focused visible pane, never a stale hidden path. */
export function focusedDocument(state: DocumentFocus): EditorTab | undefined {
  const path = state.isSplit && state.focusedTabPath === state.rightTabPath
    ? state.rightTabPath : state.activeTabPath;
  return state.tabs.find(tab => tab.filePath === path)
    ?? state.tabs.find(tab => tab.filePath === state.activeTabPath);
}

/** Cycling to the right-owned tab focuses it without replacing the left model. */
export function cycleDocument(state: DocumentFocus, step: number) {
  if (!state.tabs.length) return null;
  const current = focusedDocument(state)?.filePath;
  const index = state.tabs.findIndex(tab => tab.filePath === current);
  const next = state.tabs[(Math.max(0, index) + step + state.tabs.length) % state.tabs.length];
  return { activeTabPath: state.isSplit && next.filePath === state.rightTabPath ? state.activeTabPath : next.filePath,
    focusedTabPath: next.filePath };
}

export function visibleDocumentPaths(state: Pick<DocumentFocus,'activeTabPath'|'isSplit'|'rightTabPath'>): string[] {
  return [state.activeTabPath, state.isSplit ? state.rightTabPath : null].filter((path): path is string => !!path);
}
