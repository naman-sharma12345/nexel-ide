/** Lexical parent for Explorer targets, keeping POSIX/drive root separators. */
export function parentDirectory(path: string, fallback: string | null): string | null {
  const normalized = path.replace(/\\/g, '/');
  const slash = normalized.lastIndexOf('/');
  if (slash < 0) return fallback;
  if (slash === 0 || /^[A-Za-z]:\/$/.test(normalized.slice(0, slash + 1))) {
    return normalized.slice(0, slash + 1);
  }
  return normalized.slice(0, slash);
}
