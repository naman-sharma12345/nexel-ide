import type { SearchMatch } from './searchInFiles';

export const REGEX_FILE_TIMEOUT_MS = 750;
/** True when this environment can run regex jobs off the UI thread. Without it, regex features must refuse instead of running inline. */
export const regexIsolationAvailable = (): boolean => typeof Worker !== 'undefined';
const STARTUP_MS = 5000;

export interface RegexRunner {
  /** Resolves matches, or 'timeout' if the pattern ran past the budget (the worker is terminated and replaced). */
  run(content: string, source: string, flags: string, cap: number, maxLineChars: number, signal?: AbortSignal): Promise<SearchMatch[] | 'timeout' | 'unavailable'>;
  /** Same budget for Replace all: resolves the replaced text, or 'timeout' (nothing should be written). */
  replace(content: string, source: string, flags: string, replacement: string, regexMode: boolean, signal?: AbortSignal): Promise<{ text: string; count: number } | 'timeout' | 'unavailable'>;
  /** Names that match the pattern (non-global regex), same budget for the whole batch. */
  matchNames(names: string[], source: string, flags: string, signal?: AbortSignal): Promise<string[] | 'timeout' | 'unavailable'>;
  dispose(): void;
}

/**
 * Runs regex matching in a Web Worker so a pathological pattern cannot freeze the UI:
 * every call has a hard time budget, after which the worker is killed. Calls are serialized
 * (one worker) because matching is CPU-bound. Startup and execution budgets are separate.
 */
export function createWorkerRegexRunner(makeWorker: () => Worker = () => new Worker(new URL('./searchRegex.worker.ts', import.meta.url), { type: 'module' })): RegexRunner {
  let worker: Worker | null = null;
  let ready: Promise<boolean> | null = null;
  let chain: Promise<unknown> = Promise.resolve();
  let nextId = 1;
  let disposed = false;
  let cancelStartup: (() => void) | null = null;
  let cancelActive: (() => void) | null = null;
  const kill = () => { worker?.terminate(); worker = null; ready = null; };
  const start = (): Promise<boolean> => {
    if (ready) return ready;
    ready = new Promise<boolean>(resolve => {
      try {
        const w = makeWorker();
        worker = w;
        const t = setTimeout(() => { if (worker === w) kill(); finish(false); }, STARTUP_MS);
        const finish = (ok:boolean) => { clearTimeout(t); cancelStartup=null; resolve(ok); };
        cancelStartup = () => finish(false);
        w.onmessage = e => { if (e.data?.ready) finish(true); };
        w.onerror = () => { if (worker === w) kill(); finish(false); };
      } catch { resolve(false); }
    });
    return ready;
  };
  const once = async (extra: Record<string, unknown>, content: string, source: string, flags: string, cap: number, maxLineChars: number, signal?: AbortSignal): Promise<any> => {
    if (disposed || signal?.aborted) return extra.kind === 'replace' ? 'timeout' : [];
    const started=await start();
    if (disposed || signal?.aborted) return extra.kind === 'replace' ? 'timeout' : [];
    if (!started) return 'unavailable';
    const w = worker;
    if (!w) return 'unavailable';
    const id = nextId++;
    return new Promise(resolve => {
      let settled=false;
      const done = (v: any) => { if(settled)return;settled=true;clearTimeout(t);cancelActive=null;signal?.removeEventListener('abort', onAbort);resolve(v); };
      const t = setTimeout(() => { if (worker === w) kill(); done('timeout'); }, REGEX_FILE_TIMEOUT_MS);
      const onAbort = () => { if (worker === w) kill(); done(extra.kind === 'replace' ? 'timeout' : []); };
      cancelActive=onAbort;
      signal?.addEventListener('abort', onAbort, { once: true });
      w.onmessage = e => { if (e.data?.id !== id) return; done(e.data.error ? 'timeout' : extra.kind === 'replace' ? e.data.replaced : extra.kind === 'names' ? e.data.matchedNames : e.data.matches); };
      w.onerror = () => { if (worker === w) kill(); done('timeout'); };
      try { w.postMessage({ id, content, source, flags, cap, maxLineChars, ...extra }); }
      catch { if (worker === w) kill(); done('unavailable'); }
    });
  };
  return {
    run(content, source, flags, cap, maxLineChars, signal) {
      const p = chain.then(() => once({ kind: 'search' }, content, source, flags, cap, maxLineChars, signal));
      chain = p.catch(() => undefined);
      return p;
    },
    matchNames(names, source, flags, signal) {
      const p = chain.then(() => once({ kind: 'names', names }, '', source, flags, 0, 0, signal));
      chain = p.catch(() => undefined);
      return p;
    },
    replace(content, source, flags, replacement, regexMode, signal) {
      const p = chain.then(() => once({ kind: 'replace', replacement, regexMode }, content, source, flags, 0, 0, signal));
      chain = p.catch(() => undefined);
      return p;
    },
    dispose() { disposed = true; cancelStartup?.(); cancelActive?.(); kill(); },
  };
}
