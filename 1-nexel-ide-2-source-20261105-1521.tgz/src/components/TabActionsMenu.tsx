import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
export function TabActionsMenu({onClose,actions}:{onClose:()=>void;actions:{label:string;run:()=>void;disabled?:boolean}[]}) {
 const ref=useRef<HTMLDivElement>(null);
 const triggerRef=useRef<HTMLButtonElement|null>(null);
 const [position,setPosition]=useState({left:8,top:100,maxHeight:160});
 const closeRef=useRef(onClose);closeRef.current=onClose;
 useLayoutEffect(()=>{
  const trigger=document.querySelector<HTMLButtonElement>('.nx-tab-menu-btn');triggerRef.current=trigger;
  const rect=trigger?.getBoundingClientRect();if(!rect)return;
  const top=Math.min(rect.bottom+10,innerHeight-80);
  setPosition({left:Math.max(8,Math.min(innerWidth-228,rect.right-220)),top,maxHeight:Math.max(60,innerHeight-top-12)});
 },[]);
 useEffect(()=>{
  const menu=ref.current;
  menu?.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus();
  const outside=(e:PointerEvent)=>{if(!menu?.contains(e.target as Node)&&!triggerRef.current?.contains(e.target as Node))closeRef.current();};
  const resize=()=>closeRef.current();window.addEventListener('pointerdown',outside);window.addEventListener('resize',resize);
  return()=>{window.removeEventListener('pointerdown',outside);window.removeEventListener('resize',resize);if(document.activeElement===document.body||menu?.contains(document.activeElement))triggerRef.current?.focus();};
 },[]);
 return createPortal(<div ref={ref} className="nx-tab-dropdown-menu nx-tab-actions-portal" style={{position:'fixed',left:position.left,top:position.top,right:'auto',width:Math.min(220,innerWidth-16),maxWidth:'none',maxHeight:position.maxHeight,zIndex:10000}} role="menu" aria-label="Tab Actions" onKeyDown={e=>{
  const buttons=[...e.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];const i=buttons.indexOf(document.activeElement as HTMLButtonElement);
  if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();buttons[e.key==='Home'?0:e.key==='End'?buttons.length-1:(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}
  else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();triggerRef.current?.focus();onClose();}
  else if(e.key==='Tab')onClose();
 }}>{actions.map(a=><button type="button" role="menuitem" className="nx-dropdown-item" key={a.label} disabled={a.disabled} onClick={()=>{onClose();a.run();}}>{a.label}</button>)}</div>,document.body);
}
