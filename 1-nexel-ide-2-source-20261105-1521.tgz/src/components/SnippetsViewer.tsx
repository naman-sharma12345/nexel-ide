import React, {useEffect, useRef, useState} from 'react';
import {useStatusStore} from '../stores/useStatusStore';

interface SnippetsViewerProps {
  focusRequest: number;
  focused: boolean;
  snippetsData: Record<string, { prefix: string; description?: string; body: string | string[] }>;
}

export const SnippetsViewer: React.FC<SnippetsViewerProps> = ({ snippetsData, focusRequest, focused }) => {
  const [search, setSearch] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const copiedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const copyRequest = useRef(0);
  useEffect(() => () => { copyRequest.current++; if (copiedTimer.current) clearTimeout(copiedTimer.current); }, []);
  useEffect(() => {
    if (focused) searchRef.current?.focus({preventScroll: true});
  }, [focusRequest, focused]);

  const filteredSnippets = Object.entries(snippetsData).filter(([key, value]) => {
    const q = search.toLowerCase();
    return (
      key.toLowerCase().includes(q) ||
      (value.prefix && value.prefix.toLowerCase().includes(q)) ||
      (value.description && value.description.toLowerCase().includes(q))
    );
  });

  const handleCopy = async (key: string, body: string | string[]) => {
    const request = ++copyRequest.current;
    try {
      const text = Array.isArray(body) ? body.join('\n') : body;
      if (window.nexelAPI.writeClipboardText) window.nexelAPI.writeClipboardText(text);
      else await navigator.clipboard.writeText(text);
      if (request !== copyRequest.current) return;
      if (copiedTimer.current) clearTimeout(copiedTimer.current);
      setCopiedKey(key);
      copiedTimer.current = setTimeout(() => { setCopiedKey(null); copiedTimer.current = null; }, 1500);
    } catch {
      if (request !== copyRequest.current) return;
      if (copiedTimer.current) clearTimeout(copiedTimer.current);
      copiedTimer.current = null;
      setCopiedKey(null);
      useStatusStore.getState().pushToast('Could not copy snippet. Clipboard access is unavailable.', 'error');
    }
  };

  return (
    <div className="nx-snippets-viewer">
      <div className="nx-snippets-header">
        <div>
          <h1 className="nx-snippets-title">NEXEL SNIPPETS</h1>
          <p className="nx-snippets-subtitle">Fast keyboard-expandable boilerplate fragments for Competitive Programming</p>
        </div>
        <input
          type="text"
          ref={searchRef} placeholder="Search snippets..." aria-label="Search snippets"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="nx-snippets-search"
        />
      </div>

      <div className="nx-snippets-grid">
        {filteredSnippets.map(([key, value]) => (
          <div key={key} className="nx-snippet-card">
            <div className="nx-snippet-card-header">
              <span className="nx-snippet-prefix-badge" title="Type prefix and press Tab to expand">{value.prefix}</span>
              <span className="nx-snippet-desc">{value.description}</span>
              <button
                aria-label={`Copy ${value.prefix} snippet`}
                className={`nx-snippet-copy-btn ${copiedKey === key ? 'copied' : ''}`}
                onClick={() => handleCopy(key, value.body)}
              >
                {copiedKey === key ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="nx-snippet-code-block" tabIndex={0} role="region" aria-label={`${value.prefix} snippet code`}>
              <code>{Array.isArray(value.body) ? value.body.join('\n') : value.body}</code>
            </pre>
          </div>
        ))}
        {filteredSnippets.length === 0 && (
          <div className={`nx-snippets-empty ${Object.keys(snippetsData).length === 0 ? "library" : "miss"}`}>{Object.keys(snippetsData).length === 0
            ? 'No snippets are installed. Snippets come from extensions - enable Competitive Programming in Settings.'
            : 'No matching snippets found.'}</div>
        )}
      </div>
    </div>
  );
};

