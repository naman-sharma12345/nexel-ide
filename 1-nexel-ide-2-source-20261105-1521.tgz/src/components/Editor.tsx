import {explainStaleDiagnostic} from '../lib/diagnosticReaderState';
import {revertDocument} from '../lib/revertDocument';
import { syncOpenModelBuffers } from '../lib/modelBufferSync';
import { monaco } from '../lib/monacoSetup';
import {ContestProblemViewer} from './ContestProblemViewer';
import {SnippetsViewer} from './SnippetsViewer';
import {closeTargets, type CloseKind} from '../lib/closeTargets';
import {keepSuggestionsInViewport} from '../lib/suggestViewport';
import {selectionsLength} from '../lib/selectionLength';
import {createDocumentViewStates} from '../lib/documentViewState';
import {invalidateDocumentOpen} from '../lib/openRequest';
import {fileOpenError} from '../lib/fileOpenError';
import {SplitDivider} from './SplitDivider';
import { focusedDocument, cycleDocument, visibleDocumentPaths } from '../lib/focusedDocument';
import { createDocumentFlash } from '../lib/documentFlash';
import { onDocumentReveal, takeDocumentReveal } from '../lib/documentReveal';
import { readDocumentForOpen } from '../lib/documentWriteLock';
import { CODE_FONT_FAMILY, CODE_LINE_HEIGHT } from '../lib/codeTypography';
import { registerLangCompletions } from '../lib/langCompletions';
import { registerHoverDocs } from '../lib/hoverDocs';
import { registerSignatureHelp } from '../lib/signatureHelp';
import { overwriteDocumentIfUnchanged } from '../lib/saveDocument';
import { saveIfUnchanged } from '../lib/externalChange';
import { isGitOpActive } from '../lib/gitOpLock';
import { DocumentContext } from './DocumentContext';
import { getClangd } from '../lib/clangd/session';
import { isClangdActive } from '../lib/clangd/state';
import { registerMenuEditor, focusDocumentEditor } from '../lib/editorMenu';
import { registerModelDisposer } from '../stores/useEditorStore';
import { disposeModelsForClosedPaths } from '../lib/modelDisposal';

registerModelDisposer(disposeModelsForClosedPaths);
import { resetStickyScrollOnModelChange } from '../lib/editorStickyScroll';
import { pathToUri } from '../lib/clangd/uri';
import { useStatusStore } from '../stores/useStatusStore';
import { collectPluginCompletions } from '../plugins/registry';
import { collectOfflineItems } from '../lib/offlineCompletions';
import React, { useState, useEffect, useRef } from 'react';
import { ConfirmDialog } from './ConfirmDialog';
import MonacoEditor from '@monaco-editor/react';
import '../lib/monacoSetup';
import './Editor.css';
import { useEditorStore } from '../stores/useEditorStore';
import type { EditorTab } from '../stores/useEditorStore';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { WelcomeCanvas } from './WelcomeCanvas';
import { TabActionsMenu } from './TabActionsMenu';
import { EditorTabRail } from './EditorTabRail';
import './ShortcutsSheet.css';
import { useSettingsStore } from '../stores/useSettingsStore';
import { THEMES, monacoThemeName, monacoThemeData } from '../lib/themes';
import dataset from '../../dataset.json';

interface EditorProps {
  activeFilePath: string | null;
  onFileSelect: (filePath: string) => void;
  onCloseFile?: (filePath: string) => void;
  onQuickOpen: () => void;
  zen?: boolean;
}

export const Editor: React.FC<EditorProps> = ({ activeFilePath, onFileSelect, onCloseFile, onQuickOpen }) => {
  const settings = useSettingsStore();
  useEffect(() => syncOpenModelBuffers(monaco.editor, () => useEditorStore.getState().tabs,
    (path, text) => useEditorStore.getState().updateTabContent(path, text)), []);
  // Keep the original floating horizontal document rail at every workspace width.
  const rootPath = useWorkspaceStore(st => st.rootPath);
  const rootName = useWorkspaceStore(st => st.rootName);
  const tree = useWorkspaceStore(st => st.tree);
  const recent = useWorkspaceStore(st => st.recentWorkspaces);
  const openRecent = useWorkspaceStore(st => st.openRecent);
  const openFolder = useWorkspaceStore(st => st.openWorkspaceDir);
  const {
    tabs,
    activeTabPath,
    focusedTabPath,
    isSplit,
    rightTabPath,
    splitRatio,
    autoSave,
    acCelebration,
    enableSnippets,
    updateTabContent,
    toggleSplit,
    setFocusedTabPath,
    closeTab,
    setAutoSave,
    setSplitRatio,
  } = useEditorStore();

  const [showMenu, setShowMenu] = useState<boolean>(false);
  const [pendingClose, setPendingClose] = useState<null | { kind: CloseKind; path?: string; name?: string; closePaths: string[]; targets: string[]; dirtyNames: string[] }>(null);
  const [pendingConflict, setPendingConflict] = useState<null | { path: string; name: string; observed: string | null }>(null);
  const conflictRequest = useRef(0);
  useEffect(() => {
    const stop = useEditorStore.subscribe((next, previous) => {
      if (next.activeTabPath !== previous.activeTabPath || next.focusedTabPath !== previous.focusedTabPath) conflictRequest.current++;
    });
    const stopWorkspace = useWorkspaceStore.subscribe((next, previous) => {
      if (next.rootPath !== previous.rootPath) conflictRequest.current++;
    });
    return () => { conflictRequest.current++; stop(); stopWorkspace(); };
  }, []);
  const conflictRef = useRef(pendingConflict);
  conflictRef.current = pendingConflict;
  const conflictBusy = useRef<typeof pendingConflict>(null);
  const [conflictSaving, setConflictSaving] = useState(false);
  const [conflictError, setConflictError] = useState('');
  useEffect(() => { setConflictSaving(false); setConflictError(''); }, [pendingConflict]);
  useEffect(() => () => { conflictRef.current = null; }, []);
  const [closeError, setCloseError] = useState('');
  const closeGeneration = useRef(0);
  const closeSaveBusy = useRef(false);
  const [closeSaving, setCloseSaving] = useState(false);
  const cancelPendingClose = () => {closeGeneration.current++;closeSaveBusy.current=false;setCloseSaving(false);setPendingClose(null);};

  const containerRef = useRef<HTMLDivElement>(null);
  const autoSaveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const editorRef = useRef<any>(null);
  const mountedEditors = useRef(new Set<any>());
  const viewStates = useRef(createDocumentViewStates());
  useEffect(() => { viewStates.current.retain(tabs.map(tab => tab.filePath)); }, [tabs]);
  useEffect(() => () => viewStates.current.clear(), []);
  const openViewPaths = tabs.map(tab => tab.filePath).join('\0');
  useEffect(() => {
    const stops = [...mountedEditors.current].map(editor => keepSuggestionsInViewport(editor.getDomNode()));
    return () => stops.forEach(stop => stop());
  }, [openViewPaths, isSplit]);
  const selectedEditorFocus = useRef<string | null>(null);
  const completionProviderRef = useRef<any>(null);

  // Clean up completion provider on unmount
  useEffect(() => {
    return () => {
      if (completionProviderRef.current) {
        completionProviderRef.current.dispose();
      }
    };
  }, []);

  const toggleSplitTab = (path: string) => {
    toggleSplit(path);
    const updatedState = useEditorStore.getState();
    if (updatedState.activeTabPath) {
      onFileSelect(updatedState.activeTabPath);
    }
  };

  const execClose = (paths: string[]) => {
    paths.forEach(path => { closeTab(path); getClangd().closePath(path); });
    if (!useEditorStore.getState().activeTabPath) onCloseFile?.('');
  };

  const requestClose = (kind: CloseKind, path?: string) => {
    closeGeneration.current++;closeSaveBusy.current=false;setCloseSaving(false);
    conflictRequest.current++;
    setShowMenu(false);
    const state = useEditorStore.getState();
    const targetPaths = closeTargets(state.tabs.map(tab => tab.filePath), focusedDocument(state)?.filePath ?? null, kind, path);
    const targets = state.tabs.filter(tab => targetPaths.includes(tab.filePath));
    if (!targets.length) return;
    const dirty = targets.filter(t => t.isDirty);
    if (!dirty.length) { execClose(targetPaths); return; }
    setCloseError('');
    setPendingClose({ kind, path, name: kind === 'one' ? targets[0].name : undefined, closePaths: targetPaths, targets: dirty.map(t => t.filePath), dirtyNames: dirty.map(t => t.name) });
  };

  const saveAndClose = async () => {
    if (!pendingClose || closeSaveBusy.current) return;
    const generation = closeGeneration.current;
    const conflictGeneration = ++conflictRequest.current;
    closeSaveBusy.current=true;
    setCloseSaving(true);
    setCloseError('');
    const conflicted: { path: string; name: string }[] = [];
    for (const p of pendingClose.targets) {
      const tab = useEditorStore.getState().tabs.find(t => t.filePath === p);
      if (!tab) continue;
      const contentAtSave = tab.content;
      try {
        const result = await saveIfUnchanged(tab.filePath, contentAtSave, tab.originalContent);
        if (result === 'conflict') {
          // Same signal as the other guarded-save paths: badge the tab so the
          // conflict is visible after any dialog closes.
          useEditorStore.getState().markExternalConflict(tab.filePath);
          conflicted.push({ path: tab.filePath, name: tab.name });
          continue;
        }
        // Mark clean only if nothing changed while the async write was in flight.
        const latest = useEditorStore.getState().tabs.find(t => t.filePath === tab.filePath);
        if (latest && latest.content === contentAtSave) {
          useEditorStore.getState().saveTabSuccess(tab.filePath, contentAtSave);
          getClangd().notifySaved(tab.filePath);
        }
      } catch { /* stays dirty; reported below */ }
      if (generation !== closeGeneration.current) return;
    }
    if (generation !== closeGeneration.current) return;
    closeSaveBusy.current=false;
    setCloseSaving(false);
    // Attempt every target; close only when none remain dirty (failed writes and
    // mid-save edits keep their buffer, tab, and disk state untouched).
    const stillDirty = useEditorStore.getState().tabs.filter(t => pendingClose.closePaths.includes(t.filePath) && t.isDirty);
    if (stillDirty.length) {
      const firstConflict = conflicted.find(c => stillDirty.some(t => t.filePath === c.path));
      if (firstConflict) {
        // Route to the same Overwrite/Revert resolution dialog a manual save
        // offers instead of a dead-end error. Other failed tabs stay open and
        // dirty; closing them again re-enters this flow.
        const observed = await window.nexelAPI.readFileContent(firstConflict.path).catch(() => null);
        if (generation !== closeGeneration.current || conflictGeneration !== conflictRequest.current) return;
        setPendingClose(null);
        setPendingConflict({ path: firstConflict.path, name: firstConflict.name, observed });
        return;
      }
      setCloseError(`Could not save ${stillDirty.map(t => t.name).join(', ')}. Your changes are still in the editor.`);
      setPendingClose({ ...pendingClose, targets: stillDirty.map(t => t.filePath), dirtyNames: stillDirty.map(t => t.name) });
      return;
    }
    const paths = pendingClose.closePaths;
    setPendingClose(null);
    execClose(paths);
  };

  const handleCloseAllTabs = () => requestClose('all');

  const handleCloseOtherTabs = () => requestClose('others');

  const handleCloseTabsToRight = () => requestClose('right');

  const handleCloseTabsToLeft = () => requestClose('left');

  const handleCloseSavedTabs = () => {
    setShowMenu(false);
    execClose(useEditorStore.getState().tabs.filter(tab => !tab.isDirty).map(tab => tab.filePath));
  };

  // Sync with activeFilePath from props
  useEffect(() => {
    if (!activeFilePath) return;

    const existingTab = tabs.find(t => t.filePath === activeFilePath);
    if (existingTab) {
      useEditorStore.setState({ activeTabPath: activeFilePath });
      return;
    }

    const loadFile = async () => {
      try {
        const content = await readDocumentForOpen(activeFilePath);
        const name = activeFilePath.split(/[\\/]/).pop() || activeFilePath;
        useEditorStore.getState().openFile(activeFilePath, name, content);
      } catch (err) {
        console.error("Failed to read selected file:", err);
        useStatusStore.getState().pushToast(fileOpenError(activeFilePath, err), 'error', 5000);
      }
    };

    loadFile();
  }, [activeFilePath, tabs]);

  // Handle Ctrl+S and keybinds
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        saveActiveTab();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'w') {
        e.preventDefault();
        const target = focusedDocument(useEditorStore.getState());
        if (target) handleCloseTab(target.filePath);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === '\\') {
        e.preventDefault();
        if (isSplit && rightTabPath) toggleSplitTab(rightTabPath);
        else if (activeTabPath) toggleSplitTab(activeTabPath);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === '1' && isSplit && activeTabPath) {
        e.preventDefault();
        if (focusDocumentEditor(activeTabPath)) setFocusedTabPath(activeTabPath);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === '2' && isSplit && rightTabPath) {
        e.preventDefault();
        if (focusDocumentEditor(rightTabPath)) setFocusedTabPath(rightTabPath);
      }
      // Editor font zoom: only when the key is not aimed at the terminal or a non-editor
      // input (rename box, search, palette). Monaco's own textarea still counts as editor context.
      if ((e.ctrlKey || e.metaKey) && (e.key === '=' || e.key === '+' || e.key === '-' || e.key === '0')) {
        const ae = document.activeElement as HTMLElement | null;
        const inTerminal = !!ae?.closest?.('.xterm');
        const inOtherEditable = !!ae?.closest?.('input, textarea, [contenteditable="true"]') && !ae?.closest?.('.monaco-editor');
        if (!inTerminal && !inOtherEditable) {
          e.preventDefault();
          const { fontSize, setFontSize } = useSettingsStore.getState();
          if (e.key === '0') setFontSize(13);
          else if (e.key === '-') setFontSize(fontSize - 1);
          else setFontSize(fontSize + 1);
        }
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Tab') {
        e.preventDefault();
        const state = useEditorStore.getState();
        const next = cycleDocument(state, e.shiftKey ? -1 : 1);
        if (next && state.tabs.length > 1) {
          invalidateDocumentOpen();
          useEditorStore.setState(next);
          if (next.activeTabPath !== state.activeTabPath && next.activeTabPath) onFileSelect(next.activeTabPath);
          focusDocumentEditor(next.focusedTabPath);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [tabs, activeTabPath]);

  // Pane closure/split teardown must move real focus as well as the indicator.
  useEffect(() => {
    const target = focusedDocument(useEditorStore.getState());
    const active = document.activeElement;
    if (target && (active === document.body || active?.closest('.monaco-editor'))) focusDocumentEditor(target.filePath);
  }, [focusedTabPath, activeTabPath, isSplit, rightTabPath]);

  // Handle Auto-Save loop
  useEffect(() => {
    if (autoSave) {
      autoSaveIntervalRef.current = setInterval(() => {
        if (isGitOpActive()) return; // a git checkout/pull is changing files on disk; retry next tick
        saveAllDirtyTabs();
      }, 5000);
    } else {
      if (autoSaveIntervalRef.current) clearInterval(autoSaveIntervalRef.current);
    }

    return () => {
      if (autoSaveIntervalRef.current) clearInterval(autoSaveIntervalRef.current);
    };
  }, [autoSave, tabs]);

  // EditorTabRail owns reveal without scrolling the page or clipping oversized tab starts.

  // Guarded write: refuses to clobber bytes written outside this tab. Read
  // failures reject, so nothing is written and the tab stays dirty.
  const conflictNotifiedRef = useRef<Set<string>>(new Set());
  const saveTabGuarded = async (tab: EditorTab, opts?: { silent?: boolean }): Promise<'saved' | 'conflict' | 'error'> => {
    try {
      const result = await saveIfUnchanged(tab.filePath, tab.content, tab.originalContent);
      if (result === 'conflict') {
        useEditorStore.getState().markExternalConflict(tab.filePath);
        // Background saves (auto-save, Save All) must not look like success: one
        // recoverable notice per conflict episode, and the tab keeps a badge.
        if (opts?.silent && !conflictNotifiedRef.current.has(tab.filePath)) {
          conflictNotifiedRef.current.add(tab.filePath);
          useStatusStore.getState().pushToast(`${tab.name} changed on disk - not auto-saved. Save it manually to choose overwrite or revert.`, 'error', 6000);
        }
        return 'conflict';
      }
      conflictNotifiedRef.current.delete(tab.filePath);
      useEditorStore.getState().saveTabSuccess(tab.filePath, tab.content);
      getClangd().notifySaved(tab.filePath);
      useStatusStore.getState().pushToast(`Saved ${tab.name}`, 'success');
      return 'saved';
    } catch (err) {
      console.error("Failed to save file:", err);
      useStatusStore.getState().pushToast(`Could not save ${tab.name}`, 'error', 4000);
      return 'error';
    }
  };

  const saveActiveTab = async () => {
    const activeTab = focusedDocument(useEditorStore.getState());
    if (!activeTab || !activeTab.isDirty) return;
    const request = ++conflictRequest.current;
    const result = await saveTabGuarded(activeTab);
    if (request !== conflictRequest.current) return;
    if (result === 'conflict') {
      // Capture the conflicting bytes this dialog is about, so an Overwrite click
      // only ever overwrites exactly what the user was shown to be in conflict.
      const observed = await window.nexelAPI.readFileContent(activeTab.filePath).catch(() => null);
      if (request !== conflictRequest.current) return;
      setPendingConflict({ path: activeTab.filePath, name: activeTab.name, observed });
    }
  };

  const revertConflictToDisk = async () => {
    const conflict = pendingConflict;
    if (conflictBusy.current === conflict && conflict) return;
    conflictRequest.current++;
    setPendingConflict(null);
    if (!conflict) return;
    try {
      if (await revertDocument(conflict.path) === 'changed') {
        useStatusStore.getState().pushToast(`Revert cancelled: ${conflict.name} changed while reading disk. Your current buffer was kept.`, 'info', 5000);
        return;
      }
      useStatusStore.getState().pushToast(`Reverted ${conflict.name} to the version on disk`, 'info');
    } catch (err) {
      console.error("Failed to revert file:", err);
      useStatusStore.getState().pushToast(`Could not read ${conflict.name} from disk`, 'error', 4000);
    }
  };

  const saveAllDirtyTabs = async () => {
    const dirtyTabs = tabs.filter(t => t.isDirty && !t.isOrphaned);
    for (const tab of dirtyTabs) {
      // Guarded: a conflict or read failure skips the tab instead of clobbering.
      await saveTabGuarded(tab, { silent: true });
    }
  };

  // App-close guard save requests: reuse the same guarded save-all (conflicts
  // badge and skip, failures keep tabs dirty) and signal completion so the
  // guard can re-check the live dirty count before allowing the close.
  useEffect(() => {
    const onSaveAllRequest = (event: Event) => {
      const request = (event as CustomEvent).detail;
      void (async () => {
        // finally: a save-all-done must fire even on an unexpected throw, so the
        // app-close dialog can never stick in its Saving state.
        try { await saveAllDirtyTabs(); }
        finally { window.dispatchEvent(new CustomEvent('nexel:save-all-done', { detail: request })); }
      })();
    };
    window.addEventListener('nexel:save-all', onSaveAllRequest);
    return () => window.removeEventListener('nexel:save-all', onSaveAllRequest);
  }, [tabs]);

  const handleEditorChangeForTab = (path: string, value: string | undefined) => {
    updateTabContent(path, value || '');
  };

  const handleCloseTab = (path: string) => {
    const tabToClose = tabs.find(t => t.filePath === path);
    if (tabToClose?.isDirty) {
      requestClose('one', path);
      return;
    }
    execClose([path]);
  };

  const getLanguage = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'ts':
      case 'tsx':
        return 'typescript';
      case 'js':
      case 'jsx':
        return 'javascript';
      case 'html':
        return 'html';
      case 'css':
        return 'css';
      case 'json':
        return 'json';
      case 'md':
        return 'markdown';
      case 'cpp':
      case 'c':
      case 'h':
        return 'cpp';
      case 'py':
        return 'python';
      default:
        return 'plaintext';
    }
  };

  const langProvidersRef = useRef<{ dispose(): void }[] | null>(null);
  // Find-in-files / palette jump: reveal a line and pulse-highlight it.
  const flashes = useRef(new Map<any, ReturnType<typeof createDocumentFlash>>());
  const applyRevealRef = useRef<(editor:any)=>void>(()=>{});
  applyRevealRef.current = (ed:any) => {
    const filePath = ed?.getModel()?.uri?.fsPath;
    if (!filePath) return;
    const request = takeDocumentReveal(filePath);
    if (!request) return;
    const {line,col} = request;
    ed.revealLineInCenter(line);
    ed.setPosition({lineNumber:line,column:col || 1});
    ed.focus();
    flashes.current.get(ed)?.show(line);
  };
  useEffect(() => onDocumentReveal(() => { for (const editor of mountedEditors.current) applyRevealRef.current(editor); }), []);
  const handleEditorDidMount = (editor: any, monaco: any) => {
    editorRef.current = editor;
    mountedEditors.current.add(editor);
    const flash = createDocumentFlash(editor);
    flashes.current.set(editor, flash);
    editor.onDidChangeModel(() => flash.clear());
    editor.onDidDispose(() => { flash.dispose(); flashes.current.delete(editor); mountedEditors.current.delete(editor); });
    // A first document can mount before the bundled face finishes decoding.
    void document.fonts?.load('13px "JetBrains Mono"').then(() => monaco.editor.remeasureFonts());
    registerMenuEditor(editor);
    editor.onDidDispose(keepSuggestionsInViewport(editor.getDomNode()));
    editor.onDidDispose(explainStaleDiagnostic(editor.getDomNode()));
    const focusIfCurrent = () => {
      const target = focusedDocument(useEditorStore.getState());
      const active = document.activeElement;
      if (selectedEditorFocus.current && editor.getModel()?.uri?.toString() === pathToUri(selectedEditorFocus.current)) {
        selectedEditorFocus.current = null; editor.focus(); return;
      }
      if (target && editor.getModel()?.uri?.toString() === pathToUri(target.filePath)
        && (active === document.body || active?.closest('.monaco-editor'))) editor.focus();
    };
    editor.onDidChangeModel(focusIfCurrent);
    focusIfCurrent();
    resetStickyScrollOnModelChange(editor);
    // The split/single layout remounts Monaco. Keep only serializable view
    // snapshots for open tabs, not retained models or editor instances.
    const modelPath = () => {
      const model = editor.getModel();
      return model?.uri ? decodeURIComponent(model.uri.fsPath) : undefined;
    };
    const saveView = () => {
      const path = modelPath();
      if (path && useEditorStore.getState().tabs.some(tab => tab.filePath === path))
        viewStates.current.save(path, editor.saveViewState());
    };
    const restoreView = () => {
      const path = modelPath();
      const state = path ? viewStates.current.get(path) : undefined;
      if (state) editor.restoreViewState(state);
    };
    restoreView();
    editor.onWillChangeModel(saveView);
    editor.onDidChangeModel(restoreView);
    editor.onDidChangeCursorSelection(saveView);
    editor.onDidScrollChange(saveView);
    // Feed the status bar: cursor + selection length (store skips no-op updates).
    const reportCursor = () => {
      const pos = editor.getPosition(); const selections = editor.getSelections(); const model = editor.getModel();
      if (!pos || !model?.uri) return;
      const path = decodeURIComponent(model.uri.fsPath);
      // A closing editor can emit a final selection event after its tab is gone.
      if (!useEditorStore.getState().tabs.some(tab => tab.filePath === path)) return;
      useStatusStore.getState().setCursor(pos.lineNumber, pos.column, selectionsLength(model, selections), path, selections?.length ?? 1);
    };
    editor.onDidChangeCursorSelection(reportCursor);
    editor.onDidFocusEditorText(() => {
      const state = useEditorStore.getState();
      const modelUri = editor.getModel()?.uri?.toString();
      const visible = visibleDocumentPaths(state).find(path => pathToUri(path) === modelUri);
      if (visible && state.focusedTabPath !== visible) state.setFocusedTabPath(visible);
      reportCursor();
    });
    editor.onDidChangeModel(() => { reportCursor(); applyRevealRef.current(editor); }); // tab switch swaps the model; re-report the new cursor instead of leaving stale Ln/Col
    reportCursor();
    applyRevealRef.current(editor);

    THEMES.forEach(t => monaco.editor.defineTheme(monacoThemeName(t.id), monacoThemeData(t)));
    monaco.editor.setTheme(monacoThemeName(useSettingsStore.getState().theme));

    if (!langProvidersRef.current) langProvidersRef.current = [...registerLangCompletions(monaco), ...registerHoverDocs(monaco), ...registerSignatureHelp(monaco)];
    // clangd: providers registered after the offline ones (so they are asked first); every C/C++ model shown in an
    // editor is synced. When clangd is absent or crashes the providers no-op and the offline ones serve alone.
    const clangd = getClangd((m, k, ttl) => useStatusStore.getState().pushToast(m, k, ttl));
    clangd.attachMonaco(monaco);
    clangd.track(editor.getModel());
    editor.onDidChangeModel(() => clangd.track(editor.getModel()));
    if (completionProviderRef.current) {
      completionProviderRef.current.dispose();
    }
    completionProviderRef.current = monaco.languages.registerCompletionItemProvider('cpp', {
      provideCompletionItems: (model: any, position: any) => {
        const text = model.getValue();
        const hasUsingStd = /\busing\s+namespace\s+std\s*;/.test(text);

        const word = model.getWordUntilPosition(position);
        // Member / scope access (v.  p->  std::) belongs to clangd; dataset words there would only be noise.
        const before = model.getLineContent(position.lineNumber).slice(0, word.startColumn - 1);
        if (/(\.|->|::)\s*$/.test(before)) return { suggestions: [] };
        // With clangd active, it owns keywords/containers/algorithms; Nexel keeps its CP aliases and snippets.
        const clangdOn = isClangdActive();
        const contrib = collectPluginCompletions(useSettingsStore.getState().plugins);
        const range = {
          startLineNumber: position.lineNumber,
          endLineNumber: position.lineNumber,
          startColumn: word.startColumn,
          endColumn: word.endColumn,
        };

        const suggestions: any[] = [];
        const kindFor = (cat: string, isSnippet: boolean) => {
          const K = monaco.languages.CompletionItemKind;
          if (isSnippet || cat === 'cp') return K.Snippet;
          if (cat === 'containers') return K.Class;
          if (cat === 'algorithms' || cat === 'math') return K.Function;
          if (cat === 'io') return K.Interface;
          return K.Keyword;
        };
        for (const item of collectOfflineItems({ dataset: { ...dataset, ...contrib.dataset }, snippets: contrib.snippets, clangdOn, pluginCategories: contrib.categories, enableSnippets, hasUsingStd })) {
          // Offline items rank after clangd's semantic results (clangd sortText starts with a digit run like "3f...").
          const sortText = item.isSnippet ? (clangdOn ? '~0001' : '0001') : (clangdOn ? '~' : '') + String(1000 - item.score).padStart(4, '0');
          suggestions.push({
            kind: kindFor(item.category, item.isSnippet),
            detail: item.detail,
            label: clangdOn ? { label: item.label, description: item.isSnippet ? 'snippet' : 'Nexel' } : item.label,
            documentation: { value: item.documentation },
            insertText: item.insertText,
            ...(item.isSnippet ? { insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet } : {}),
            range: range,
            sortText: sortText,
          });
        }

        return { suggestions };
      }
    });
  };

  const activeTab = tabs.find(t => t.filePath === activeTabPath);
  const focusedTab = focusedDocument({tabs,activeTabPath,focusedTabPath,isSplit,rightTabPath});

  const renderWelcomeBackdrop = () => (
    <WelcomeCanvas recent={recent} openFolder={openFolder} openRecent={openRecent}
      workspace={rootPath ? { name: rootName || rootPath.split(/[\\/]/).pop() || rootPath, path: rootPath, files: tree.filter(node => node.type === 'file') } : undefined}
      findFile={onQuickOpen} openFile={onFileSelect} />
  );

  const renderTabContent = (tab: EditorTab) => {
    if (tab.filePath === 'nexel://snippets') {
      return <SnippetsViewer focusRequest={useEditorStore.getState().snippetsFocusRequest} focused={focusedTab?.filePath === tab.filePath} snippetsData={collectPluginCompletions(useSettingsStore.getState().plugins).snippets} />;
    } else if (tab.filePath.startsWith('cf://')) {
      try {
        const parsed = JSON.parse(tab.content);
        return <ContestProblemViewer problemData={parsed} focused={focusedTab?.filePath === tab.filePath} focusRequest={useEditorStore.getState().problemFocusRequest} />;
      } catch (e) {
        console.error("Failed to parse problem statement JSON:", e);
        return (
          <div className="nx-contests-status-msg error">
            <p>Error rendering problem statement: Invalid data format.</p>
          </div>
        );
      }
    } else {
      return (
        <div className="nx-editor-workspace-area">
          <MonacoEditor
            height="100%"
            language={getLanguage(tab.name)}
            theme={monacoThemeName(settings.theme)}
            value={tab.content}
            // One Monaco model per file, keyed by its file:// URI, so clangd sees each document separately.
            path={pathToUri(tab.filePath)}
            onChange={(val) => handleEditorChangeForTab(tab.filePath, val)}
            beforeMount={(m: any) => THEMES.forEach(t => m.editor.defineTheme(monacoThemeName(t.id), monacoThemeData(t)))}
            onMount={handleEditorDidMount}
            options={{
              // Keep parameter hints in the code viewport. Above-first-line
              // overflow is clipped by the workbench's document header.
              allowOverflow: false,
              hover: { above: false },
              fontSize: settings.fontSize,
              fontFamily: CODE_FONT_FAMILY,
              lineHeight: CODE_LINE_HEIGHT,
              minimap: { enabled: settings.minimap },
              wordWrap: settings.wordWrap ? 'on' : 'off',
              scrollbar: {
                vertical: 'visible',
                horizontal: 'visible',
                verticalScrollbarSize: 8,
                horizontalScrollbarSize: 8,
              },
              lineNumbersMinChars: 3,
              automaticLayout: true,
              cursorBlinking: 'smooth',
              cursorSmoothCaretAnimation: 'on',
              smoothScrolling: true,
              bracketPairColorization: { enabled: true },
              fontLigatures: settings.ligatures,
              roundedSelection: false,
              padding: { top: 16 },
              tabSize: settings.tabSize,
            }}
          />
        </div>
      );
    }
  };

  const rightTab = tabs.find(t => t.filePath === rightTabPath);

  const documentRail = <EditorTabRail orientation="horizontal" tabs={tabs}
    focusedPath={focusedTabPath} rightPath={rightTabPath} isSplit={isSplit} celebration={acCelebration}
    onSelect={(path, focusEditor) => {
      invalidateDocumentOpen();
      selectedEditorFocus.current = focusEditor ? path : null;
      if (isSplit && rightTabPath === path) setFocusedTabPath(path);
      else { useEditorStore.setState({ activeTabPath: path, focusedTabPath: path }); onFileSelect(path); }
      if (focusEditor && focusDocumentEditor(path)) selectedEditorFocus.current = null;
    }}
    onClose={handleCloseTab} onSplit={toggleSplitTab}
    onMove={(from, to) => useEditorStore.getState().moveTab(from, to)} />;

  return (
    <div ref={containerRef} className={`nx-editor-canvas ${acCelebration ? 'ac-celebrate-glow' : ''}`}>
      {/* Floating Premium tabs bar */}
      {tabs.length > 0 && (
        <div className="nx-floating-tabbar-container">
          <div className="nx-floating-tabbar">
            {documentRail}

            {/* Minimalist Tab Actions Menu Dropdown */}
            <div className="nx-tab-menu-container">
              <button
                className="nx-tab-menu-btn"
                title="Tab Actions" aria-label="Tab Actions"
                aria-haspopup="menu" aria-expanded={showMenu}
                onClick={() => setShowMenu(!showMenu)}
              >
                •••
              </button>
              {showMenu && <TabActionsMenu onClose={() => setShowMenu(false)} actions={[
                {label:'Save All Tabs',run:saveAllDirtyTabs,disabled:!tabs.some(tab=>tab.isDirty)},
                {label:'Close All Tabs',run:handleCloseAllTabs},
                {label:'Close Other Tabs',run:handleCloseOtherTabs,disabled:tabs.length<2},
                {label:'Close Tabs to the Left',run:handleCloseTabsToLeft,disabled:closeTargets(tabs.map(tab=>tab.filePath),focusedDocument(useEditorStore.getState())?.filePath??null,'left').length===0},
                {label:'Close Tabs to the Right',run:handleCloseTabsToRight,disabled:closeTargets(tabs.map(tab=>tab.filePath),focusedDocument(useEditorStore.getState())?.filePath??null,'right').length===0},
                {label:'Close Saved Tabs',run:handleCloseSavedTabs,disabled:!tabs.some(tab=>!tab.isDirty)},
              ]}/>}
            </div>

            {/* Global Toolbar actions inside floating bar */}
            {activeTabPath && (
              <div className="nx-editor-toolbar-actions">
                <button
                  className={`nx-toolbar-btn auto-save ${autoSave ? 'active' : ''}`}
                  onClick={() => setAutoSave(!autoSave)}
                  title={autoSave ? "Disable Auto-Save" : "Enable Auto-Save"}
                  aria-label="Auto-Save"
                  aria-pressed={autoSave}
                >
                  <div className="nx-auto-save-led" />
                  <span>Auto-Save</span>
                </button>

                <button
                  className="nx-toolbar-btn save"
                  onClick={saveActiveTab}
                  disabled={!focusedTab?.isDirty}
                  title="Save changes (Ctrl+S)"
                  aria-label="Save"
                >
                  <svg className="nx-save-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2.5h8l2 2V13a.5.5 0 0 1-.5.5h-9A.5.5 0 0 1 3 13V2.5Z" /><path d="M5.5 2.5v3h4v-3M5.5 13.5v-4h5v4" /></svg>
                  <span>Save</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {(tabs.find(tab => tab.filePath === focusedTabPath) || activeTab) && <DocumentContext
        tab={(tabs.find(tab => tab.filePath === focusedTabPath) || activeTab)!}
        rootPath={useWorkspaceStore.getState().rootPath} rootName={useWorkspaceStore.getState().rootName}
        onReveal={path => useWorkspaceStore.getState().revealPath(path)} />}

      {/* Editor Main Content Area */}
      <div className="nx-editor-main-container">
        {isSplit ? (
          <div className="nx-editor-split-container">
            {/* Left Pane */}
            <div
              className={`nx-editor-split-pane left ${focusedTabPath === activeTabPath ? 'focused' : ''}`}
              style={{ width: `${splitRatio}%` }}
              onMouseDown={() => {
                if (activeTabPath && focusedTabPath !== activeTabPath) {
                  setFocusedTabPath(activeTabPath);
                }
              }}
            >
              {activeTab && activeTab.filePath !== rightTabPath ? (
                renderTabContent(activeTab)
              ) : (
                renderWelcomeBackdrop()
              )}
            </div>

            {/* Draggable vertical divider */}
            <SplitDivider ratio={splitRatio} onChange={setSplitRatio} />

            {/* Right Pane */}
            <div
              className={`nx-editor-split-pane right ${focusedTabPath === rightTabPath ? 'focused' : ''}`}
              style={{ width: `${100 - splitRatio}%` }}
              onMouseDown={() => {
                if (rightTabPath && focusedTabPath !== rightTabPath) {
                  setFocusedTabPath(rightTabPath);
                }
              }}
            >
              {rightTab ? (
                <div className="nx-right-pane-wrapper">
                  <div className="nx-right-pane-header">
                    <span className="nx-right-pane-title">{rightTab.name}</span>
                    <button
                      className="nx-right-pane-close"
                      onClick={() => { useEditorStore.setState({ isSplit: false, rightTabPath: null, focusedTabPath: activeTabPath }); }}
                      title="Close Split Pane"
                    >
                      ×
                    </button>
                  </div>
                  <div className="nx-right-pane-content">
                    {renderTabContent(rightTab)}
                  </div>
                </div>
              ) : (
                renderWelcomeBackdrop()
              )}
            </div>
          </div>
        ) : (
          activeTab ? renderTabContent(activeTab) : renderWelcomeBackdrop()
        )}
      </div>

      {pendingClose && (
        <ConfirmDialog
          title="Unsaved changes"
          message={pendingClose.kind === 'one'
            ? `File "${pendingClose.name}" has unsaved changes.`
            : `${pendingClose.dirtyNames.length} tab${pendingClose.dirtyNames.length === 1 ? ' has' : 's have'} unsaved changes.`}
          detail={pendingClose.kind === 'one' ? undefined : pendingClose.dirtyNames.join(', ')}
          detailLabel="Unsaved files"
          saveLabel={pendingClose.kind === 'one' ? 'Save' : 'Save all'}
          saving={closeSaving}
          discardDisabled={closeSaving}
          cancelLabel={closeSaving ? 'Keep open' : 'Cancel'}
          pendingMessage="Saving has already started. Keeping tabs open does not stop the save."
          discardLabel="Don't save"
          error={closeError || undefined}
          onSave={() => void saveAndClose()}
          onDiscard={() => { if (closeSaveBusy.current) return; const paths = pendingClose.closePaths; cancelPendingClose(); execClose(paths); }}
          onCancel={cancelPendingClose}
        />
      )}

      {pendingConflict && (
        <ConfirmDialog
          title="File changed on disk"
          message={`"${pendingConflict.name}" was changed on disk after this tab last opened or saved it. Saving would overwrite those external changes.`}
          detail={pendingConflict.path}
          detailLabel="File"
          saveLabel="Overwrite"
          discardLabel="Revert to disk"
          saving={conflictSaving}
          discardDisabled={conflictSaving}
          cancelLabel={conflictSaving ? 'Close' : 'Cancel'}
          pendingMessage="The write is already in progress. Closing this dialog does not stop it."
          error={conflictError}
          defaultFocus="cancel"
          onSave={() => {
            const c = pendingConflict;
            if (conflictBusy.current === c) return;
            conflictBusy.current = c;
            setConflictSaving(true);
            setConflictError('');
            void (async () => {
              try {
              // Consent binding lives INSIDE the serialized write: the disk is
              // re-read and compared in the same critical section as the write,
              // so a queued checkout/pull cannot change it in between. On any
              // mismatch the dialog reopens against the newly observed bytes.
              const tab = useEditorStore.getState().tabs.find((t) => t.filePath === c.path);
              if (!tab) { setPendingConflict(null); return; }
              const r = await overwriteDocumentIfUnchanged(c.path, tab.content, c.observed);
              if (conflictRef.current !== c) return;
              if (r.status === 'mismatch') { setPendingConflict({ ...c, observed: r.observed }); return; }
              setPendingConflict(null);
              getClangd().notifySaved(c.path);
              useStatusStore.getState().pushToast(`Saved ${c.name}`, 'success');
              } catch (err) {
                console.error('Failed to overwrite file:', err);
                if (conflictRef.current === c) setConflictError(`Could not save ${c.name}. Your changes are still in the editor. Check the file and try again.`);
              } finally {
                if (conflictBusy.current === c) conflictBusy.current = null;
                if (conflictRef.current === c) setConflictSaving(false);
              }
            })();
          }}
          onDiscard={() => void revertConflictToDisk()}
          onCancel={() => { conflictRequest.current++; setPendingConflict(null); }}
        />
      )}
    </div>
  );
};

export default Editor;
