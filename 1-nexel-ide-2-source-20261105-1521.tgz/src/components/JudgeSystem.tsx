import React, { useEffect, useRef, useState } from 'react';
import { useJudgeStore } from '../stores/useJudgeStore';
import { saveIfUnchanged } from '../lib/externalChange';
import { useEditorStore } from '../stores/useEditorStore';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { StressPanel } from './StressPanel';
import './JudgeSystem.css';

import { readJudgeResults, isJudgeSource, JUDGE_SOURCE_NOTICE } from '../lib/judgeResults';
export { readJudgeResults } from '../lib/judgeResults';

interface JudgeSystemProps {
  activeFilePath?: string | null;
}

export const JudgeSystem: React.FC<JudgeSystemProps> = ({ activeFilePath }) => {
  const {
    testCases,
    activeTCId,
    activeTab,
    isRunning,
    addTestCase,
    deleteTestCase,
    updateTestCase,
    setActiveTCId,
    setActiveTab,
    setRunning,
  } = useJudgeStore();

  const sourceDirty = useEditorStore(state => state.tabs.some(tab => tab.filePath === activeFilePath && tab.isDirty));
  const [runNotice, setRunNotice] = useState('');
  const runButtonRef = useRef<HTMLButtonElement>(null);
  const runningRef = useRef(false);
  const activeRunIdRef = useRef<string | null>(null);
  const cancelRequestedRef = useRef(false);
  const testcaseShelfRef = useRef<HTMLDivElement>(null);
  const deletedFocusId = useRef<number | null>(null);
  useEffect(() => {
    const id = deletedFocusId.current;
    if (id === null) return;
    deletedFocusId.current = null;
    testcaseShelfRef.current?.querySelector<HTMLElement>(`[data-testcase-id="${id}"]`)?.focus();
  }, [testCases]);
  const runNoticeRef = useRef<HTMLParagraphElement>(null);
  useEffect(() => {
    if (runNotice && document.activeElement === runButtonRef.current) runNoticeRef.current?.focus();
  }, [runNotice]);
  const [showAcEffect, setShowAcEffect] = useState<boolean>(false);
  const [showWaEffect, setShowWaEffect] = useState<boolean>(false);
  const [showStress, setShowStress] = useState<boolean>(false);
  const stressTriggerRef = useRef<HTMLButtonElement>(null);
  const closeStress = () => { setShowStress(false); stressTriggerRef.current?.focus(); };

  const activeTC = testCases.find(tc => tc.id === activeTCId) || testCases[0];
  const hasSeparateExecutionDetails = (activeTab === 'actual' || activeTab === 'diff')
    && ['RE', 'TLE', 'MLE', 'CE'].includes(activeTC?.verdict || '')
    && !!activeTC?.actual && !!activeTC?.errorMsg && activeTC.actual !== activeTC.errorMsg;


  const handleDeleteTestCase = (e: React.MouseEvent, idToDelete: number) => {
    e.stopPropagation();
    if (isRunning || testCases.length <= 1) return;
    const remaining = testCases.filter(tc => tc.id !== idToDelete);
    if (document.activeElement === e.currentTarget) deletedFocusId.current = remaining.find(tc => tc.id === activeTCId)?.id ?? remaining[0].id;
    deleteTestCase(idToDelete);
  };

  const handleTextChange = (value: string) => {
    // Only allow updating input and expected. actual is read-only.
    if (activeTab === 'input' || activeTab === 'expected') {
      updateTestCase(activeTCId, { [activeTab]: value });
    }
  };

  const handleRun = async () => {
    if (runningRef.current || useJudgeStore.getState().isRunning) return;
    if (!activeFilePath) {
      alert("Please open a valid C++, Python, or Java source file in the editor first.");
      return;
    }

    if (!isJudgeSource(activeFilePath)) { setRunNotice(JUDGE_SOURCE_NOTICE); return; }

    runningRef.current = true;
    cancelRequestedRef.current = false;
    activeRunIdRef.current = `run-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    setRunNotice('');
    const source = useEditorStore.getState().tabs.find(tab => tab.filePath === activeFilePath);
    const requestedWorkspace = useWorkspaceStore.getState().rootPath;
    const requestedCases = JSON.stringify(testCases.map(tc => [tc.id, tc.input, tc.expected]));
    setRunning(true);
    if (source?.isDirty) {
      try {
        if (source.isOrphaned) throw new Error('This file was deleted on disk. Save it to a new file before running.');
        const guard = await saveIfUnchanged(source.filePath, source.content, source.originalContent);
        if (guard === 'conflict') throw new Error('This file changed on disk since you opened it. Save it manually first (you can overwrite or revert), then run again.');
        useEditorStore.getState().saveTabSuccess(source.filePath, source.content);
        if (useEditorStore.getState().tabs.find(tab => tab.filePath === source.filePath)?.content !== source.content) {
          throw new Error('The file changed while saving. Review it, then run again.');
        }
        const currentEditor = useEditorStore.getState();
        if (useWorkspaceStore.getState().rootPath !== requestedWorkspace ||
          (currentEditor.focusedTabPath || currentEditor.activeTabPath) !== activeFilePath ||
          JSON.stringify(useJudgeStore.getState().testCases.map(tc => [tc.id, tc.input, tc.expected])) !== requestedCases) {
          throw new Error('The file, workspace, or test cases changed while saving. Review them, then run again.');
        }
      } catch (error) {
        setRunNotice(error instanceof Error ? error.message : 'Could not save. Nothing was run.');
        runningRef.current = false;
        setRunning(false);
        return;
      }
    }
    
    if (cancelRequestedRef.current) {
      runningRef.current = false;
      activeRunIdRef.current = null;
      setRunning(false);
      setRunNotice('Canceled. Nothing was run.');
      return;
    }

    // Set all testcases to RUNNING state for visual cue animations
    useJudgeStore.setState({
      testCases: testCases.map(tc => ({ ...tc, verdict: 'RUNNING', actual: '' }))
    });

    // Result validity is grounded in what was actually run: this run's id, the
    // workspace, the source file, the exact source content that was run, and
    // every case's id+input+expected. A completion whose run context no longer
    // matches the panel must not overwrite the user's cases.
    const myRunId = activeRunIdRef.current!;
    const runFile = activeFilePath;
    const runWorkspace = useWorkspaceStore.getState().rootPath;
    // Buffer identity proxy for the source that was run. The runner compiles
    // from DISK: a dirty buffer is saved to disk immediately above, so this
    // buffer equals the bytes the compile read at that moment. It does NOT
    // prove the bytes stayed on disk: an external edit between the save and
    // the compile, or mid-run with a clean buffer, is invisible here
    // (recorded residual). Captured after the save so mid-run buffer edits
    // differ.
    const runSourceContent = useEditorStore.getState().tabs.find(tab => tab.filePath === runFile)?.content ?? null;
    const runSignature = JSON.stringify(testCases.map(tc => [tc.id, tc.input, tc.expected]));
    const runContextIntact = (): boolean => {
      if (activeRunIdRef.current !== myRunId) return false; // a newer run owns the panel
      // Workspace switch: same-looking relative paths can be different files.
      if (useWorkspaceStore.getState().rootPath !== runWorkspace) return false;
      const ed = useEditorStore.getState();
      const currentFile = ed.focusedTabPath || ed.activeTabPath;
      // A different focused source - or no focused source at all - means these
      // results would be presented for the wrong (or no) target.
      if (currentFile !== runFile) return false;
      // Source tab closed, or its content edited mid-run (covers switching
      // away and back: re-focus matches, but an edit changes the content).
      const runTab = ed.tabs.find(tab => tab.filePath === runFile);
      if (!runTab) return false;
      if (runSourceContent !== null && runTab.content !== runSourceContent) return false;
      const now = useJudgeStore.getState().testCases;
      return JSON.stringify(now.map(tc => [tc.id, tc.input, tc.expected])) === runSignature;
    };
    const discardNotice = 'Run finished, but the file or test cases changed while it ran, so those results were discarded.';
    // Discard only touches state when this run still owns the panel; a newer
    // run's RUNNING markers and notice are left alone.
    const discardStaleResults = () => {
      if (activeRunIdRef.current !== myRunId) return;
      useJudgeStore.setState({
        testCases: useJudgeStore.getState().testCases.map(tc =>
          tc.verdict === 'RUNNING' ? { ...tc, verdict: 'IDLE' as const, actual: '' } : tc
        )
      });
      setRunNotice(discardNotice);
    };

    try {
      const payload = testCases.map(tc => ({
        id: tc.id,
        input: tc.input,
        expected: tc.expected
      }));

      if (cancelRequestedRef.current) {
        runningRef.current = false;
        activeRunIdRef.current = null;
        setRunning(false);
        setRunNotice('Canceled. Nothing was run.');
        return;
      }
      const results = readJudgeResults(await window.nexelAPI.runJudge(activeFilePath, payload, 2000, 256, activeRunIdRef.current!), payload.map(tc => tc.id));

      if (!runContextIntact()) { discardStaleResults(); return; }
      // Apply onto the CURRENT cases (ids/inputs/expected verified identical),
      // preserving any other field the user edited while the run was in flight.
      useJudgeStore.setState({
        testCases: useJudgeStore.getState().testCases.map(tc => {
          const res = results.find(r => r.id === tc.id);
          if (res) {
            return {
              ...tc,
              verdict: res.verdict,
              resultSourcePath: runFile,
              actual: res.actual,
              time: res.metrics.time,
              memory: res.metrics.memory,
              memoryMeasured: res.metrics.memoryMeasured === true,
              exitCode: res.metrics.exitCode,
              errorMsg: res.diff
            };
          }
          return tc;
        })
      });

      const allAc = results.length > 0 && results.every(r => r.verdict === 'AC');
      const anyWa = results.some(r => r.verdict === 'WA' || r.verdict === 'TLE' || r.verdict === 'MLE' || r.verdict === 'RE' || r.verdict === 'CE');

      if (allAc) {
        setShowAcEffect(true);
        useEditorStore.getState().triggerAcCelebration();
        setTimeout(() => setShowAcEffect(false), 1500);
      } else if (anyWa) {
        setShowWaEffect(true);
        setTimeout(() => setShowWaEffect(false), 800);
      }

      setActiveTab('actual');

    } catch (err: unknown) {
      console.error(err);
      const message = err instanceof Error ? err.message : String(err);
      if (!runContextIntact()) { discardStaleResults(); return; }
      useJudgeStore.setState({
        testCases: useJudgeStore.getState().testCases.map(tc => ({
          ...tc,
          verdict: 'RE',
          resultSourcePath: runFile,
          actual: message || 'Execution error'
        }))
      });
      setActiveTab('actual');
    } finally {
      runningRef.current = false;
      activeRunIdRef.current = null;
      cancelRequestedRef.current = false;
      setRunning(false);
    }
  };

  const handleCancel = () => {
    cancelRequestedRef.current = true;
    const runId = activeRunIdRef.current;
    if (runId && window.nexelAPI.cancelJudge) void window.nexelAPI.cancelJudge(runId);
  };

  const getVerdictLabel = (verdict?: string) => {
    if (!verdict || verdict === 'IDLE') return 'IDLE';
    if (verdict === 'RUNNING') return 'RUNNING';
    if (verdict === 'AC') return 'ACCEPTED (AC)';
    if (verdict === 'WA') return 'WRONG ANSWER (WA)';
    if (verdict === 'TLE') return 'TIME LIMIT EXCEEDED (TLE)';
    if (verdict === 'MLE') return 'MEMORY LIMIT EXCEEDED (MLE)';
    if (verdict === 'CE') return 'COMPILATION ERROR (CE)';
    if (verdict === 'RE') return 'RUNTIME ERROR (RE)';
    if (verdict === 'CANCELLED') return 'CANCELLED';
    return verdict;
  };

  return (
    <div className={`nx-judge-wrapper ${showAcEffect ? 'ac-celebrate-glow' : ''}`}>
      <div className="nx-judge-header">
        <span className="nx-judge-title">NEXEL JUDGE</span>
        <button ref={stressTriggerRef} className={`nx-judge-stress-toggle ${showStress ? 'on' : ''}`} onClick={() => setShowStress(v => !v)} title="Stress tester: solution vs brute force" aria-label="Stress tester: solution vs brute force" aria-pressed={showStress}>
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2.2"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>
          STRESS
        </button>
      </div>

      {showStress ? <StressPanel solutionPath={activeFilePath} onClose={closeStress} /> : <>

      <div className="nx-judge-tcs-shelf">
        <div ref={testcaseShelfRef} className="nx-judge-tcs-scroll">
          {testCases.map((tc) => {
            const isActive = tc.id === activeTCId;
            let statusClass = 'idle';
            if (tc.verdict === 'RUNNING') statusClass = 'running';
            else if (tc.verdict === 'AC') statusClass = 'passed';
            else if (tc.verdict === 'CANCELLED') statusClass = 'idle';
            else if (tc.verdict && tc.verdict !== 'IDLE') statusClass = 'failed';

            return (
              <div 
                key={tc.id} 
                className={`nx-tc-pill ${isActive ? 'active' : ''} ${statusClass}`}
                onClick={() => setActiveTCId(tc.id)}
                data-testcase-id={tc.id} role="button" tabIndex={0} aria-label={`Select ${tc.name}`} aria-pressed={isActive}
                onKeyDown={event => { if(event.target===event.currentTarget && (event.key==='Enter'||event.key===' ')){event.preventDefault();setActiveTCId(tc.id);} }}
              >
                <span className="nx-tc-pill-name" title={tc.name}>{tc.name}</span>
                {tc.verdict && tc.verdict !== 'IDLE' && tc.verdict !== 'RUNNING' && (
                  <span className={`nx-tc-verdict-dot ${statusClass}`}>
                    {tc.verdict}
                  </span>
                )}
                <button 
                  className="nx-tc-pill-del" 
                  title="Delete Testcase" aria-label={`Delete ${tc.name}`} disabled={isRunning || testCases.length <= 1}
                  onClick={(e) => handleDeleteTestCase(e, tc.id)}
                >
                  ×
                </button>
              </div>
            );
          })}
          <button 
            className="nx-tc-add-btn" 
            title="Add Testcase" aria-label="Add testcase"
            onClick={addTestCase}
            disabled={isRunning}
          >
            +
          </button>
        </div>
      </div>

      <div className="nx-judge-tabs" role="tablist" aria-label="Testcase data">
        {([
          { key: 'input', label: 'Input' },
          { key: 'expected', label: 'Expected' },
          { key: 'actual', label: 'Actual' },
          { key: 'diff', label: 'Diff' }
        ] as const).map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key} role="tab" aria-selected={isActive} tabIndex={isActive ? 0 : -1}
              onKeyDown={event => {
                const keys = ['input','expected','actual','diff'] as const;
                const index=keys.indexOf(tab.key);
                if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) { event.preventDefault(); const next=event.key==='Home'?0:event.key==='End'?3:(index+(event.key==='ArrowRight'?1:-1)+4)%4;setActiveTab(keys[next]);(event.currentTarget.parentElement?.children[next] as HTMLElement)?.focus(); }
              }}
              className={`nx-judge-tab-pill ${isActive ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTC?.verdict && !['IDLE','RUNNING'].includes(activeTC.verdict) && <div className="nx-judge-result-source" role="region" aria-label={`${activeTC.name} result source`} tabIndex={0}>
        <span>{activeTC.resultSourcePath ? `Last run: ${activeTC.resultSourcePath}` : 'Saved results: source not recorded'}</span>
        <span>Run again after source changes. Results are kept when switching files.</span>
      </div>}

      <div className={`nx-judge-textbox-container${hasSeparateExecutionDetails ? ' has-execution-details' : ''}`}>
        {activeTab === 'diff' ? (
          <div className="nx-judge-diff-viewer">
            <div className="nx-diff-hdr-row">
              <span className="nx-diff-column-hdr green">EXPECTED</span>
              <span className="nx-diff-column-hdr red">ACTUAL</span>
            </div>
            <div className="nx-diff-lines-container" role="region" aria-label={`${activeTC.name} expected and actual comparison`} tabIndex={0}>
              {(() => {
                const expectedLines = (activeTC.expected || '').trim().split(/\r?\n/);
                const actualLines = (activeTC.actual || activeTC.errorMsg || '').trim().split(/\r?\n/);
                const maxLines = Math.max(expectedLines.length, actualLines.length);
                
                if (maxLines === 0 || (!activeTC.expected && !activeTC.actual && !activeTC.errorMsg)) {
                  return <div className="nx-diff-empty">No execution data to compare yet.</div>;
                }

                return Array.from({ length: maxLines }).map((_, i) => {
                  const expLine = expectedLines[i] !== undefined ? expectedLines[i] : '';
                  const actLine = actualLines[i] !== undefined ? actualLines[i] : '';
                  const isMatch = expLine.trimEnd() === actLine.trimEnd();
                  
                  return (
                    <div key={i} className={`nx-diff-line-row ${isMatch ? 'match' : 'mismatch'}`}>
                      <div className="nx-diff-cell expected-cell">
                        <span className="nx-line-num">{i + 1}</span>
                        <span className="nx-line-text">{expLine || ' '}</span>
                      </div>
                      <div className="nx-diff-cell actual-cell">
                        <span className="nx-line-num">{i + 1}</span>
                        <span className="nx-line-text">{actLine || ' '}</span>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        ) : (
          <textarea aria-label={`${activeTC.name} ${activeTab}`} readOnly={activeTab === 'actual'}
            className={`nx-judge-textarea ${
              activeTab === 'actual' && activeTC.verdict === 'AC' ? 'passed-area' : ''
            } ${
              activeTab === 'actual' && activeTC.verdict && activeTC.verdict !== 'AC' && activeTC.verdict !== 'IDLE' && activeTC.verdict !== 'CANCELLED' ? 'failed-area' : ''
            }`}
            value={activeTC ? (activeTC[activeTab as 'input' | 'expected' | 'actual'] || (activeTab === 'actual' ? activeTC.errorMsg : '') || '') : ''}
            onChange={(e) => handleTextChange(e.target.value)}
            placeholder={`Enter active testcase ${activeTab} data...`}
            disabled={isRunning}
          />
        )}
        {hasSeparateExecutionDetails && <section className="nx-judge-execution-details" role="region" aria-label={`${activeTC.name} execution details`} tabIndex={0}>
          <h3>Execution details</h3><pre>{activeTC.errorMsg}</pre>
        </section>}
      </div>

      <div className="nx-judge-run-footer">
        {runNotice && <p ref={runNoticeRef} className="nx-judge-run-notice" role="alert" tabIndex={0}>{runNotice}</p>}
        <button ref={runButtonRef}
          className={`nx-judge-run-btn ${isRunning ? 'running' : ''}`}
          onClick={isRunning ? handleCancel : handleRun}
          aria-label={isRunning ? "Cancel running testcases" : sourceDirty ? "Save and run testcases" : "Run testcases"}
          aria-disabled={!isRunning && !activeFilePath}
          aria-busy={isRunning}
          disabled={!isRunning && !activeFilePath}
        >
          {isRunning ? (
            <>
              <span className="nx-run-spinner" />
              CANCEL
            </>
          ) : (
            <>
              <svg className="nx-run-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
              {sourceDirty ? 'SAVE & RUN' : 'RUN'}
            </>
          )}
        </button>

        <div className={`nx-judge-metrics-panel ${
          activeTC.verdict === 'AC' ? 'passed' : ''
        } ${
          activeTC.verdict && activeTC.verdict !== 'AC' && activeTC.verdict !== 'IDLE' && activeTC.verdict !== 'RUNNING' && activeTC.verdict !== 'CANCELLED' ? 'failed' : ''
        } ${showWaEffect ? 'wa-shake' : ''}`}>
          {activeTC.verdict === 'RUNNING' ? (
            <span className="nx-metric-chip running">RUNNING...</span>
          ) : (
            <>
              <div className="nx-metric-chip" title="Elapsed wall time, including sandbox startup">
                {activeTC.time !== undefined ? `${activeTC.time}ms` : '--'}
              </div>
              <div className="nx-metric-divider">│</div>
              <div className="nx-metric-chip" title={activeTC.memoryMeasured ? 'Sampled process-group RSS (shared pages may be counted twice; short peaks may be missed)' : 'Memory measurement unavailable'}>
                {activeTC.memoryMeasured && activeTC.memory !== undefined ? `${activeTC.memory}MB` : '--'}
              </div>
              <div className="nx-metric-divider">│</div>
              <div className={`nx-metric-chip verdict-chip ${
                activeTC.verdict === 'AC' ? 'passed' : ''
              } ${
                activeTC.verdict && activeTC.verdict !== 'AC' && activeTC.verdict !== 'IDLE' && activeTC.verdict !== 'CANCELLED' ? 'failed' : ''
              }`} title={getVerdictLabel(activeTC.verdict)}>
                {activeTC.verdict || 'IDLE'}
              </div>
            </>
          )}
        </div>
      </div>
      </>}
    </div>
  );
};

export default JudgeSystem;
