import { useEffect, useRef, useState } from 'react';

export const DEFAULT_WORKSPACE_WIDTH = 340;
export function clampWorkspaceWidth(width: number) { return Math.max(270, Math.min(540, width)); }

/** A quiet shared edge, available to pointer and keyboard users. */
export function WorkspaceResize({ width, onChange }: { width: number; onChange: (width: number) => void }) {
  const [viewportWidth, setViewportWidth] = useState(window.innerWidth);
  useEffect(() => { const resize = () => setViewportWidth(window.innerWidth); window.addEventListener('resize', resize); return () => window.removeEventListener('resize', resize); }, []);
  const maximum = Math.max(270, Math.min(540, Math.floor(viewportWidth * .45)));
  const visibleWidth = Math.min(width, maximum);
  const change = (value: number) => onChange(Math.min(maximum, clampWorkspaceWidth(value)));
  const drag = useRef<{ x: number; width: number } | null>(null);
  return <div className="nx-workspace-resize" role="separator" aria-label="Workspace panel width" aria-orientation="vertical" aria-valuemin={270} aria-valuemax={maximum} aria-valuenow={visibleWidth} tabIndex={0}
    onDoubleClick={() => change(DEFAULT_WORKSPACE_WIDTH)}
    onKeyDown={event => {
      const value = event.key === 'ArrowLeft' ? visibleWidth - 16 : event.key === 'ArrowRight' ? visibleWidth + 16 : event.key === 'Home' ? 270 : event.key === 'End' ? 540 : null;
      if (value !== null) { event.preventDefault(); event.stopPropagation(); change(value); }
    }}
    onPointerDown={event => { if (event.button !== 0) return; event.preventDefault(); event.currentTarget.focus(); event.currentTarget.setPointerCapture(event.pointerId); drag.current = { x: event.clientX, width: visibleWidth }; }}
    onPointerMove={event => { if (drag.current) change(drag.current.width + event.clientX - drag.current.x); }}
    onPointerUp={event => { drag.current = null; if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); }}
    onLostPointerCapture={() => { drag.current = null; }}
    onPointerCancel={() => { drag.current = null; }}
  />;
}
