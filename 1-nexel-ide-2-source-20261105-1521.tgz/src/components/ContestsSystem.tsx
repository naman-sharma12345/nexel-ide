import React, { useState, useEffect, useRef } from 'react';
import { useEditorStore } from '../stores/useEditorStore';
import { useStatusStore } from '../stores/useStatusStore';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import './ContestsSystem.css';

interface Contest {
  id: number;
  name: string;
  type: string;
  phase: 'BEFORE' | 'CODING' | 'FINISHED' | 'PENDING_SYSTEM_TEST' | 'SYSTEM_TEST';
  durationSeconds: number;
  startTimeSeconds: number;
  relativeTimeSeconds?: number;
}

interface CategorizedContests {
  active: Contest[];
  upcoming: Contest[];
  passed: Contest[];
}

export interface CFProblem extends Record<string, unknown> {
  index: string;
  title?: string;
  error?: string;
  url: string;
  timeLimit: string;
  memoryLimit: string;
  statement?: string;
  inputFormat?: string;
  outputFormat?: string;
  note?: string;
  testCases?: Array<{ input: string; output: string }>;
}

export function readContests(data: unknown): CategorizedContests {
  const invalid = () => new Error('The contest list response was incomplete. Please retry.');
  if (!data || typeof data !== 'object') throw invalid();
  const result = data as Record<string, unknown>;
  const phases = { active: 'CODING', upcoming: 'BEFORE', passed: 'FINISHED' };
  for (const [category, phase] of Object.entries(phases)) {
    const contests = result[category];
    if (!Array.isArray(contests)) throw invalid();
    const ids = new Set<number>();
    for (const contest of contests) {
      if (!contest || typeof contest !== 'object' || !Number.isInteger(contest.id) || contest.id < 1 || contest.id > 99999999
        || ids.has(contest.id) || typeof contest.name !== 'string' || typeof contest.type !== 'string' || contest.phase !== phase
        || !Number.isFinite(contest.durationSeconds) || contest.durationSeconds < 0
        || !Number.isFinite(contest.startTimeSeconds) || !Number.isFinite(new Date(contest.startTimeSeconds * 1000).getTime())) throw invalid();
      ids.add(contest.id);
    }
  }
  return data as CategorizedContests;
}

export function readContestProblems(data: unknown): CFProblem[] {
  const invalid = () => new Error('The contest response was incomplete. Please retry.');
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw invalid();
  const indices = new Set<string>();
  const problems = Object.values(data).map((value: unknown) => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw invalid();
    const problem = value as Record<string, unknown>;
    if (typeof problem.index !== 'string' || !/^[A-Za-z][A-Za-z0-9]{0,2}$/.test(problem.index)) throw invalid();
    const index = problem.index.toUpperCase();
    if (indices.has(index)) throw invalid();
    indices.add(index);
    for (const field of ['title', 'error', 'url', 'timeLimit', 'memoryLimit', 'statement', 'inputFormat', 'outputFormat', 'note']) {
      if (problem[field] !== undefined && typeof problem[field] !== 'string') throw invalid();
    }
    if (problem.testCases !== undefined && (!Array.isArray(problem.testCases) || problem.testCases.some(sample =>
      !sample || typeof sample !== 'object' || typeof sample.input !== 'string' || typeof sample.output !== 'string'))) throw invalid();
    return { ...problem, index } as CFProblem;
  });
  return problems.sort((a, b) => a.index.localeCompare(b.index));
}

export const ContestsSystem: React.FC = () => {
  const [contests, setContests] = useState<CategorizedContests | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // States for viewing a specific contest's problems
  const [selectedContest, setSelectedContest] = useState<{ id: number; name: string } | null>(null);
  const [problems, setProblems] = useState<CFProblem[] | null>(null);
  const [problemsLoading, setProblemsLoading] = useState<boolean>(false);
  const selectedRequest = useRef(0);
  useEffect(() => () => { selectedRequest.current += 1; }, []);

  // Upcoming contest detail view (countdown + auto-load at start)
  const [upcoming, setUpcoming] = useState<Contest | null>(null);
  const [now, setNow] = useState<number>(() => Date.now());
  useEffect(() => {
    if (!upcoming) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [upcoming]);
  const upcomingStarted = !!upcoming && now >= upcoming.startTimeSeconds * 1000;
  useEffect(() => {
    if (upcoming && upcomingStarted) {
      const c = upcoming;
      setUpcoming(null);
      void handleContestClick({ preventDefault() {} } as React.MouseEvent, { ...c, phase: 'CODING' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [upcomingStarted]);

  // Custom fetch inputs
  const [customInput, setCustomInput] = useState<string>('');
  const [customLoading, setCustomLoading] = useState<boolean>(false);
  const [customError, setCustomError] = useState<string | null>(null);
  const customRef = useRef<HTMLInputElement>(null);
  const customBusy = useRef(false);
  const listBusy = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const [listRetryFocus, setListRetryFocus] = useState(false);
  useEffect(() => {
    if (!listRetryFocus || loading) return;
    if (listRef.current?.closest('.nx-contests-wrapper')?.contains(document.activeElement)) {
      (listRef.current?.querySelector<HTMLElement>('a.nx-contest-card') || customRef.current)?.focus();
    }
    setListRetryFocus(false);
  }, [listRetryFocus, loading, contests]);

  const selectedRef = useRef<HTMLDivElement>(null);
  const backRef = useRef<HTMLButtonElement>(null);
  const [focusTarget, setFocusTarget] = useState<'back' | 'custom' | 'problems' | null>(null);
  useEffect(() => {
    if (!focusTarget || (focusTarget === 'problems' && problemsLoading)) return;
    if (focusTarget === 'problems' && !selectedRef.current?.contains(document.activeElement)) { setFocusTarget(null); return; }
    const target = focusTarget === 'custom' ? customRef.current
      : focusTarget === 'problems'
        ? selectedRef.current?.querySelector<HTMLElement>('.nx-problem-row-card[tabindex="0"]') || backRef.current
        : backRef.current;
    if (target) { target.focus(); setFocusTarget(null); }
  }, [focusTarget, problemsLoading, selectedContest, problems, upcoming]);

  // Custom modal dialog states
  const [showPrompt, setShowPrompt] = useState<boolean>(false);
  const [problemCount, setProblemCount] = useState<string>('4');
  const [promptDestination, setPromptDestination] = useState<string | null>(null);
  const [promptError, setPromptError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const generatingRef = useRef(false);
  const promptRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!showPrompt) return;
    const previous = document.activeElement as HTMLElement | null;
    promptRef.current?.querySelector('input')?.focus();
    return () => {
      if (previous?.isConnected) {
        if (previous.matches(':disabled')) backRef.current?.focus();
        else previous.focus();
      }
    };
  }, [showPrompt]);

  const handleCustomFetch = async () => {
    if (customBusy.current) return;
    const raw = customInput.trim();
    if (!raw) return;

    const match = raw.match(/^(\d+)(?:\s*[\/\s-]*\s*([A-Za-z0-9]+))?$/);
    if (!match) {
      setCustomError('Enter a contest ID (e.g. 1981) or problem (e.g. 1981A).');
      customRef.current?.focus();
      return;
    }

    const contestId = parseInt(match[1], 10);
    const problemIndex = match[2] ? match[2].toUpperCase() : null;
    if (!Number.isInteger(contestId) || contestId < 1 || contestId > 99999999 || (problemIndex && !/^[A-Z][A-Z0-9]{0,2}$/.test(problemIndex))) {
      setCustomError('Use a contest ID from 1 to 99999999 and a problem index such as A or A1.');
      customRef.current?.focus();
      return;
    }

    customBusy.current = true;
    setCustomLoading(true);
    setCustomError(null);
    setError(null);

    try {
      const data = await window.nexelAPI.fetchContestProblems(contestId);
      const arr = readContestProblems(data);
      
      setSelectedContest({ id: contestId, name: `Contest ${contestId}` });
      setProblems(arr);

      if (problemIndex) {
        const found = arr.find((p) => p.index.toUpperCase() === problemIndex);
        if (found) {
          if (found.error) {
            setError(`Could not load problem: ${found.error}`);
            setFocusTarget('back');
          } else {
            useEditorStore.getState().openCfProblem(contestId, found);
          }
        } else {
          setFocusTarget('back');
          setError(`Problem ${problemIndex} not found in contest ${contestId}. Available problems: ${arr.map((p) => p.index).join(', ') || 'none'}`);
        }
      }
      if (!problemIndex) setFocusTarget('back');
      setCustomInput('');
    } catch (err: unknown) {
      console.error(err);
      const message = err instanceof Error ? err.message : String(err);
      setCustomError(`Could not load contest or problem: ${message || 'Unknown error'}`);
    } finally {
      customBusy.current = false;
      setCustomLoading(false);
    }
  };

  const handleOpenToFolder = () => {
    if (!selectedContest || generatingRef.current) return;
    const activeDir = useWorkspaceStore.getState().activeDir || useWorkspaceStore.getState().rootPath;
    if (!activeDir) {
      useStatusStore.getState().pushToast('Open a workspace folder in Explorer before generating contest files.', 'info');
      return;
    }
    if (problems && problems.length > 0) {
      setProblemCount(problems.length.toString());
    } else {
      setProblemCount('4');
    }
    setPromptDestination(activeDir);
    setPromptError(null);
    setShowPrompt(true);
  };

  const confirmOpenToFolder = async () => {
    if (!selectedContest || generatingRef.current) return;
    const activeDir = useWorkspaceStore.getState().activeDir || useWorkspaceStore.getState().rootPath;
    if (!activeDir || activeDir !== promptDestination) { setPromptError('The destination changed. Cancel and reopen this prompt to confirm the new folder.'); return; }

    const count = Number(problemCount);
    if (!Number.isInteger(count) || count < 1 || count > 26) {
      setPromptError('Enter a whole number from 1 to 26.');
      promptRef.current?.querySelector('input')?.focus();
      return;
    }

    generatingRef.current = true;
    setGenerating(true);
    setShowPrompt(false);
    const contestFolderName = selectedContest.id.toString();
    const cppTemplate = useEditorStore.getState().cppTemplate || '';
    try {
      const contestFolderPath = await window.nexelAPI.createFolder(activeDir, contestFolderName);


      for (let i = 0; i < count; i++) {
        const problemChar = String.fromCharCode(65 + i);
        const fileName = `${problemChar}.cpp`;
        const filePath = await window.nexelAPI.createFile(contestFolderPath, fileName);
        if (cppTemplate) {
          await window.nexelAPI.writeFileContent(filePath, cppTemplate);
        }
      }

      await useWorkspaceStore.getState().refreshTree();

      useStatusStore.getState().pushToast(`Created contest ${contestFolderName} with ${count} problem files in ${contestFolderPath}.`, 'success');
    } catch (err: unknown) {
      console.error(err);
      const message = err instanceof Error ? err.message : String(err);
      useStatusStore.getState().pushToast(`Could not finish generating contest ${contestFolderName}: ${message || 'Unknown error'}. Some files may already exist; check the folder before retrying.`, 'error', 6000);
    } finally {
      generatingRef.current = false;
      setGenerating(false);
    }
  };

  const fetchContestsList = async () => {
    if (listBusy.current) return;
    listBusy.current = true;
    setLoading(true);
    setError(null);
    try {
      const result = await window.nexelAPI.fetchContests();
      setContests(readContests(result));
    } catch (err: unknown) {
      console.error(err);
      const message = err instanceof Error ? err.message : String(err);
      setError(message || 'Failed to fetch contests.');
    } finally {
      listBusy.current = false;
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContestsList();
  }, []);

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (minutes === 0) return `${hours} hrs`;
    return `${hours}h ${minutes}m`;
  };

  const formatStartTime = (seconds: number) => {
    return new Date(seconds * 1000).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleContestClick = async (e: React.MouseEvent, contest: Contest) => {
    e.preventDefault();
    if (contest.phase === 'BEFORE') {
      setFocusTarget('back');
      setUpcoming(contest);
      return;
    }
    const request = ++selectedRequest.current;
    setFocusTarget('back');
    setSelectedContest({ id: contest.id, name: contest.name });
    setProblemsLoading(true);
    setProblems(null);
    setError(null);
    try {
      const data = await window.nexelAPI.fetchContestProblems(contest.id);
      if (request !== selectedRequest.current) return;
      const arr = readContestProblems(data);
      setProblems(arr);
    } catch (err: unknown) {
      console.error(err);
      const message = err instanceof Error ? err.message : String(err);
      if (request === selectedRequest.current) setError(message || 'Failed to load contest problems.');
    } finally {
      if (request === selectedRequest.current) setProblemsLoading(false);
    }
  };

  if (upcoming && !selectedContest) {
    const left = Math.max(0, Math.floor(upcoming.startTimeSeconds - now / 1000));
    const d = Math.floor(left / 86400), h = Math.floor((left % 86400) / 3600), m = Math.floor((left % 3600) / 60), sec = left % 60;
    const pad = (n: number) => String(n).padStart(2, '0');
    const startIst = new Date(upcoming.startTimeSeconds * 1000).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' });
    return (
      <div className="nx-contests-wrapper">
        <div className="nx-contests-header">
          <button ref={backRef} className="nx-contests-back-btn" onClick={() => { setUpcoming(null); setFocusTarget('custom'); }}>← Back</button>
          <h3 className="nx-contests-title">{upcoming.name}</h3>
        </div>
        <div className="nx-contests-scroll-area" role="region" aria-label="Upcoming contest details" tabIndex={0}>
        <div className="nx-contests-status-msg" style={{ gap: 12 }}>
          <div className="nx-contests-countdown" style={{ fontSize: 34, fontWeight: 700, letterSpacing: 1, fontVariantNumeric: 'tabular-nums', color: 'var(--nx-accent, #4ade80)' }}>
            {d > 0 ? `${d}d ` : ''}{pad(h)}:{pad(m)}:{pad(sec)}
          </div>
          <p>Starts {startIst} IST · {formatDuration(upcoming.durationSeconds)}</p>
          <p style={{ opacity: 0.7 }}>Problems load automatically when the contest starts.</p>
          <button className="nx-retry-btn" onClick={() => window.open(`https://codeforces.com/contestRegistration/${upcoming.id}`, '_blank', 'noopener')}>Register on Codeforces</button>
          <button className="nx-retry-btn" onClick={() => { const contest = upcoming; setUpcoming(null); void handleContestClick({ preventDefault() {} } as React.MouseEvent, { ...contest, phase: 'CODING' }); }}>Try loading problems now</button>
        </div>
        </div>
      </div>
    );
  }

  if (selectedContest) {
    return (
      <div ref={selectedRef} className="nx-contests-wrapper">
        <div className="nx-contests-header">
          <button
            ref={backRef}
            className="nx-contests-back-btn" 
            onClick={() => { selectedRequest.current += 1; setSelectedContest(null); setProblems(null); setProblemsLoading(false); setError(null); setFocusTarget('custom'); }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="nx-back-icon">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            BACK
          </button>
          <button className="nx-contests-folder-btn" onClick={handleOpenToFolder} disabled={generating} aria-busy={generating} title="Create folders for this contest in workspace">
            {generating ? 'Generating...' : 'Open To Folder'}
          </button>
        </div>

        <div className="nx-contests-scroll-area" role="region" aria-label="Contest problems" tabIndex={0}>
          <div className="nx-contest-header-banner">
            <h3 className="nx-banner-name">{selectedContest.name}</h3>
          </div>

          {problemsLoading && (
            <div className="nx-contests-status-msg">
              <span className="nx-contests-loader" />
              <p>Fetching problems...</p>
            </div>
          )}

          {(error || (!problemsLoading && problems?.length === 0)) && (
            <div className={`nx-contests-status-msg${error ? ' error' : ''}`} role="status">
              {error && <svg className="nx-error-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>}
              <p>{error || 'No problems are available for this contest yet. Try again or go Back to choose another contest.'}</p>
              <button 
                className="nx-retry-btn" 
                onClick={() => {
                  const request = ++selectedRequest.current;
                  backRef.current?.focus();
                  setFocusTarget('problems');
                  setProblemsLoading(true);
                  setError(null);
                  window.nexelAPI.fetchContestProblems(selectedContest.id)
                    .then((data) => {
                      if (request !== selectedRequest.current) return;
                      const arr = readContestProblems(data);
                      setProblems(arr);
                    })
                    .catch((err: unknown) => {
                      const message = err instanceof Error ? err.message : String(err);
                      if (request === selectedRequest.current) setError(message || 'Failed.');
                    })
                    .finally(() => { if (request === selectedRequest.current) setProblemsLoading(false); });
                }}
              >
                Retry
              </button>
            </div>
          )}

          {!problemsLoading && problems && problems.length > 0 && (
            <div className="nx-problems-list">
              <span className="nx-section-title">CONTEST PROBLEMS</span>
              <div className="nx-contests-cards-list">
                {problems.map((prob) => (
                  <div 
                    key={prob.index} 
                    className={`nx-problem-row-card ${prob.error ? 'error' : ''}`}
                    role="button" tabIndex={prob.error ? -1 : 0} aria-disabled={!!prob.error}
                    aria-label={`${prob.index}: ${prob.title || prob.error || 'Problem Statement'}`}
                    onKeyDown={event => {
                      if (!prob.error && (event.key === 'Enter' || event.key === ' ')) {
                        event.preventDefault();
                        useEditorStore.getState().openCfProblem(selectedContest.id, prob);
                      }
                    }}
                    onClick={() => {
                      if (!prob.error) {
                        useEditorStore.getState().openCfProblem(selectedContest.id, prob);
                      }
                    }}
                  >
                    <div className="nx-problem-row-info">
                      <span className="nx-problem-row-index">{prob.index}</span>
                      <span className="nx-problem-row-title">{prob.title || prob.error || 'Problem Statement'}</span>
                    </div>
                    {!prob.error && (
                      <svg className="nx-problem-arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <polyline points="9 18 15 12 9 6" />
                      </svg>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {showPrompt && (
          <div className="nx-prompt-modal-overlay">
            <div ref={promptRef} className="nx-prompt-modal" role="dialog" aria-modal="true" aria-labelledby="nx-prompt-heading" aria-describedby="nx-prompt-description" onKeyDown={event => {
              if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); setShowPrompt(false); }
              if (event.key === 'Tab') {
                const controls = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('input,button'));
                const first = controls[0], last = controls[controls.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
              }
            }}>
              <h4 id="nx-prompt-heading" className="nx-prompt-title">Generate Folder</h4>
              <p id="nx-prompt-description" className="nx-prompt-desc">
                Create <strong>{selectedContest.id}</strong> with template files?
              </p>
              <p className="nx-prompt-destination" title={promptDestination || undefined}>Destination: {promptDestination}</p>
              <div className="nx-prompt-field">
                <label className="nx-prompt-label" htmlFor="nx-prob-count-input">Number of problems (1-26):</label>
                <input
                  id="nx-prob-count-input"
                  type="number"
                  min="1"
                  max="26"
                  value={problemCount}
                  onChange={(e) => {setProblemCount(e.target.value);setPromptError(null);}}
                  aria-invalid={!!promptError}
                  aria-describedby={promptError ? 'nx-prompt-error' : undefined}
                  className="nx-prompt-input"
                />
              </div>
              {promptError && <p id="nx-prompt-error" className="nx-prompt-error" role="alert">{promptError}</p>}
              <div className="nx-prompt-actions">
                <button className="nx-prompt-cancel-btn" onClick={() => setShowPrompt(false)}>
                  Cancel
                </button>
                <button className="nx-prompt-confirm-btn" onClick={confirmOpenToFolder}>
                  Generate
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="nx-contests-wrapper">
      <div className="nx-contests-header">
        <span className="nx-contests-title">CODEFORCES CONTESTS</span>
        <button 
          className={`nx-contests-sync-btn ${loading ? 'syncing' : ''}`}
          onClick={fetchContestsList}
          disabled={loading}
          title="Sync Codeforces Contests"
        >
          <svg className="nx-sync-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l.56-1.19" />
          </svg>
        </button>
      </div>

      <div className="nx-contests-custom-fetch">
        <input 
          type="text"
          ref={customRef}
          aria-label="Contest ID or problem"
          aria-invalid={!!customError}
          aria-describedby={customError ? 'nx-custom-fetch-error' : undefined}
          placeholder={customLoading ? "Importing..." : "Contest ID or Problem (e.g. 1981A)"}
          value={customInput}
          onChange={(e) => {setCustomInput(e.target.value);setCustomError(null);}}
          onKeyDown={(e) => { if (e.key === 'Enter') handleCustomFetch(); }}
          readOnly={customLoading}
          aria-busy={customLoading}
          className="nx-contests-custom-input"
        />
        <button 
          onClick={handleCustomFetch}
          disabled={!customInput.trim() || customLoading}
          className="nx-contests-custom-btn"
        >
          {customLoading ? <span className="nx-custom-spinner" /> : "Import"}
        </button>
      </div>

      {customError && <p id="nx-custom-fetch-error" className="nx-custom-fetch-error" role="alert" tabIndex={0}>{customError}</p>}

      <div ref={listRef} className="nx-contests-scroll-area" role="region" aria-label="Contest list" tabIndex={0}>
        {loading && !contests && (
          <div className="nx-contests-status-msg">
            <span className="nx-contests-loader" />
            <p>Fetching contests...</p>
          </div>
        )}

        {error && (
          <div className="nx-contests-status-msg error">
            <svg className="nx-error-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <p>{error}</p>
            <button className="nx-retry-btn" onClick={() => { customRef.current?.focus(); setListRetryFocus(true); void fetchContestsList(); }}>Retry</button>
          </div>
        )}

        {contests && (
          <div className="nx-contests-sections-stack">
            {/* Active section */}
            <div className="nx-contests-section">
              <div className="nx-contests-section-hdr">
                <span className="nx-section-badge active" />
                <span className="nx-section-title">ACTIVE NOW</span>
              </div>
              <div className="nx-contests-cards-list">
                {contests.active.length > 0 ? (
                  contests.active.map((contest) => (
                    <a 
                      key={contest.id}
                      className="nx-contest-card active-card"
                      href={`https://codeforces.com/contest/${contest.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => handleContestClick(e, contest)}
                    >
                      <div className="nx-contest-card-meta">
                        <span className="nx-contest-id">#{contest.id}</span>
                        <span className="nx-contest-duration">{formatDuration(contest.durationSeconds)}</span>
                      </div>
                      <h4 className="nx-contest-name">{contest.name}</h4>
                      <div className="nx-contest-status-line">
                        <span className="nx-pulse-dot" />
                        CODING NOW
                      </div>
                    </a>
                  ))
                ) : (
                  <div className="nx-contest-empty-card">No contests active at the moment.</div>
                )}
              </div>
            </div>

            {/* Upcoming section */}
            <div className="nx-contests-section">
              <div className="nx-contests-section-hdr">
                <span className="nx-section-badge upcoming" />
                <span className="nx-section-title">UPCOMING CONTESTS</span>
              </div>
              <div className="nx-contests-cards-list">
                {contests.upcoming.length > 0 ? (
                  contests.upcoming.map((contest) => (
                    <a 
                      key={contest.id}
                      className="nx-contest-card upcoming-card"
                      href={`https://codeforces.com/contest/${contest.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => handleContestClick(e, contest)}
                    >
                      <div className="nx-contest-card-meta">
                        <span className="nx-contest-id">#{contest.id}</span>
                        <span className="nx-contest-duration">{formatDuration(contest.durationSeconds)}</span>
                      </div>
                      <h4 className="nx-contest-name">{contest.name}</h4>
                      <div className="nx-contest-time-info">
                        <svg className="nx-time-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
                        </svg>
                        <span>{formatStartTime(contest.startTimeSeconds)}</span>
                      </div>
                    </a>
                  ))
                ) : (
                  <div className="nx-contest-empty-card">No upcoming contests scheduled.</div>
                )}
              </div>
            </div>

            {/* Passed section */}
            <div className="nx-contests-section">
              <div className="nx-contests-section-hdr">
                <span className="nx-section-badge passed" />
                <span className="nx-section-title">RECENT PAST CONTESTS</span>
              </div>
              <div className="nx-contests-cards-list">
                {contests.passed.length > 0 ? (
                  contests.passed.map((contest) => (
                    <a 
                      key={contest.id}
                      className="nx-contest-card passed-card"
                      href={`https://codeforces.com/contest/${contest.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => handleContestClick(e, contest)}
                    >
                      <div className="nx-contest-card-meta">
                        <span className="nx-contest-id">#{contest.id}</span>
                        <span className="nx-contest-duration">{formatDuration(contest.durationSeconds)}</span>
                      </div>
                      <h4 className="nx-contest-name">{contest.name}</h4>
                      <div className="nx-contest-status-line completed">
                        FINISHED
                      </div>
                    </a>
                  ))
                ) : (
                  <div className="nx-contest-empty-card">No past contest data.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContestsSystem;
