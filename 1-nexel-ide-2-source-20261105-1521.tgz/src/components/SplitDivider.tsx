import {useEffect,useRef} from 'react';
interface Props { ratio:number; onChange:(ratio:number)=>void; }
const clamp=(value:number)=>Math.min(80,Math.max(20,value));
export function SplitDivider({ratio,onChange}:Props) {
 const divider=useRef<HTMLDivElement>(null);
 const drag = useRef<number | null>(null);
 const stop = (node: HTMLDivElement, pointerId: number) => {
  drag.current = null;node.classList.remove('dragging');
  if(node.hasPointerCapture(pointerId))node.releasePointerCapture(pointerId);
 };
 useEffect(()=>{const blur=()=>{if(divider.current&&drag.current!==null)stop(divider.current,drag.current);};window.addEventListener('blur',blur);return()=>window.removeEventListener('blur',blur);},[]);
 return <div ref={divider} className="nx-editor-split-divider" role="separator" aria-label="Resize editor panes" aria-orientation="vertical" aria-valuemin={20} aria-valuemax={80} aria-valuenow={Math.round(ratio)} aria-valuetext={`Left pane ${Math.round(ratio)} percent`} tabIndex={0}
 onPointerDown={event=>{if(event.button!==0||drag.current!==null)return;event.preventDefault();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);drag.current=event.pointerId;event.currentTarget.classList.add('dragging');}}
 onPointerMove={event=>{if(drag.current!==event.pointerId)return;const rect=divider.current?.parentElement?.getBoundingClientRect();if(rect&&rect.width>0)onChange(clamp((event.clientX-rect.left)/rect.width*100));}}
 onPointerUp={event=>{if(drag.current===event.pointerId)stop(event.currentTarget,event.pointerId);}}
 onPointerCancel={event=>{if(drag.current===event.pointerId)stop(event.currentTarget,event.pointerId);}}
 onLostPointerCapture={event=>{if(drag.current===event.pointerId){drag.current=null;event.currentTarget.classList.remove('dragging');}}}
 onBlur={event=>{if(drag.current!==null)stop(event.currentTarget,drag.current);}}
 onKeyDown={event=>{
  let next:number;
  if(event.key==='ArrowLeft')next=ratio-(event.shiftKey?10:2);
  else if(event.key==='ArrowRight')next=ratio+(event.shiftKey?10:2);
  else if(event.key==='Home')next=20;else if(event.key==='End')next=80;
  else return;
  event.preventDefault();event.stopPropagation();onChange(clamp(next));
 }} onDoubleClick={()=>onChange(50)}><div className="nx-divider-glow-line" /></div>;
}
