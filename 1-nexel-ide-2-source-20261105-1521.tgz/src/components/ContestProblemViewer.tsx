import React, {useEffect, useRef} from 'react';
import {useJudgeStore} from '../stores/useJudgeStore';
import {useStatusStore} from '../stores/useStatusStore';

interface ContestProblemViewerProps {
  focused?: boolean;
  focusRequest?: number;
  problemData: {
    url: string;
    index: string;
    title: string;
    timeLimit: string;
    memoryLimit: string;
    statement?: string;
    inputFormat?: string;
    outputFormat?: string;
    note?: string;
    testCases?: Array<{ input: string; output: string }>;
  };
}

export const ContestProblemViewer: React.FC<ContestProblemViewerProps> = React.memo(({ problemData, focused = false, focusRequest = 0 }) => {
  const viewerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (focused) viewerRef.current?.focus({preventScroll: true});
  }, [focused, focusRequest]);
  useEffect(() => {
    const mj = (window as any).MathJax;
    if (mj && mj.typesetPromise) {
      mj.typesetPromise();
    }
  }, [problemData.url]);

  const handleImportSamples = () => {
    if (problemData.testCases?.length && Array.isArray(problemData.testCases)) {
      useJudgeStore.getState().importSamples(problemData.testCases);
      useStatusStore.getState().pushToast('Sample tests imported. Open Judge to run them.', 'success');
    }
  };

  const copySample = async (text: string, label: string) => {
    try {
      if (window.nexelAPI.writeClipboardText) window.nexelAPI.writeClipboardText(text);
      else await navigator.clipboard.writeText(text);
      useStatusStore.getState().pushToast(`${label} copied.`, 'success');
    } catch {
      useStatusStore.getState().pushToast('Could not copy sample. Clipboard access is unavailable.', 'error');
    }
  };

  return (
    <div ref={viewerRef} className="nx-cf-problem-viewer" role="region" aria-label="Problem statement" tabIndex={0}>
      <div className="nx-cf-problem-header">
        <h1 className="nx-cf-problem-title">{problemData.index}. {problemData.title}</h1>
        <div className="nx-cf-problem-meta-row">
          <div className="nx-cf-meta-chip">
            <span className="label">TIME LIMIT</span>
            <span className="value">{problemData.timeLimit}</span>
          </div>
          <div className="nx-cf-meta-chip">
            <span className="label">MEMORY LIMIT</span>
            <span className="value">{problemData.memoryLimit}</span>
          </div>
          <button className="nx-cf-import-btn" disabled={!problemData.testCases?.length} title={problemData.testCases?.length ? undefined : 'No sample tests available'} onClick={handleImportSamples}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="nx-import-icon">
              <path d="M12 5v14M5 12h14" />
            </svg>
            IMPORT SAMPLES TO JUDGE
          </button>
        </div>
      </div>

      <div className="nx-cf-problem-body" role="region" aria-label="Problem content" tabIndex={0}>
        {problemData.statement && (
          <div className="nx-cf-section statement-section">
            <div dangerouslySetInnerHTML={{ __html: problemData.statement }} />
          </div>
        )}

        {problemData.inputFormat && (
          <div className="nx-cf-section">
            <h3 className="nx-cf-section-title">Input</h3>
            <div dangerouslySetInnerHTML={{ __html: problemData.inputFormat }} />
          </div>
        )}

        {problemData.outputFormat && (
          <div className="nx-cf-section">
            <h3 className="nx-cf-section-title">Output</h3>
            <div dangerouslySetInnerHTML={{ __html: problemData.outputFormat }} />
          </div>
        )}

        {problemData.testCases && problemData.testCases.length > 0 && (
          <div className="nx-cf-section">
            <h3 className="nx-cf-section-title">Sample Tests</h3>
            <div className="nx-cf-samples-stack">
              {problemData.testCases.map((tc, idx) => (
                <div key={idx} className="nx-cf-sample-box">
                  <div className="nx-cf-sample-header">
                    <span className="nx-sample-num">Example #{idx + 1}</span>
                    <div className="nx-cf-sample-actions">
                      <button
                        className="nx-cf-copy-sample-btn"
                        aria-label={`Copy sample ${idx + 1} input`}
                        onClick={() => void copySample(tc.input, `Sample input #${idx + 1}`)}
                      >
                        Copy Input
                      </button>
                      <button
                        className="nx-cf-copy-sample-btn"
                        aria-label={`Copy sample ${idx + 1} output`}
                        onClick={() => void copySample(tc.output, `Sample output #${idx + 1}`)}
                      >
                        Copy Output
                      </button>
                    </div>
                  </div>
                  <div className="nx-cf-sample-grid">
                    <div className="nx-cf-sample-column">
                      <div className="nx-cf-sample-label">INPUT</div>
                      <pre className="nx-cf-sample-pre" role="region" tabIndex={0} aria-label={`Sample ${idx + 1} input code`}><code>{tc.input}</code></pre>
                    </div>
                    <div className="nx-cf-sample-column">
                      <div className="nx-cf-sample-label">OUTPUT</div>
                      <pre className="nx-cf-sample-pre" role="region" tabIndex={0} aria-label={`Sample ${idx + 1} output code`}><code>{tc.output}</code></pre>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {problemData.note && (
          <div className="nx-cf-section note-section">
            <h3 className="nx-cf-section-title">Note</h3>
            <div dangerouslySetInnerHTML={{ __html: problemData.note }} />
          </div>
        )}
      </div>
    </div>
  );
});
