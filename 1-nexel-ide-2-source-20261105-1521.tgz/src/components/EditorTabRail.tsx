import { useEffect, useMemo, useRef } from 'react';
import {tabPathLabels} from '../lib/tabPathLabels';
import type { EditorTab } from '../stores/useEditorStore';

interface EditorTabRailProps {
  tabs: EditorTab[];
  orientation?: 'horizontal' | 'vertical';
  focusedPath: string | null;
  rightPath: string | null;
  isSplit: boolean;
  celebration: boolean;
  onSelect: (path: string, focusEditor?: boolean) => void;
  onClose: (path: string) => void;
  onSplit: (path: string) => void;
  onMove: (from: string, to: string) => void;
}

export function EditorTabRail({ tabs, orientation = 'horizontal', focusedPath, rightPath, isSplit, celebration, onSelect, onClose, onSplit, onMove }: EditorTabRailProps) {
  const rail = useRef<HTMLDivElement>(null);
  const parentLabels=useMemo(()=>tabPathLabels(tabs),[tabs]);
  useEffect(() => {
    const reveal = () => {
      const container = rail.current;
      if (container && orientation === 'horizontal') {
        // Measure natural tab widths with the shrink attr off, then restore: the
        // shrunk state would report no overflow and flap on every reveal.
        container.dataset.overflow = 'false';
        const naturalOverflow = container.scrollWidth > container.clientWidth + 1;
        container.dataset.overflow = String(naturalOverflow);
        container.dataset.before = String(container.scrollLeft > 2);
        container.dataset.after = String(container.scrollLeft + container.clientWidth < container.scrollWidth - 2);
      }
      const selected = container?.querySelector<HTMLElement>('[aria-selected="true"]');
      if (!container || !selected) return;
      const bounds = container.getBoundingClientRect();
      const tab = selected.parentElement!.getBoundingClientRect();
      if (orientation === 'vertical') {
        if (tab.top < bounds.top) container.scrollTop -= bounds.top - tab.top;
        else if (tab.bottom > bounds.bottom) container.scrollTop += tab.bottom - bounds.bottom;
        return;
      }
      if (tab.width > bounds.width) container.scrollLeft += tab.left - bounds.left;
      else if (tab.left < bounds.left) container.scrollLeft -= bounds.left - tab.left;
      else if (tab.right > bounds.right) container.scrollLeft += tab.right - bounds.right;
      container.dataset.before = String(container.scrollLeft > 2);
      container.dataset.after = String(container.scrollLeft + container.clientWidth < container.scrollWidth - 2);
    };
    reveal();
    if (!rail.current || typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(reveal);
    observer.observe(rail.current);
    return () => observer.disconnect();
  }, [focusedPath, tabs.length, orientation]);
  function navigate(event: React.KeyboardEvent, index: number) {
    const previous = orientation === 'vertical' ? 'ArrowUp' : 'ArrowLeft';
    const nextKey = orientation === 'vertical' ? 'ArrowDown' : 'ArrowRight';
    if (event.ctrlKey || event.metaKey || event.altKey || ![previous, nextKey, 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (index + (event.key === nextKey ? 1 : -1) + tabs.length) % tabs.length;
    onSelect(tabs[next].filePath);
    rail.current?.querySelectorAll<HTMLButtonElement>('.nx-tab-select')[next]?.focus();
  }
  return <div ref={rail} className={`nx-tabs-scroll-stack ${orientation === 'vertical' ? 'nx-document-index-rail' : ''}`} role="tablist" aria-orientation={orientation} aria-label="Open files" title="Open files: use Left/Right or Home/End to switch" onScroll={e => {
    const el=e.currentTarget;el.dataset.before=String(el.scrollLeft>2);el.dataset.after=String(el.scrollLeft+el.clientWidth<el.scrollWidth-2);
  }}>
    {tabs.map((tab, index) => {
      const active = focusedPath === tab.filePath;
      const duplicate = parentLabels.has(tab.filePath);
      const parent = parentLabels.get(tab.filePath);
      const split = isSplit && rightPath === tab.filePath;
      return <div key={tab.filePath} draggable
        onDragStart={e => { e.dataTransfer.setData('text/nx-tab', tab.filePath); e.dataTransfer.effectAllowed = 'move'; }}
        onDragOver={e => { if (e.dataTransfer.types.includes('text/nx-tab')) e.preventDefault(); }}
        onDrop={e => { const from = e.dataTransfer.getData('text/nx-tab'); if (from) { e.preventDefault(); onMove(from, tab.filePath); } }}
        onAuxClick={e => { if (e.button === 1) { e.preventDefault(); onClose(tab.filePath); } }}
        className={`nx-editor-tab ${active ? 'active' : ''} ${active && celebration ? 'ac-celebrate-glow' : ''} ${tab.isOrphaned ? 'nx-tab-orphaned' : ''}`}>
        <button className="nx-tab-select" role="tab" aria-selected={active} tabIndex={active || (!focusedPath && index === 0) ? 0 : -1}
          aria-label={`${tab.name}${duplicate ? `, ${tab.filePath}` : ''}${tab.isDirty ? ', unsaved changes' : ''}${tab.isOrphaned ? ', deleted on disk' : ''}${tab.hasExternalConflict ? ', changed on disk' : ''}${split ? ', right pane' : ''}`}
          title={tab.isOrphaned ? `${tab.filePath} (deleted on disk - saving recreates the file)` : tab.filePath}
          onClick={() => onSelect(tab.filePath, true)} onKeyDown={e => navigate(e, index)}>
          <span className="nx-tab-file-mark" aria-hidden="true">{tab.name.split('.').pop()?.slice(0, 3).toUpperCase() || 'FILE'}</span>
          <span className="nx-tab-title">{orientation === 'vertical' && tab.name.length > 26 ? <><span className="nx-index-name-start">{tab.name.slice(0, -14)}</span><span className="nx-index-name-end">{tab.name.slice(-14)}</span></> : tab.name}</span>
          {duplicate && <span className="nx-tab-parent" title={tab.filePath}>{parent}</span>}
          {tab.isOrphaned && <span className="nx-tab-orphan-badge" aria-hidden="true" title="Deleted on disk - saving recreates the file">!</span>}
          {tab.hasExternalConflict && <span className="nx-tab-orphan-badge" aria-hidden="true" title="Changed on disk since you opened it - saving asks before overwriting">&#8646;</span>}
          {tab.isDirty && <span className="nx-dirty-indicator-glow" aria-hidden="true" />}
        </button>
        <div className="nx-tab-actions-group">
          <button className={`nx-tab-split-btn ${split ? 'active' : ''}`} title={split ? 'Close Split Pane' : 'Split to Right Pane'} aria-label={`${split ? 'Close split for' : 'Split'} ${tab.name}${duplicate ? `, ${tab.filePath}` : ''}`} onClick={() => onSplit(tab.filePath)}>
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="1.5"/><path d="M12 3v18"/></svg>
          </button>
          <button className="nx-tab-close-btn" title="Close Tab" aria-label={`Close ${tab.name}${duplicate ? `, ${tab.filePath}` : ''}`} onClick={() => onClose(tab.filePath)}>×</button>
        </div>
      </div>;
    })}
  </div>;
}
