import { Component } from 'react';
import type { ReactNode } from 'react';
import { ConfirmDialog } from './ConfirmDialog';
import { useEditorStore } from '../stores/useEditorStore';

interface PluginErrorBoundaryProps {
  /** Plugin display name, used in the fallback notice. */
  name: string;
  /** Optional recovery action: disable the failing plugin from Settings state. */
  onDisable?: () => void;
  /** panel: centered block filling the panel area. notice: floating card for non-panel failures (e.g. activation hooks). */
  variant?: 'panel' | 'notice';
  /** When this changes (e.g. the plugin was disabled), a failed boundary starts clean. */
  resetKey?: unknown;
  children: ReactNode;
}

interface PluginErrorBoundaryState {
  failed: boolean;
  /** True when the failure is a lazy chunk load: retry/re-enable cannot help, only a reload can. */
  chunkFailure: boolean;
  /** Dirty-buffer confirmation before a reload: reload discards unsaved text (restore is paths-only). */
  confirmReload: boolean;
}

/** Matches the browser/bundler messages for failed dynamic imports. */
const CHUNK_FAILURE = /Loading (?:CSS )?chunk [\w-]+ failed|Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed/i;

/** Live dirty-count confirmation: subscribes to the editor store so tabs that
    become dirty (or get saved) while the dialog is open update the message. */
function ReloadConfirmDialog({ onDiscard, onCancel }: { onDiscard: () => void; onCancel: () => void }) {
  const dirty = useEditorStore((s) => s.tabs.filter((t) => t.isDirty).length);
  const saved = dirty === 0;
  return (
    <ConfirmDialog
      title="Reload window?"
      message={saved
        ? 'All changes are now saved. Reloading will not lose any edits.'
        : `${dirty} tab${dirty === 1 ? ' has' : 's have'} unsaved changes. Reloading discards them - unsaved text is not restored after a reload.`}
      discardLabel={saved ? 'Reload' : 'Discard and reload'}
      defaultFocus="cancel"
      onDiscard={onDiscard}
      onCancel={onCancel}
    />
  );
}

/**
 * Keeps a failing plugin surface (panel, activation hook) from unmounting the
 * whole shell. The fallback names the plugin and offers retry/disable; every
 * other part of the app keeps running.
 */
export class PluginErrorBoundary extends Component<PluginErrorBoundaryProps, PluginErrorBoundaryState> {
  state: PluginErrorBoundaryState = { failed: false, chunkFailure: false, confirmReload: false };

  static getDerivedStateFromError(error: unknown): PluginErrorBoundaryState {
    const message = error instanceof Error ? error.message : String(error);
    return { failed: true, chunkFailure: CHUNK_FAILURE.test(message), confirmReload: false };
  }

  private requestReload = () => {
    // Read at click time, never a render-time snapshot: edits made after the
    // fallback appeared must not slip past the confirmation.
    const dirty = useEditorStore.getState().tabs.filter(t => t.isDirty).length;
    // Session restore is paths-only: a reload silently drops unsaved text.
    // Clean session reloads immediately; dirty session asks first.
    if (dirty === 0) { window.location.reload(); return; }
    this.setState({ confirmReload: true });
  };

  componentDidCatch(error: unknown) {
    console.error(`Plugin "${this.props.name}" failed:`, error);
  }

  componentDidUpdate(prev: PluginErrorBoundaryProps) {
    // A different plugin, or a reset signal (e.g. the plugin was disabled from the notice), starts clean.
    if ((prev.name !== this.props.name || prev.resetKey !== this.props.resetKey) && this.state.failed) this.setState({ failed: false, chunkFailure: false });
  }

  private retry = () => this.setState({ failed: false, chunkFailure: false });

  render() {
    if (!this.state.failed) return this.props.children;
    if (this.state.confirmReload) {
      return (
        <ReloadConfirmDialog
          onDiscard={() => window.location.reload()}
          onCancel={() => this.setState({ confirmReload: false })}
        />
      );
    }
    return (
      <div className={`nx-plugin-failed${this.props.variant === 'notice' ? ' nx-plugin-failed-notice' : ''}`} role="alert">
        <div className="nx-plugin-failed-title">{this.props.name} stopped working</div>
        <div className="nx-plugin-failed-msg">{this.state.chunkFailure
          ? "This plugin's code could not be loaded. Reloading the window may fix this. Any unsaved editor changes will be asked about first."
          : this.props.variant === 'notice' ? 'This plugin stopped while running in the background. Your files and other panels are unaffected.' : "This plugin's panel failed to load. Your files and other panels are unaffected."}</div>
        <div className="nx-plugin-failed-actions">
          {this.state.chunkFailure
            ? <button type="button" className="nx-plugin-failed-btn" onClick={this.requestReload}>Reload window</button>
            : <button type="button" className="nx-plugin-failed-btn" onClick={this.retry}>Try again</button>}
          {this.props.onDisable && (
            <button type="button" className="nx-plugin-failed-btn" onClick={this.props.onDisable}>Disable this plugin</button>
          )}
        </div>
      </div>
    );
  }
}
