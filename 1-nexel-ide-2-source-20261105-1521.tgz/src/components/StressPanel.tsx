import React, { useEffect, useMemo, useRef, useState } from 'react';
import { readJudgeResults, isJudgeSource, JUDGE_SOURCE_NOTICE } from '../lib/judgeResults';
import { runStress, type StressFailure } from '../lib/stress';
import { useJudgeStore } from '../stores/useJudgeStore';
import { useEditorStore } from '../stores/useEditorStore';
import { useStatusStore } from '../stores/useStatusStore';
import './StressPanel.css';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';

interface Props { solutionPath?: string | null; onClose: () => void; }

const guessBrute = (p?: string | null) => (p ? p.replace(/(\.[^./\\]+)$/, '_brute$1') : '');
const R = 26, C = 2 * Math.PI * R;

export const StressPanel: React.FC<Props> = ({ solutionPath, onClose }) => {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => { closeRef.current?.focus(); }, []);
  const [submittedSolution, setSubmittedSolution] = useState<string | null>(null);
  const [submittedBrute, setSubmittedBrute] = useState<string | null>(null);
  const [brute, setBrute] = useState(guessBrute(solutionPath));
  const selectionRef = useRef({ solutionPath, brute });
  selectionRef.current = { solutionPath, brute };
  const validatingRef = useRef(false);
  const [iterations, setIterations] = useState(200);
  const [maxN, setMaxN] = useState(8);
  const [maxV, setMaxV] = useState(20);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [inputError, setInputError] = useState('');
  const inputErrorRef = useRef<HTMLParagraphElement>(null);
  useEffect(() => { if (inputError) inputErrorRef.current?.focus(); }, [inputError]);
  const [stopping, setStopping] = useState(false);
  const [state, setState] = useState<'idle' | 'running' | 'pass' | 'fail'>('idle');
  const [savedCase, setSavedCase] = useState(false);
  const [failure, setFailure] = useState<StressFailure | null>(null);
  const failRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!failure) return;
    const el = failRef.current;
    if (!el) return;
    const reduce = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const behavior = reduce ? 'instant' : 'smooth';
    const scroller = el.closest('.nx-stress');
    if (scroller && typeof scroller.scrollTo === 'function') {
      const top = el.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop - 8;
      scroller.scrollTo({ top: Math.max(0, top), behavior });
    } else if (typeof el.scrollIntoView === 'function') {
      el.scrollIntoView({ block: 'nearest', behavior });
    }
  }, [failure]);
  const abortRef = useRef<AbortController | null>(null);
  const mounted = useRef(true);
  const judgeBusy = useJudgeStore(s => s.isRunning);
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; abortRef.current?.abort(); };
  }, []);
  const canSaveFailure = !!failure && !failure.verdict.startsWith('BRUTE-') && failure.verdict !== 'CE' && failure.verdict !== 'CANCELLED';
  const failureIsMismatch = failure?.verdict === 'WA';
  const pct = useMemo(() => (progress.total ? progress.done / progress.total : 0), [progress]);

  const run = async (file: string, input: string) => {
    const [r] = readJudgeResults(await window.nexelAPI.runJudge(file, [{ id: 1, input, expected: '' }], 2000, 256), [1]);
    return { out: r?.actual ?? '', diagnostics: r?.diff, verdict: r?.verdict === 'WA' ? 'AC' : (r?.verdict ?? 'RE') };
  };

  const start = async () => {
    if (validatingRef.current || abortRef.current || useJudgeStore.getState().isRunning) return;
    if (![iterations, maxN, maxV].every(value => Number.isSafeInteger(value) && value >= 1) || iterations > 2000 || maxN > 200000) { setInputError('Use whole numbers: 1-2000 tests, 1-200000 for Max n, and a positive Max val.'); return; }
    if (!solutionPath || !brute.trim()) { setInputError('Open your solution and enter a brute-force file.'); return; }
    if (![solutionPath, brute.trim()].every(isJudgeSource)) { setInputError(JUDGE_SOURCE_NOTICE); return; }
    if (!/^(?:\/|[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)/.test(brute.trim())) { setInputError('Use the full absolute path to the brute-force file. Relative paths do not run from your workspace.'); return; }
    const sourceTabs = useEditorStore.getState().tabs.filter(tab => tab.filePath === solutionPath || tab.filePath === brute.trim());
    if (sourceTabs.some(tab => tab.isOrphaned)) { setInputError('A program file was deleted on disk. Save it to a valid path before starting Stress.'); return; }
    if (sourceTabs.some(tab => tab.isDirty)) { setInputError('Save changes to both programs before starting Stress. It runs the files on disk.'); return; }
    const tabs = useEditorStore.getState().tabs;
    const riskyTabs = tabs.filter(tab => (tab.isDirty || tab.isOrphaned) && !sourceTabs.includes(tab));
    if (riskyTabs.length) {
      const root = useWorkspaceStore.getState().rootPath;
      const requestedBrute = brute;
      validatingRef.current = true;
      try {
        const programs = await Promise.all([solutionPath, brute.trim()].map(path => window.nexelAPI.fileIdentity(path)));
        const aliases = await Promise.all(riskyTabs.map(tab => window.nexelAPI.fileIdentity(tab.filePath)));
        if (!mounted.current || selectionRef.current.solutionPath !== solutionPath || selectionRef.current.brute !== requestedBrute ||
          useWorkspaceStore.getState().rootPath !== root || useEditorStore.getState().tabs !== tabs || useJudgeStore.getState().isRunning) return;
        const related = riskyTabs.filter((_, index) => programs.includes(aliases[index]));
        if (related.some(tab => tab.isOrphaned)) { setInputError('A program file was deleted on disk. Save it to a valid path before starting Stress.'); return; }
        if (related.some(tab => tab.isDirty)) { setInputError('Save changes to both programs before starting Stress. It runs the files on disk.'); return; }
      } catch {
        if (mounted.current && selectionRef.current.solutionPath === solutionPath && selectionRef.current.brute === requestedBrute)
          setInputError('Could not verify open unsaved files against these program paths. Save those files before starting Stress.');
        return;
      } finally { validatingRef.current = false; }
    }
    setInputError('');
    const ac = new AbortController(); abortRef.current = ac;
    useJudgeStore.getState().setRunning(true);
    setSubmittedSolution(solutionPath);
    setSubmittedBrute(brute.trim());
    setStopping(false);
    setState('running'); setFailure(null); setSavedCase(false); setProgress({ done: 0, total: iterations });
    try {
      const res = await runStress(run, { solution: solutionPath, brute: brute.trim(), iterations, maxN, maxV, seed: Date.now() % 100000 }, ac.signal, progress => { if (mounted.current && !ac.signal.aborted) setProgress(progress); });
      if (!mounted.current) return;
      if (res.failure) { setFailure(res.failure); setState('fail'); useStatusStore.getState().pushToast(res.failure.verdict === 'WA' ? 'Stress test found a counter-example' : 'Stress stopped: a program failed', 'error'); }
      else if (res.stopped) setState('idle');
      else { setState('pass'); useStatusStore.getState().pushToast(`Stress passed: ${res.ran} random tests`, 'success'); }
    } catch (e) {
      if (!mounted.current || ac.signal.aborted) { if (mounted.current) setState('idle'); return; }
      setState('idle'); useStatusStore.getState().pushToast(e instanceof Error ? e.message : 'Stress run failed', 'error');
    } finally {
      if (abortRef.current === ac) abortRef.current = null;
      useJudgeStore.getState().setRunning(false);
      if (mounted.current) setStopping(false);
    }
  };

  const saveAsTest = () => {
    if (!failure || !canSaveFailure || savedCase || useJudgeStore.getState().isRunning) return;
    const st = useJudgeStore.getState();
    st.addTestCase();
    const id = useJudgeStore.getState().activeTCId;
    st.updateTestCase(id, { name: `Stress #${failure.seed}`, input: failure.input, expected: failure.expected });
    setSavedCase(true);
    useStatusStore.getState().pushToast('Counter-example added to Judge test cases', 'success');
  };

  return (
    <div className="nx-stress" role="region" aria-label="Stress tester" onChange={() => setInputError('')}>
      <div className="nx-stress-top">
        <div className={`nx-stress-ring ${state}`} aria-label={`progress ${Math.round(pct * 100)}%`}>
          <svg viewBox="0 0 64 64" width="64" height="64">
            <circle className="trk" cx="32" cy="32" r={R} />
            <circle className="bar" cx="32" cy="32" r={R} strokeDasharray={C} strokeDashoffset={C * (1 - (state === 'pass' ? 1 : pct))} />
          </svg>
          <span className="nx-stress-ring-txt">{state === 'pass' ? '✓' : state === 'fail' ? '!' : `${Math.round(pct * 100)}%`}</span>
        </div>
        <div className="nx-stress-heading">
          <b>Stress Tester</b>
          <span>{state === 'running' ? `${progress.done}/${progress.total} tests` : state === 'pass' ? 'All outputs matched' : state === 'fail' ? (failureIsMismatch ? 'Mismatch found' : 'Program failed') : 'solution vs brute force'}</span>
        </div>
        <button ref={closeRef} className="nx-stress-x" onClick={onClose} title="Back to testcases" aria-label="Close stress tester">×</button>
      </div>

      <p className="nx-stress-source">Solution file: <span>{state === 'running' ? submittedSolution : (solutionPath || 'No source selected')}</span></p>
      {(state === 'pass' || state === 'fail') && <p className="nx-stress-source">Results from: {submittedSolution} vs {submittedBrute}</p>}
      <label className="nx-stress-field"><span>Brute force file</span>
        <input disabled={state === 'running'} value={brute} onChange={e => setBrute(e.target.value.slice(0, 500))} spellCheck={false} placeholder="Full absolute path to brute source" />
      </label>
      <div className="nx-stress-row">
        <label className="nx-stress-field"><span>Tests</span><input disabled={state === 'running'} type="number" min={1} max={2000} value={iterations} onChange={e => setIterations(Math.min(2000, Math.max(1, +e.target.value || 1)))} /></label>
        <label className="nx-stress-field"><span>Max n</span><input disabled={state === 'running'} type="number" min={1} max={200000} value={maxN} onChange={e => setMaxN(Math.min(200000, Math.max(1, +e.target.value || 1)))} /></label>
        <label className="nx-stress-field"><span>Max val</span><input disabled={state === 'running'} type="number" min={1} value={maxV} onChange={e => setMaxV(Math.max(1, +e.target.value || 1))} /></label>
      </div>

      {inputError && <p ref={inputErrorRef} className="nx-stress-input-error" role="alert" tabIndex={0}>{inputError}</p>}

      <button className={`nx-stress-btn ${state === 'running' ? 'stop' : ''}`}
        disabled={state !== 'running' && judgeBusy}
        aria-disabled={state === 'running' && stopping}
        aria-busy={state === 'running'}
        onClick={state === 'running' ? () => { setStopping(true); abortRef.current?.abort(); } : start}>
        {state === 'running' ? (stopping ? 'STOPPING...' : 'STOP') : 'START STRESS'}
      </button>

      {stopping && <p className="nx-stress-stop-notice" role="status">Stopping after the current program finishes. No new tests will start.</p>}

      {failure && (
        <div ref={failRef} className="nx-stress-fail">
          <div className="nx-stress-fail-h"><span className="chip">{failure.verdict}</span> test {failure.iteration} · seed {failure.seed}</div>
          {!canSaveFailure && <p className="nx-stress-preview-note">Fix the program before testing again. This failure cannot be added as a test case.</p>}
          {(!canSaveFailure || failure.diagnostics) && !failureIsMismatch && <pre tabIndex={0} role="region" aria-label="Program error output">{failure.diagnostics || failure.actual || 'No program output was reported.'}</pre>}
          {canSaveFailure && failure.input.length > 600 && <p className="nx-stress-preview-note">Showing the first 600 characters. Add to test cases keeps the full input.</p>}
          <pre tabIndex={0} role="region" aria-label="Counter-example input preview">{failure.input.length > 600 ? failure.input.slice(0, 600) + '…' : failure.input}</pre>
          {failureIsMismatch && failure.diff && <div className="nx-stress-diff" tabIndex={0} role="region" aria-label="Counter-example output difference"><i>line {failure.diff.line}</i><code className="a">brute: {failure.diff.a}</code><code className="b">yours: {failure.diff.b}</code></div>}
          {canSaveFailure && <button className="nx-stress-btn ghost" aria-disabled={savedCase || judgeBusy} onClick={saveAsTest}>{savedCase ? 'Added to test cases' : 'Add to test cases'}</button>}
        </div>
      )}
    </div>
  );
};
export default StressPanel;
