import {useLayoutEffect,useRef} from 'react';
export function ExplorerContextMenu({x,y,actions,onClose,onRestoreFocus}:{x:number;y:number;actions:{label:string;danger?:boolean;run:()=>void}[];onClose:()=>void;onRestoreFocus:()=>void}) {
 const ref=useRef<HTMLDivElement>(null);
 const close=useRef(onClose);close.current=onClose;
 const restore=useRef(onRestoreFocus);restore.current=onRestoreFocus;
 useLayoutEffect(()=>{
  const menu=ref.current!;
  const rect=menu.getBoundingClientRect();
  // Clamp to the usable content area, not the raw viewport: the app layout
  // clips at the status bar's top edge, so a viewport-flush menu loses its
  // last items behind/below the status bar. Zen mode has no status bar.
  const sb=document.querySelector('.sb-bar');
  const bottomLimit=sb?sb.getBoundingClientRect().top:window.innerHeight;
  menu.style.maxHeight=`${Math.max(120,bottomLimit-12)}px`;
  menu.style.left=`${Math.max(6,Math.min(x,window.innerWidth-rect.width-6))}px`;
  menu.style.top=`${Math.max(6,Math.min(y,bottomLimit-rect.height-6))}px`;
  menu.querySelector<HTMLButtonElement>('button')?.focus();
  const outside=(e:PointerEvent)=>{if(!menu.contains(e.target as Node))close.current();};
  const resize=()=>{restore.current();close.current();};
  window.addEventListener('pointerdown',outside);window.addEventListener('resize',resize);
  return()=>{window.removeEventListener('pointerdown',outside);window.removeEventListener('resize',resize);};
 },[x,y]);
 return <div ref={ref} className="nx-context-menu" role="menu" aria-label="File actions" style={{left:x,top:y,maxWidth:'calc(100vw - 12px)',maxHeight:'calc(100vh - 12px)',overflowY:'auto',boxSizing:'border-box'}} onKeyDown={e=>{
  const buttons=[...e.currentTarget.querySelectorAll<HTMLButtonElement>('button')];const i=buttons.indexOf(document.activeElement as HTMLButtonElement);
  if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();buttons[e.key==='Home'?0:e.key==='End'?buttons.length-1:(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}
  else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();onRestoreFocus();onClose();}
  else if(e.key==='Tab'){onRestoreFocus();onClose();}
 }}>{actions.map(a=><button type="button" role="menuitem" key={a.label} className={`nx-context-item${a.danger?' danger':''}`} onClick={()=>{onRestoreFocus();onClose();a.run();}}>{a.label}</button>)}</div>;
}
