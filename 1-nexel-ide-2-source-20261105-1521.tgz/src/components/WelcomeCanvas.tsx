import React from 'react';
import logoImg from '../assets/logo.png';
import { SHORTCUT_GROUPS } from '../lib/shortcuts';

interface WelcomeCanvasProps {
  recent: string[];
  openFolder: () => unknown;
  openRecent: (path: string) => unknown;
  workspace?: { name: string; path: string; files: { name: string; path: string }[] };
  findFile?: () => unknown;
  openFile?: (path: string) => unknown;
}

export const WelcomeCanvas: React.FC<WelcomeCanvasProps> = ({recent,openFolder,openRecent,workspace,findFile,openFile}) => (
<section className="nx-integrated-welcome" aria-label="Welcome to Nexel">
  <div className="nx-welcome-mark" aria-hidden="true"><img src={logoImg} alt="" /></div>
  <h1>{workspace ? workspace.name : 'NEXEL IDE'}</h1>
  <p>{workspace ? 'Your workspace is open. Choose a file in Explorer to begin.' : 'Open a workspace and start building.'}</p>
  <button onClick={()=>void(workspace?findFile?.():openFolder())}>{workspace?'Find a file':'Open a folder'}</button>
  {workspace && <><div className="nx-welcome-file-list">{workspace.files.length===0 && <p>Browse the folders in the sidebar, or find a file.</p>}{workspace.files.slice(0,4).map(file=><button key={file.path} title={file.path} aria-label={`Open ${file.path}`} onClick={()=>void openFile?.(file.path)}><span>{file.name}</span>{workspace.files.slice(0,4).filter(item=>item.name===file.name).length>1 && <small>{file.path.replace(/[/\\][^/\\]+$/, "")}</small>}</button>)}</div><button onClick={()=>void openFolder()}>Open another folder</button></>}
  {!workspace && recent.length>0 && <div className="nx-welcome-file-list">{recent.map(path=><button key={path} title={path} aria-label={`Open recent workspace ${path}`} onClick={()=>void openRecent(path)}><span>{path.split(/[\\/]/).filter(Boolean).pop() || path}</span>{recent.filter(item=>item.split(/[\\/]/).filter(Boolean).pop()===path.split(/[\\/]/).filter(Boolean).pop()).length>1 && <small>{path}</small>}</button>)}</div>}
  <div className="nx-welcome-hints">{[SHORTCUT_GROUPS[0].items[0],SHORTCUT_GROUPS[0].items[4]].map(item=><span key={item.label}><span>{item.label}</span> {item.keys.join('+')}</span>)}</div>
</section>);
