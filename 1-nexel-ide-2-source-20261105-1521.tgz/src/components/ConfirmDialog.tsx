import { useEffect, useId, useRef } from 'react';
import './ConfirmDialog.css';

export interface ConfirmDialogProps {
  title: string;
  message: string;
  detail?: string;
  detailLabel?: string;
  /** When set, a Save button is shown and focused by default. */
  saveLabel?: string;
  saving?: boolean;
  pendingMessage?: string;
  cancelLabel?: string;
  discardDisabled?: boolean;
  discardLabel: string;
  /** Save-failure notice; the dialog stays open so no edit is lost. */
  error?: string;
  /** Which button gets initial focus. Defaults to the Save button (or Cancel when no Save). */
  defaultFocus?: 'save' | 'cancel';
  onSave?: () => void;
  onDiscard: () => void;
  onCancel: () => void;
}

/** In-app modal replacing native window.confirm for destructive close/save flows. */
export function ConfirmDialog({ title, message, detail, detailLabel = 'Details', saveLabel, saving = false, pendingMessage, cancelLabel = 'Cancel', discardDisabled = false, discardLabel, error, defaultFocus, onSave, onDiscard, onCancel }: ConfirmDialogProps) {
  const descriptionId = useId();
  const saveRef = useRef<HTMLButtonElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const detailRef = useRef<HTMLDivElement>(null);
  const errorRef=useRef<HTMLDivElement>(null);
  const hasSave = Boolean(saveLabel);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const initial = defaultFocus === 'cancel' ? cancelRef.current : (hasSave ? saveRef.current : cancelRef.current);
    initial?.focus();
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, [hasSave, defaultFocus]);
  useEffect(() => {
    if (saving && document.activeElement === saveRef.current) cancelRef.current?.focus();
  }, [saving]);
  useEffect(() => {
    const kd = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); onCancel(); return; }
      if (e.key === 'Tab') {
        // Focus containment: Tab/Shift+Tab includes scrollable details and stays in the dialog.
        const box = boxRef.current;
        if (!box) return;
        const focusables = Array.from(box.querySelectorAll<HTMLElement>('[tabindex="0"],button:not(:disabled)'));
        if (!focusables.length) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement;
        if (e.shiftKey && (active === first || !box.contains(active))) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && (active === last || !box.contains(active))) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', kd, true);
    return () => window.removeEventListener('keydown', kd, true);
  }, [onCancel]);
  return (
    <div className="nx-cf-backdrop" onMouseDown={onCancel}>
      <div ref={boxRef} className="nx-cf-box" role="alertdialog" aria-modal="true" aria-label={title} aria-describedby={descriptionId} onMouseDown={e => e.stopPropagation()}>
        <div className="nx-cf-title">{title}</div>
        <div id={descriptionId} className="nx-cf-msg" role="region" aria-label="Decision details" tabIndex={0}>{message}</div>
        {detail && <div ref={detailRef} className="nx-cf-detail" role="region" aria-label={detailLabel} tabIndex={0}>{detail}</div>}
        {saving && pendingMessage && <div className="nx-cf-detail" role="status">{pendingMessage}</div>}
        {error && <div ref={errorRef} className="nx-cf-error" role="alert" aria-label="Save failure" tabIndex={0}>{error}</div>}
        <div className="nx-cf-actions">
          {saveLabel && <button ref={saveRef} type="button" className="nx-cf-btn nx-cf-save" disabled={saving} onClick={onSave}>{saving ? 'Saving...' : saveLabel}</button>}
          <button type="button" className="nx-cf-btn nx-cf-discard" disabled={discardDisabled} onClick={onDiscard}>{discardLabel}</button>
          <button ref={cancelRef} type="button" className="nx-cf-btn nx-cf-cancel" onClick={onCancel}>{cancelLabel}</button>
        </div>
      </div>
    </div>
  );
}
