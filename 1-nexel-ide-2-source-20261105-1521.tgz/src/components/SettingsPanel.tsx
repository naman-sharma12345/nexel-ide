import '../plugins/color-lab';
import '../plugins/time-lab';
import '../plugins/regex-lab';
import '../plugins/document-insights';
import '../plugins/text-compare';
import '../plugins/document-navigator';
import '../plugins/data-tools';
import { useEffect, useRef, useState } from 'react';
import { CPP_STDS } from '../stores/useSettingsStore';
import { partitionFlags } from '../main/services/lsp/lspValidate';
import { useLspStore, STATUS_LABEL } from '../lib/clangd/state';
import { getClangd } from '../lib/clangd/session';
import { useSettingsStore } from '../stores/useSettingsStore';
import { THEMES } from '../lib/themes';
import { listPlugins, pluginEnabled } from '../plugins/registry';
import '../plugins/competitive-programming';
import './SettingsPanel.css';
import {useUIStore} from '../stores/useUIStore';
import { switchTheme } from '../lib/themeTransition';

function Toggle({ on, onClick, label, hint }: { on: boolean; onClick: () => void; label: string; hint: string }) {
  return (
    <button className="sp-row sp-toggle" role="switch" aria-label={label} aria-checked={on} onClick={onClick}>
      <span><b>{label}</b><small>{hint}</small></span>
      <i className={`sp-switch ${on ? 'on' : ''}`}><em /></i>
    </button>
  );
}

function ExtensionsSection({onOpen}: {onOpen:(navId:string)=>void}) {
  const s = useSettingsStore();
  const [query,setQuery]=useState('');
  const plugins=listPlugins();
  const filtered=plugins.filter(plugin=>(plugin.name+' '+plugin.blurb).toLowerCase().includes(query.toLowerCase()));
  return (
    <section id="sp-extensions">
      <div className="sp-ext-heading"><h3>Extensions</h3><span>{plugins.filter(plugin=>pluginEnabled(plugin,s.plugins)).length} enabled / {plugins.length}</span></div>
      <p className="sp-ext-intro">Built-in tools. Enable only what you need; each adds its own panel to the floating bar.</p>
      <input className="sp-ext-filter" type="search" aria-label="Filter extensions" placeholder="Find a tool..." value={query} onChange={event=>setQuery(event.target.value)}/>
      <div className="sp-ext-list">
      {filtered.map(plugin=>{const enabled=pluginEnabled(plugin,s.plugins);return <article className={`sp-ext-card ${enabled?'is-enabled':''}`} key={plugin.id}>
        <div className="sp-ext-icon" aria-hidden="true">{plugin.navItems[0]?.icon}</div>
        <div className="sp-ext-copy"><h4>{plugin.name}</h4><p>{plugin.blurb}</p><span>{plugin.sections.length} panel{plugin.sections.length===1?'':'s'} · Built in</span></div>
        <div className="sp-ext-actions"><button className="sp-ext-toggle" role="switch" aria-label={plugin.name} aria-checked={enabled} onClick={()=>s.togglePlugin(plugin.id)}>{enabled?'Enabled':'Enable'}</button>
        {enabled&&plugin.sections[0]&&<button className="sp-ext-open" aria-label={`Open ${plugin.name}`} onClick={()=>{onOpen(plugin.navItems.find(item=>item.id===plugin.sections[0])?.id ?? plugin.navItems[0]?.id ?? 'workspace');useUIStore.getState().setSection(plugin.sections[0]);useUIStore.getState().setSidebarCollapsed(false);s.openSettings(false);}}>Open</button>}</div>
      </article>})}
      {!filtered.length&&<p className="sp-ext-empty">No matching tools. Try a different search.</p>}
      </div>
    </section>
  );
}

function IntelliSenseSection() {
  const s = useSettingsStore();
  const status = useLspStore(x => x.status);
  const detail = useLspStore(x => x.detail);
  const [draft, setDraft] = useState(s.clangdFlags);
  const [seen, setSeen] = useState(s.clangdFlags);
  if (seen !== s.clangdFlags) { setSeen(s.clangdFlags); setDraft(s.clangdFlags); } // store changed elsewhere (reset)
  const { rejected } = partitionFlags(draft);
  const commit = () => { if (draft.trim() !== s.clangdFlags) s.setClangdFlags(draft); };
  return (
    <section id="sp-intellisense">
      <h3>IntelliSense <span className="sp-h-note">C / C++</span></h3>
      <div className="sp-row sp-lsp-status">
        <span><b>clangd</b><small title={detail}>{detail || 'Language server for C and C++'}</small></span>
        <span className="sp-lsp-right">
          <i className={`sp-lsp-pill sb-lsp-${status}`}><i className="sb-lsp-dot" />{STATUS_LABEL[status]}</i>
          <button className="sp-mini" onClick={() => void getClangd().restart()} disabled={!s.clangdEnabled}>Restart</button>
        </span>
      </div>
      <Toggle on={s.clangdEnabled} onClick={() => s.toggle('clangdEnabled')} label="Enable clangd" hint="Semantic completions, hovers, diagnostics, go to definition, rename, format. Off = built-in completions only" />
      <div className="sp-row">
        <span><b>C++ standard</b><small>Written to the workspace .clangd (never over your own config)</small></span>
        <div className="sp-seg" role="group" aria-label="C++ standard">
          {CPP_STDS.map(v => <button key={v} className={s.cppStd === v ? 'on' : ''} aria-pressed={s.cppStd === v} onClick={() => s.setCppStd(v)} disabled={!s.clangdEnabled}>{v.replace('c++', 'C++')}</button>)}
        </div>
      </div>
      <label className="sp-row sp-col">
        <span><b>Extra compiler flags</b><small id="sp-flags-hint">For example <code>-DLOCAL -Wshadow -Wconversion</code>. Applied on Enter or when you leave the field</small></span>
        <input aria-label="Extra compiler flags" aria-describedby={`sp-flags-hint${rejected.length ? ' sp-flags-warning' : ''}`} aria-invalid={rejected.length > 0} className={`sp-input ${rejected.length ? 'bad' : ''}`} value={draft} spellCheck={false} placeholder="-DLOCAL -Wshadow" disabled={!s.clangdEnabled}
          onChange={e => setDraft(e.target.value)} onBlur={commit} onKeyDown={e => { if (e.nativeEvent.isComposing || e.nativeEvent.keyCode === 229) { e.stopPropagation(); return; } if (e.key === 'Enter') { e.preventDefault(); commit(); } }} />
        {rejected.length > 0 && <small id="sp-flags-warning" className="sp-warn" role="status">Ignored for safety: {rejected.join(' ')} (only -D, -U, -W, -f, -O, -m, -I style flags are allowed)</small>}
      </label>
    </section>
  );
}

export function SettingsPanel() {
  const open = useSettingsStore(s => s.settingsOpen);
  const s = useSettingsStore();
  const boxRef = useRef<HTMLDivElement>(null);
  const openedNav = useRef<string|null>(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    openedNav.current=null;
    boxRef.current?.querySelector<HTMLButtonElement>('.sp-x')?.focus({preventScroll:true});
    const handle = (e: KeyboardEvent) => {
      if (e.isComposing || e.keyCode === 229) { e.stopImmediatePropagation(); return; }
      if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); useSettingsStore.getState().openSettings(false); }
      else if (e.key === 'Tab') {
        const controls = [...(boxRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), [tabindex="0"]') ?? [])];
        const first = controls[0], last = controls.at(-1);
        if (e.shiftKey && (document.activeElement === first || !boxRef.current?.contains(document.activeElement))) { e.preventDefault(); last?.focus(); }
        else if (!e.shiftKey && (document.activeElement === last || !boxRef.current?.contains(document.activeElement))) { e.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener('keydown', handle, true);
    return () => {
      window.removeEventListener('keydown', handle, true);
      // Palette commands can remove their input before this sheet mounts.
      const fallback=Array.from(document.querySelectorAll<HTMLButtonElement>('.nx-menu-trigger-btn')).find(button=>button.textContent==='View');
      const destination=openedNav.current ? Array.from(document.querySelectorAll<HTMLButtonElement>('.nd-item-row')).find(button=>button.dataset.navId===openedNav.current) : undefined;
      if(destination) destination.focus({preventScroll:true});
      else if(previous?.isConnected && previous!==document.body) previous.focus({preventScroll:true});
      else fallback?.focus({preventScroll:true});
    };
  }, [open]);
  if (!open) return null;
  return (
    <div className="sp-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) s.openSettings(false); }}>
      <div className="sp-box" role="dialog" aria-modal="true" aria-label="Settings" tabIndex={-1} ref={boxRef}>
        <header className="sp-head">
          <div><span className="sp-edition">NEXEL / PREFERENCES</span><h2>Settings</h2></div>
          <button className="sp-x" onClick={() => s.openSettings(false)} aria-label="Close settings">✕</button>
        </header>
        <div className="sp-body">
          <section>
            <h3>Appearance</h3>
            <div className="sp-themes">
              {THEMES.map((t, i) => (
                <button key={t.id} className={`sp-theme ${s.theme === t.id ? 'active' : ''}`} style={{ animationDelay: `${i * 45}ms` }} onClick={() => switchTheme(t.id)} aria-pressed={s.theme === t.id}>
                  <span className="sp-preview" style={{ background: t.editorBg, borderColor: `${t.accent}44` }}>
                    <i style={{ background: t.bg1 }} />
                    <u style={{ background: t.accent }} /><u style={{ background: t.accent2, width: '38%' }} /><u style={{ background: '#'+t.syntax.keyword, width: '52%' }} />
                  </span>
                  <b>{t.name}</b><small>{t.blurb}</small>
                </button>
              ))}
            </div>
          </section>
          <section>
            <h3>Editor</h3>
            <div className="sp-row">
              <span><b>Font size</b><small>10 – 24 px</small></span>
              <div className="sp-stepper">
                <button onClick={() => s.setFontSize(s.fontSize - 1)} aria-label="Decrease font size" disabled={s.fontSize <= 10}>−</button>
                <output aria-label="Font size">{s.fontSize}</output>
                <button onClick={() => s.setFontSize(s.fontSize + 1)} aria-label="Increase font size" disabled={s.fontSize >= 24}>+</button>
              </div>
            </div>
            <div className="sp-row">
              <span><b>Tab size</b><small>Spaces per indent</small></span>
              <div className="sp-seg" role="group" aria-label="Tab size">
                {[2, 4, 8].map(n => <button key={n} className={s.tabSize === n ? 'on' : ''} aria-label={`${n} spaces`} aria-pressed={s.tabSize === n} onClick={() => s.setTabSize(n)}>{n}</button>)}
              </div>
            </div>
            <Toggle on={s.ligatures} onClick={() => s.toggle('ligatures')} label="Font ligatures" hint="Render -> != >= as single glyphs" />
            <Toggle on={s.wordWrap} onClick={() => s.toggle('wordWrap')} label="Word wrap" hint="Wrap long lines at the viewport edge" />
            <Toggle on={s.minimap} onClick={() => s.toggle('minimap')} label="Minimap" hint="Code overview on the right edge" />
          </section>
          <ExtensionsSection onOpen={navId=>{openedNav.current=navId;}} />
          <IntelliSenseSection />
        </div>
        <footer className="sp-foot">
          <button className="sp-reset" onClick={() => s.reset()}>Reset to defaults</button>
          <span><kbd>Ctrl</kbd><kbd>,</kbd> to toggle · <kbd>Esc</kbd> to close</span>
        </footer>
      </div>
    </div>
  );
}
