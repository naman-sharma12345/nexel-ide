import { render, screen, fireEvent, cleanup, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
vi.mock('xterm', () => ({ Terminal: class { options = {}; cols = 80; rows = 20; loadAddon() {} attachCustomKeyEventHandler() {} open() {} onData() { return { dispose() {} }; } write(_text: string, callback?: () => void) { callback?.(); } dispose() {} } }));
vi.mock('xterm-addon-fit', () => ({ FitAddon: class { fit() {} } }));
import { Terminal } from '../Terminal';
afterEach(cleanup);
describe('terminal working area', () => {
  it('resizes with named keyboard controls without taking the whole window', async () => {
    Object.defineProperty(window, 'innerHeight', { value: 800, configurable: true });
    vi.stubGlobal('ResizeObserver', class { observe() {} disconnect() {} });
    window.nexelAPI = { createTerminal: async () => true, onTerminalData: () => () => {}, resizeTerminal: vi.fn() } as unknown as typeof window.nexelAPI;
    const change = vi.fn(); render(<Terminal visible onClose={vi.fn()} sidebarCollapsed={false} height={240} onHeightChange={change} />);
    await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());
    const edge = screen.getByRole('separator', { name: 'Terminal height' });
    fireEvent.keyDown(edge, { key: 'ArrowUp' }); expect(change).toHaveBeenLastCalledWith(260);
    fireEvent.keyDown(edge, { key: 'Home' }); expect(change).toHaveBeenLastCalledWith(140);
    fireEvent.keyDown(edge, { key: 'End' }); expect(change).toHaveBeenLastCalledWith(440);
    fireEvent.doubleClick(edge); expect(change).toHaveBeenLastCalledWith(240);
  });
  it('keeps code visible at the minimum window height and reports the real cap', async () => {
    Object.defineProperty(window, 'innerHeight', { value: 480, configurable: true });
    vi.stubGlobal('ResizeObserver', class { observe() {} disconnect() {} });
    window.nexelAPI = { createTerminal: async () => true, onTerminalData: () => () => {}, resizeTerminal: vi.fn() } as unknown as typeof window.nexelAPI;
    const change = vi.fn(); render(<Terminal visible onClose={vi.fn()} sidebarCollapsed={false} height={240} onHeightChange={change} />);
    await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());
    const edge = screen.getByRole('separator', { name: 'Terminal height' });
    expect(edge.getAttribute('aria-valuemax')).toBe('140');
    expect(edge.getAttribute('aria-valuenow')).toBe('140');
    fireEvent.keyDown(edge, { key: 'End' }); expect(change).toHaveBeenLastCalledWith(140);
  });

  it('lets short windows shrink the terminal to a reachable 56px floor',async()=>{
    Object.defineProperty(window,'innerHeight',{value:320,configurable:true});vi.stubGlobal('ResizeObserver',class{observe(){}disconnect(){}});
    window.nexelAPI={createTerminal:async()=>true,onTerminalData:()=>()=>{},resizeTerminal:vi.fn()} as unknown as typeof window.nexelAPI;
    const change=vi.fn();render(<Terminal visible onClose={vi.fn()} sidebarCollapsed height={240} onHeightChange={change}/>);
    await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());const edge=screen.getByRole('separator',{name:'Terminal height'});
    expect(edge).toHaveAttribute('aria-valuenow','80');expect(edge).toHaveAttribute('aria-valuemin','56');expect(edge).toHaveAttribute('aria-valuemax','80');expect(edge).toHaveAttribute('aria-disabled','false');fireEvent.keyDown(edge,{key:'Home'});expect(change).toHaveBeenCalledWith(56);change.mockClear();fireEvent.keyDown(edge,{key:'End'});expect(change).toHaveBeenLastCalledWith(80);
  });

});
