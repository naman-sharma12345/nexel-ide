import {render,cleanup,act} from '@testing-library/react';
import {afterEach,it,expect,vi} from 'vitest';
const mocks=vi.hoisted(()=>({send:undefined as undefined|((value:string)=>void),written:[] as string[],callbacks:[] as Array<()=>void>,hold:false}));
vi.mock('xterm',()=>({Terminal:class{options={};cols=80;rows=20;loadAddon(){}attachCustomKeyEventHandler(){}open(){}onData(cb:(v:string)=>void){mocks.send=cb;return{dispose(){}};}write(t:string,cb?:()=>void){mocks.written.push(t);if(cb){if(mocks.hold)mocks.callbacks.push(cb);else cb();}}reset(){}dispose(){}}}));
vi.mock('xterm-addon-fit',()=>({FitAddon:class{fit(){}}}));
import {Terminal} from '../Terminal';
afterEach(()=>{cleanup();vi.restoreAllMocks();mocks.send=undefined;mocks.written.length=0;mocks.callbacks.length=0;mocks.hold=false;});
function setup(native:boolean){vi.stubGlobal('ResizeObserver',class{observe(){}disconnect(){}});const write=vi.fn();window.nexelAPI={createTerminal:async()=>native,onTerminalData:()=>()=>{},resizeTerminal:vi.fn(),writeTerminal:write} as any;render(<Terminal visible onClose={()=>{}} sidebarCollapsed={false}/>);return{write};}
async function ready(){await act(async()=>{await Promise.resolve();await Promise.resolve();});}

it('pipe fallback: an arrow-key escape sequence is DROPPED (pipe shell has no readline) and never enters the command buffer',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('ls');
 mocks.send?.('\x1b[A');
 expect(write).not.toHaveBeenCalledWith('\x1b[A'); // dropping protects the next submitted line from stray bytes
 expect(write).not.toHaveBeenCalledWith('[');
 expect(write).not.toHaveBeenCalledWith('A');
 expect(mocks.written).not.toContain('[');
 expect(mocks.written).not.toContain('A');
 mocks.send?.('\r');
 expect(write).toHaveBeenCalledWith('ls\n');
});

it('pipe fallback: backspace still edits only the buffered printable text after an escape',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('ab');
 mocks.send?.('\x1b[D');
 mocks.send?.('\u007F');
 expect(mocks.written).toContain('\b \b');
 mocks.send?.('\r');
 expect(write).toHaveBeenCalledWith('a\n');
});

it('pipe fallback: mixed printable+escape+printable in ONE chunk keeps trailing text editable',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('ab\x1b[Dcd\r');
 expect(write).not.toHaveBeenCalledWith('\x1b[D'); // dropped, not forwarded
 // Everything printable before and after the sequence is buffered; Enter submits exactly 'abcd'.
 expect(write).toHaveBeenCalledWith('abcd\n');
 expect(mocks.written.filter(t=>t==='['||t==='D')).toEqual([]);
});

it('pipe fallback: multiple sequences in one chunk are each consumed and dropped',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('\x1b[A\x1b[B\x1b[3~');
 expect(write).not.toHaveBeenCalled();
 expect(mocks.written).toEqual([]);
 mocks.send?.('\r');
 expect(write).toHaveBeenCalledWith('\n'); // empty buffer, nothing smuggled in
});

it('pipe fallback: a CSI split across two chunks is reassembled and dropped, not echoed or buffered',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('\x1b[');   // chunk ends mid-sequence: stash, nothing yet
 expect(write).not.toHaveBeenCalled();
 expect(mocks.written).toEqual([]);
 mocks.send?.('A');       // next chunk completes the sequence - still dropped, 'A' not treated as text
 expect(write).not.toHaveBeenCalled();
 expect(mocks.written).toEqual([]);
 mocks.send?.('\r');
 expect(write).toHaveBeenCalledWith('\n');
});

it('pipe fallback: a lone ESC key is consumed immediately and does not swallow the next printable key',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('\x1b');
 expect(write).not.toHaveBeenCalled();
 mocks.send?.('x');
 expect(mocks.written).toContain('x');
 mocks.send?.('\r');
 expect(write).toHaveBeenCalledWith('x\n');
});

it('pipe fallback: an over-long incomplete escape tail is dropped and parsing resets',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('\x1b['+'1;'.repeat(12)); // 27 chars, never a final byte -> exceeds bound, dropped not forwarded
 expect(write).not.toHaveBeenCalled();
 mocks.send?.('y\r'); // parser recovered: printable text still buffers and submits
 expect(write).toHaveBeenCalledWith('y\n');
});

it('native path still forwards input verbatim',async()=>{
 const {write}=setup(true);await ready();
 mocks.send?.('ls\x1b[A\r');
 expect(write).toHaveBeenCalledWith('ls\x1b[A\r');
});

it('pipe fallback: bracketed-paste delimiters around text are dropped as sequences; text stays editable',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('\x1b[200~hello\x1b[201~\r');
 expect(write).toHaveBeenCalledWith('hello\n');
 expect(write).not.toHaveBeenCalledWith(expect.stringContaining('200'));
 expect(mocks.written.filter(t=>t==='['||t==='~')).toEqual([]);
});

it('pipe fallback: a shell restart drops a stashed incomplete escape and the old buffer',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.('old');
 mocks.send?.('\x1b['); // stashed, incomplete
 expect(write).not.toHaveBeenCalled();
 // restart: startShell resets both buffers
 const restartBtns=document.querySelectorAll('button');
 let restart:HTMLElement|undefined;restartBtns.forEach(b=>{if(b.getAttribute('aria-label')==='Restart Shell'||b.textContent==='Restart Shell')restart=b as HTMLElement;});
 await act(async()=>{restart?.dispatchEvent(new MouseEvent('click',{bubbles:true}));await Promise.resolve();await Promise.resolve();});
 mocks.send?.('new\r');
 expect(write).toHaveBeenCalledWith('new\n');
 expect(write).not.toHaveBeenCalledWith('oldnew\n');
 expect(write).not.toHaveBeenCalledWith('\x1b[new\n');
});
it('pipe fallback: mixed ASCII and Unicode stay in order until Enter',async()=>{
 const {write}=setup(false);await ready();
 mocks.send?.("printf '%s' नमस्ते 🌐");
 expect(write).not.toHaveBeenCalled();
 mocks.send?.('\r');expect(write).toHaveBeenCalledExactlyOnceWith("printf '%s' नमस्ते 🌐\n");
});
it('pipe fallback: backspace removes a buffered supplementary character without leaving a broken surrogate',async()=>{
 const {write}=setup(false);await ready();mocks.send?.('echo A🌐');mocks.send?.('\u007F');mocks.send?.('B\r');
 expect(write).toHaveBeenCalledExactlyOnceWith('echo AB\n');
});
it('pipe fallback: grapheme deletion removes combining accents and joined emoji as a unit',async()=>{
 const {write}=setup(false);await ready();
 for(const text of ['e\u0301','👩‍💻','🇮🇳']) {mocks.send?.('echo A'+text);mocks.send?.('\u007F');mocks.send?.('B\r');}
 expect(write.mock.calls.map(call=>call[0])).toEqual(['echo AB\n','echo AB\n','echo AB\n']);
});
it('pipe fallback: shell LF submission remains separate from the local CRLF echo',async()=>{
 const {write}=setup(false);await ready();mocks.send?.('printf ok\r');
 expect(write).toHaveBeenCalledExactlyOnceWith('printf ok\n');expect(mocks.written).toContain('\r\n');
});

it('pipe fallback: queued echo cannot overtake a pending write or survive teardown',async()=>{
 const {write}=setup(false);await ready();mocks.hold=true;
 mocks.send?.('ab');mocks.send?.('\u007F');mocks.send?.('c\r');
 expect(write).toHaveBeenCalledExactlyOnceWith('ac\n');expect(mocks.written).toEqual(['a']);
 mocks.callbacks.shift()?.();expect(mocks.written).toEqual(['a','b']);
 mocks.callbacks.shift()?.();expect(mocks.written[2]).toBe('\b \bc\r\n');
 mocks.send?.('pending');cleanup();const count=mocks.written.length;mocks.callbacks.shift()?.();expect(mocks.written).toHaveLength(count);
});
it('pipe fallback: LF and CRLF pasted lines submit preceding text in order without a duplicate blank command',async()=>{
 const {write}=setup(false);await ready();mocks.send?.('first\nsecond\r\nthird\r');
 expect(write.mock.calls.map(call=>call[0])).toEqual(['first\n','second\n','third\n']);
});
