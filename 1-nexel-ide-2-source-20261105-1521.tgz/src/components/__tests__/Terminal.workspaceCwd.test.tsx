import {render,screen,fireEvent,cleanup,waitFor} from '@testing-library/react';
import {afterEach,it,expect,vi} from 'vitest';
vi.mock('xterm',()=>({Terminal:class{options={};cols=80;rows=20;loadAddon(){}attachCustomKeyEventHandler(){}open(){}onData(_cb:(value:string)=>void){return{dispose(){}};}write(_t:string,callback?:()=>void){callback?.();}reset(){}dispose(){}}}));
vi.mock('xterm-addon-fit',()=>({FitAddon:class{fit(){}}}));
import {Terminal} from '../Terminal';
import {useStatusStore} from '../../stores/useStatusStore';
import {useWorkspaceStore} from '../../stores/useWorkspaceStore';

afterEach(()=>{cleanup();vi.restoreAllMocks();useStatusStore.setState({toasts:[]});useWorkspaceStore.setState({rootPath:null});});

function setup(start:(...args:unknown[])=>Promise<boolean>){
 vi.stubGlobal('ResizeObserver',class{observe(){}disconnect(){}});
 window.nexelAPI={createTerminal:start,onTerminalData:()=>()=>{},resizeTerminal:vi.fn(),writeTerminal:vi.fn()} as any;
 return render(<Terminal visible onClose={()=>{}} sidebarCollapsed={false}/>);
}

it('starts the shell in the current workspace root and a restart follows a workspace switch',async()=>{
 const start=vi.fn().mockResolvedValue(true);
 useWorkspaceStore.setState({rootPath:'/work/alpha'});
 setup(start);
 await waitFor(()=>expect(start).toHaveBeenCalledWith('/work/alpha'));
 // Switch workspace, then restart: the new shell must land in the new root.
 useWorkspaceStore.setState({rootPath:'/work/beta'});
 await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());
 fireEvent.click(screen.getByRole('button',{name:'Restart Shell'}));
 await waitFor(()=>expect(start).toHaveBeenCalledWith('/work/beta'));
 expect(start).toHaveBeenCalledTimes(2);
});

it('passes no cwd when no workspace is open (main falls back to home)',async()=>{
 const start=vi.fn().mockResolvedValue(true);
 setup(start);
 await waitFor(()=>expect(start).toHaveBeenCalledWith(undefined));
});
