import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { WelcomeCanvas } from '../WelcomeCanvas';

afterEach(cleanup);
describe('WelcomeCanvas', () => {
  it('opens a folder through its real action and has no entry gate', () => {
    const openFolder = vi.fn();
    render(<WelcomeCanvas recent={[]} openFolder={openFolder} openRecent={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', {name: 'Open a folder'}));
    expect(openFolder).toHaveBeenCalledOnce();
    expect(screen.queryByText('Pick up where you left off')).toBeNull();
    expect(screen.getByText('Palette')).toBeInTheDocument();
    expect(screen.queryByText('Next tab')).toBeNull();
  });
  it('keeps full recent paths for actions and supports Windows paths', () => {
    const openRecent = vi.fn();
    const paths = ['/work/one', 'C:\\work\\two', '/work/three', '/work/four'];
    render(<WelcomeCanvas recent={paths} openFolder={vi.fn()} openRecent={openRecent} />);
    expect(screen.getAllByRole('button')).toHaveLength(5);
    fireEvent.click(screen.getByTitle(paths[1]));
    expect(openRecent).toHaveBeenCalledWith(paths[1]);
    expect(screen.getByText('two')).toBeInTheDocument();
  });
  it('makes the open workspace a file entry point, not repeat onboarding', () => {
    const findFile = vi.fn(), openFile = vi.fn(), openFolder = vi.fn();
    render(<WelcomeCanvas recent={['/old']} openFolder={openFolder} openRecent={vi.fn()} findFile={findFile} openFile={openFile}
      workspace={{name:'Atlas API',path:'/work/atlas',files:[{name:'README.md',path:'/work/atlas/README.md'}]}} />);
    expect(screen.getByRole('heading',{level:1})).toHaveTextContent('Atlas API');
    expect(screen.queryByText('Start with a folder and make it real.')).toBeNull();
    expect(screen.queryByText('Pick up where you left off')).toBeNull();
    fireEvent.click(screen.getByRole('button',{name:'Find a file'})); expect(findFile).toHaveBeenCalledOnce();
    fireEvent.click(screen.getByTitle('/work/atlas/README.md')); expect(openFile).toHaveBeenCalledWith('/work/atlas/README.md');
    fireEvent.click(screen.getByRole('button',{name:/Open another folder/})); expect(openFolder).toHaveBeenCalledOnce();
  });
  it('keeps empty and large root indexes bounded and honest', () => {
    const props={recent:[],openFolder:vi.fn(),openRecent:vi.fn()};
    const view=render(<WelcomeCanvas {...props} workspace={{name:'Empty',path:'/empty',files:[]}} />);
    expect(screen.getByText('Browse the folders in the sidebar, or find a file.')).toBeInTheDocument();
    view.rerender(<WelcomeCanvas {...props} workspace={{name:'Full',path:'/full',files:Array.from({length:10},(_,i)=>({name:`file${i}.ts`,path:`/full/file${i}.ts`}))}} />);
    expect(screen.getAllByTitle(/\/full\/file/)).toHaveLength(4);
  });

});
it('distinguishes duplicate recent workspace and file names by visible path and accessible name',()=>{
 const props={recent:['/work/api','C:\\team\\api'],openFolder:vi.fn(),openRecent:vi.fn()};const view=render(<WelcomeCanvas {...props}/>);
 expect(screen.getByRole('button',{name:'Open recent workspace /work/api'})).toHaveTextContent('/work/api');
 expect(screen.getByRole('button',{name:'Open recent workspace C:\\team\\api'})).toHaveTextContent('C:\\team\\api');
 const open=vi.fn();view.rerender(<WelcomeCanvas {...props} openFile={open} workspace={{name:'Project',path:'/work',files:[{name:'config.py',path:'/work/api/config.py'},{name:'config.py',path:'/work/web/config.py'}]}}/>);
 const web=screen.getByRole('button',{name:'Open /work/web/config.py'});expect(web).toHaveTextContent('/work/web');fireEvent.click(web);expect(open).toHaveBeenCalledWith('/work/web/config.py');
});
