import {fireEvent,render,screen} from '@testing-library/react';
import {expect,it,vi} from 'vitest';
import {ExplorerContextMenu} from '../ExplorerContextMenu';
it('focuses actions, moves with keys, escapes back without executing',()=>{
 const run=vi.fn(),close=vi.fn(),restore=vi.fn();
 render(<ExplorerContextMenu x={9999} y={9999} onClose={close} onRestoreFocus={restore} actions={[{label:'Rename',run},{label:'Delete',run}]} />);
 expect(screen.getByRole('menuitem',{name:'Rename'})).toHaveFocus();
 fireEvent.keyDown(screen.getByRole('menu'),{key:'End'});expect(screen.getByRole('menuitem',{name:'Delete'})).toHaveFocus();
 fireEvent.keyDown(screen.getByRole('menu'),{key:'ArrowDown'});expect(screen.getByRole('menuitem',{name:'Rename'})).toHaveFocus();
 fireEvent.keyDown(screen.getByRole('menu'),{key:'Escape'});expect(close).toHaveBeenCalledOnce();expect(restore).toHaveBeenCalledOnce();expect(run).not.toHaveBeenCalled();
});
it('button activation restores focus, closes, then executes exactly once',()=>{
 const order:string[]=[];
 render(<ExplorerContextMenu x={20} y={20} onClose={()=>order.push('close')} onRestoreFocus={()=>order.push('focus')} actions={[{label:'Rename',run:()=>order.push('run')}]} />);
 fireEvent.click(screen.getByRole('menuitem'));expect(order).toEqual(['focus','close','run']);
});

it('clamps the menu above the status bar, not just the viewport',()=>{
 const sb=document.createElement('div');sb.className='sb-bar';document.body.appendChild(sb);
 const real=HTMLElement.prototype.getBoundingClientRect;
 const spy=vi.spyOn(HTMLElement.prototype,'getBoundingClientRect').mockImplementation(function(this:HTMLElement){
  if(this.classList?.contains('nx-context-menu'))return {x:0,y:0,top:0,left:0,right:200,bottom:140,width:200,height:140,toJSON(){return{}}} as DOMRect;
  if(this.classList?.contains('sb-bar'))return {x:0,y:774,top:774,left:0,right:725,bottom:800,width:725,height:26,toJSON(){return{}}} as DOMRect;
  return real.call(this);
 });
 try{
  const {container}=render(<ExplorerContextMenu x={100} y={722} onClose={()=>{}} onRestoreFocus={()=>{}} actions={[{label:'Rename',run:()=>{}}]} />);
  const menu=container.querySelector<HTMLElement>('.nx-context-menu')!;
  // 774 (status bar top) - 140 (menu height) - 6 (margin): viewport-flush would clip.
  expect(menu.style.top).toBe('628px');
  expect(menu.style.maxHeight).toBe('762px');
 }finally{spy.mockRestore();sb.remove();}
});
it('falls back to the viewport edge when no status bar exists',()=>{
 const spy=vi.spyOn(HTMLElement.prototype,'getBoundingClientRect').mockImplementation(function(this:HTMLElement){
  if(this.classList?.contains('nx-context-menu'))return {x:0,y:0,top:0,left:0,right:200,bottom:140,width:200,height:140,toJSON(){return{}}} as DOMRect;
  return {x:0,y:0,top:0,left:0,right:0,bottom:0,width:0,height:0,toJSON(){return{}}} as DOMRect;
 });
 try{
  const {container}=render(<ExplorerContextMenu x={100} y={722} onClose={()=>{}} onRestoreFocus={()=>{}} actions={[{label:'Rename',run:()=>{}}]} />);
  const menu=container.querySelector<HTMLElement>('.nx-context-menu')!;
  expect(menu.style.top).toBe(`${window.innerHeight-140-6}px`);
 }finally{spy.mockRestore();}
});
