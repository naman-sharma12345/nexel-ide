import {render,screen,fireEvent,cleanup,waitFor,act} from '@testing-library/react';
import {afterEach,it,expect,vi} from 'vitest';
const mocks=vi.hoisted(()=>({fontOptions:vi.fn(),fit:vi.fn(),reset:vi.fn(),send:undefined as undefined|((value:string)=>void)}));
vi.mock('xterm',()=>({Terminal:class{constructor(options:unknown){mocks.fontOptions(options);}options={};cols=80;rows=20;loadAddon(){}attachCustomKeyEventHandler(){}open(){}onData(callback:(value:string)=>void){mocks.send=callback;return{dispose(){}};}write(_text:string,callback?:()=>void){callback?.();}reset=mocks.reset;dispose(){}}}));
vi.mock('xterm-addon-fit',()=>({FitAddon:class{fit=mocks.fit;}}));
import {Terminal} from '../Terminal';
import {useStatusStore} from '../../stores/useStatusStore';
afterEach(()=>{cleanup();vi.useRealTimers();vi.restoreAllMocks();mocks.fit.mockClear();mocks.reset.mockClear();useStatusStore.setState({toasts:[]});});
function setup(start:()=>Promise<boolean>){vi.stubGlobal('ResizeObserver',class{observe(){}disconnect(){}});const write=vi.fn();window.nexelAPI={createTerminal:start,onTerminalData:()=>()=>{},resizeTerminal:vi.fn(),writeTerminal:write} as any;const view=render(<Terminal visible onClose={()=>{}} sidebarCollapsed={false}/>);return{...view,write};}
it('catches start failure, disables overlapping retries and accepts false as pipe fallback',async()=>{
 vi.spyOn(console,'error').mockImplementation(()=>{});let resolve!:(value:boolean)=>void;const start=vi.fn().mockRejectedValueOnce(Error('spawn refused')).mockImplementationOnce(()=>new Promise<boolean>(r=>resolve=r));const {write}=setup(start);
 await waitFor(()=>expect(useStatusStore.getState().toasts[0]?.message).toContain('Could not start shell'));
 const restart=screen.getByRole('button',{name:'Restart Shell'});fireEvent.click(restart);expect(screen.getByRole('button',{name:'Starting Shell'})).toBeDisabled();mocks.send?.('ignored');expect(write).not.toHaveBeenCalled();
 await act(async()=>resolve(false));expect(useStatusStore.getState().toasts).toHaveLength(0);mocks.send?.('echo ok\r');expect(write).toHaveBeenCalledWith('echo ok\n');expect(start).toHaveBeenCalledTimes(2);
});
it('cancels delayed fit and ignores a start rejection after unmount',async()=>{
 vi.useFakeTimers();let reject!:(error:Error)=>void;const {unmount}=setup(()=>new Promise<boolean>((_,r)=>reject=r));unmount();await act(async()=>{reject(Error('late failure'));await Promise.resolve();});vi.runAllTimers();expect(mocks.fit).not.toHaveBeenCalled();expect(useStatusStore.getState().toasts).toHaveLength(0);
});

it('restores the durable terminal toggle when a focused panel closes without stealing outside focus',async()=>{
 const toggle=document.createElement('button');toggle.className='sb-terminal-toggle';document.body.append(toggle);
 const outside=document.createElement('button');document.body.append(outside);
 try{const first=setup(async()=>true);await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());screen.getByRole('button',{name:'Close Terminal Panel'}).focus();first.unmount();expect(toggle).toHaveFocus();
 const second=setup(async()=>true);outside.focus();second.unmount();expect(outside).toHaveFocus();
 }finally{toggle.remove();outside.remove();}
});

it('keeps current ASCII font choices ahead of the bundled emoji fallback',async()=>{
 setup(async()=>false);await waitFor(()=>expect(screen.getByRole('button',{name:'Restart Shell'})).toBeEnabled());
 expect(mocks.fontOptions).toHaveBeenLastCalledWith(expect.objectContaining({fontFamily:'Consolas, "Courier New", "Nexel Emoji", "Apple Color Emoji", "Segoe UI Emoji", monospace'}));
});
