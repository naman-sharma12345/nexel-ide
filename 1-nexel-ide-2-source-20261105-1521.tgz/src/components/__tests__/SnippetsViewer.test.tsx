import {afterEach,expect,it,vi} from 'vitest';
import {cleanup,render,screen,fireEvent,waitFor} from '@testing-library/react';
import {SnippetsViewer} from '../SnippetsViewer';
import {useStatusStore} from '../../stores/useStatusStore';
const snippetsData={sample:{prefix:'demo',description:'Example',body:['line one','line two']}};
afterEach(()=>{cleanup();vi.useRealTimers();vi.restoreAllMocks();});
it('focuses on entry and explicit reentry, not an unrelated render',()=>{
 const props={snippetsData,focusRequest:1,focused:true};const view=render(<SnippetsViewer {...props}/>);const search=screen.getByRole('textbox');expect(search).toHaveFocus();const copy=screen.getByRole('button');copy.focus();view.rerender(<SnippetsViewer {...props}/>);expect(copy).toHaveFocus();view.rerender(<SnippetsViewer {...props} focusRequest={2}/>);expect(search).toHaveFocus();
});
it('does not focus an unfocused split viewer',()=>{render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused={false}/>);expect(screen.getByRole('textbox')).not.toHaveFocus();});
it('copies exact multiline text and reports success',async()=>{const copy=vi.fn();window.nexelAPI.writeClipboardText=copy;render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);fireEvent.click(screen.getByRole('button',{name:'Copy demo snippet'}));expect(copy).toHaveBeenCalledExactlyOnceWith('line one\nline two');expect(await screen.findByText('Copied')).toBeInTheDocument();});
it('keeps retry available and reports failed clipboard access truthfully',async()=>{window.nexelAPI.writeClipboardText=()=>{throw Error('denied');};const toast=vi.spyOn(useStatusStore.getState(),'pushToast').mockClear();render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);fireEvent.click(screen.getByRole('button',{name:'Copy demo snippet'}));await waitFor(()=>expect(toast).toHaveBeenCalledWith('Could not copy snippet. Clipboard access is unavailable.','error'));expect(screen.queryByText('Copied')).not.toBeInTheDocument();expect(screen.getByRole('button',{name:'Copy demo snippet'})).toBeEnabled();});

it('keeps latest copy feedback for its full lifetime and clears pending timers on unmount',()=>{
 vi.useFakeTimers();window.nexelAPI.writeClipboardText=vi.fn();const view=render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);const button=screen.getByRole('button');fireEvent.click(button);vi.advanceTimersByTime(1000);fireEvent.click(button);vi.advanceTimersByTime(600);expect(screen.getByText('Copied')).toBeInTheDocument();view.unmount();expect(vi.getTimerCount()).toBe(0);
});
it('waits for browser clipboard fallback rejection and keeps Copy retry available',async()=>{const native=window.nexelAPI.writeClipboardText;window.nexelAPI.writeClipboardText=undefined;const old=Object.getOwnPropertyDescriptor(navigator,'clipboard');const write=vi.fn().mockRejectedValue(Error('denied'));Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:write}});try{const toast=vi.spyOn(useStatusStore.getState(),'pushToast').mockClear();render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);fireEvent.click(screen.getByRole('button',{name:'Copy demo snippet'}));await waitFor(()=>expect(toast).toHaveBeenCalledWith('Could not copy snippet. Clipboard access is unavailable.','error'));expect(screen.queryByText('Copied')).toBeNull();expect(screen.getByRole('button',{name:'Copy demo snippet'})).toBeEnabled();}finally{window.nexelAPI.writeClipboardText=native;if(old)Object.defineProperty(navigator,'clipboard',old);else Reflect.deleteProperty(navigator,'clipboard');}});
it('ignores an older browser copy failure after a newer copy succeeds',async()=>{
 const native=window.nexelAPI.writeClipboardText;window.nexelAPI.writeClipboardText=undefined;
 const old=Object.getOwnPropertyDescriptor(navigator,'clipboard');let rejectOld!:(reason:Error)=>void;
 const write=vi.fn().mockImplementationOnce(()=>new Promise<void>((_,reject)=>{rejectOld=reject;})).mockResolvedValue(undefined);
 Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:write}});
 try{const toast=vi.spyOn(useStatusStore.getState(),'pushToast').mockClear();render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);
 const copy=screen.getByRole('button');fireEvent.click(copy);fireEvent.click(copy);expect(await screen.findByText('Copied')).toBeInTheDocument();rejectOld(Error('late denial'));
 await waitFor(()=>expect(write).toHaveBeenCalledTimes(2));await Promise.resolve();expect(screen.getByText('Copied')).toBeInTheDocument();expect(toast).not.toHaveBeenCalled();
 }finally{window.nexelAPI.writeClipboardText=native;if(old)Object.defineProperty(navigator,'clipboard',old);else Reflect.deleteProperty(navigator,'clipboard');}
});
it('does not report a late browser clipboard failure after leaving the viewer',async()=>{
 const native=window.nexelAPI.writeClipboardText;window.nexelAPI.writeClipboardText=undefined;const old=Object.getOwnPropertyDescriptor(navigator,'clipboard');let rejectCopy!:(reason:Error)=>void;
 Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>new Promise<void>((_,reject)=>{rejectCopy=reject;})}});
 try{const toast=vi.spyOn(useStatusStore.getState(),'pushToast').mockClear();const view=render(<SnippetsViewer snippetsData={snippetsData} focusRequest={1} focused/>);fireEvent.click(screen.getByRole('button'));view.unmount();rejectCopy(Error('late denial'));await Promise.resolve();expect(toast).not.toHaveBeenCalled();
 }finally{window.nexelAPI.writeClipboardText=native;if(old)Object.defineProperty(navigator,'clipboard',old);else Reflect.deleteProperty(navigator,'clipboard');}
});
it('explains how to install snippets when the library is empty',()=>{
 render(<SnippetsViewer snippetsData={{}} focusRequest={0} focused={false}/>);
 expect(screen.getByText(/enable Competitive Programming in Settings/)).toBeInTheDocument();
});
it('keeps the query wording when a populated library has no match',()=>{
 render(<SnippetsViewer snippetsData={snippetsData} focusRequest={0} focused={false}/>);
 expect(screen.queryByText(/enable Competitive Programming/)).toBeNull();
});
it('filters by key, prefix, and description as new coverage',()=>{
 const data={alpha:{prefix:'bfs',description:'Breadth-first search',body:'b'},beta:{prefix:'dfs',description:'Graph walk',body:'d'},gamma:{prefix:'sort',description:'Ordering helper',body:'s'}};
 const view=render(<SnippetsViewer snippetsData={data} focusRequest={0} focused={false}/>);
 const input=screen.getByRole('textbox');
 fireEvent.change(input,{target:{value:'alph'}});expect(screen.getByText('bfs')).toBeInTheDocument();expect(screen.queryByText('dfs')).toBeNull();
 fireEvent.change(input,{target:{value:'df'}});expect(screen.getByText('dfs')).toBeInTheDocument();expect(screen.queryByText('bfs')).toBeNull();
 fireEvent.change(input,{target:{value:'ordering'}});expect(screen.getByText('sort')).toBeInTheDocument();expect(screen.queryByText('dfs')).toBeNull();
 view.unmount();
});
