import { describe, it, expect } from 'vitest';
import { languageLabel, isClangdRelevant } from '../StatusBar';
import { judgeSummary } from '../../plugins/competitive-programming';
import { useStatusStore } from '../../stores/useStatusStore';

describe('StatusBar helpers', () => {
  it('maps extensions to labels', () => {
    expect(languageLabel('a.cpp')).toBe('C++');
    expect(languageLabel('x.py')).toBe('Python');
    expect(languageLabel('README')).toBe('Plain Text');
    expect(languageLabel()).toBe('—');
  });

  it('shows the clangd chip only for C/C++ sources', () => {
    expect(isClangdRelevant('main.cpp')).toBe(true);
    expect(isClangdRelevant('utils.hpp')).toBe(true);
    expect(isClangdRelevant('x.c')).toBe(true);
    expect(isClangdRelevant('script.py')).toBe(false);
    expect(isClangdRelevant('app.ts')).toBe(false);
    expect(isClangdRelevant('README.md')).toBe(false);
    expect(isClangdRelevant('Makefile')).toBe(false);
    expect(isClangdRelevant(undefined)).toBe(false);
  });
  it('summarises judge state', () => {
    expect(judgeSummary([], true).tone).toBe('run');
    expect(judgeSummary([{ verdict: 'IDLE' }], false).text).toBe('Judge ready');
    expect(judgeSummary([{ verdict: 'AC' }, { verdict: 'WA' }], false)).toEqual({ tone: 'bad', text: 'Last run: 1/2 passed' });
    // cancelled cases are neutral: excluded from the pass tally and never red on their own
    expect(judgeSummary([{ verdict: 'CANCELLED' }], false)).toEqual({ tone: 'idle', text: 'Canceled' });
    expect(judgeSummary([{ verdict: 'TLE' }, { verdict: 'CANCELLED' }, { verdict: 'CANCELLED' }], false)).toEqual({ tone: 'bad', text: 'Last run: 0/1 passed' });
    expect(judgeSummary([{ verdict: 'AC' }, { verdict: 'CANCELLED' }], false)).toEqual({ tone: 'ok', text: 'Last run: 1/1 passed' });
    expect(judgeSummary([{ verdict: 'AC' }], false).tone).toBe('ok');
  });
});

describe('useStatusStore', () => {
  it('bounds the toast queue and dedupes messages', () => {
    const s = useStatusStore.getState();
    for (let i = 0; i < 8; i++) s.pushToast('m' + i, 'info', 0);
    s.pushToast('m7', 'info', 0);
    const t = useStatusStore.getState().toasts;
    expect(t.length).toBeLessThanOrEqual(4);
    expect(t.filter(x => x.message === 'm7').length).toBe(1);
  });
});

import { render, screen, cleanup } from '@testing-library/react';
import { afterEach } from 'vitest';
import { StatusBar } from '../StatusBar';
import { useEditorStore } from '../../stores/useEditorStore';
afterEach(cleanup);
describe('focused document status', () => {
  it('uses the right focused document for file and language instead of left active tab', () => {
    useEditorStore.setState({tabs:[{filePath:'/server.py',name:'server.py',content:'',originalContent:'',isDirty:true},{filePath:'/README.md',name:'README.md',content:'',originalContent:'',isDirty:false}],activeTabPath:'/server.py',focusedTabPath:'/README.md'});
    render(<StatusBar/>);expect(screen.getByText('README.md')).toBeTruthy();expect(screen.queryByText('server.py')).toBeNull();expect(screen.getByText('Markdown')).toBeTruthy();
  });
});

describe('document cursor identity',()=>{it('never borrows left cursor position for right document',()=>{
  useStatusStore.getState().setCursor(8,24,0,'/server.py');useStatusStore.getState().setCursor(1,4,0,'/README.md');
  useEditorStore.setState({activeTabPath:'/server.py',focusedTabPath:'/README.md'});render(<StatusBar/>);expect(screen.getByText('Ln 1, Col 4')).toBeTruthy();expect(screen.queryByText('Ln 8, Col 24')).toBeNull();
});});

it('uses utility metadata instead of fabricated cursor, language and encoding',()=>{useEditorStore.setState({tabs:[{filePath:'nexel://snippets',name:'Code Snippets',content:'',originalContent:'',isDirty:false}],activeTabPath:'nexel://snippets',focusedTabPath:'nexel://snippets'});render(<StatusBar/>);expect(screen.getByText('VIEW')).toBeInTheDocument();expect(screen.getByText('Snippet library')).toBeInTheDocument();expect(screen.queryByText('Ln 1, Col 1')).toBeNull();expect(screen.queryByText('UTF-8')).toBeNull();expect(screen.queryByText('Plain Text')).toBeNull();});
