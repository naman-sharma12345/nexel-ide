import {afterEach,it,expect,vi} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import {ClangdChip} from '../StatusBar';
import {useLspStore} from '../../lib/clangd/state';
import {useSettingsStore} from '../../stores/useSettingsStore';
afterEach(cleanup);
it('moves through enabled status-menu actions and restores chip focus on Escape',()=>{useLspStore.setState({status:'off'});useSettingsStore.setState({clangdEnabled:true});render(<ClangdChip/>);const chip=screen.getByRole('button',{name:/clangd/});fireEvent.click(chip);const first=screen.getByRole('menuitem',{name:'Use built-in IntelliSense only'});expect(first).toHaveFocus();fireEvent.keyDown(first,{key:'End'});const last=screen.getByRole('menuitem',{name:/IntelliSense settings/});expect(last).toHaveFocus();fireEvent.keyDown(last,{key:'ArrowDown'});expect(first).toHaveFocus();fireEvent.keyDown(first,{key:'Escape'});expect(screen.queryByRole('menu')).not.toBeInTheDocument();expect(chip).toHaveFocus();});

it('hands settings a durable chip focus origin instead of an unmounted menu item',()=>{useLspStore.setState({status:'off'});render(<ClangdChip/>);const chip=screen.getByRole('button',{name:/clangd/});fireEvent.click(chip);const action=screen.getByRole('menuitem',{name:/IntelliSense settings/});action.focus();fireEvent.click(action);expect(screen.queryByRole('menu')).not.toBeInTheDocument();expect(chip).toHaveFocus();useSettingsStore.getState().openSettings(false);});

it.each([[true,'instant'],[false,'smooth']])('respects reduced-motion preference %s when revealing IntelliSense settings', (reduce,behavior)=>{vi.useFakeTimers();const match=window.matchMedia;window.matchMedia=vi.fn(()=>({matches:reduce})) as unknown as typeof window.matchMedia;const section=document.createElement('section');section.id='sp-intellisense';section.scrollIntoView=vi.fn();document.body.append(section);try{useLspStore.setState({status:'off'});render(<ClangdChip/>);fireEvent.click(screen.getByRole('button',{name:/clangd/}));fireEvent.click(screen.getByRole('menuitem',{name:/IntelliSense settings/}));vi.advanceTimersByTime(60);expect(section.scrollIntoView).toHaveBeenCalledWith({block:'start',behavior});}finally{section.remove();window.matchMedia=match;vi.useRealTimers();useSettingsStore.getState().openSettings(false);}});

it('makes long diagnostic details a named keyboard reader without stealing initial action focus',()=>{
 useLspStore.setState({status:'error',detail:'long diagnostic '.repeat(100)});useSettingsStore.setState({clangdEnabled:true});render(<ClangdChip/>);fireEvent.click(screen.getByRole('button',{name:'clangd: error'}));const reader=screen.getByRole('region',{name:'clangd diagnostic details'});expect(reader).toHaveAttribute('tabindex','0');expect(screen.getByRole('menuitem',{name:'Restart clangd'})).toHaveFocus();reader.focus();fireEvent.keyDown(reader,{key:'Escape'});expect(screen.queryByRole('menu')).toBeNull();expect(screen.getByRole('button',{name:'clangd: error'})).toHaveFocus();
});

it('leaves reader scroll keys to the reader, not menu navigation',()=>{
 useLspStore.setState({status:'error',detail:'long diagnostic '.repeat(100)});render(<ClangdChip/>);fireEvent.click(screen.getByRole('button',{name:'clangd: error'}));const reader=screen.getByRole('region');reader.focus();expect(fireEvent.keyDown(reader,{key:'End'})).toBe(true);expect(reader).toHaveFocus();expect(fireEvent.keyDown(reader,{key:'ArrowDown'})).toBe(true);expect(reader).toHaveFocus();
});
it('returns focus to the chip after changing IntelliSense mode',()=>{
 useLspStore.setState({status:'error'});useSettingsStore.setState({clangdEnabled:true});render(<ClangdChip/>);const chip=screen.getByRole('button',{name:'clangd: error'});fireEvent.click(chip);const mode=screen.getByRole('menuitem',{name:'Use built-in IntelliSense only'});mode.focus();fireEvent.click(mode);expect(chip).toHaveFocus();expect(screen.queryByRole('menu')).toBeNull();
});
