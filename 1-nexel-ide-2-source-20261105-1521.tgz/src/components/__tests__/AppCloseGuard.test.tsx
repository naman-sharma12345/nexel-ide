import { render, screen, fireEvent, act } from '@testing-library/react';
import { AppCloseGuard } from '../AppCloseGuard';
import { useEditorStore } from '../../stores/useEditorStore';

describe('AppCloseGuard', () => {
  let closeRequested: (() => void) | null;
  let confirmAppClose: ReturnType<typeof vi.fn>;
  const realAPI = window.nexelAPI;
  const tab = (id: string, dirty = true) => ({ id, filePath: `/${id}.py`, name: `${id}.py`, content: 'e', originalContent: dirty ? 'o' : 'e', isDirty: dirty });

  beforeEach(() => {
    closeRequested = null;
    confirmAppClose = vi.fn();
    (window as any).nexelAPI = {
      ...realAPI,
      onAppCloseRequested: (cb: () => void) => { closeRequested = cb; },
      confirmAppClose,
    };
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });
  afterEach(() => {
    (window as any).nexelAPI = realAPI;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  const fireClose = () => act(() => { closeRequested?.(); });

  it('registers a close-request listener with the main process', () => {
    render(<AppCloseGuard />);
    expect(closeRequested).toBeTypeOf('function');
  });

  it('clean session confirms immediately without a dialog', () => {
    render(<AppCloseGuard />);
    fireClose();
    expect(confirmAppClose).toHaveBeenCalledOnce();
    expect(screen.queryByText('Close window?')).not.toBeInTheDocument();
  });

  it('dirty tabs pause the close behind an unsaved-changes dialog naming the count', () => {
    useEditorStore.setState({ tabs: [tab('a'), tab('b')], activeTabPath: 'a' });
    render(<AppCloseGuard />);
    fireClose();
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.getByText('Close window?')).toBeInTheDocument();
    expect(screen.getByText(/2 tabs have unsaved changes/)).toBeInTheDocument();
  });

  it('cancel keeps the window and the buffers; discard confirms the close', () => {
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    render(<AppCloseGuard />);
    fireClose();
    fireEvent.click(screen.getByText('Cancel'));
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.queryByText('Close window?')).not.toBeInTheDocument();
    expect(useEditorStore.getState().tabs[0].isDirty).toBe(true);
    fireClose();
    fireEvent.click(screen.getByText('Discard and close'));
    expect(confirmAppClose).toHaveBeenCalledOnce();
  });

  it('saving every tab while the dialog is open flips it to a safe plain close', () => {
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    render(<AppCloseGuard />);
    fireClose();
    expect(screen.getByText(/1 tab has unsaved changes/)).toBeInTheDocument();
    act(() => { useEditorStore.setState({ tabs: [tab('a', false)], activeTabPath: 'a' }); });
    expect(screen.getByText(/All changes are now saved/)).toBeInTheDocument();
    fireEvent.click(screen.getByText('Close'));
    expect(confirmAppClose).toHaveBeenCalledOnce();
  });

  it('dirty state is read at event time, never from a render-time snapshot', () => {
    render(<AppCloseGuard />);
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    fireClose();
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.getByText('Close window?')).toBeInTheDocument();
  });
});

describe('AppCloseGuard save-then-close', () => {
  let closeRequested: (() => void) | null;
  let confirmAppClose: ReturnType<typeof vi.fn>;
  const realAPI = window.nexelAPI;
  const tab = (id: string, dirty = true) => ({ id, filePath: `/${id}.py`, name: `${id}.py`, content: 'e', originalContent: dirty ? 'o' : 'e', isDirty: dirty });

  beforeEach(() => {
    closeRequested = null;
    confirmAppClose = vi.fn();
    (window as any).nexelAPI = {
      ...realAPI,
      onAppCloseRequested: (cb: () => void) => { closeRequested = cb; },
      confirmAppClose,
    };
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
  });
  afterEach(() => {
    (window as any).nexelAPI = realAPI;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  const openDialog = () => {
    render(<AppCloseGuard />);
    act(() => { closeRequested?.(); });
    expect(screen.getByText('Close window?')).toBeInTheDocument();
  };

  it('Save all dispatches a save request and closes once every tab is clean', () => {
    openDialog();
    const saves: string[] = [];
    window.addEventListener('nexel:save-all', (event) => {
      saves.push('x');
      act(() => { useEditorStore.setState({ tabs: [tab('a', false)], activeTabPath: 'a' }); });
      window.dispatchEvent(new CustomEvent('nexel:save-all-done', {detail: (event as CustomEvent).detail}));
    }, { once: true });
    fireEvent.click(screen.getByText('Save all'));
    expect(saves).toHaveLength(1);
    expect(confirmAppClose).toHaveBeenCalledOnce();
  });

  it('a failed save keeps the dialog open with the live count and never closes', () => {
    openDialog();
    window.addEventListener('nexel:save-all', (event) => {
      window.dispatchEvent(new CustomEvent('nexel:save-all-done', {detail: (event as CustomEvent).detail})); // tab stays dirty: write failed
    }, { once: true });
    fireEvent.click(screen.getByText('Save all'));
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.getByText(/1 tab has unsaved changes/)).toBeInTheDocument();
  });

  it('an edit made during the save keeps the window open (live count re-checked at completion)', () => {
    openDialog();
    window.addEventListener('nexel:save-all', (event) => {
      // save cleaned tab a, but the user typed into tab b while it was in flight
      act(() => { useEditorStore.setState({ tabs: [tab('a', false), tab('b', true)], activeTabPath: 'a' }); });
      window.dispatchEvent(new CustomEvent('nexel:save-all-done', {detail: (event as CustomEvent).detail}));
    }, { once: true });
    fireEvent.click(screen.getByText('Save all'));
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.getByText(/1 tab has unsaved changes/)).toBeInTheDocument();
  });

  it('ignores unsolicited save completions outside a window close-save request', () => {
    openDialog();
    act(() => { useEditorStore.setState({tabs:[tab('a',false)]});window.dispatchEvent(new CustomEvent('nexel:save-all-done')); });
    expect(confirmAppClose).not.toHaveBeenCalled();
  });

  it('Keep open cancels close intent, blocks pending discard, and ignores the issued save completion', () => {
    openDialog();let request: unknown;
    window.addEventListener('nexel:save-all', event => {request=(event as CustomEvent).detail;},{once:true});
    fireEvent.click(screen.getByText('Save all'));
    expect(screen.getByText('Discard and close')).toBeDisabled();
    expect(screen.getByRole('status')).toHaveTextContent('Keeping the window open does not stop the save');
    fireEvent.click(screen.getByText('Keep open'));
    act(() => {useEditorStore.setState({tabs:[tab('a',false)]});window.dispatchEvent(new CustomEvent('nexel:save-all-done',{detail:request}));});
    expect(confirmAppClose).not.toHaveBeenCalled();expect(screen.queryByRole('alertdialog')).toBeNull();
  });

  it('an old completion cannot close a newer close-save request', () => {
    openDialog();const requests:unknown[]=[];
    const listener=(event:Event)=>requests.push((event as CustomEvent).detail);
    window.addEventListener('nexel:save-all',listener);
    fireEvent.click(screen.getByText('Save all'));fireEvent.click(screen.getByText('Keep open'));
    act(()=>closeRequested?.());fireEvent.click(screen.getByText('Save all'));
    act(()=>{useEditorStore.setState({tabs:[tab('a',false)]});window.dispatchEvent(new CustomEvent('nexel:save-all-done',{detail:requests[0]}));});
    expect(confirmAppClose).not.toHaveBeenCalled();
    act(()=>window.dispatchEvent(new CustomEvent('nexel:save-all-done',{detail:requests[1]})));
    expect(confirmAppClose).toHaveBeenCalledOnce();window.removeEventListener('nexel:save-all',listener);
  });

  it('repeated Save clicks while a save is in flight dispatch only once', () => {
    openDialog();
    let dispatches = 0;
    window.addEventListener('nexel:save-all', () => { dispatches++; }); // never completes: still in flight
    fireEvent.click(screen.getByText('Save all'));
    expect(screen.getByText('Saving...')).toBeDisabled();
    fireEvent.click(screen.getByText('Saving...'));
    expect(dispatches).toBe(1);
    expect(confirmAppClose).not.toHaveBeenCalled();
  });
});

describe('AppCloseGuard save-done safety net', () => {
  let closeRequested: (() => void) | null;
  let confirmAppClose: ReturnType<typeof vi.fn>;
  const realAPI = window.nexelAPI;
  const tab = (id: string, dirty = true) => ({ id, filePath: `/${id}.py`, name: `${id}.py`, content: 'e', originalContent: dirty ? 'o' : 'e', isDirty: dirty });

  beforeEach(() => {
    vi.useFakeTimers();
    closeRequested = null;
    confirmAppClose = vi.fn();
    (window as any).nexelAPI = {
      ...realAPI,
      onAppCloseRequested: (cb: () => void) => { closeRequested = cb; },
      confirmAppClose,
    };
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
  });
  afterEach(() => {
    vi.useRealTimers();
    (window as any).nexelAPI = realAPI;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  it('a timed-out completion cannot close the window or complete the newer retry', () => {
    render(<AppCloseGuard />);act(()=>closeRequested?.());const requests:unknown[]=[];
    const listener=(event:Event)=>requests.push((event as CustomEvent).detail);window.addEventListener('nexel:save-all',listener);
    fireEvent.click(screen.getByText('Save all'));act(()=>vi.advanceTimersByTime(11000));
    fireEvent.click(screen.getByText('Save all'));
    act(()=>{useEditorStore.setState({tabs:[tab('a',false)]});window.dispatchEvent(new CustomEvent('nexel:save-all-done',{detail:requests[0]}));});
    expect(confirmAppClose).not.toHaveBeenCalled();
    act(()=>window.dispatchEvent(new CustomEvent('nexel:save-all-done',{detail:requests[1]})));
    expect(confirmAppClose).toHaveBeenCalledOnce();window.removeEventListener('nexel:save-all',listener);
  });

  it('a missing/wedged save handler re-enables Save after the timeout and never closes', () => {
    render(<AppCloseGuard />);
    act(() => { closeRequested?.(); });
    fireEvent.click(screen.getByText('Save all'));
    expect(screen.getByText('Saving...')).toBeDisabled();
    act(() => { vi.advanceTimersByTime(11000); }); // no handler answered
    expect(screen.getByText('Save all')).toBeEnabled(); // dialog usable again
    expect(confirmAppClose).not.toHaveBeenCalled();
    expect(screen.getByText(/1 tab has unsaved changes/)).toBeInTheDocument();
  });
});

describe('AppCloseGuard orphaned deleted-file tabs', () => {
  let closeRequested: (() => void) | null;
  let confirmAppClose: ReturnType<typeof vi.fn>;
  const realAPI = window.nexelAPI;
  const tab = (id: string, dirty = true, orphaned = false) => ({ id, filePath: `/${id}.py`, name: `${id}.py`, content: 'e', originalContent: dirty ? 'o' : 'e', isDirty: dirty, isOrphaned: orphaned });

  beforeEach(() => {
    closeRequested = null;
    confirmAppClose = vi.fn();
    (window as any).nexelAPI = { ...realAPI, onAppCloseRequested: (cb: () => void) => { closeRequested = cb; }, confirmAppClose };
  });
  afterEach(() => {
    (window as any).nexelAPI = realAPI;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  it('names dirty deleted-file tabs and explains Save all cannot save them', () => {
    useEditorStore.setState({ tabs: [tab('gone', true, true), tab('normal', true, false)], activeTabPath: 'gone' });
    render(<AppCloseGuard />);
    act(() => { closeRequested?.(); });
    expect(screen.getByText(/2 tabs have unsaved changes/)).toBeInTheDocument();
    expect(screen.getByText(/gone\.py was deleted from disk, so Save all cannot save it/)).toBeInTheDocument();
    expect(screen.getByText('Discard and close')).toBeInTheDocument();
    expect(screen.getByText('Cancel')).toBeInTheDocument();
  });

  it('no orphan note when every dirty tab lives on disk', () => {
    useEditorStore.setState({ tabs: [tab('normal', true, false)], activeTabPath: 'normal' });
    render(<AppCloseGuard />);
    act(() => { closeRequested?.(); });
    expect(screen.queryByText(/deleted from disk/)).not.toBeInTheDocument();
  });
});
