import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, act } from '@testing-library/react';
import { Explorer } from '../Explorer';
import { useWorkspaceStore } from '../../stores/useWorkspaceStore';
import { mockNexelAPI } from '../../__mocks__/nexelAPI';

describe('Explorer external-change freshness', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo', tree: [{ name: 'old.ts', path: '/repo/old.ts', type: 'file' } as any], isTreeLoading: false } as any);
  });

  it('re-reads the tree on window focus (external file ops surface without manual Refresh)', async () => {
    const spy = vi.fn().mockResolvedValue([{ name: 'old.ts', path: '/repo/old.ts', type: 'file' }]);
    (window.nexelAPI.readWorkspaceFiles as any) = spy;
    render(<Explorer />);
    const before = spy.mock.calls.length;
    await act(async () => { window.dispatchEvent(new Event('focus')); await new Promise((r) => setTimeout(r, 450)); });
    expect(spy.mock.calls.length).toBeGreaterThan(before);
  });

  it('no focus refresh without a workspace', async () => {
    useWorkspaceStore.setState({ rootPath: null } as any);
    const spy = vi.fn().mockResolvedValue([]);
    (window.nexelAPI.readWorkspaceFiles as any) = spy;
    render(<Explorer />);
    await act(async () => { window.dispatchEvent(new Event('focus')); await new Promise((r) => setTimeout(r, 450)); });
    expect(spy).not.toHaveBeenCalled();
  });
});
