import { readFileSync } from 'node:fs';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import { JudgeSystem, readJudgeResults } from '../JudgeSystem';
import { useEditorStore } from '../../stores/useEditorStore';
import { useJudgeStore } from '../../stores/useJudgeStore';

const renderJudge = (path: string) => {
  // Mirror production: activeFilePath derives from the editor store's focused
  // tab, and the run-validity guard reads the same stores at completion.
  useEditorStore.getState().openFile(path, path.split('/').pop() || path, 'int main(){}');
  useEditorStore.setState({ focusedTabPath: path, activeTabPath: path });
  return render(<JudgeSystem activeFilePath={path} />);
};

describe('JudgeSystem component rendering', () => {
  beforeEach(() => {
    useEditorStore.getState().closeAllTabs();
    // Reset judge store to default clean state
    useJudgeStore.setState({
      testCases: [
        { id: 1, name: 'TC 1', input: '5', expected: '10', actual: '', verdict: 'IDLE' }
      ],
      activeTCId: 1,
      activeTab: 'input',
      isRunning: false
    });
  });

  it('keeps testcase tabs keyboard reachable and actual output selectable', () => {
    renderJudge("main.cpp");
    const input = screen.getByRole('tab', {name:'Input'});
    input.focus(); fireEvent.keyDown(input, {key:'ArrowRight'});
    expect(screen.getByRole('tab', {name:'Expected'})).toHaveFocus();
    fireEvent.click(screen.getByRole('tab', {name:'Actual'}));
    expect(screen.getByRole('textbox', {name:'TC 1 actual'})).not.toBeDisabled();
    expect(screen.getByRole('textbox', {name:'TC 1 actual'})).toHaveAttribute('readonly');
  });
  it('makes the comparison a named keyboard reader', () => {
    useJudgeStore.setState({ activeTab: 'diff' });
    renderJudge("main.cpp");
    const reader = screen.getByRole('region', { name: 'TC 1 expected and actual comparison' });
    expect(reader).toHaveAttribute('tabindex', '0');
    reader.focus();
    expect(reader).toHaveFocus();
  });
  it('puts an orphaned-file save warning in keyboard focus without running', async () => {
    useEditorStore.getState().openFile('missing.cpp', 'missing.cpp', 'int main() {}');
    useEditorStore.setState(state => ({ tabs: state.tabs.map(tab => ({ ...tab, isDirty: true, isOrphaned: true })) }));
    const runJudge = vi.fn();
    window.nexelAPI.runJudge = runJudge;
    renderJudge("missing.cpp");
    const run = screen.getByRole('button', { name: 'Save and run testcases' });
    run.focus(); fireEvent.click(run);
    await waitFor(() => expect(screen.getByRole('alert')).toHaveFocus());
    expect(runJudge).not.toHaveBeenCalled();
    expect(useJudgeStore.getState().isRunning).toBe(false);
  });
  it('retains the run trigger during a deferred save, rejects duplicate starts and focuses its warning', async () => {
    useEditorStore.getState().openFile('pending.cpp', 'pending.cpp', 'int main() {}');
    useEditorStore.setState(state => ({ tabs: state.tabs.map(tab => ({ ...tab, isDirty: true })) }));
    let rejectWrite!: (reason: Error) => void;
    const write = vi.fn(() => new Promise<'written' | 'conflict'>((_, reject) => { rejectWrite = reject; }));
    const runJudge = vi.fn();
    window.nexelAPI.writeFileIfBaseline = write;
    window.nexelAPI.runJudge = runJudge;
    renderJudge("pending.cpp");
    const run = screen.getByRole('button', { name: 'Save and run testcases' });
    run.focus(); fireEvent.click(run);
    await waitFor(() => expect(write).toHaveBeenCalledTimes(1));
    expect(run).toHaveFocus();
    // during save/run the button is a live Cancel control, not disabled
    expect(run).toHaveAttribute('aria-disabled', 'false');
    expect(run).toHaveAttribute('aria-label', 'Cancel running testcases');
    fireEvent.click(run); // cancel during the save phase: no second write, runJudge never starts
    expect(write).toHaveBeenCalledTimes(1);
    await act(async () => { rejectWrite(new Error('Simulated write rejection')); });
    expect(screen.getByRole('alert')).toHaveFocus();
    expect(runJudge).not.toHaveBeenCalled();
    expect(useJudgeStore.getState().isRunning).toBe(false);
  });
  it('does not steal focus when a pending save fails after moving to another control', async () => {
    useEditorStore.getState().openFile('other.cpp', 'other.cpp', 'int main() {}');
    useEditorStore.setState(state => ({ tabs: state.tabs.map(tab => ({ ...tab, isDirty: true })) }));
    let rejectWrite!: (reason: Error) => void;
    window.nexelAPI.writeFileIfBaseline = vi.fn(() => new Promise<'written' | 'conflict'>((_, reject) => { rejectWrite = reject; }));
    renderJudge("other.cpp");
    const run = screen.getByRole('button', { name: 'Save and run testcases' });
    run.focus(); fireEvent.click(run);
    await waitFor(() => expect(window.nexelAPI.writeFileIfBaseline).toHaveBeenCalled());
    const input = screen.getByRole('tab', { name: 'Input' });
    input.focus();
    await act(async () => { rejectWrite(new Error('Simulated late rejection')); });
    expect(input).toHaveFocus();
    expect(screen.getByRole('alert')).not.toHaveFocus();
  });
  it('shows a rejected runner message in Actual instead of leaving the input pane visible', async () => {
    window.nexelAPI.runJudge = vi.fn().mockRejectedValue(new Error('Simulated runner unavailable'));
    renderJudge("clean.cpp");
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(screen.getByRole('textbox', { name: 'TC 1 actual' })).toHaveValue('Simulated runner unavailable'));
    expect(screen.getByRole('tab', { name: 'Actual' })).toHaveAttribute('aria-selected', 'true');
    expect(useJudgeStore.getState().isRunning).toBe(false);
  });
  it('returns focus to the selected remaining testcase after keyboard deletion', () => {
    useJudgeStore.setState({ testCases: [
      { id: 1, name: 'TC 1', input: '', expected: '', actual: '' },
      { id: 2, name: 'TC 2', input: '', expected: '', actual: '' }
    ], activeTCId: 2 });
    renderJudge("clean.cpp");
    const remove = screen.getByRole('button', { name: 'Delete TC 2' });
    remove.focus(); fireEvent.click(remove);
    expect(screen.getByRole('button', { name: 'Select TC 1' })).toHaveFocus();
    expect(screen.getByRole('button', { name: 'Delete TC 1' })).toBeDisabled();
  });
  it('cancel during execution calls cancelJudge with the active run id and releases the lock', async () => {
    let finish!: (value: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(resolve => { finish = resolve; })) as typeof window.nexelAPI.runJudge;
    const cancelJudge = vi.fn();
    window.nexelAPI.cancelJudge = cancelJudge;
    renderJudge("clean.cpp");
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    const cancel = await screen.findByRole('button', { name: 'Cancel running testcases' });
    fireEvent.click(cancel);
    expect(cancelJudge).toHaveBeenCalledTimes(1);
    expect(String(cancelJudge.mock.calls[0][0])).toMatch(/^run-/);
    // runner resolves with cancelled results; the lock releases
    await act(async () => { finish([{ id: 1, verdict: 'CANCELLED', metrics: { time: 0, memory: 0, memoryMeasured: false, exitCode: null }, actual: '', diff: 'Canceled by user' }]); });
    expect(useJudgeStore.getState().isRunning).toBe(false);
    expect(useJudgeStore.getState().testCases[0].verdict).toBe('CANCELLED');
  });
  it('locks testcase edits while pending, keeps Run focus, and releases after valid results', async () => {
    let finish!: (value: unknown) => void;
    const runner = vi.fn(() => new Promise(resolve => { finish = resolve; }));
    window.nexelAPI.runJudge = runner as typeof window.nexelAPI.runJudge;
    renderJudge("clean.cpp");
    const run = screen.getByRole('button', { name: 'Run testcases' });
    run.focus(); fireEvent.click(run);
    expect(screen.getByRole('button', { name: 'Add testcase' })).toBeDisabled();
    expect(screen.getByRole('textbox', { name: 'TC 1 input' })).toBeDisabled();
    expect(run).toHaveFocus();
    fireEvent.click(run);
    expect(runner).toHaveBeenCalledTimes(1);
    await act(async () => { finish([{ id: 1, verdict: 'WA', actual: '11', metrics: { time: 2, memory: 0, exitCode: 0 } }]); });
    expect(screen.getByRole('textbox', { name: 'TC 1 actual' })).toHaveValue('11');
    expect(screen.getByRole('button', { name: 'Add testcase' })).not.toBeDisabled();
    expect(run).toHaveFocus();
  });
  it('moves focus into Stress and returns to its trigger on close', () => {
    renderJudge("clean.cpp");
    const trigger = screen.getByRole('button', { name: 'Stress tester: solution vs brute force' });
    trigger.focus(); fireEvent.click(trigger);
    const close = screen.getByRole('button', { name: 'Close stress tester' });
    expect(close).toHaveFocus();
    fireEvent.click(close);
    expect(trigger).toHaveFocus();
    expect(trigger).toHaveAttribute('aria-pressed', 'false');
  });
  it('shows compilation errors distinctly from runtime errors', () => {
    useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:'compiler syntax error',verdict:'CE'}],activeTab:'actual'});
    renderJudge("main.cpp");expect(screen.getByTitle('COMPILATION ERROR (CE)')).toHaveTextContent('CE');
    expect(screen.getByRole('textbox',{name:'TC 1 actual'})).toHaveValue('compiler syntax error');
  });
  it('shows a runner error when stdout is empty', () => {
    useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:'',verdict:'RE',errorMsg:'Runner error'}],activeTab:'actual'});
    renderJudge("main.cpp");
    expect(screen.getByRole('textbox', {name:'TC 1 actual'})).toHaveValue('Runner error');
  });
  it('renders input tab text area by default', () => {
    renderJudge("main.cpp");
    const textarea = screen.getByPlaceholderText(/Enter active testcase input data.../i);
    expect(textarea).toBeInTheDocument();
    expect(textarea).toHaveValue('5');
  });

  it('verifies the Diff Viewer correctly highlights mismatched and matched lines', () => {
    // Populate store with mismatched diff state
    useJudgeStore.setState({
      testCases: [
        {
          id: 1,
          name: 'TC 1',
          input: '5',
          expected: 'line1\nline2\nline3',
          actual: 'line1\nlineX\nline3',
          verdict: 'WA'
        }
      ],
      activeTCId: 1,
      activeTab: 'diff'
    });

    const { container } = renderJudge("main.cpp");
    
    // Check row classes for match/mismatch
    const lineRows = container.querySelectorAll('.nx-diff-line-row');
    expect(lineRows.length).toBe(3);
    
    expect(lineRows[0]).toHaveClass('match');
    expect(lineRows[1]).toHaveClass('mismatch');
    expect(lineRows[2]).toHaveClass('match');
  });

  it('hides legacy unmeasured memory instead of displaying its dummy floor', () => {
    useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:'',verdict:'AC',memory:0.5}]});
    const r=renderJudge("main.cpp");
    expect(screen.queryByText('0.5MB')).toBeNull();
    expect(screen.getByTitle('Memory measurement unavailable')).toHaveTextContent('--');
    r.unmount();
    useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:'',verdict:'AC',memory:32.1,memoryMeasured:true}]});
    renderJudge("main.cpp");
    expect(screen.getByText('32.1MB')).toBeInTheDocument();
  });

  it('verifies that an AC verdict applies correct classes to textarea and metrics panel', () => {
    // Set store state to correct AC verdict
    useJudgeStore.setState({
      testCases: [
        {
          id: 1,
          name: 'TC 1',
          input: '5',
          expected: '10',
          actual: '10',
          verdict: 'AC',
          time: 25,
          memory: 0.8,
          exitCode: 0
        }
      ],
      activeTCId: 1,
      activeTab: 'actual'
    });

    const { container } = renderJudge("main.cpp");
    
    // Verify textarea has .passed-area class
    const textarea = container.querySelector('.nx-judge-textarea');
    expect(textarea).toHaveClass('passed-area');

    // Verify metrics panel has .passed class
    const metricsPanel = container.querySelector('.nx-judge-metrics-panel');
    expect(metricsPanel).toHaveClass('passed');
  });
});

it('refuses to run when the guarded save reports an on-disk conflict',async()=>{
  useEditorStore.getState().openFile('/work/main.py','main.py','old');useEditorStore.getState().updateTabContent('/work/main.py','new');
  const write=vi.fn().mockResolvedValue('conflict'), run=vi.fn();window.nexelAPI.writeFileIfBaseline=write;window.nexelAPI.runJudge=run;
  renderJudge("/work/main.py");fireEvent.click(screen.getByRole('button',{name:'Save and run testcases'}));
  await waitFor(()=>expect(screen.getByRole('alert')).toHaveTextContent('changed on disk'));
  expect(run).not.toHaveBeenCalled();expect(useEditorStore.getState().tabs.find(tb=>tb.filePath==='/work/main.py')!.isDirty).toBe(true);
});
it('runs only after confirmed save and refuses a snapshot changed during the write',async()=>{
  useEditorStore.getState().openFile('/work/main.py','main.py','old');useEditorStore.getState().updateTabContent('/work/main.py','new');
  let finish!: (v:'written'|'conflict')=>void;window.nexelAPI.writeFileIfBaseline=vi.fn(()=>new Promise<'written'|'conflict'>(r=>{finish=r;}));const run=vi.fn();window.nexelAPI.runJudge=run;
  renderJudge("/work/main.py");fireEvent.click(screen.getByRole('button',{name:'Save and run testcases'}));
  await waitFor(()=>expect(window.nexelAPI.writeFileIfBaseline).toHaveBeenCalled());
  await act(async()=>{useEditorStore.getState().updateTabContent('/work/main.py','newer');finish('written');});
  expect(screen.getByRole('alert')).toHaveTextContent('changed while saving');expect(run).not.toHaveBeenCalled();expect(useEditorStore.getState().tabs.find(tb=>tb.filePath==='/work/main.py')!.isDirty).toBe(true);
});

it.each(['cases', 'workspace', 'file'])('refuses changed %s after the pre-run save without overwriting cases', async (change) => {
  const { useWorkspaceStore: ws } = await import('../../stores/useWorkspaceStore');
  const root = ws.getState().rootPath;
  useJudgeStore.setState({ isRunning: false });
  useEditorStore.getState().closeAllTabs();
  renderJudge('/work/save-context.py');
  act(() => { useEditorStore.getState().updateTabContent('/work/save-context.py', 'print(42)'); });
  let finish!: (v: 'written') => void;
  window.nexelAPI.writeFileIfBaseline = vi.fn(() => new Promise<'written'>(r => { finish = r; }));
  window.nexelAPI.runJudge = vi.fn();
  fireEvent.click(screen.getByRole('button', { name: 'Save and run testcases' }));
  await waitFor(() => expect(window.nexelAPI.writeFileIfBaseline).toHaveBeenCalled());
  act(() => {
    if (change === 'cases') useJudgeStore.getState().importSamples([{ input: 'imported', output: 'new' }]);
    if (change === 'workspace') ws.setState({ rootPath: '/other' });
    if (change === 'file') useEditorStore.setState({ activeTabPath: '/other.py', focusedTabPath: '/other.py' });
  });
  const before = useJudgeStore.getState().testCases;
  await act(async () => { finish('written'); });
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
  expect(useJudgeStore.getState().testCases).toEqual(before);
  expect(useJudgeStore.getState().isRunning).toBe(false);
  expect(screen.getByRole('alert')).toHaveTextContent('changed while saving');
  ws.setState({ rootPath: root });
});

describe('Judge result boundary', () => {
  const good = { id: 1, verdict: 'AC', actual: '10', metrics: { time: 12, memory: 0, memoryMeasured: false, exitCode: 0 } };
  it('accepts a complete result set in any order', () => {
    expect(readJudgeResults([{ ...good, id: 2 }, good], [1, 2])).toHaveLength(2);
    expect(readJudgeResults([{...good,verdict:'CE'}],[1])[0].verdict).toBe('CE');
  });
  it('rejects empty and partial results', () => {
    expect(() => readJudgeResults([], [1])).toThrow('incomplete');
    expect(() => readJudgeResults([good], [1, 2])).toThrow('incomplete');
  });
  it('rejects duplicate or unexpected ids', () => {
    expect(() => readJudgeResults([good, good], [1, 2])).toThrow('invalid');
    expect(() => readJudgeResults([{ ...good, id: 3 }], [1])).toThrow('invalid');
  });
  it('rejects invalid verdicts, output and metrics', () => {
    for (const bad of [{ ...good, verdict: 'RUNNING' }, { ...good, actual: null }, { ...good, metrics: null }, { ...good, metrics: { ...good.metrics, time: NaN } }, { ...good, metrics: { ...good.metrics, memory: -1 } }]) {
      expect(() => readJudgeResults([bad], [1])).toThrow('invalid');
    }
  });

  it("discards a finished run's results when the cases changed mid-run, keeping the user's cases", async () => {
    const { useEditorStore: es } = await import('../../stores/useEditorStore');
    es.getState().openFile('main.cpp', 'main.cpp', 'int main(){}');
    es.setState({ focusedTabPath: 'main.cpp', activeTabPath: 'main.cpp' });
    let finish!: (r: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(r => { finish = r; })) as typeof window.nexelAPI.runJudge;
    renderJudge("main.cpp");
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    // Mid-run: new samples arrive (companion import shape).
    act(() => { useJudgeStore.getState().importSamples([{ input: 'alpha-in', output: 'alpha-out' }]); });
    await act(async () => {
      finish([{ id: 1, verdict: 'AC', actual: '10', diff: '', expected: '10', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().isRunning).toBe(false));
    const cases = useJudgeStore.getState().testCases;
    expect(cases.map(tc => tc.input)).toEqual(['alpha-in']); // imported samples survive
    expect(cases[0].verdict).toBe('IDLE'); // stale results not applied
    expect(screen.getByText(/results were discarded/)).toBeInTheDocument();
  });

  it.each(['completion', 'failure'])('discards colliding testcase boundaries on %s', async (mode) => {
    useJudgeStore.getState().importSamples([{ input: '42', output: '42 ' }]);
    let finish!: (r: unknown) => void;
    let fail!: (e: Error) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise((resolve, reject) => { finish = resolve; fail = reject; })) as typeof window.nexelAPI.runJudge;
    renderJudge('main.cpp');
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    act(() => { useJudgeStore.getState().importSamples([{ input: '42 42', output: '' }]); });
    await act(async () => {
      if (mode === 'failure') fail(new Error('old run failed'));
      else finish([{ id: 1, verdict: 'AC', actual: '42', diff: '', expected: '42 ', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().isRunning).toBe(false));
    expect(useJudgeStore.getState().testCases[0]).toMatchObject({ input: '42 42', expected: '', actual: '', verdict: 'IDLE' });
    expect(screen.getByText(/results were discarded/)).toBeInTheDocument();
  });

  it("discards results when the focused source file changed mid-run", async () => {
    const { useEditorStore: es } = await import('../../stores/useEditorStore');
    es.getState().openFile('main.cpp', 'main.cpp', 'int main(){}');
    es.setState({ focusedTabPath: 'main.cpp', activeTabPath: 'main.cpp' });
    let finish!: (r: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(r => { finish = r; })) as typeof window.nexelAPI.runJudge;
    renderJudge("main.cpp");
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    act(() => { es.setState({ focusedTabPath: 'other.cpp', activeTabPath: 'other.cpp' }); });
    await act(async () => {
      finish([{ id: 1, verdict: 'AC', actual: '10', diff: '', expected: '10', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().isRunning).toBe(false));
    expect(useJudgeStore.getState().testCases[0].verdict).toBe('IDLE');
    expect(screen.getByText(/results were discarded/)).toBeInTheDocument();
  });

  it("discards results when the workspace changed mid-run", async () => {
    const { useWorkspaceStore: ws } = await import('../../stores/useWorkspaceStore');
    let finish!: (r: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(r => { finish = r; })) as typeof window.nexelAPI.runJudge;
    renderJudge('main.cpp');
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    act(() => { ws.setState({ rootPath: '/other-workspace' }); });
    await act(async () => {
      finish([{ id: 1, verdict: 'AC', actual: '10', diff: '', expected: '10', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().isRunning).toBe(false));
    expect(useJudgeStore.getState().testCases[0].verdict).toBe('IDLE');
    expect(screen.getByText(/results were discarded/)).toBeInTheDocument();
    act(() => { ws.setState({ rootPath: null }); });
  });

  it("discards results when the same source file was edited mid-run", async () => {
    let finish!: (r: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(r => { finish = r; })) as typeof window.nexelAPI.runJudge;
    renderJudge('main.cpp');
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    act(() => { useEditorStore.getState().updateTabContent('main.cpp', 'int main(){/*edited*/}'); });
    await act(async () => {
      finish([{ id: 1, verdict: 'AC', actual: '10', diff: '', expected: '10', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().isRunning).toBe(false));
    expect(useJudgeStore.getState().testCases[0].verdict).toBe('IDLE');
    expect(screen.getByText(/results were discarded/)).toBeInTheDocument();
  });

  it('still applies results when the run context is unchanged', async () => {
    const { useEditorStore: es } = await import('../../stores/useEditorStore');
    es.getState().closeAllTabs();
    es.getState().openFile('main.cpp', 'main.cpp', 'int main(){}');
    es.setState({ focusedTabPath: 'main.cpp', activeTabPath: 'main.cpp' });
    let finish!: (r: unknown) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise(r => { finish = r; })) as typeof window.nexelAPI.runJudge;
    renderJudge("main.cpp");
    fireEvent.click(screen.getByRole('button', { name: 'Run testcases' }));
    await waitFor(() => expect(window.nexelAPI.runJudge).toHaveBeenCalled());
    await act(async () => {
      finish([{ id: 1, verdict: 'AC', actual: '10', diff: '', expected: '10', passed: true, metrics: { time: 1, memory: 1, memoryMeasured: true, exitCode: 0 } }]);
    });
    await waitFor(() => expect(useJudgeStore.getState().testCases[0].verdict).toBe('AC'));
    expect(screen.queryByText(/results were discarded/)).toBeNull();
  });
});


it('rejects unsupported JavaScript before saving or starting the runner', async () => {
  const {useEditorStore}=await import('../../stores/useEditorStore');
  useEditorStore.getState().openFile('main.js','main.js','console.log(1)');
  useEditorStore.getState().updateTabContent('main.js','console.log(2)');
  window.nexelAPI.runJudge=vi.fn();window.nexelAPI.writeFileIfBaseline=vi.fn();
  render(<JudgeSystem activeFilePath="main.js"/>);
  fireEvent.click(screen.getByRole('button',{name:'Save and run testcases'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('supports .cpp, .cc, .py, and .java');
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
  expect(window.nexelAPI.writeFileIfBaseline).not.toHaveBeenCalled();
});


it('invalidates only the edited testcase result when expected output changes', () => {
  useJudgeStore.setState({testCases:[{id:1,name:'one',input:'5',expected:'42',actual:'42',verdict:'AC',time:5,memory:4,memoryMeasured:true,exitCode:0,errorMsg:'old'},{id:2,name:'two',input:'',expected:'',actual:'bad',verdict:'WA'}],activeTCId:1,activeTab:'expected',isRunning:false});
  renderJudge('main.py');
  fireEvent.change(screen.getByRole('textbox',{name:'one expected'}),{target:{value:'999'}});
  expect(useJudgeStore.getState().testCases[0]).toMatchObject({input:'5',expected:'999',verdict:'IDLE',actual:''});
  for(const key of ['time','memory','memoryMeasured','exitCode','errorMsg'])expect(useJudgeStore.getState().testCases[0][key as 'time']).toBeUndefined();
  expect(useJudgeStore.getState().testCases[1]).toMatchObject({verdict:'WA',actual:'bad'});
});
it('invalidates changed input but keeps a result for identical input or renamed testcase', () => {
  useJudgeStore.setState({testCases:[{id:1,name:'one',input:'5',expected:'42',actual:'42',verdict:'AC',time:5}]});
  useJudgeStore.getState().updateTestCase(1,{input:'5',name:'renamed'});
  expect(useJudgeStore.getState().testCases[0]).toMatchObject({verdict:'AC',actual:'42',name:'renamed'});
  useJudgeStore.getState().updateTestCase(1,{input:'6'});
  expect(useJudgeStore.getState().testCases[0]).toMatchObject({verdict:'IDLE',actual:'',input:'6',expected:'42',name:'renamed'});
});

it('keeps Judge textarea primary fonts ahead of the existing offline emoji fallback', () => {
  const css = readFileSync('src/styles/original-glass.css', 'utf8');
  const rules = css.split('}').filter(rule => /(?:html )?\.nx-judge-textarea\s*\{/.test(rule) && /font:/.test(rule));
  expect(rules).toHaveLength(2);
  for (const rule of rules) expect(rule).toContain("font:12px/1.65 Consolas,'Courier New','Nexel Emoji','Apple Color Emoji','Segoe UI Emoji',monospace");
});

it('keeps stdout exact and exposes separate execution details when a failed run has both', () => {
  useJudgeStore.setState({ testCases: [{ id: 1, name: 'TC 1', input: '', expected: '', actual: 'BEFORE_ERROR\n', errorMsg: 'RuntimeError: VISIBLE_RUNTIME_TRACE', verdict: 'RE' }], activeTCId: 1, activeTab: 'actual' });
  renderJudge('main.py');
  expect(screen.getByRole('textbox', { name: 'TC 1 actual' })).toHaveValue('BEFORE_ERROR\n');
  const details = screen.getByRole('region', { name: 'TC 1 execution details' });
  expect(details).toHaveTextContent('RuntimeError: VISIBLE_RUNTIME_TRACE');
  expect(details).toHaveAttribute('tabindex', '0');
  fireEvent.click(screen.getByRole('tab', { name: 'Diff' }));
  expect(screen.getByRole('region', { name: 'TC 1 execution details' })).toHaveTextContent('RuntimeError: VISIBLE_RUNTIME_TRACE');
  fireEvent.click(screen.getByRole('tab', { name: 'Input' }));
  expect(screen.queryByRole('region', { name: 'TC 1 execution details' })).not.toBeInTheDocument();
});

it('labels retained completed output as a last run with its source after a source edit', async () => {
  const runJudge = vi.fn().mockResolvedValue([{id:1,verdict:'AC',actual:'10',metrics:{time:1,memory:0,exitCode:0},diff:''}]);
  window.nexelAPI.runJudge = runJudge;
  renderJudge('/work/main.cpp');
  fireEvent.click(screen.getByRole('button',{name:'Run testcases'}));
  await waitFor(()=>expect(screen.getByRole('textbox',{name:'TC 1 actual'})).toHaveValue('10'));
  await act(async()=>useEditorStore.setState(state=>({tabs:state.tabs.map(tab=>({...tab,content:'changed',isDirty:true}))})));
  const provenance = screen.getByRole('region',{name:'TC 1 result source'});
  expect(provenance).toHaveTextContent('Last run: /work/main.cpp');
  expect(provenance).toHaveTextContent('Run again after source changes');
  expect(screen.getByRole('textbox',{name:'TC 1 actual'})).toHaveValue('10');
  expect(useJudgeStore.getState().testCases[0]).toMatchObject({verdict:'AC',resultSourcePath:'/work/main.cpp'});
});
it('marks older saved results without a source as unverified instead of guessing current file', () => {
  useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:'old',verdict:'CE'}],activeTCId:1,activeTab:'actual'});
  renderJudge('/work/other.cpp');
  expect(screen.getByRole('region',{name:'TC 1 result source'})).toHaveTextContent('Saved results: source not recorded');
});
