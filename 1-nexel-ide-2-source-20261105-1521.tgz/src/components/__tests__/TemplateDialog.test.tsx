import {afterEach,describe,expect,it,vi} from 'vitest';
import {cleanup,fireEvent,render,screen} from '@testing-library/react';
import {TemplateDialog} from '../TemplateDialog';
afterEach(cleanup);
describe('Template dialog integration',()=>{
 it('saves only the edited value through callback',()=>{const save=vi.fn();render(<TemplateDialog initialValue="old" onSave={save} onCancel={vi.fn()}/>);fireEvent.change(screen.getByRole('textbox'),{target:{value:'new'}});expect(save).not.toHaveBeenCalled();fireEvent.click(screen.getByRole('button',{name:'Save Boilerplate'}));expect(save).toHaveBeenCalledWith('new');});
 it('focuses code, traps reverse Tab and Escape cancels',()=>{const cancel=vi.fn();render(<TemplateDialog initialValue="" onSave={vi.fn()} onCancel={cancel}/>);expect(document.activeElement).toBe(screen.getByRole('textbox'));fireEvent.keyDown(document.activeElement!,{key:'Tab',shiftKey:true});expect(document.activeElement).toBe(screen.getByRole('button',{name:'Save Boilerplate'}));fireEvent.keyDown(document.activeElement!,{key:'Escape'});expect(cancel).toHaveBeenCalledOnce();});
});

it('returns to Options if its original palette input has gone',()=>{const options=document.createElement('button');options.className='nx-menu-trigger-btn';options.textContent='Options';const prior=document.createElement('input');document.body.append(options,prior);prior.focus();const view=render(<TemplateDialog initialValue="" onSave={vi.fn()} onCancel={vi.fn()}/>);prior.remove();view.unmount();expect(options).toHaveFocus();options.remove();});

it('wraps forward Tab back to code and restores its connected trigger',()=>{
 const trigger=document.createElement('button');document.body.append(trigger);trigger.focus();
 const view=render(<TemplateDialog initialValue="" onSave={vi.fn()} onCancel={vi.fn()}/>);
 screen.getByRole('button',{name:'Save Boilerplate'}).focus();
 fireEvent.keyDown(document.activeElement!,{key:'Tab'});
 expect(screen.getByRole('textbox')).toHaveFocus();
 view.unmount();expect(trigger).toHaveFocus();trigger.remove();
});
it('keeps cancelled edits out of the save callback',()=>{
 const save=vi.fn(),cancel=vi.fn();render(<TemplateDialog initialValue="original" onSave={save} onCancel={cancel}/>);
 fireEvent.change(screen.getByRole('textbox'),{target:{value:'discard this'}});
 fireEvent.click(screen.getByRole('button',{name:'Cancel'}));
 expect(cancel).toHaveBeenCalledOnce();expect(save).not.toHaveBeenCalled();
});
it.each(['', '  // exact whitespace\n\nint main() { return 0; }\n'])('saves exact blank or multiline text without filling the placeholder',value=>{
 const save=vi.fn();render(<TemplateDialog initialValue="original" onSave={save} onCancel={vi.fn()}/>);
 fireEvent.change(screen.getByRole('textbox'),{target:{value}});
 fireEvent.click(screen.getByRole('button',{name:'Save Boilerplate'}));
 expect(save).toHaveBeenCalledExactlyOnceWith(value);
});
