import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import {afterEach,it,expect,vi} from 'vitest';
import {SplitDivider} from '../SplitDivider';
afterEach(cleanup);
it('names the splitter, exposes bounds and handles fine/coarse/boundary/reset keys',()=>{
 const change=vi.fn();render(<SplitDivider ratio={50} onChange={change}/>);const divider=screen.getByRole('separator',{name:'Resize editor panes'});
 expect(divider).toHaveAttribute('aria-valuenow','50');expect(divider).toHaveAttribute('aria-orientation','vertical');
 for(const [key,shiftKey,value] of [['ArrowLeft',false,48],['ArrowRight',true,60],['Home',false,20],['End',false,80]] as const){fireEvent.keyDown(divider,{key,shiftKey});expect(change).toHaveBeenLastCalledWith(value);}
 fireEvent.doubleClick(divider);expect(change).toHaveBeenLastCalledWith(50);
});
it('uses pointer capture, clamps against its own rect and stops on cancel/lost capture',()=>{
 const change=vi.fn();const view=render(<div><SplitDivider ratio={50} onChange={change}/></div>);const divider=screen.getByRole('separator');vi.spyOn(divider.parentElement!,'getBoundingClientRect').mockReturnValue({left:100,width:500} as DOMRect);
 divider.setPointerCapture=vi.fn();divider.hasPointerCapture=vi.fn(()=>true);divider.releasePointerCapture=vi.fn();
 const pointer=(type:string,x:number,id=1,button=0)=>{const event=new Event(type,{bubbles:true,cancelable:true});Object.assign(event,{pointerId:id,button,clientX:x});fireEvent(divider,event);};
 pointer('pointerdown',200,1,2);pointer('pointermove',300);expect(change).not.toHaveBeenCalled();
 pointer('pointerdown',200);expect(divider).toHaveFocus();expect(divider.setPointerCapture).toHaveBeenCalledWith(1);pointer('pointermove',300);expect(change).toHaveBeenLastCalledWith(40);pointer('pointermove',900);expect(change).toHaveBeenLastCalledWith(80);
 change.mockClear();pointer('pointermove',350,2);expect(change).not.toHaveBeenCalled();pointer('pointercancel',300);pointer('pointermove',350);expect(change).not.toHaveBeenCalled();expect(divider.releasePointerCapture).toHaveBeenCalledWith(1);
 pointer('pointerdown',200);fireEvent.blur(window);pointer('pointermove',350);expect(change).not.toHaveBeenCalled();pointer('pointerdown',200);pointer('lostpointercapture',300);pointer('pointermove',350);expect(change).not.toHaveBeenCalled();expect(divider).not.toHaveClass('dragging');view.unmount();
});
it('cancels pointer sizing when keyboard focus leaves the divider',()=>{const change=vi.fn();render(<div><SplitDivider ratio={50} onChange={change}/></div>);const divider=screen.getByRole('separator');divider.setPointerCapture=vi.fn();divider.hasPointerCapture=vi.fn(()=>true);divider.releasePointerCapture=vi.fn();const event=new Event('pointerdown',{bubbles:true});Object.assign(event,{button:0,pointerId:7});fireEvent(divider,event);fireEvent.blur(divider);expect(divider.releasePointerCapture).toHaveBeenCalledWith(7);expect(divider).not.toHaveClass('dragging');});
