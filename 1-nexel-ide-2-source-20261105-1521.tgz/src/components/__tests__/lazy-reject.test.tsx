// Proves: a rejected React.lazy stays rejected across boundary resets (retry futile for chunk failures)
import { lazy, Suspense } from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { PluginErrorBoundary } from '../PluginErrorBoundary';

it('rejected lazy re-throws after boundary retry (cached rejection)', async () => {
  const Bad = lazy(() => Promise.reject(new Error('non-chunk rejection')));
  render(<PluginErrorBoundary name="X"><Suspense fallback={<div>loading</div>}><Bad /></Suspense></PluginErrorBoundary>);
  await screen.findByRole('alert');
  fireEvent.click(screen.getByText('Try again'));
  await screen.findByRole('alert'); // still failed: the rejection is cached
  expect(screen.getByRole('alert')).toBeInTheDocument();
});

it('chunk-load failure swaps Try again for Reload window and keeps Disable', async () => {
  const Bad = lazy(() => Promise.reject(new Error('Loading chunk 42 failed')));
  const onDisable = vi.fn();
  render(<PluginErrorBoundary name="X" onDisable={onDisable}><Suspense fallback={<div>loading</div>}><Bad /></Suspense></PluginErrorBoundary>);
  await screen.findByRole('alert');
  expect(screen.queryByText('Try again')).not.toBeInTheDocument();
  expect(screen.getByText('Reload window')).toBeInTheDocument();
  fireEvent.click(screen.getByText('Disable this plugin'));
  expect(onDisable).toHaveBeenCalledOnce();
});

it('non-chunk failures keep Try again', async () => {
  const Bad = lazy(() => Promise.reject(new Error('some other failure')));
  render(<PluginErrorBoundary name="X"><Suspense fallback={<div>loading</div>}><Bad /></Suspense></PluginErrorBoundary>);
  await screen.findByRole('alert');
  expect(screen.getByText('Try again')).toBeInTheDocument();
  expect(screen.queryByText('Reload window')).not.toBeInTheDocument();
});
