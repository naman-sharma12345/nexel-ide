import {afterEach,describe,it,expect} from 'vitest';import {render,screen,fireEvent,cleanup,act} from '@testing-library/react';import {SettingsPanel} from '../SettingsPanel';import {useSettingsStore} from '../../stores/useSettingsStore';
afterEach(()=>{cleanup();useSettingsStore.getState().openSettings(false);});
describe('preference sheet keyboard',()=>{it('contains Tab and restores previous focus on close',()=>{const prior=document.createElement('button');document.body.append(prior);prior.focus();useSettingsStore.getState().openSettings(true);const r=render(<SettingsPanel/>);const close=screen.getByRole('button',{name:'Close settings'});expect(document.activeElement).toBe(close);fireEvent.keyDown(close,{key:'Tab',shiftKey:true});expect(document.activeElement).toBe(screen.getByRole('button',{name:'Reset to defaults'}));fireEvent.keyDown(document.activeElement!,{key:'Tab'});expect(document.activeElement).toBe(close);expect(screen.getByRole('dialog').getAttribute('aria-modal')).toBe('true');r.unmount();expect(document.activeElement).toBe(prior);prior.remove();});});

it('labels numeric choices and exposes their selected state',()=>{useSettingsStore.getState().openSettings(true);render(<SettingsPanel/>);const choice=screen.getByRole('button',{name:'8 spaces'});fireEvent.click(choice);expect(choice).toHaveAttribute('aria-pressed','true');expect(screen.getByRole('button',{name:'2 spaces'})).toHaveAttribute('aria-pressed','false');expect(screen.getByRole('group',{name:'Tab size'})).toBeInTheDocument();expect(screen.getByRole('group',{name:'C++ standard'})).toBeInTheDocument();const standard=screen.getByRole('button',{name:'C++20'});fireEvent.click(standard);expect(standard).toHaveAttribute('aria-pressed','true');expect(screen.getByRole('switch',{name:'Word wrap'})).toBeInTheDocument();});
it('disables font steppers at their real limits and restores them away from the boundary',()=>{useSettingsStore.getState().setFontSize(10);useSettingsStore.getState().openSettings(true);render(<SettingsPanel/>);expect(screen.getByRole('button',{name:'Decrease font size'})).toBeDisabled();fireEvent.click(screen.getByRole('button',{name:'Increase font size'}));expect(screen.getByRole('button',{name:'Decrease font size'})).not.toBeDisabled();for(let i=0;i<13;i++)fireEvent.click(screen.getByRole('button',{name:'Increase font size'}));expect(screen.getByRole('button',{name:'Increase font size'})).toBeDisabled();expect(screen.getByLabelText('Font size')).toHaveTextContent('24');});
it('filters tool cards, enables a plugin and opens its panel',()=>{useSettingsStore.setState({plugins:{},settingsOpen:true});render(<SettingsPanel/>);fireEvent.change(screen.getByRole('searchbox',{name:'Filter extensions'}),{target:{value:'JSON'}});expect(screen.getByRole('switch',{name:'Data Tools'})).toBeInTheDocument();expect(screen.queryByRole('switch',{name:'Text Compare'})).toBeNull();fireEvent.click(screen.getByRole('switch',{name:'Data Tools'}));expect(screen.getByRole('switch',{name:'Data Tools'})).toHaveAttribute('aria-checked','true');fireEvent.click(screen.getByRole('button',{name:'Open Data Tools'}));expect(useSettingsStore.getState().settingsOpen).toBe(false);act(()=>useSettingsStore.setState({plugins:{}}));});

it('applies compiler flags on Enter without dropping keyboard focus',()=>{
 useSettingsStore.setState({settingsOpen:true,clangdEnabled:true,clangdFlags:''});render(<SettingsPanel/>);
 const field=screen.getByRole('textbox',{name:'Extra compiler flags'});field.focus();
 fireEvent.change(field,{target:{value:'-DLOCAL -Wshadow'}});fireEvent.keyDown(field,{key:'Enter'});
 expect(useSettingsStore.getState().clangdFlags).toBe('-DLOCAL -Wshadow');expect(field).toHaveFocus();
 expect(field).toHaveAttribute('aria-invalid','false');
});
it('ties rejected compiler flag feedback to the field',()=>{
 useSettingsStore.setState({settingsOpen:true,clangdEnabled:true,clangdFlags:''});render(<SettingsPanel/>);
 const field=screen.getByRole('textbox',{name:'Extra compiler flags'});
 fireEvent.change(field,{target:{value:'--not-an-allowed-flag'}});
 expect(field).toHaveAttribute('aria-invalid','true');expect(field).toHaveAttribute('aria-describedby','sp-flags-hint sp-flags-warning');
 expect(document.getElementById('sp-flags-warning')).toHaveTextContent('Ignored for safety: --not-an-allowed-flag');
});
it('returns to View when the command palette focus origin is removed',()=>{
 const viewButton=document.createElement('button');viewButton.className='nx-menu-trigger-btn';viewButton.textContent='View';
 const paletteInput=document.createElement('input');document.body.append(viewButton,paletteInput);paletteInput.focus();
 useSettingsStore.setState({settingsOpen:true});const view=render(<SettingsPanel/>);paletteInput.remove();
 view.unmount();expect(viewButton).toHaveFocus();viewButton.remove();
});
it('hands focus to the selected tool navigation when opening it',()=>{
 const nav=document.createElement('button');nav.className='nd-item-row';nav.dataset.navId='data-tools';document.body.append(nav);
 useSettingsStore.setState({plugins:{'data-tools':true},settingsOpen:true});const view=render(<SettingsPanel/>);
 fireEvent.click(screen.getByRole('button',{name:'Open Data Tools'}));
 expect(nav).toHaveFocus();view.unmount();nav.remove();
});
it('does not apply compiler flags or dismiss Settings while an IME key is composing',()=>{
 useSettingsStore.setState({settingsOpen:true,clangdEnabled:true,clangdFlags:''});render(<SettingsPanel/>);
 const field=screen.getByRole('textbox',{name:'Extra compiler flags'});field.focus();fireEvent.change(field,{target:{value:'-DIME_DRAFT'}});
 fireEvent.keyDown(field,{key:'Enter',isComposing:true});expect(useSettingsStore.getState().clangdFlags).toBe('');
 fireEvent.keyDown(field,{key:'Enter',keyCode:229});expect(useSettingsStore.getState().clangdFlags).toBe('');
 fireEvent.keyDown(field,{key:'Escape',isComposing:true});expect(useSettingsStore.getState().settingsOpen).toBe(true);
 fireEvent.keyDown(field,{key:'Escape',keyCode:229});expect(useSettingsStore.getState().settingsOpen).toBe(true);
 fireEvent.keyDown(field,{key:'Enter'});expect(useSettingsStore.getState().clangdFlags).toBe('-DIME_DRAFT');
 fireEvent.keyDown(field,{key:'Escape'});expect(useSettingsStore.getState().settingsOpen).toBe(false);
});
