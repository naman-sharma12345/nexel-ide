import {render,screen,fireEvent,cleanup} from '@testing-library/react';import {afterEach,it,expect,vi} from 'vitest';import {DocumentContext} from '../DocumentContext';
afterEach(cleanup);
const tab={filePath:'/work/atlas/src/server.py',name:'server.py',content:'line one\nline two',originalContent:'',isDirty:true};
it('uses real workspace identity, shows document state and routes reveal',()=>{const reveal=vi.fn();render(<DocumentContext tab={tab} rootPath="/work/atlas" rootName="Atlas API" onReveal={reveal}/>);expect(screen.getByText('Atlas API')).toBeInTheDocument();expect(screen.getByText('2 lines')).toBeInTheDocument();expect(screen.getByText('Unsaved')).toBeInTheDocument();fireEvent.click(screen.getByRole('button',{name:'src'}));expect(reveal).toHaveBeenCalledWith('/work/atlas/src');expect(screen.queryByText('Nexel Engine')).toBeNull();});
it('keeps deleted state distinct from unsaved and handles a single line',()=>{render(<DocumentContext tab={{...tab,content:'x',isOrphaned:true}} rootPath="/work/atlas" rootName="Atlas API" onReveal={vi.fn()}/>);expect(screen.getByText('Deleted on disk')).toBeInTheDocument();expect(screen.getByText('1 line')).toBeInTheDocument();expect(screen.queryByText('Unsaved')).toBeNull();});
it('gives the active file a real heading, separate location and reveal action',()=>{const reveal=vi.fn();render(<DocumentContext tab={tab} rootPath="/work/atlas" rootName="Atlas API" onReveal={reveal}/>);expect(screen.getByRole('heading',{level:1})).toHaveTextContent('server.py');expect(screen.getByRole('navigation',{name:'File location'})).not.toHaveTextContent('server.py');fireEvent.click(screen.getByRole('button',{name:'server.py'}));expect(reveal).toHaveBeenCalledWith(tab.filePath);});

it.each([['nexel://snippets','Code Snippets','Snippet library'],['cf://123/A','CF 123A','Problem statement']])('gives %s view identity without filesystem reveal or fake counts',(filePath,name,label)=>{render(<DocumentContext tab={{...tab,filePath,name,content:''}} rootPath={null} rootName="" onReveal={vi.fn()}/>);expect(screen.getByRole('heading')).toHaveTextContent(name);expect(screen.getByText(label)).toBeInTheDocument();expect(screen.getByText('Read-only')).toBeInTheDocument();expect(screen.queryByRole('button')).toBeNull();expect(screen.queryByText('1 line')).toBeNull();});

it('reveals the real outside POSIX path rather than a differently cased workspace',()=>{
 const reveal=vi.fn();render(<DocumentContext tab={{...tab,filePath:'/Work/Atlas/src/server.py'}} rootPath="/work/atlas" rootName="Other Atlas" onReveal={reveal}/>);
 expect(screen.queryByText('Other Atlas')).toBeNull();fireEvent.click(screen.getByRole('button',{name:'src'}));expect(reveal).toHaveBeenCalledWith('/Work/Atlas/src');
});
it('preserves the share prefix when revealing a UNC breadcrumb',()=>{
 const reveal=vi.fn();render(<DocumentContext tab={{...tab,filePath:'//server/share/project/src/server.py'}} rootPath="//server/share/project" rootName="Network Project" onReveal={reveal}/>);
 fireEvent.click(screen.getByRole('button',{name:'src'}));expect(reveal).toHaveBeenCalledWith('//server/share/project/src');
});
