import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { StressPanel } from '../StressPanel';
import { useJudgeStore } from '../../stores/useJudgeStore';
import { useEditorStore } from '../../stores/useEditorStore';
import { useStatusStore } from '../../stores/useStatusStore';

afterEach(cleanup);
beforeEach(() => { useEditorStore.getState().closeAllTabs(); useJudgeStore.setState({ isRunning: false }); useStatusStore.setState({ toasts: [] }); });
const result = [{ id: 1, verdict: 'WA' as const, actual: '1', metrics: { time: 1, memory: 0, exitCode: 0 } }];
describe('Stress lifecycle', () => {
  it('stops at the pending brute boundary and keeps the shared runner locked until it settles', async () => {
    let finish!: (value: typeof result) => void;
    const runner = vi.fn(() => new Promise<typeof result>(resolve => { finish = resolve; }));
    window.nexelAPI.runJudge = runner;
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    const trigger = screen.getByRole('button', { name: 'START STRESS' });
    trigger.focus(); fireEvent.click(trigger);
    await waitFor(() => expect(runner).toHaveBeenCalledTimes(1));
    expect(screen.getByRole('button', { name: 'STOP' })).toHaveFocus();
    expect(useJudgeStore.getState().isRunning).toBe(true);
    expect(screen.getByRole('textbox', { name: 'Brute force file' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: 'STOP' }));
    expect(useJudgeStore.getState().isRunning).toBe(true);
    expect(screen.getByRole('button', { name: 'STOPPING...' })).toHaveAttribute('aria-busy', 'true');
    expect(screen.getByRole('status')).toHaveTextContent('No new tests will start');
    await act(async () => { finish(result); });
    expect(runner).toHaveBeenCalledTimes(1);
    expect(useJudgeStore.getState().isRunning).toBe(false);
    expect(screen.getByRole('button', { name: 'START STRESS' })).not.toBeDisabled();
    expect(screen.getByRole('button', { name: 'START STRESS' })).toHaveFocus();
    expect(useStatusStore.getState().toasts).toHaveLength(0);
  });
  it('aborts on unmount and suppresses late results and success/failure toasts', async () => {
    let finish!: (value: typeof result) => void;
    const runner = vi.fn(() => new Promise<typeof result>(resolve => { finish = resolve; }));
    window.nexelAPI.runJudge = runner;
    const view = render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    view.unmount();
    expect(useJudgeStore.getState().isRunning).toBe(true);
    await act(async () => { finish(result); });
    expect(runner).toHaveBeenCalledTimes(1);
    expect(useJudgeStore.getState().isRunning).toBe(false);
    expect(useStatusStore.getState().toasts).toHaveLength(0);
  });
  it('rejects missing Stress results instead of comparing empty outputs', async () => {
    window.nexelAPI.runJudge = vi.fn().mockResolvedValue([]);
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    await waitFor(() => expect(useStatusStore.getState().toasts).toHaveLength(1));
    expect(useStatusStore.getState().toasts[0].message).toContain('incomplete or invalid');
    expect(useJudgeStore.getState().isRunning).toBe(false);
    expect(screen.queryByText('All outputs matched')).toBeNull();
    expect(window.nexelAPI.runJudge).toHaveBeenCalledTimes(1);
  });
  it('rejects fractional test counts before starting any program', () => {
    window.nexelAPI.runJudge = vi.fn();
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.change(screen.getByRole('spinbutton', { name: 'Tests' }), { target: { value: '2.5' } });
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Use whole numbers');
    expect(screen.getByRole('alert')).toHaveFocus();
    expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
    expect(useJudgeStore.getState().isRunning).toBe(false);
  });
  it('requires saved source snapshots rather than silently running old disk contents', () => {
    useEditorStore.getState().openFile('/workspace/solution.cpp', '/workspace/solution.cpp', 'old');
    useEditorStore.getState().updateTabContent('/workspace/solution.cpp', 'new');
    window.nexelAPI.runJudge = vi.fn();
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Save changes to both programs');
    expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
  });
  it('rejects unsupported program types and missing paths inline', () => {
    window.nexelAPI.runJudge = vi.fn();
    const view = render(<StressPanel solutionPath="/workspace/notes.md" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    expect(screen.getByRole('alert')).toHaveTextContent('supports .cpp, .cc, .py, and .java');
    view.unmount();
    render(<StressPanel solutionPath={null} onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Open your solution');
    expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
  });
  it('shows the captured running solution when selection changes mid-run', async () => {
    let finish!: (value: typeof result) => void;
    window.nexelAPI.runJudge = vi.fn(() => new Promise<typeof result>(resolve => { finish = resolve; }));
    const view = render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    view.rerender(<StressPanel solutionPath="/workspace/other.cpp" onClose={() => {}} />);
    expect(screen.getByText('/workspace/solution.cpp', { exact: true })).toBeInTheDocument();
    expect(screen.queryByText('/workspace/other.cpp', { exact: true })).toBeNull();
    fireEvent.click(screen.getByRole('button', { name: 'STOP' }));
    await act(async () => { finish(result); });
    expect(screen.getByText('/workspace/other.cpp', { exact: true })).toBeInTheDocument();
  });
  it('adds a mismatch to Judge test cases once without writing a file', async () => {
    useJudgeStore.setState({ testCases: [{ id: 1, name: 'TC 1', input: '', expected: '', actual: '' }], activeTCId: 1 });
    window.nexelAPI.runJudge = vi.fn().mockImplementation(async file => [{ ...result[0], actual: file === '/workspace/solution.cpp' ? 'different' : 'expected' }]);
    window.nexelAPI.writeFileContent = vi.fn();
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    const add = await screen.findByRole('button', { name: 'Add to test cases' });
    expect(screen.getByRole('region', { name: 'Counter-example input preview' })).toHaveAttribute('tabindex', '0');
    add.focus(); fireEvent.click(add);
    expect(add).toHaveTextContent('Added to test cases');
    expect(add).toHaveFocus();
    fireEvent.click(add);
    expect(useJudgeStore.getState().testCases).toHaveLength(2);
    expect(useJudgeStore.getState().testCases[1]).toMatchObject({ expected: 'expected' });
    expect(window.nexelAPI.writeFileContent).not.toHaveBeenCalled();
  });
  it('explains a truncated preview while adding the full counter-example input', async () => {
    useJudgeStore.setState({ testCases: [{ id: 1, name: 'TC 1', input: '', expected: '', actual: '' }], activeTCId: 1 });
    let fullInput = '';
    window.nexelAPI.runJudge = vi.fn().mockImplementation(async (file, cases) => {
      fullInput = cases[0].input;
      return [{ ...result[0], actual: file === '/workspace/solution.cpp' ? 'different' : 'expected' }];
    });
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    fireEvent.change(screen.getByRole('spinbutton', { name: 'Max n' }), { target: { value: '200000' } });
    fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
    const add = await screen.findByRole('button', { name: 'Add to test cases' });
    expect(screen.getByText('Showing the first 600 characters. Add to test cases keeps the full input.')).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'Counter-example input preview' }).textContent!.length).toBe(601);
    fireEvent.click(add);
    expect(useJudgeStore.getState().testCases[1].input).toBe(fullInput);
  });
  it('refuses to start while another Judge run owns the shared runner', () => {
    useJudgeStore.setState({ isRunning: true });
    window.nexelAPI.runJudge = vi.fn();
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
    const start = screen.getByRole('button', { name: 'START STRESS' });
    expect(start).toBeDisabled();
    fireEvent.click(start);
    expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
    expect(useJudgeStore.getState().isRunning).toBe(true);
  });
});

describe('Stress failure reveal', () => {
  it.each([[true, 'instant'], [false, 'smooth']])('scrolls the counter-example into view on mismatch, reduced-motion %s', async (reduce, behavior) => {
    const match = window.matchMedia;
    window.matchMedia = vi.fn(() => ({ matches: reduce })) as unknown as typeof window.matchMedia;
    const spy = vi.fn();
    Element.prototype.scrollTo = spy;
    let call = 0;
    window.nexelAPI.runJudge = vi.fn(() => Promise.resolve([{ id: 1, verdict: 'WA' as const, actual: call++ === 0 ? '7' : '8', metrics: { time: 1, memory: 0, exitCode: 0 } }]));
    try {
      render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={() => {}} />);
      fireEvent.change(screen.getByRole('spinbutton', { name: 'Tests' }), { target: { value: '1' } });
      fireEvent.click(screen.getByRole('button', { name: 'START STRESS' }));
      await waitFor(() => expect(screen.getByText('Mismatch found')).toBeInTheDocument());
      expect(spy).toHaveBeenCalledWith({ top: 0, behavior });
    } finally { delete (Element.prototype as Partial<Element>).scrollTo; window.matchMedia = match; }
  });
});


describe('Stress program failures are not output mismatches', () => {
  it.each([['brute','CE'],['brute','RE'],['solution','CE']])('does not create testcase data for %s %s', async (target, verdict) => {
    useJudgeStore.setState({testCases:[{id:1,name:'TC 1',input:'',expected:'',actual:''}]});
    window.nexelAPI.runJudge=vi.fn().mockImplementation(async file=>[{...result[0],verdict:(file==='/workspace/solution.cpp')===(target==='solution')?verdict:'WA',actual:'compiler diagnostic'}]);
    render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={()=>{}}/>);
    fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
    await screen.findByText('Program failed');
    expect(screen.queryByText('Mismatch found')).toBeNull();
    expect(screen.queryByRole('region',{name:'Counter-example output difference'})).toBeNull();
    expect(screen.queryByRole('button',{name:'Add to test cases'})).toBeNull();
    expect(screen.getByRole('region',{name:'Program error output'})).toHaveTextContent('compiler diagnostic');
    expect(useJudgeStore.getState().testCases).toHaveLength(1);
    expect(useStatusStore.getState().toasts[0].message).not.toContain('counter-example');
  });
});


describe('Stress completed result provenance', () => {
  it('keeps the source pair that produced a retained mismatch when current selection and brute field change', async () => {
    window.nexelAPI.runJudge=vi.fn().mockImplementation(async file=>[{...result[0],actual:file==='/workspace/solution.cpp'?'different':'expected'}]);
    const view=render(<StressPanel solutionPath="/workspace/solution.cpp" onClose={()=>{}}/>);
    fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
    await screen.findByText('Mismatch found');
    view.rerender(<StressPanel solutionPath="/workspace/other.cpp" onClose={()=>{}}/>);
    fireEvent.change(screen.getByRole('textbox',{name:'Brute force file'}),{target:{value:'/workspace/new_brute.cpp'}});
    expect(screen.getByText('Results from: /workspace/solution.cpp vs /workspace/solution_brute.cpp')).toBeInTheDocument();
    expect(screen.getByText('/workspace/other.cpp',{exact:true})).toBeInTheDocument();
    expect(screen.getByRole('button',{name:'Add to test cases'})).toBeInTheDocument();
  });
});


it('shows brute runtime stderr separately and never treats it as expected stdout', async () => {
  window.nexelAPI.runJudge=vi.fn().mockResolvedValue([{...result[0],verdict:'RE',actual:'',diff:'RuntimeError: BRUTE_RUNTIME_TRACE'}]);
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  expect(await screen.findByRole('region',{name:'Program error output'})).toHaveTextContent('BRUTE_RUNTIME_TRACE');
  expect(screen.queryByRole('button',{name:'Add to test cases'})).toBeNull();
});


it('does not advertise JavaScript as an executable Stress language', async () => {
  window.nexelAPI.runJudge=vi.fn();
  render(<StressPanel solutionPath="/workspace/solution.js" onClose={()=>{}}/>);
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('supports .cpp, .cc, .py, and .java');
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
});


it.each(['main_brute.py','./main_brute.py','../main_brute.py'])('requires an explicit absolute brute path instead of running %s in the app directory', async path => {
  window.nexelAPI.runJudge=vi.fn();
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.change(screen.getByRole('textbox',{name:'Brute force file'}),{target:{value:path}});
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('Use the full absolute path');
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
});


it('refuses a dirty brute tab reached through a symlink spelling', async () => {
  useEditorStore.getState().openFile('/workspace/brute.py','brute.py','print(42)');
  useEditorStore.getState().updateTabContent('/workspace/brute.py','print(99)');
  window.nexelAPI.fileIdentity=vi.fn(async path=>path.replace('link.py','brute.py'));
  window.nexelAPI.runJudge=vi.fn();
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.change(screen.getByRole('textbox',{name:'Brute force file'}),{target:{value:'/workspace/link.py'}});
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('Save changes to both programs');
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
  expect(useEditorStore.getState().tabs[0].content).toBe('print(99)');
});
it('does not start a stale request when selection changes during alias validation', async () => {
  useEditorStore.getState().openFile('/workspace/other.py','other.py','old');
  useEditorStore.getState().updateTabContent('/workspace/other.py','dirty');
  let finish!:(path:string)=>void;
  let first=true;window.nexelAPI.fileIdentity=vi.fn(path=>{if(first){first=false;return new Promise<string>(r=>{finish=r;});}return Promise.resolve(path);});
  window.nexelAPI.runJudge=vi.fn();
  const view=render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  view.rerender(<StressPanel solutionPath="/workspace/new.py" onClose={()=>{}}/>);
  await act(async()=>{finish?.('/workspace/solution.py');});
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
});


it('explains an unverifiable alias check without executing unsaved files', async () => {
  useEditorStore.getState().openFile('/workspace/other.py','other.py','old');
  useEditorStore.getState().updateTabContent('/workspace/other.py','dirty');
  window.nexelAPI.fileIdentity=vi.fn().mockRejectedValue(Error('unreadable'));
  window.nexelAPI.runJudge=vi.fn();
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('Could not verify open unsaved files');
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
});
it('allows an unrelated dirty tab after identity validation and deduplicates pending starts', async () => {
  useEditorStore.getState().openFile('/workspace/other.py','other.py','old');
  useEditorStore.getState().updateTabContent('/workspace/other.py','dirty');
  let finish!:(path:string)=>void;let first=true;
  window.nexelAPI.fileIdentity=vi.fn(path=>{if(first){first=false;return new Promise<string>(r=>{finish=r;});}return Promise.resolve(path);});
  window.nexelAPI.runJudge=vi.fn().mockResolvedValue([{...result[0],actual:'42'}]);
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.change(screen.getByRole('spinbutton',{name:'Tests'}),{target:{value:'1'}});
  const start=screen.getByRole('button',{name:'START STRESS'});fireEvent.click(start);fireEvent.click(start);
  await act(async()=>{finish('/workspace/solution.py');});
  expect(await screen.findByText('All outputs matched')).toBeInTheDocument();
  expect(window.nexelAPI.runJudge).toHaveBeenCalledTimes(2);
  expect(useEditorStore.getState().tabs[0].content).toBe('dirty');
});
it('discards validation if a buffer changes before it completes', async () => {
  useEditorStore.getState().openFile('/workspace/other.py','other.py','old');
  useEditorStore.getState().updateTabContent('/workspace/other.py','dirty');
  let finish!:(path:string)=>void;let first=true;
  window.nexelAPI.fileIdentity=vi.fn(path=>{if(first){first=false;return new Promise<string>(r=>{finish=r;});}return Promise.resolve(path);});
  window.nexelAPI.runJudge=vi.fn();
  render(<StressPanel solutionPath="/workspace/solution.py" onClose={()=>{}}/>);
  fireEvent.click(screen.getByRole('button',{name:'START STRESS'}));
  useEditorStore.getState().updateTabContent('/workspace/other.py','newer dirty');
  await act(async()=>{finish('/workspace/solution.py');});
  expect(window.nexelAPI.runJudge).not.toHaveBeenCalled();
});
