import {afterEach,it,expect,vi} from 'vitest';
import {render,screen,fireEvent,cleanup,within} from '@testing-library/react';
import {TitleBar} from '../TitleBar';
import {useUIStore} from '../../stores/useUIStore';
import {useWorkspaceStore} from '../../stores/useWorkspaceStore';
import {useSettingsStore} from '../../stores/useSettingsStore';
import {registerPlugin} from '../../plugins/registry';
afterEach(cleanup);
it('focuses the clicked menu, clamps its right edge and restores focus on Escape',()=>{
 const bounds=vi.spyOn(HTMLElement.prototype,'getBoundingClientRect').mockReturnValue({left:370,bottom:28} as DOMRect);
 const width=vi.spyOn(HTMLElement.prototype,'offsetWidth','get').mockReturnValue(210);
 const old=window.innerWidth;Object.defineProperty(window,'innerWidth',{configurable:true,value:400});
 render(<TitleBar/>);const trigger=screen.getByRole('button',{name:'Help'});fireEvent.click(trigger);
 const menu=screen.getByRole('menu',{name:'Help'});expect(menu.style.left).toBe('182px');expect(menu.style.top).toBe('34px');expect(screen.getByRole('menuitem',{name:'About Nexel IDE'})).toHaveFocus();
 fireEvent.keyDown(document.activeElement!,{key:'End'});expect(screen.getByRole('menuitem',{name:'Keyboard Shortcuts'})).toHaveFocus();
 Object.defineProperty(window,'innerWidth',{configurable:true,value:560});fireEvent(window,new Event('resize'));expect(menu.style.left).toBe('342px');
 fireEvent.keyDown(document.activeElement!,{key:'Escape'});expect(screen.queryByRole('menu')).not.toBeInTheDocument();expect(trigger).toHaveFocus();
 Object.defineProperty(window,'innerWidth',{configurable:true,value:old});bounds.mockRestore();width.mockRestore();
});

it('gives the template dialog a durable Options focus return target',()=>{render(<TitleBar/>);const trigger=screen.getByRole('button',{name:'Options'});fireEvent.click(trigger);fireEvent.click(screen.getByRole('menuitem',{name:'C++ Template...'}));expect(trigger).toHaveFocus();expect(screen.queryByRole('menu')).not.toBeInTheDocument();});

it('keeps About focus contained and returns to Help on Escape',()=>{render(<TitleBar/>);const help=screen.getByRole('button',{name:'Help'});fireEvent.click(help);fireEvent.click(screen.getByRole('menuitem',{name:'About Nexel IDE'}));const close=within(screen.getByRole('dialog')).getByRole('button',{name:'Close'});expect(close).toHaveFocus();fireEvent.keyDown(close,{key:'Tab',shiftKey:true});expect(close).toHaveFocus();fireEvent.keyDown(close,{key:'Escape'});expect(screen.queryByRole('dialog')).not.toBeInTheDocument();expect(help).toHaveFocus();});

it('returns Help-menu shortcut reference dismissal to Help',()=>{render(<TitleBar/>);const help=screen.getByRole('button',{name:'Help'});fireEvent.click(help);fireEvent.click(screen.getByRole('menuitem',{name:'Keyboard Shortcuts'}));const close=screen.getByRole('button',{name:'Close keyboard shortcuts'});expect(close).toHaveFocus();fireEvent.keyDown(close,{key:'Escape'});expect(screen.queryByRole('dialog')).not.toBeInTheDocument();expect(help).toHaveFocus();});

it('gives View settings a live return target before its menu item unmounts',()=>{render(<TitleBar/>);const view=screen.getByRole('button',{name:'View'});fireEvent.click(view);fireEvent.click(screen.getByRole('menuitem',{name:'Appearance / Settings...'}));expect(view).toHaveFocus();expect(screen.queryByRole('menu')).not.toBeInTheDocument();});

it.each(['New File','New Folder'])('reveals Workspace before %s starts its inline name field',label=>{useUIStore.setState({currentSection:'text-compare',sidebarCollapsed:true});useWorkspaceStore.setState({rootPath:'/fixture',rootName:'fixture',lastSelectedNode:null});render(<TitleBar/>);fireEvent.click(screen.getByRole('button',{name:'File'}));fireEvent.click(screen.getByRole('menuitem',{name:label}));expect(useUIStore.getState()).toMatchObject({currentSection:'workspace',sidebarCollapsed:false});expect(useWorkspaceStore.getState().inlineInput.visible).toBe(true);useWorkspaceStore.getState().setInlineInput({visible:false});});

it('merges plugin menu items into any named menu, not only Options',()=>{
 registerPlugin({id:'test-menu-plugin',name:'Test Menu Plugin',blurb:'t',defaultEnabled:false,sections:[],commandIds:[],navItems:[],menuItems:{File:[{label:'Test File Item',action:vi.fn()}],Options:[{label:'Test Options Item',action:vi.fn()}]}});
 useSettingsStore.setState({plugins:{...useSettingsStore.getState().plugins,'test-menu-plugin':true}});
 render(<TitleBar/>);
 fireEvent.click(screen.getByRole('button',{name:'File'}));
 expect(screen.getByRole('menuitem',{name:'Test File Item'})).toBeInTheDocument();
 fireEvent.keyDown(document.activeElement!,{key:'Escape'});
 fireEvent.click(screen.getByRole('button',{name:'Options'}));
 expect(screen.getByRole('menuitem',{name:'Test Options Item'})).toBeInTheDocument();
 fireEvent.keyDown(document.activeElement!,{key:'Escape'});
 useSettingsStore.setState({plugins:{...useSettingsStore.getState().plugins,'test-menu-plugin':false}});
});
