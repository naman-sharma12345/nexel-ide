import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { WorkspaceResize, clampWorkspaceWidth } from '../WorkspaceResize';
describe('workspace shared edge', () => {
  it('offers named keyboard sizing and reset without selecting text', () => {
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 1440 });
    const onChange = vi.fn(); const view = render(<WorkspaceResize width={340} onChange={onChange} />);
    const edge = screen.getByRole('separator', { name: 'Workspace panel width' });
    fireEvent.keyDown(edge, { key: 'ArrowRight' }); expect(onChange).toHaveBeenLastCalledWith(356);
    fireEvent.keyDown(edge, { key: 'Home' }); expect(onChange).toHaveBeenLastCalledWith(270);
    fireEvent.keyDown(edge, { key: 'End' }); expect(onChange).toHaveBeenLastCalledWith(540);
    fireEvent.doubleClick(edge); expect(onChange).toHaveBeenLastCalledWith(340); view.unmount();
  });
  it('bounds drag requests', () => { expect(clampWorkspaceWidth(-500)).toBe(270); expect(clampWorkspaceWidth(900)).toBe(540); });
});
