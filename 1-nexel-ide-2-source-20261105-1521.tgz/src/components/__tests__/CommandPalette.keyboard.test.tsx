import {describe,it,expect,vi} from 'vitest';import {render,screen,fireEvent} from '@testing-library/react';import {CommandPalette} from '../CommandPalette';
describe('command choices',()=>{it('exposes selected option and executes the last result from Ctrl+End',()=>{const run=vi.fn();const r=render(<CommandPalette commands={[{id:'a',label:'Open',run:vi.fn()},{id:'b',label:'Save',run}]} onClose={()=>{}}/>);const input=screen.getByRole('combobox');fireEvent.keyDown(input,{key:'End',ctrlKey:true});expect(screen.getByRole('option',{name:'Save'}).getAttribute('aria-selected')).toBe('true');expect(input.getAttribute('aria-activedescendant')).toBe(screen.getByRole('option',{name:'Save'}).id);expect(fireEvent.keyDown(input,{key:'Enter'})).toBe(false);expect(run).toHaveBeenCalledOnce();r.unmount();});});

it('shows paths for duplicate files and searches the full relative identity',()=>{const runA=vi.fn(),runB=vi.fn();render(<CommandPalette commands={[{id:'api',label:'config.py',detail:'services/api/config.py',run:runA},{id:'web',label:'config.py',detail:'services/web/config.py',run:runB}]} onClose={vi.fn()} label="Quick open"/>);expect(screen.getByRole('option',{name:'config.py, services/api/config.py'})).toBeInTheDocument();const input=screen.getByRole('combobox');fireEvent.change(input,{target:{value:'web/config'}});expect(screen.getAllByRole('option')).toHaveLength(1);expect(screen.getByText('services/web/config.py')).toBeInTheDocument();fireEvent.keyDown(input,{key:'Enter'});expect(runB).toHaveBeenCalledOnce();expect(runA).not.toHaveBeenCalled();});

it('restores trigger on cancel but does not steal the command target on execution',()=>{
 const trigger=document.createElement('button');const target=document.createElement('button');document.body.append(trigger,target);trigger.focus();
 let r=render(<CommandPalette commands={[]} onClose={()=>{}}/>);r.unmount();expect(document.activeElement).toBe(trigger);
 r=render(<CommandPalette commands={[{id:'focus',label:'Focus',run:()=>target.focus()}]} onClose={()=>{}}/>);fireEvent.keyDown(r.getByRole('combobox'),{key:'Enter'});r.unmount();expect(document.activeElement).toBe(target);trigger.remove();target.remove();
});

it('keeps a selected result when a live command list shrinks',()=>{
 const run=vi.fn();const commands=[{id:'one',label:'One',run},{id:'two',label:'Two',run:vi.fn()},{id:'three',label:'Three',run:vi.fn()}];
 const view=render(<CommandPalette commands={commands} onClose={()=>{}}/>);fireEvent.keyDown(view.getByRole('combobox'),{key:'End',ctrlKey:true});view.rerender(<CommandPalette commands={commands.slice(0,1)} onClose={()=>{}}/>);
 expect(view.getByRole('option',{name:'One'})).toHaveAttribute('aria-selected','true');fireEvent.keyDown(view.getByRole('combobox'),{key:'Enter'});expect(run).toHaveBeenCalledOnce();view.unmount();
});

it('does not execute or close while the input method is composing',()=>{
 const run=vi.fn(),close=vi.fn();const view=render(<CommandPalette commands={[{id:'one',label:'One',run}]} onClose={close}/>);const input=view.getByRole('combobox');
 fireEvent.keyDown(input,{key:'Enter',isComposing:true});fireEvent.keyDown(input,{key:'Escape',isComposing:true});fireEvent.keyDown(input,{key:'Enter',keyCode:229});expect(run).not.toHaveBeenCalled();expect(close).not.toHaveBeenCalled();fireEvent.keyDown(input,{key:'Enter'});expect(run).toHaveBeenCalledOnce();view.unmount();
});
it('executes at most once while close is being processed',()=>{const run=vi.fn();const view=render(<CommandPalette commands={[{id:'one',label:'One',run}]} onClose={vi.fn()}/>);const input=view.getByRole('combobox');fireEvent.keyDown(input,{key:'Enter'});fireEvent.keyDown(input,{key:'Enter'});fireEvent.click(view.getByRole('option'));expect(run).toHaveBeenCalledOnce();view.unmount();});

it('renders the first chunk and reports the total, then grows as ArrowDown passes the rendered tail',()=>{
 const runs=Array.from({length:150},()=>vi.fn());
 const commands=runs.map((run,i)=>({id:'f'+String(i),label:'file-'+String(i).padStart(3,'0')+'.ts',run}));
 const view=render(<CommandPalette commands={commands} onClose={vi.fn()} label="Quick open"/>);
 expect(view.getAllByRole('option')).toHaveLength(100);
 expect(view.getByText('Showing 100 of 150')).toBeInTheDocument();
 const input=view.getByRole('combobox');
 for(let k=0;k<100;k++) fireEvent.keyDown(input,{key:'ArrowDown'});
 expect(view.getAllByRole('option').length).toBeGreaterThanOrEqual(101);
 expect(view.getByRole('option',{name:'file-100.ts'})).toHaveAttribute('aria-selected','true');
 expect(input.getAttribute('aria-activedescendant')).toBe(view.getByRole('option',{name:'file-100.ts'}).id);
 fireEvent.keyDown(input,{key:'Enter'});
 expect(runs[100]).toHaveBeenCalledOnce();runs.forEach((r,i)=>{if(i!==100)expect(r).not.toHaveBeenCalled();});
 view.unmount();
});

it('Ctrl+End renders and selects the true last result of the full list',()=>{
 const runs=Array.from({length:150},()=>vi.fn());
 const commands=runs.map((run,i)=>({id:'f'+String(i),label:'file-'+String(i).padStart(3,'0')+'.ts',run}));
 const view=render(<CommandPalette commands={commands} onClose={vi.fn()} label="Quick open"/>);
 const input=view.getByRole('combobox');
 fireEvent.keyDown(input,{key:'End',ctrlKey:true});
 expect(view.getAllByRole('option')).toHaveLength(150);
 expect(view.getByRole('option',{name:'file-149.ts'})).toHaveAttribute('aria-selected','true');
 fireEvent.keyDown(input,{key:'Enter'});
 expect(runs[149]).toHaveBeenCalledOnce();view.unmount();
});

it('scrolling near the end reveals the next chunk without hiding it behind a query',()=>{
 const commands=Array.from({length:150},(_,i)=>({id:'f'+String(i),label:'file-'+String(i).padStart(3,'0')+'.ts',run:vi.fn()}));
 const view=render(<CommandPalette commands={commands} onClose={vi.fn()} label="Quick open"/>);
 const list=view.getByRole('listbox');
 Object.defineProperty(list,'scrollHeight',{value:2000,configurable:true});
 Object.defineProperty(list,'clientHeight',{value:400,configurable:true});
 Object.defineProperty(list,'scrollTop',{value:1500,configurable:true});
 fireEvent.scroll(list);
 expect(view.getAllByRole('option')).toHaveLength(150);
 expect(view.getByText('150 results')).toBeInTheDocument();
 view.unmount();
});

it('narrowing the query surfaces matches beyond the initial chunk',()=>{
 const target=vi.fn();
 const commands=[...Array.from({length:140},(_,i)=>({id:'f'+String(i),label:'alpha-'+String(i)+'.ts',run:vi.fn()})),{id:'t',label:'zzz-target.ts',run:target}];
 const view=render(<CommandPalette commands={commands} onClose={vi.fn()} label="Quick open"/>);
 expect(view.queryByRole('option',{name:'zzz-target.ts'})).toBeNull();
 const input=view.getByRole('combobox');
 fireEvent.change(input,{target:{value:'zzz-target'}});
 expect(view.getAllByRole('option')).toHaveLength(1);
 fireEvent.keyDown(input,{key:'Enter'});expect(target).toHaveBeenCalledOnce();view.unmount();
});

it('keeps the plain count when results fit in one chunk',()=>{
 const view=render(<CommandPalette commands={[{id:'a',label:'One',run:vi.fn()},{id:'b',label:'Two',run:vi.fn()}]} onClose={vi.fn()}/>);
 expect(view.getByText('2 results')).toBeInTheDocument();view.unmount();
});

it('highlights complete supplementary characters in matching filenames',()=>{
 render(<CommandPalette commands={[{id:'emoji',label:'🌐-notes.txt',run:vi.fn()}]} onClose={()=>{}}/>);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'🌐'}});
 const option=screen.getByRole('option');expect(option.textContent).toBe('🌐-notes.txt');expect(option.querySelector('mark')?.textContent).toBe('🌐');
});
it('keeps original filename text when case folding expands a character before the match',()=>{
 const view=render(<CommandPalette commands={[{id:'unicode-fold',label:'İ-notes.txt',run:vi.fn()}]} onClose={vi.fn()} />);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'notes'}});
 const row=screen.getByRole('option');expect(row.textContent).toBe('İ-notes.txt');expect(row.querySelectorAll('mark')[0]).toHaveTextContent('n');view.unmount();
});
it('maps an expanded folded hit once to its original source character',()=>{
 const view=render(<CommandPalette commands={[{id:'unicode-fold-hit',label:'İ-🌐.txt',run:vi.fn()}]} onClose={vi.fn()} />);
 fireEvent.change(screen.getByRole('combobox'),{target:{value:'i\u0307'}});expect(screen.getByRole('option').textContent).toBe('İ-🌐.txt');expect(screen.getByRole('option').querySelector('mark')).toHaveTextContent('İ');expect(screen.getByRole('option').querySelectorAll('mark')).toHaveLength(1);view.unmount();
});
