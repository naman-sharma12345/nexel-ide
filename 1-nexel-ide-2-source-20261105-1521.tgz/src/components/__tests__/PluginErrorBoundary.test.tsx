import { render, screen, fireEvent, act } from '@testing-library/react';
import { PluginErrorBoundary } from '../PluginErrorBoundary';
import { useEditorStore } from '../../stores/useEditorStore';

const Boom = () => { throw new Error('boom'); };
const ok = () => <div>healthy sibling</div>;

describe('PluginErrorBoundary', () => {
  beforeEach(() => { vi.spyOn(console, 'error').mockImplementation(() => {}); });
  afterEach(() => { (console.error as any).mockRestore?.(); });

  it('keeps siblings mounted and names the plugin when a child throws', () => {
    render(<><PluginErrorBoundary name="Regex Lab"><Boom /></PluginErrorBoundary>{ok()}</>);
    expect(screen.getByRole('alert')).toHaveTextContent('Regex Lab stopped working');
    expect(screen.getByText('healthy sibling')).toBeInTheDocument();
  });

  it('retry remounts children; disable fires the callback', () => {
    let fail = true;
    const Maybe = () => { if (fail) throw new Error('x'); return <div>panel ok</div>; };
    const onDisable = vi.fn();
    render(<PluginErrorBoundary name="Time Lab" onDisable={onDisable}><Maybe /></PluginErrorBoundary>);
    expect(screen.getByRole('alert')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Disable this plugin'));
    expect(onDisable).toHaveBeenCalledOnce();
    fail = false;
    fireEvent.click(screen.getByText('Try again'));
    expect(screen.getByText('panel ok')).toBeInTheDocument();
  });

  it('a different plugin under the same boundary starts clean', () => {
    const { rerender } = render(<PluginErrorBoundary name="A"><Boom /></PluginErrorBoundary>);
    expect(screen.getByRole('alert')).toBeInTheDocument();
    rerender(<PluginErrorBoundary name="B"><div>fresh</div></PluginErrorBoundary>);
    expect(screen.getByText('fresh')).toBeInTheDocument();
  });
});

it('resets when resetKey changes (e.g. plugin disabled from the notice)', () => {
  let fail = true;
  const Maybe = () => { if (fail) throw new Error('x'); return null; };
  const { rerender } = render(<PluginErrorBoundary name="CP" resetKey={true}><Maybe /></PluginErrorBoundary>);
  expect(screen.getByRole('alert')).toBeInTheDocument();
  fail = false;
  rerender(<PluginErrorBoundary name="CP" resetKey={false}><Maybe /></PluginErrorBoundary>);
  expect(screen.queryByRole('alert')).not.toBeInTheDocument();
});

describe('reload guard', () => {
  const ChunkBoom = () => { throw new Error('Loading chunk 12 failed'); };
  let reload: ReturnType<typeof vi.fn>;
  const realLocation = window.location;
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    reload = vi.fn();
    delete (window as any).location;
    (window as any).location = { reload };
  });
  afterEach(() => {
    (console.error as any).mockRestore?.();
    (window as any).location = realLocation;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  const dirtyTab = () => ({ id: 't1', filePath: '/x.py', name: 'x.py', content: 'edited', originalContent: 'orig', isDirty: true });

  it('clean session reloads immediately without a dialog', () => {
    useEditorStore.setState({ tabs: [], activeTabPath: null });
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    fireEvent.click(screen.getByText('Reload window'));
    expect(reload).toHaveBeenCalledOnce();
    expect(screen.queryByText('Reload window?')).not.toBeInTheDocument();
  });

  it('dirty tabs pause the reload behind an unsaved-changes dialog', () => {
    useEditorStore.setState({ tabs: [dirtyTab()], activeTabPath: 't1' });
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    expect(screen.getByText("This plugin's code could not be loaded. Reloading the window may fix this. Any unsaved editor changes will be asked about first.")).toBeInTheDocument();
    fireEvent.click(screen.getByText('Reload window'));
    expect(reload).not.toHaveBeenCalled();
    expect(screen.getByText('Reload window?')).toBeInTheDocument();
    expect(screen.getByText(/unsaved changes/)).toBeInTheDocument();
  });

  it('cancel keeps the session and the buffer; discard reloads', () => {
    useEditorStore.setState({ tabs: [dirtyTab()], activeTabPath: 't1' });
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    fireEvent.click(screen.getByText('Reload window'));
    fireEvent.click(screen.getByText('Cancel'));
    expect(reload).not.toHaveBeenCalled();
    expect(screen.queryByText('Reload window?')).not.toBeInTheDocument();
    expect(useEditorStore.getState().tabs[0].isDirty).toBe(true);
    fireEvent.click(screen.getByText('Reload window'));
    fireEvent.click(screen.getByText('Discard and reload'));
    expect(reload).toHaveBeenCalledOnce();
  });
});

describe('reload guard late-dirty transitions', () => {
  const ChunkBoom = () => { throw new Error('Loading chunk 12 failed'); };
  let reload: ReturnType<typeof vi.fn>;
  const realLocation = window.location;
  const tab = (id: string, dirty = true) => ({ id, filePath: `/${id}.py`, name: `${id}.py`, content: 'e', originalContent: dirty ? 'o' : 'e', isDirty: dirty });
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    reload = vi.fn();
    delete (window as any).location;
    (window as any).location = { reload };
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });
  afterEach(() => {
    (console.error as any).mockRestore?.();
    (window as any).location = realLocation;
    useEditorStore.setState({ tabs: [], activeTabPath: null });
  });

  it('clean at render, dirty before click: confirmation still appears (click-time read, no stale snapshot)', () => {
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    fireEvent.click(screen.getByText('Reload window'));
    expect(reload).not.toHaveBeenCalled();
    expect(screen.getByText('Reload window?')).toBeInTheDocument();
  });

  it('count updates while the dialog is open when another tab becomes dirty', () => {
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    fireEvent.click(screen.getByText('Reload window'));
    expect(screen.getByText(/1 tab has unsaved changes/)).toBeInTheDocument();
    act(() => { useEditorStore.setState({ tabs: [tab('a'), tab('b')], activeTabPath: 'a' }); });
    expect(screen.getByText(/2 tabs have unsaved changes/)).toBeInTheDocument();
    expect(reload).not.toHaveBeenCalled();
  });

  it('saving the dirty tab while the dialog is open switches to a safe-to-reload message', () => {
    useEditorStore.setState({ tabs: [tab('a')], activeTabPath: 'a' });
    render(<PluginErrorBoundary name="CL"><ChunkBoom /></PluginErrorBoundary>);
    fireEvent.click(screen.getByText('Reload window'));
    act(() => { useEditorStore.setState({ tabs: [tab('a', false)], activeTabPath: 'a' }); });
    expect(screen.getByText('All changes are now saved. Reloading will not lose any edits.')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Reload'));
    expect(reload).toHaveBeenCalledOnce();
  });
});
