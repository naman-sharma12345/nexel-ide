import {useEffect,useLayoutEffect,useRef} from 'react';
import { useStatusStore } from '../stores/useStatusStore';
import './Toasts.css';

const ICON = { success: 'M5 13l4 4L19 7', error: 'M6 6l12 12M18 6L6 18', info: 'M12 8v.01M12 11v5' } as const;

export function Toasts() {
  const stack=useRef<HTMLDivElement>(null);
  const priorFocus=useRef<HTMLElement|null>(null);
  const pendingFocus=useRef<{index:number;removed:HTMLElement}|null>(null);
  useEffect(()=>{
    const remember=(event:FocusEvent)=>{const target=event.target as HTMLElement;if(target!==document.body && !stack.current?.contains(target))priorFocus.current=target;};
    document.addEventListener('focusin',remember);
    const unsubscribe=useStatusStore.subscribe(state=>{
      const active=document.activeElement as HTMLElement|null;
      if(!active || !stack.current?.contains(active))return;
      const toast=active.closest<HTMLElement>('[data-toast-id]');
      if(toast && !state.toasts.some(item=>String(item.id)===toast.dataset.toastId))pendingFocus.current={index:[...stack.current.querySelectorAll('[data-toast-reader],button')].indexOf(active as HTMLButtonElement),removed:active};
    });
    return()=>{document.removeEventListener('focusin',remember);unsubscribe();};
  },[]);
  useEffect(()=>{const element=stack.current;if(!element || typeof ResizeObserver==='undefined')return;const observer=new ResizeObserver(()=>{document.documentElement.style.setProperty('--nx-notification-height',`${element.getBoundingClientRect().height}px`);requestAnimationFrame(()=>{const active=document.activeElement as HTMLElement|null;if(active?.closest('.sb-menu'))active.scrollIntoView({block:'nearest'});});});observer.observe(element);return()=>{observer.disconnect();document.documentElement.style.removeProperty('--nx-notification-height');};},[]);
  const toasts = useStatusStore(s => s.toasts);
  const dismiss = useStatusStore(s => s.dismissToast);
  const pinnedToBottom=useRef(true);
  const seenIds=useRef<Set<number>>(new Set());
  useEffect(()=>{const element=stack.current;if(!element)return;
    const track=()=>{pinnedToBottom.current=element.scrollHeight-element.clientHeight-element.scrollTop<24;};
    element.addEventListener('scroll',track,{passive:true});
    return()=>element.removeEventListener('scroll',track);},[]);
  // Keep the newest notification in view: the strip is height-capped, so a
  // fresh toast would otherwise arrive hidden below its scroll fold. Only
  // additions scroll, and only while the strip is pinned to its latest toast -
  // a user who scrolled up to read older notices is not yanked away,
  // dismissals never move the strip, and keyboard focus inside it wins.
  useLayoutEffect(()=>{
    const element=stack.current;
    const hasNewToast=toasts.some(toast=>!seenIds.current.has(toast.id));
    seenIds.current=new Set(toasts.map(toast=>toast.id));
    if(!toasts.length)pinnedToBottom.current=true;
    if(!element||!hasNewToast||!pinnedToBottom.current)return;
    if(element.contains(document.activeElement))return;
    element.scrollTop=element.scrollHeight;
  },[toasts]);
  useLayoutEffect(()=>{
    const pending=pendingFocus.current;pendingFocus.current=null;if(!pending)return;
    if(document.activeElement!==document.body && document.activeElement!==pending.removed)return;
    const buttons=stack.current?.querySelectorAll<HTMLElement>('[data-toast-reader],button');
    const next=buttons?.[Math.min(pending.index,(buttons?.length??0)-1)];
    const restore=priorFocus.current?.isConnected ? priorFocus.current : document.querySelector<HTMLElement>('.nd-item-row[data-nav-id="workspace"]');
    (next??restore)?.focus({preventScroll:true});
  },[toasts]);
  return (
    <div ref={stack} className="tz-stack" aria-label="Notifications">
      {toasts.map(t => (
        <div key={t.id} data-toast-id={t.id} className={`tz-toast tz-${t.kind}`} role={t.kind === 'error' ? 'alert' : 'status'}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d={ICON[t.kind]} /></svg>
          <span tabIndex={0} role="region" aria-label="Notification details" data-toast-reader>{t.message}</span>
          <button type="button" aria-label={`Dismiss: ${t.message}`} onClick={() => dismiss(t.id)}><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="m4 4 8 8M12 4l-8 8" /></svg></button>
        </div>
      ))}
    </div>
  );
}
