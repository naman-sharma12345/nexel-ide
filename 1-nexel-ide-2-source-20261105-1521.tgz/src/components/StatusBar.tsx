import {utilityTabLabel} from '../lib/utilityTab';
import { memo, useEffect, useRef, useState } from 'react';
import { useLspStore, STATUS_HINT, STATUS_LABEL } from '../lib/clangd/state';
import { getClangd } from '../lib/clangd/session';
import { useStatusStore } from '../stores/useStatusStore';
import { useEditorStore } from '../stores/useEditorStore';
import { collectPluginStatusItems } from '../plugins/registry';
import '../plugins/competitive-programming';
import { useUIStore } from '../stores/useUIStore';
import { useSettingsStore, } from '../stores/useSettingsStore';
import { getTheme } from '../lib/themes';
import './StatusBar.css';

const LANGS: Record<string, string> = { cpp: 'C++', cc: 'C++', cxx: 'C++', h: 'C++', hpp: 'C++', c: 'C', py: 'Python', java: 'Java', js: 'JavaScript', ts: 'TypeScript', tsx: 'TypeScript React', rs: 'Rust', go: 'Go', md: 'Markdown', json: 'JSON', html: 'HTML', css: 'CSS', txt: 'Plain Text' };
export function languageLabel(name?: string): string {
  if (!name) return '—';
  const ext = name.includes('.') ? name.split('.').pop()!.toLowerCase() : '';
  return LANGS[ext] ?? 'Plain Text';
}

/** clangd only serves C/C++ sources; the chip is hidden for other files so the
 *  status bar never implies a language server that is not running for that file. */
const CLANGD_EXTS = new Set(['c', 'cc', 'cpp', 'cxx', 'h', 'hh', 'hpp', 'hxx', 'm', 'mm']);
export function isClangdRelevant(name?: string): boolean {
  if (!name) return false;
  const ext = name.includes('.') ? name.split('.').pop()!.toLowerCase() : '';
  return CLANGD_EXTS.has(ext);
}

/** clangd chip: live state dot + label, tooltip, and a small menu (restart, enable/disable, settings). */
export function ClangdChip() {
  const status = useLspStore(s => s.status);
  const detail = useLspStore(s => s.detail);
  const progress = useLspStore(s => s.progress);
  const enabled = useSettingsStore(s => s.clangdEnabled);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const down = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') {e.preventDefault();setOpen(false);triggerRef.current?.focus();} };
    ref.current?.querySelector<HTMLButtonElement>('[role=menuitem]:not(:disabled)')?.focus();
    window.addEventListener('mousedown', down); window.addEventListener('keydown', key);
    return () => { window.removeEventListener('mousedown', down); window.removeEventListener('keydown', key); };
  }, [open]);
  const label = STATUS_LABEL[status] + (status === 'indexing' && progress != null ? ` ${Math.round(progress)}%` : '');
  const canRestart = enabled && status !== 'off' && status !== 'disabled';
  return (
    <div className="sb-lsp-wrap" ref={ref}>
      <button ref={triggerRef} className={`sb-item sb-btn sb-lsp sb-lsp-${status} ${open ? 'on' : ''}`} onClick={() => setOpen(o => !o)}
        title={`clangd: ${label}\n${STATUS_HINT[status]}${detail ? `\n${detail}` : ''}`} aria-label={`clangd: ${label}`} aria-haspopup="menu" aria-expanded={open} data-status={status}>
        <i className="sb-lsp-dot" aria-hidden="true" /><span className="sb-lsp-name">clangd</span><em>{label}</em>
      </button>
      {open && (
        <div className="sb-menu" role="menu" aria-label="clangd" onKeyDown={event=>{
          if ((event.target as HTMLElement).closest('[role=region]') && ['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Home','End','PageUp','PageDown'].includes(event.key)) return;
          const items=[...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=menuitem]:not(:disabled)')];
          const index=items.indexOf(document.activeElement as HTMLButtonElement);
          if(event.key==='Tab') {setOpen(false);return;}
          if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)) {
            event.preventDefault();
            const next=event.key==='Home'?0:event.key==='End'?items.length-1:(index+(event.key==='ArrowDown'?1:-1)+items.length)%items.length;
            items[next]?.focus();
          }
        }}>
          <header><i className={`sb-lsp-dot sb-lsp-${status}`} /><b>clangd IntelliSense</b><span className={`sb-lsp-tag sb-lsp-${status}`}>{label}</span></header>
          <p>{STATUS_HINT[status]}</p>
          {detail && <small tabIndex={0} role="region" aria-label="clangd diagnostic details">{detail}</small>}
          <div className="sb-menu-items">
            <button role="menuitem" disabled={!canRestart} onClick={() => { triggerRef.current?.focus(); setOpen(false); void getClangd().restart(); }}>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7" /></svg>Restart clangd
            </button>
            <button role="menuitem" onClick={() => { triggerRef.current?.focus(); setOpen(false); useSettingsStore.getState().toggle('clangdEnabled'); }}>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d={enabled ? 'M6 6l12 12M18 6L6 18' : 'M5 13l4 4L19 7'} /></svg>{enabled ? 'Use built-in IntelliSense only' : 'Enable clangd'}
            </button>
            <button role="menuitem" onClick={() => { triggerRef.current?.focus(); setOpen(false); useSettingsStore.getState().openSettings(true); window.setTimeout(() => document.getElementById('sp-intellisense')?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }), 60); }}>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h4M12 17h8M14 4v6M8 14v6" /></svg>IntelliSense settings…
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export const StatusBar = memo(function StatusBar() {
  const activePath = useEditorStore(s => s.focusedTabPath ?? s.activeTabPath);
  const cursor = useStatusStore(s => activePath ? s.cursors[activePath] : undefined);
  const {line, col, selected, count = 1} = cursor ?? {line:1,col:1,selected:0,count:1};
  const tab = useEditorStore(s => s.tabs.find(t => t.filePath === activePath));
  const utility = utilityTabLabel(tab?.filePath);
  const pluginPrefs = useSettingsStore(s => s.plugins);
  const pluginStatusItems = collectPluginStatusItems(pluginPrefs);
  const terminalVisible = useUIStore(s => s.terminalVisible);
  const toggleTerminal = useUIStore(s => s.toggleTerminal);
  const themeName = getTheme(useSettingsStore(s => s.theme)).name;
  const openSettings = useSettingsStore(s => s.openSettings);

  return (
    <footer className="sb-bar" role="status" aria-label="Status bar">
      <div className="sb-group">
        <span className="sb-context-label">{utility ? 'VIEW' : tab ? 'DOCUMENT' : 'WORKSPACE'}</span>
        {tab && <span className="sb-item sb-file" title={tab.filePath}>{tab.name}{tab.isDirty && <i className="sb-dirty" title="Unsaved changes" />}</span>}
      </div>
      <div className="sb-group sb-right">
        {pluginStatusItems.map((Item, i) => <Item key={i} />)}
        {tab && !utility && <span className="sb-item sb-num" title={`Ln ${line}, Col ${col}${count > 1 ? ` (${count} cursors)` : ''}${selected > 0 ? ` (${selected} sel)` : ''}`}>Ln {line}, Col {col}{count > 1 && <em> ({count} cursors)</em>}{selected > 0 && <em> ({selected} sel)</em>}</span>}
        {!utility && isClangdRelevant(tab?.name) && <ClangdChip />}
        <span className="sb-item">{utility ?? languageLabel(tab?.name)}</span>
        {!utility && <span className="sb-item sb-encoding">UTF-8</span>}
        <button className="sb-item sb-btn sb-theme" onClick={() => openSettings(true)} title={`Appearance: ${themeName} (Ctrl+,)`} aria-label={`Appearance: ${themeName}`}><span>Appearance</span></button>
        <button className={`sb-item sb-btn sb-terminal-toggle ${terminalVisible ? 'on' : ''}`} onClick={toggleTerminal} title="Toggle terminal" aria-pressed={terminalVisible}>Terminal</button>
        <span className="sb-item sb-hint"><kbd>Ctrl</kbd><kbd>⇧</kbd><kbd>P</kbd></span>
      </div>
    </footer>
  );
});
