import { removeLastTerminalGrapheme, terminalBackspaceSequence } from '../lib/terminalDelete';
import React, { useEffect, useRef, useState } from 'react';
import { escapeSequenceLength, MAX_PENDING_ESCAPE } from '../lib/terminalInput';
import { Terminal as XTerm } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';
import './Terminal.css';
import { useSettingsStore } from '../stores/useSettingsStore';
import { getTheme } from '../lib/themes';
import { useStatusStore } from '../stores/useStatusStore';
import {useWorkspaceStore} from '../stores/useWorkspaceStore';
import { terminalTheme } from '../lib/terminalTheme';

interface TerminalProps {
  visible: boolean;
  onClose: () => void;
  sidebarCollapsed: boolean;
  height?: number;
  onHeightChange?: (height: number) => void;
}

export const Terminal: React.FC<TerminalProps> = ({ visible, onClose, sidebarCollapsed, height = 240, onHeightChange }) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const restartShellRef = useRef<() => void>(() => {});
  const [starting,setStarting] = useState(false);
  // Mount-once latch: hiding the panel must not destroy the shell session, so the
  // terminal stays mounted (CSS-hidden) after its first show.
  const [hasBeenVisible, setHasBeenVisible] = useState(visible);
  useEffect(() => { if (visible) setHasBeenVisible(true); }, [visible]);
  // Visible at first render = a persisted panel restored at startup: it must not
  // steal focus. A deliberate open later always puts keystrokes in the shell.
  const restoredAtStart = useRef(visible);
  const heightDrag = useRef<{ y: number; height: number } | null>(null);
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  useEffect(() => { const resize = () => setViewportHeight(window.innerHeight); window.addEventListener('resize', resize); return () => window.removeEventListener('resize', resize); }, []);
  const [notificationHeight,setNotificationHeight] = useState(0);
  useEffect(()=>{
    const stack=document.querySelector('.tz-stack');
    if(!stack || typeof ResizeObserver==='undefined')return;
    const update=()=>setNotificationHeight(stack.getBoundingClientRect().height);
    update();const observer=new ResizeObserver(update);observer.observe(stack);return()=>observer.disconnect();
  },[]);
  const shortViewport = viewportHeight <= 380;
  const maximumHeight = Math.max(0, Math.floor(shortViewport
    ? Math.min(80,viewportHeight-220-notificationHeight)
    : Math.min(Math.max(140,viewportHeight-340),viewportHeight*.55,viewportHeight-210-notificationHeight)));
  // Short windows: let the user trade terminal for editor down to 56px
  // instead of pinning the terminal at the 80px cap with no resize at all.
  const minimumHeight = shortViewport ? Math.min(56,maximumHeight) : Math.min(140,maximumHeight);
  const visibleHeight = Math.max(minimumHeight,Math.min(height, maximumHeight));
  const changeHeight = (value: number) => onHeightChange?.(Math.max(minimumHeight, Math.min(maximumHeight, value)));
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermInstance = useRef<XTerm | null>(null);
  const fitAddonInstance = useRef<FitAddon | null>(null);

  const themeId = useSettingsStore(st => st.theme);
  useEffect(() => {
    const t = xtermInstance.current;
    if (t) t.options.theme = terminalTheme(getTheme(themeId));
  }, [themeId]);

  useEffect(() => {
    if (!hasBeenVisible || !terminalRef.current) return;

    // Initialize xterm with custom visual theme matching Monaco minimally
    const term = new XTerm({
      cursorBlink: true,
      cursorStyle: 'underline',
      fontSize: 12,
      fontFamily: 'Consolas, "Courier New", "Nexel Emoji", "Apple Color Emoji", "Segoe UI Emoji", monospace',
      theme: terminalTheme(getTheme(useSettingsStore.getState().theme)),
      allowProposedApi: true
    });
    // Workbench chords the terminal must not swallow (xterm preventDefaults keys it
    // treats as input, and the app's global handler skips defaultPrevented events):
    // Ctrl+Alt+Z toggles zen, Ctrl+` toggles this panel.
    term.attachCustomKeyEventHandler((event) => {
      if (event.type !== 'keydown') return true;
      const chord = (event.ctrlKey || event.metaKey);
      if (chord && event.altKey && event.key.toLowerCase() === 'z') return false;
      if (chord && !event.altKey && !event.shiftKey && event.key === '`') return false;
      return true;
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(terminalRef.current);
    
    // Fit terminal layout to container
    const fitTimer = setTimeout(() => {
      if (disposed) return;
      try {
        fitAddon.fit();
        window.nexelAPI.resizeTerminal(term.cols, term.rows);
      } catch {
        // Ignore terminal resizing errors on layout change
      }
    }, 100);

    xtermInstance.current = term;
    fitAddonInstance.current = fitAddon;

    // First open via a deliberate toggle (Ctrl+`, status bar, command): the user
    // expects to type immediately. Startup-restored panels skip this (guard above).
    // Timing: the toggle's setState and this init effect flush synchronously in
    // the same React commit cycle, before the browser can dispatch another input
    // event - no user navigation can interleave between toggle and this focus.
    // A click elsewhere AFTER the flush simply moves focus away (intent wins).
    if (!restoredAtStart.current) term.focus();

    let isNative = false;
    let commandInputBuffer = '';
    const echoQueue: Array<string | (() => string)> = [];
    let echoPending = false;
    const drainEcho = () => {
      if (disposed || echoPending || !echoQueue.length) return;
      echoPending = true;
      const item = echoQueue.shift()!;
      let text = typeof item === 'string' ? item : item();
      // Batch printable paste runs, but do not pass a width-sensitive deletion.
      while (typeof echoQueue[0] === 'string') text += echoQueue.shift();
      term.write(text, () => { echoPending = false; drainEcho(); });
    };
    const echo = (text: string | (() => string)) => { echoQueue.push(text); drainEcho(); };

    // Tail of a chunk that ended mid-escape-sequence (bounded, dropped on overflow).
    let pendingEscape = '';
    let disposed = false, ready = false, pending = false;
    let startErrorToast: number | undefined;

    // false is the supported pipe fallback; only a rejected start is failure.
    const startShell = async () => {
      if (disposed || pending) return;
      pending = true; ready = false; setStarting(true); echoQueue.length = 0; commandInputBuffer = ''; pendingEscape = ''; // a new shell session inherits no half-typed line or half-received escape
      try {
        // Live read at call time: a restarted shell lands in the CURRENT workspace root.
        const nativeActive = await window.nexelAPI.createTerminal(useWorkspaceStore.getState().rootPath ?? undefined);
        if (disposed) return;
        isNative = nativeActive;
        // Pipes emit LF, unlike a PTY's cooked CRLF output. Keep display columns
        // at the start of each output line without changing shell bytes.
        term.options.convertEol = !nativeActive;
        ready = true;
        if (startErrorToast !== undefined) { useStatusStore.getState().dismissToast(startErrorToast); startErrorToast = undefined; }
      } catch (error) {
        if (!disposed) {
          console.error('Could not start shell:',error);
          startErrorToast = useStatusStore.getState().pushToast('Could not start shell. Use Restart Shell to try again.','error',6000);
        }
      } finally { pending = false; if (!disposed) setStarting(false); }
    };
    restartShellRef.current = () => {
      if (!pending && !disposed) {
        // Hand focus off before React disables the restart button. Do it now,
        // never on async completion: a later click elsewhere must keep focus.
        term.focus?.();
        term.reset();
        void startShell();
      }
    };
    void startShell();

    // Late PTY output must not reach a disposed terminal.
    const unsubTerminalData = window.nexelAPI.onTerminalData((data: string) => {
      if (!disposed) {
        if (isNative) term.write(data);
        else echo(data); // preserve arrival order with local echo/deletion
      }
    });

    // Write terminal key inputs -> shell process stdin
    const onDataDisposable = term.onData((data) => {
      if (!ready || disposed) return;
      if (isNative) {
        window.nexelAPI.writeTerminal(data);
      } else {
        // Fallback TTY emulation: manual echo + standard input stream pipe.
        // Escape sequences (arrows, Home/End, Delete, function keys) are never
        // editable command text - and the pipe shell has no readline to consume
        // them, so they are CONSUMED AND DROPPED, never forwarded: natively
        // verified that a forwarded sequence merges with the next submitted
        // line in bash's byte stream and silently eats the whole command
        // ("$'\E[Aecho': command not found"). A chunk tail ending mid-sequence
        // is stashed (bounded) and re-parsed with the next chunk, so printable
        // text before and after a sequence keeps its normal editable handling.
        const input = pendingEscape + data;
        pendingEscape = '';
        for (let i = 0; i < input.length; i++) {
          const char = String.fromCodePoint(input.codePointAt(i)!);
          if (char.length === 2) i++; // one printable code point, not two surrogate halves
          
          if (char === '\r' || char === '\n') {
            if (char === '\r' && input[i + 1] === '\n') i++; // CRLF is one pasted line break
            echo('\r\n');
            window.nexelAPI.writeTerminal(commandInputBuffer + '\n');
            commandInputBuffer = '';
          } else if (char === '\x1B') {
            const len = escapeSequenceLength(input, i);
            if (len === 'incomplete') {
              pendingEscape = input.slice(i);
              if (pendingEscape.length > MAX_PENDING_ESCAPE) pendingEscape = ''; // drop, never forward (see header)
              break;
            }
            i += len - 1; // consume the whole sequence; drop it (see header comment)
          } else if (char === '\u007F' || char === '\b') {
            if (commandInputBuffer.length > 0) {
              const next = removeLastTerminalGrapheme(commandInputBuffer);
              const removed = commandInputBuffer.slice(next.length);
              commandInputBuffer = next;
              // Wait for queued echo to reach xterm before inspecting the last cell.
              echo(() => {
                return terminalBackspaceSequence(term, removed);
              });
            }
          } else if (char.codePointAt(0)! >= 32 && char !== '\u007F' && !(char.codePointAt(0)! >= 0x80 && char.codePointAt(0)! <= 0x9f)) {
            commandInputBuffer += char;
            echo(char);
          } else {
            // Preserve existing control-key forwarding; printable Unicode stays buffered.
            window.nexelAPI.writeTerminal(char);
          }
        }
      }
    });

    // Handle resize on observer updates
    const resizeObserver = new ResizeObserver(() => {
      try {
        fitAddon.fit();
        window.nexelAPI.resizeTerminal(term.cols, term.rows);
      } catch {
        // Ignore terminal resizing errors on observer trigger
      }
    });
    if (terminalRef.current) {
      resizeObserver.observe(terminalRef.current);
    }

    return () => {
      disposed = true;
      echoQueue.length = 0;
      clearTimeout(fitTimer);
      restartShellRef.current = () => {};
      if (typeof unsubTerminalData === 'function') unsubTerminalData();
      onDataDisposable.dispose();
      resizeObserver.disconnect();
      // Drain xterm's write queue before disposing: a viewport refresh queued by an
      // in-flight write crashes when it lands after the render service is torn down.
      // The empty-write callback fires only after every prior write is processed.
      term.write('', () => {
        term.dispose();
        if (xtermInstance.current === term) {
          xtermInstance.current = null;
          fitAddonInstance.current = null;
        }
      });
    };
    // Mount-once: re-runs only when the panel first becomes visible.
  }, [hasBeenVisible]);

  useEffect(()=>{
    if(!visible)return;
    const panel=panelRef.current;
    return()=>{const active=document.activeElement;if(active===document.body||panel?.contains(active))document.querySelector<HTMLButtonElement>('.sb-terminal-toggle')?.focus({preventScroll:true});};
  },[visible]);

  // Re-opening the panel (visible false -> true after the first mount) returns
  // keyboard focus to the shell input. Hiding moves focus OUT of the panel when
  // it is inside: the terminal stays mounted while hidden, and a focused hidden
  // xterm would keep swallowing keystrokes the user cannot see.
  const wasVisible = useRef(visible);
  useEffect(() => {
    const opened = visible && !wasVisible.current;
    const closed = !visible && wasVisible.current;
    wasVisible.current = visible;
    if (opened && hasBeenVisible) xtermInstance.current?.focus();
    if (closed) {
      const active = document.activeElement;
      if (active && panelRef.current?.contains(active)) document.querySelector<HTMLButtonElement>('.sb-terminal-toggle')?.focus({preventScroll:true});
    }
  }, [visible, hasBeenVisible]);

  if (!hasBeenVisible) return null;

  return (
    <div 
      ref={panelRef} className="nx-terminal-panel"
      style={{ left: sidebarCollapsed ? '0px' : undefined, display: visible ? undefined : 'none' }}
      aria-hidden={visible ? undefined : true}
    >
      <div className="nx-terminal-resize" role="separator" aria-label="Terminal height" aria-orientation="horizontal" aria-valuemin={minimumHeight} aria-valuemax={maximumHeight} aria-valuenow={visibleHeight} aria-disabled={minimumHeight===maximumHeight} tabIndex={0}
        onDoubleClick={() => changeHeight(240)}
        onKeyDown={event => { const value = event.key === 'ArrowUp' ? visibleHeight + 20 : event.key === 'ArrowDown' ? visibleHeight - 20 : event.key === 'Home' ? minimumHeight : event.key === 'End' ? maximumHeight : null; if (value !== null) { event.preventDefault(); event.stopPropagation(); changeHeight(value); } }}
        onPointerDown={event => { if (event.button !== 0) return; event.preventDefault(); event.currentTarget.focus(); event.currentTarget.setPointerCapture(event.pointerId); heightDrag.current = { y:event.clientY, height:visibleHeight }; }}
        onPointerMove={event => { if (heightDrag.current) changeHeight(heightDrag.current.height + heightDrag.current.y - event.clientY); }}
        onPointerUp={event => { heightDrag.current = null; if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); }}
        onPointerCancel={() => { heightDrag.current = null; }} onLostPointerCapture={() => { heightDrag.current = null; }} />
      <div className="nx-terminal-header">
        <div className="nx-term-header-left">
          <svg className="nx-term-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="4 17 10 11 4 5" /><line x1="12" y1="19" x2="20" y2="19" />
          </svg>
          <span className="nx-term-title">Terminal</span><span className="nx-term-session">LOCAL / SHELL</span>
        </div>
        <div className="nx-term-header-right">
          <button
            className="nx-term-header-btn clear"
            onClick={() => { xtermInstance.current?.clear(); xtermInstance.current?.focus(); }}
            title="Clear Terminal"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18" /><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
            </svg>
          </button>
          <button
            className="nx-term-header-btn restart"
            disabled={starting}
            onClick={() => restartShellRef.current()}
            title={starting ? 'Starting Shell' : 'Restart Shell'}
            aria-label={starting ? 'Starting Shell' : 'Restart Shell'}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12a9 9 0 1 1-2.64-6.36" /><polyline points="21 3 21 9 15 9" />
            </svg>
          </button>
          <button className="nx-term-header-btn close" onClick={onClose} title="Close Terminal Panel">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>
      <div className="nx-terminal-body" ref={terminalRef} />
    </div>
  );
};
