import {useEffect,useRef,useState} from 'react';
interface Props {initialValue:string;onCancel:()=>void;onSave:(value:string)=>void;}
export function TemplateDialog({initialValue,onCancel,onSave}:Props) {
  const [value,setValue]=useState(initialValue);
  const dialog=useRef<HTMLDivElement>(null);
  useEffect(()=>{const restore=document.activeElement as HTMLElement|null;dialog.current?.querySelector('textarea')?.focus();return ()=>{
    // A palette command can unmount its focused input before this dialog opens.
    const fallback=Array.from(document.querySelectorAll<HTMLButtonElement>('.nx-menu-trigger-btn')).find(button=>button.textContent==='Options');
    if(restore?.isConnected && restore!==document.body)restore.focus();else fallback?.focus();
  };},[]);
  return <div className="nx-template-modal-overlay">
    <div ref={dialog} className="nx-template-modal" role="dialog" aria-modal="true" aria-labelledby="nx-template-heading" aria-describedby="nx-template-description" onKeyDown={event=>{
      if(event.key==='Escape'){event.preventDefault();onCancel();}
      if(event.key==='Tab'){const controls=Array.from(event.currentTarget.querySelectorAll<HTMLElement>('textarea,button'));const first=controls[0],last=controls[controls.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
    }}>
      <div className="nx-template-modal-header"><h2 id="nx-template-heading" className="nx-template-modal-title">C++ FILE TEMPLATE</h2><span className="nx-template-glow-badge">OPTIONS</span></div>
      <p id="nx-template-description" className="nx-template-modal-desc">Default code for new .cpp files. Leave blank to create empty files. Existing files will not change.</p>
      <textarea aria-label="C++ boilerplate" className="nx-template-textarea" value={value} onChange={event=>setValue(event.target.value)} placeholder={'#include <iostream>\nusing namespace std;\n\nint main() {\n    return 0;\n}'} />
      <div className="nx-template-modal-actions"><button className="nx-template-modal-btn cancel" onClick={onCancel}>Cancel</button><button className="nx-template-modal-btn save" onClick={()=>onSave(value)}>Save Boilerplate</button></div>
    </div>
  </div>;
}
