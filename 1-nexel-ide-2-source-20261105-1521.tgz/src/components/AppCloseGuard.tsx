import { useEffect, useRef, useState } from 'react';
import { ConfirmDialog } from './ConfirmDialog';
import { useEditorStore } from '../stores/useEditorStore';

const liveDirtyCount = () => useEditorStore.getState().tabs.filter((t) => t.isDirty).length;

/**
 * Last data-preservation gate: main intercepts every window close (titlebar X,
 * Alt+F4, Cmd+Q) and asks the renderer first. Clean sessions close immediately;
 * dirty sessions confirm here. Save-all routes through the editor's guarded
 * save (conflicts badge and skip, failures keep tabs dirty); the close only
 * proceeds when the live dirty count is zero at completion time, so edits made
 * during the save keep the window open. Subscribes to the store so saving every
 * tab elsewhere while the dialog is open flips it to a safe plain close.
 */
export function AppCloseGuard() {
  const [asked, setAsked] = useState(false);
  const [saving, setSaving] = useState(false);
  const saveTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const requestSequence = useRef(0);
  const pendingSave = useRef<number | null>(null);
  const tabs = useEditorStore((s) => s.tabs);
  const dirty = tabs.filter((t) => t.isDirty).length;

  const clearSaveTimeout = () => { if (saveTimeout.current) { clearTimeout(saveTimeout.current); saveTimeout.current = null; } };

  useEffect(() => {
    const api = window.nexelAPI;
    if (!api?.onAppCloseRequested || !api.confirmAppClose) return;
    api.onAppCloseRequested(() => {
      // Read at event time, never a render-time snapshot: edits made after the
      // dialog appeared must not slip past the confirmation.
      if (liveDirtyCount() === 0) { api.confirmAppClose!(); return; }
      setAsked(true);
    });
  }, []);

  useEffect(() => {
    const onSaveAllDone = (event: Event) => {
      if (pendingSave.current === null || (event as CustomEvent).detail !== pendingSave.current) return;
      pendingSave.current = null;
      clearSaveTimeout();
      setSaving(false);
      // Close only if nothing is dirty NOW: a failed save, a conflict, or an
      // edit made while the save was in flight keeps the window open.
      if (liveDirtyCount() === 0) window.nexelAPI?.confirmAppClose?.();
    };
    window.addEventListener('nexel:save-all-done', onSaveAllDone);
    return () => { pendingSave.current = null; clearSaveTimeout(); window.removeEventListener('nexel:save-all-done', onSaveAllDone); };
  }, []);

  if (!asked) return null;
  const saved = dirty === 0;
  // Deleted-file (orphaned) tabs are excluded from the editor's save-all, so
  // Save all cannot clear them. Name them so the count is never a mystery.
  const orphanNames = tabs.filter((t) => t.isDirty && t.isOrphaned).map((t) => t.name);
  return (
    <ConfirmDialog
      title="Close window?"
      message={saved
        ? 'All changes are now saved. Closing will not lose any edits.'
        : `${dirty} tab${dirty === 1 ? ' has' : 's have'} unsaved changes. Closing the window discards them - unsaved text is not restored after closing.${
            orphanNames.length
              ? ` ${orphanNames.join(', ')} ${orphanNames.length === 1 ? 'was' : 'were'} deleted from disk, so Save all cannot save ${orphanNames.length === 1 ? 'it' : 'them'} - discard or cancel to keep editing.`
              : ''}`}
      saveLabel={saved ? undefined : 'Save all'}
      saving={saving}
      discardDisabled={saving}
      cancelLabel={saving ? 'Keep open' : 'Cancel'}
      pendingMessage="Saving has already started. Keeping the window open does not stop the save."
      discardLabel={saved ? 'Close' : 'Discard and close'}
      defaultFocus="cancel"
      onSave={() => {
        if (pendingSave.current !== null) return; // repeated clicks while a save is in flight are no-ops
        setSaving(true);
        const request = ++requestSequence.current;
        pendingSave.current = request;
        clearSaveTimeout();
        // Safety net: if no save-all-done ever arrives (handler absent or
        // wedged), re-enable the button. It only unlocks the dialog - it never
        // closes the window, which still requires a live dirty count of zero.
        saveTimeout.current = setTimeout(() => { if (pendingSave.current === request) { pendingSave.current = null; setSaving(false); } }, 10000);
        window.dispatchEvent(new CustomEvent('nexel:save-all', { detail: request }));
      }}
      onDiscard={() => { if (pendingSave.current !== null) return; window.nexelAPI?.confirmAppClose?.(); }}
      onCancel={() => { pendingSave.current = null; clearSaveTimeout(); setSaving(false); setAsked(false); }}
    />
  );
}
