import { useEffect, useId, useMemo, useRef, useState } from 'react';
import './CommandPalette.css';

export interface PaletteCommand { id: string; label: string; hint?: string; detail?: string; run: () => void; }

/** Progressive rendering chunk: quick open on a multi-thousand-file workspace
    must not mount one row per file up front. The full result list stays
    navigable - scrolling near the end, arrowing past the rendered tail, or
    Ctrl+End grows the rendered window in chunks. */
export const PALETTE_CHUNK = 100;

/** Subsequence fuzzy score: lower is better, -1 = no match. Rewards consecutive and early hits. */
export function fuzzyScore(query: string, text: string): number {
  const q = query.toLowerCase(), t = text.toLowerCase();
  let ti = 0, score = 0, last = -1;
  for (const ch of q) {
    const i = t.indexOf(ch, ti);
    if (i < 0) return -1;
    score += i - (last + 1) + (i === 0 ? 0 : 1);
    last = i + ch.length - 1; ti = i + ch.length;
  }
  return score;
}

export function highlight(q: string, text: string) {
  if (!q) return text;
  const t = text.toLowerCase();
  // Lowercasing can expand a source character (İ -> i + combining dot), so
  // folded indices are not source UTF-16 offsets. Keep each folded unit bound
  // to its whole original code point, then merge repeated/adjacent hits.
  const offsets: Array<{ start: number; end: number }> = [];
  let source = 0;
  for (const ch of text) {
    for (let n = 0; n < ch.toLowerCase().length; n++) offsets.push({ start: source, end: source + ch.length });
    source += ch.length;
  }
  const spans: Array<{ start: number; end: number }> = [];
  let ti = 0;
  for (const ch of q.toLowerCase()) {
    const i = t.indexOf(ch, ti); if (i < 0) break;
    const start = offsets[i]?.start, end = offsets[i + ch.length - 1]?.end;
    if (start !== undefined && end !== undefined) {
      const last = spans[spans.length - 1];
      if (last && start <= last.end) last.end = Math.max(last.end, end);
      else spans.push({ start, end });
    }
    ti = i + ch.length;
  }
  const out: React.ReactNode[] = []; let cursor = 0;
  for (const span of spans) {
    out.push(text.slice(cursor, span.start));
    out.push(<mark key={span.start} className="cp-mark">{text.slice(span.start, span.end)}</mark>);
    cursor = span.end;
  }
  out.push(text.slice(cursor)); return out;
}

export function CommandPalette({ commands, onClose, placeholder = 'Type a command…', label = 'Command palette' }: { commands: PaletteCommand[]; onClose: () => void; placeholder?: string; label?: string }) {
  const listId = useId();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  const executed = useRef(false);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { const prior = document.activeElement as HTMLElement | null; inputRef.current?.focus(); return () => { if (!executed.current && prior?.isConnected) prior.focus(); }; }, []);
  const results = useMemo(() => {
    if (!q) return commands;
    return commands.map(c => ({ c, s: fuzzyScore(q, c.detail ? `${c.label} ${c.detail}` : c.label) })).filter(x => x.s >= 0).sort((a, b) => a.s - b.s).map(x => x.c);
  }, [q, commands]);
  // Progressive rendering window over the FULL navigable list.
  const [limit, setLimit] = useState(PALETTE_CHUNK);
  const rendered = results.slice(0, limit);
  const grow = (upto?: number) => setLimit(l => Math.min(results.length, Math.max(l + PALETTE_CHUNK, (upto ?? 0) + 1)));
  useEffect(() => { document.getElementById(`${listId}-${sel}`)?.scrollIntoView?.({block:'nearest'}); }, [sel, q, listId, limit]);
  const selected = Math.min(sel, Math.max(0, results.length - 1));
  useEffect(() => { if (sel !== selected) setSel(selected); }, [sel, selected]);
  const exec = (c?: PaletteCommand) => { if (c && !executed.current) { executed.current = true; onClose(); c.run(); } };
  return (
    <div className="cp-backdrop" onMouseDown={onClose}>
      <div className="cp-box" role="dialog" aria-label={label} aria-modal="true" onMouseDown={e => e.stopPropagation()}>
        <header className="cp-heading">{label}<span>ESC</span></header>
        <input ref={inputRef} role="combobox" aria-label={label} aria-autocomplete="list" aria-expanded="true" aria-controls={listId} aria-activedescendant={results[selected] ? `${listId}-${selected}` : undefined} className="cp-input" placeholder={placeholder} value={q}
          onChange={e => { setQ(e.target.value); setSel(0); setLimit(PALETTE_CHUNK); }}
          onKeyDown={e => {
            if (e.nativeEvent.isComposing || e.keyCode === 229) return;
            if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); onClose(); }
            else if (e.key === 'Tab') { e.preventDefault(); }
            else if (e.key === 'Home' && e.ctrlKey) { e.preventDefault(); setSel(0); }
            else if (e.key === 'End' && e.ctrlKey) { e.preventDefault(); setLimit(results.length); setSel(Math.max(0,results.length-1)); }
            else if (e.key === 'ArrowDown') { e.preventDefault(); const next = Math.min(selected + 1, results.length - 1); if (next >= limit - 1) grow(next); setSel(next); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); setSel(s => Math.max(s - 1, 0)); }
            else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); exec(results[selected]); }
          }} />
        <div className="cp-list" role="listbox" id={listId} aria-label="Results" onScroll={e => { const el = e.currentTarget; if (el.scrollHeight > el.clientHeight && el.scrollTop + el.clientHeight >= el.scrollHeight - 120) grow(); }}>
          {results.length === 0 && <div className="cp-empty">No matches</div>}
          {rendered.map((c, i) => (
            <div key={c.id} role="option" id={`${listId}-${i}`} aria-selected={i === selected} aria-label={c.detail ? `${c.label}, ${c.detail}` : undefined} title={c.detail} className={'cp-item' + (i === selected ? ' active' : '')}
              style={{ animationDelay: `${Math.min(i, 8) * 18}ms` }}
              onMouseMove={() => setSel(i)} onClick={() => exec(c)}>
              <span className="cp-result-identity"><span>{highlight(q, c.label)}</span>{c.detail && <small>{c.detail}</small>}</span>{c.hint && <kbd>{c.hint}</kbd>}
            </div>
          ))}
        </div>
        <div className="cp-foot"><span><kbd>↑↓</kbd> navigate</span><span><kbd>↵</kbd> run</span><span><kbd>esc</kbd> close</span><span className="cp-count">{results.length > rendered.length ? `Showing ${rendered.length} of ${results.length}` : `${results.length} ${results.length===1?"result":"results"}`}</span></div>
      </div>
    </div>
  );
}
