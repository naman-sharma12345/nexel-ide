import { useEffect, useRef, useState } from 'react';
import { shortcutGroupsFor, keyLabel } from '../lib/shortcuts';
import { useSettingsStore } from '../stores/useSettingsStore';
import { pluginEnabledById } from '../plugins/registry';
import './ShortcutsSheet.css';

/** Cheat-sheet overlay. Keycaps physically "press" when you hit the matching key while it is open. */
export function ShortcutsSheet({ onClose }: { onClose: () => void }) {
  const [down, setDown] = useState<Set<string>>(new Set());
  const boxRef = useRef<HTMLDivElement>(null);
  const cpOn = useSettingsStore(s => pluginEnabledById('competitive-programming', s.plugins));
  // A modal must hold the keyboard: without focus here, keys fall through to whatever had
  // focus before (e.g. the terminal shell) while the sheet is up.
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    boxRef.current?.querySelector<HTMLButtonElement>('button')?.focus({ preventScroll: true });
    return () => {
      const fallback=Array.from(document.querySelectorAll<HTMLButtonElement>('.nx-menu-trigger-btn')).find(button=>button.textContent==='Help');
      if(previous?.isConnected && previous!==document.body) previous.focus({preventScroll:true});
      else fallback?.focus({preventScroll:true});
    };
  }, []);
  useEffect(() => {
    const kd = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); onClose(); return; }
      if (e.key === 'Tab') {
        const controls=Array.from(boxRef.current?.querySelectorAll<HTMLElement>('button,[tabindex="0"]')??[]);
        const first=controls[0],last=controls.at(-1);
        if(e.shiftKey && (document.activeElement===first || !boxRef.current?.contains(document.activeElement))){e.preventDefault();last?.focus();}
        else if(!e.shiftKey && (document.activeElement===last || !boxRef.current?.contains(document.activeElement))){e.preventDefault();first?.focus();}
        return;
      }
      if (e.ctrlKey || e.metaKey || e.altKey) { e.preventDefault(); e.stopPropagation(); }
      setDown(s => new Set(s).add(keyLabel(e)));
    };
    const ku = (e: KeyboardEvent) => setDown(s => { const n = new Set(s); n.delete(keyLabel(e)); return n; });
    window.addEventListener('keydown', kd, true); window.addEventListener('keyup', ku);
    return () => { window.removeEventListener('keydown', kd, true); window.removeEventListener('keyup', ku); };
  }, [onClose]);
  const groups = shortcutGroupsFor(cpOn);
  return (
    <div className="ss-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="ss-box" role="dialog" aria-modal="true" aria-label="Keyboard shortcuts" tabIndex={-1} ref={boxRef}>
        <header className="ss-head"><div><span>REFERENCE</span><h2>Keyboard shortcuts</h2></div><button type="button" aria-label="Close keyboard shortcuts" onClick={onClose}>Esc</button></header>
        <div className="ss-grid" role="region" aria-label="Shortcut reference" tabIndex={0}>
          {groups.map((g, gi) => (
            <section key={g.title} className="ss-group" style={{ animationDelay: `${120 + gi * 70}ms` }}>
              <h3>{g.title}</h3>
              {g.items.map(it => (
                <div key={it.label} className="ss-row">
                  <span>{it.label}</span>
                  <span className="ss-keys">{it.keys.map((k, i) => <kbd key={i} className={down.has(k) ? 'down' : ''}>{k}</kbd>)}</span>
                </div>
              ))}
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
