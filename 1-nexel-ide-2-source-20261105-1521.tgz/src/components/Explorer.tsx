import React, { useState, useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import './Explorer.css';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { ExplorerContextMenu } from './ExplorerContextMenu';
import { createTreeNameMatcher } from '../lib/treeNameMatcher';
import { useRegexNameMatches } from '../lib/useRegexNameMatches';
import { reserveFileMove } from '../lib/moveDocumentGuard';
import { useStatusStore } from '../stores/useStatusStore';
import { ConfirmDialog } from './ConfirmDialog';
import type { FileNode } from '../stores/useWorkspaceStore';

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
  node: FileNode | null;
}

interface ExplorerProps {
  onFileSelect?: (filePath: string, isDoubleClicked?: boolean) => void;
  activeFilePath?: string | null;
}

/** Active file and clicked (selected) node are different states: only one row may look active. */
export function explorerRowState(activePath: string | null | undefined, selectedPath: string | null, nodePath: string): 'active' | 'selected' | 'none' {
  if (activePath && activePath === nodePath) return 'active';
  if (selectedPath && selectedPath === nodePath) return 'selected';
  return 'none';
}

export interface FlatVisibleNode { node: FileNode; parent: FileNode | null; }

/** Visible rows in render order: a folder's children appear only while it is open. */
export function flattenVisibleNodes(nodes: FileNode[], parent: FileNode | null = null): FlatVisibleNode[] {
  const out: FlatVisibleNode[] = [];
  for (const n of nodes) {
    out.push({ node: n, parent });
    if (n.type === 'folder' && n.isOpen && n.children) {
      out.push(...flattenVisibleNodes(n.children, n));
    }
  }
  return out;
}

export const Explorer: React.FC<ExplorerProps> = ({ onFileSelect, activeFilePath }) => {
  const {
    rootPath,
    rootName,
    tree,
    isTreeLoading,
    treeError,
    pinnedPaths,
    searchQuery,
    isRegex,
    isMatchCase,
    lastSelectedNode,
    inlineInput,
    togglePin,
    setSearchQuery,
    setRegex,
    setMatchCase,
    setLastSelectedNode,
    setInlineInput,
    openWorkspaceDir,
    refreshTree,
    toggleFolder,
    collapseAllFolders,
    triggerHeaderNewFile,
    triggerHeaderNewFolder,
    handleDeleteNode,
    handleInlineSubmit,
    pendingDelete,
    confirmDeleteNode,
    cancelDeleteNode,
  } = useWorkspaceStore();

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<ContextMenuState>({
    visible: false,
    x: 0,
    y: 0,
    node: null
  });

  const inlineGeneration = useRef(0);
  useEffect(() => () => { inlineGeneration.current++; }, [rootPath]);
  const copyGeneration = useRef(0);
  useEffect(() => () => { copyGeneration.current++; }, [rootPath]);
  const inputRef = useRef<HTMLInputElement>(null);
  const inlineComposing = useRef(false);
  const [pendingInput, setPendingInput] = useState<typeof inlineInput | null>(null);
  const inlineBusy = pendingInput === inlineInput;
  const pendingInputRef = useRef<typeof inlineInput | null>(null);
  const inlineKeyboardProps = {
    onCompositionStart: () => { inlineComposing.current = true; },
    onCompositionEnd: () => { inlineComposing.current = false; },
    readOnly: inlineBusy,
    'aria-busy': inlineBusy,
    onBlur: () => { if (pendingInputRef.current !== useWorkspaceStore.getState().inlineInput) setInlineInput({visible:false}); },
    onKeyDown: (event: React.KeyboardEvent<HTMLInputElement>) => {
      if (pendingInputRef.current === useWorkspaceStore.getState().inlineInput && ['Escape','Enter'].includes(event.key)) {
        event.preventDefault(); event.stopPropagation(); return;
      }
      if (inlineComposing.current || event.nativeEvent.isComposing || event.keyCode === 229) {
        if (event.key === 'Enter' || event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); }
        return;
      }
      if (event.key === 'Escape') {
        event.preventDefault(); setInlineInput({visible:false}); treeScrollRef.current?.focus();
      }
    },
  };
  useEffect(() => { inlineComposing.current = false; }, [inlineInput]);
  const treeScrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const tree = treeScrollRef.current;
    if (!tree || typeof ResizeObserver === 'undefined') return;
    let frame = 0;
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const input = inputRef.current;
        if (input && document.activeElement === input && tree.contains(input)) input.scrollIntoView({block:'nearest'});
      });
    });
    observer.observe(tree);
    return () => { observer.disconnect(); cancelAnimationFrame(frame); };
  }, []);
  const shelfRef = useRef<HTMLDivElement>(null);
  const removedPinFocus = useRef<{index:number; element:HTMLElement; action:string} | null>(null);
  useEffect(() => useWorkspaceStore.subscribe(state => {
    const active = document.activeElement as HTMLElement | null;
    if (!active || !shelfRef.current?.contains(active)) return;
    const row = active.closest<HTMLElement>('[data-pin-path]');
    if (!row || state.pinnedPaths.includes(row.dataset.pinPath!)) return;
    const rows = [...shelfRef.current.querySelectorAll('[data-pin-path]')];
    removedPinFocus.current = {index:rows.indexOf(row), element:active, action:active.classList.contains('nx-shelf-unpin-btn') ? '.nx-shelf-unpin-btn' : '.nx-shelf-open'};
  }), []);
  useLayoutEffect(() => {
    const pending = removedPinFocus.current;
    removedPinFocus.current = null;
    if (!pending || (document.activeElement !== document.body && document.activeElement !== pending.element)) return;
    const actions = shelfRef.current?.querySelectorAll<HTMLButtonElement>(pending.action);
    const next = actions?.[Math.min(pending.index, actions.length - 1)] ?? treeScrollRef.current;
    next?.focus();
    next?.scrollIntoView({block:'nearest'});
  }, [pinnedPaths]);

  // Load initial workspace tree if rootPath is restored by Zustand
  useEffect(() => {
    if (rootPath && useWorkspaceStore.getState().tree.length === 0 && !useWorkspaceStore.getState().isTreeLoading) {
      refreshTree();
    }
  }, [rootPath, refreshTree]);

  useEffect(() => { setContextMenu(prev => ({ ...prev, visible: false })); }, [rootPath]);

  // External file changes (terminal, another editor) do not reach the tree on
  // their own - refresh on window focus. refreshTree has its own version/root
  // stale guards; debounce collapses focus bursts.
  useEffect(() => {
    if (!rootPath) return;
    let t: ReturnType<typeof setTimeout> | null = null;
    const onFocus = () => {
      if (t) clearTimeout(t);
      t = setTimeout(() => { t = null; void refreshTree(); }, 300);
    };
    window.addEventListener('focus', onFocus);
    return () => { window.removeEventListener('focus', onFocus); if (t) clearTimeout(t); };
  }, [rootPath, refreshTree]);

  // Autofocus inline input and select text
  useEffect(() => {
    if (inlineInput.visible && inputRef.current) {
      inputRef.current.focus();
      if (inlineInput.mode === 'rename') {
        const dotIndex = inlineInput.defaultValue.lastIndexOf('.');
        if (dotIndex > 0 && inlineInput.mode === 'rename') {
          inputRef.current.setSelectionRange(0, dotIndex);
        } else {
          inputRef.current.select();
        }
      } else {
        inputRef.current.select();
      }
    }
  }, [inlineInput.visible, inlineInput.mode, inlineInput.defaultValue]);

  // Drag and Drop implementation
  const handleDragStart = (e: React.DragEvent, node: FileNode) => {
    e.dataTransfer.setData('text/plain', node.path);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, node: FileNode) => {
    if (node.type === 'folder') {
      e.preventDefault(); // Allows drop
      e.currentTarget.classList.add('nx-drag-over');
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.currentTarget.classList.remove('nx-drag-over');
  };

  const handleDrop = async (e: React.DragEvent, targetNode: FileNode) => {
    e.preventDefault();
    e.currentTarget.classList.remove('nx-drag-over');
    
    const sourcePath = e.dataTransfer.getData('text/plain');
    if (!sourcePath || sourcePath === targetNode.path) return;

    const normalizedSource = sourcePath.replace(/\\/g, '/').replace(/\/+$/, '');
    const targetPath = targetNode.path.replace(/\\/g, '/').replace(/\/+$/, '');
    const sourceName = normalizedSource.split('/').pop() || '';
    if (!sourceName || normalizedSource === targetPath || targetPath.startsWith(normalizedSource + '/')) return;
    const newPath = `${targetPath}/${sourceName}`;
    if (newPath === normalizedSource) return;

    const workspaceAtDrop=useWorkspaceStore.getState().rootPath;
    try {
      const release = await reserveFileMove(sourcePath,()=>useWorkspaceStore.getState().rootPath===workspaceAtDrop);
      try { await window.nexelAPI.renameNode(sourcePath, newPath); } finally { release(); }
      useWorkspaceStore.getState().relocatePinnedPaths(sourcePath, newPath, workspaceAtDrop);
      // Keep selection, creation directory and expanded descendants on the moved item, and open the destination so the move is visible.
      useWorkspaceStore.getState().relocateTreePaths(sourcePath, newPath, workspaceAtDrop);
      if (useWorkspaceStore.getState().rootPath === workspaceAtDrop) await refreshTree(new Set([targetPath]));
    } catch (err) {
      console.error("Drop relocate operation failed:", err);
      const reason = err instanceof Error ? err.message : String(err);
      useStatusStore.getState().pushToast(/\bEEXIST\b/.test(reason) ? `Could not move ${sourceName}: that name already exists. Existing content was not changed.` : `Could not move ${sourceName}${reason ? `: ${reason}` : '.'}`, 'error', 6000);
    }
  };

  // Context Menu Actions
  const handleContextMenu = (e: React.MouseEvent, node: FileNode) => {
    e.preventDefault();
    e.stopPropagation();
    
    // ExplorerContextMenu measures itself pre-paint and clamps both axes;
    // pass the raw cursor position so a bottom-edge menu lands flush with the
    // viewport edge instead of floating a guessed height above the cursor.
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      node
    });
  };

  const handleEmptyAreaContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!rootPath) return;

    // Same raw-position handoff as handleContextMenu; the menu self-clamps.

    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      node: { name: rootName, path: rootPath, type: 'folder' }
    });
  };

  const triggerNewFile = (parentFolder: FileNode) => {
    useWorkspaceStore.getState().revealPath(parentFolder.path);
    setContextMenu(prev => ({ ...prev, visible: false }));
    setInlineInput({
      visible: true,
      nodePath: parentFolder.path,
      mode: 'new-file',
      defaultValue: 'untitled.txt'
    });
  };

  const triggerNewFolder = (parentFolder: FileNode) => {
    useWorkspaceStore.getState().revealPath(parentFolder.path);
    setContextMenu(prev => ({ ...prev, visible: false }));
    setInlineInput({
      visible: true,
      nodePath: parentFolder.path,
      mode: 'new-folder',
      defaultValue: 'NewFolder'
    });
  };

  const triggerRename = (node: FileNode) => {
    setContextMenu(prev => ({ ...prev, visible: false }));
    setInlineInput({
      visible: true,
      nodePath: node.path,
      mode: 'rename',
      defaultValue: node.name
    });
  };

  const handleInlineSubmitWrapper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inlineComposing.current || pendingInputRef.current === inlineInput) return;
    const value = inputRef.current?.value.trim();
    if (!value) {
      setInlineInput({ visible: false });
      return;
    }
    const generation = inlineGeneration.current;
    const input = inlineInput;
    pendingInputRef.current = input; setPendingInput(input);
    let createdPath: string | null = null;
    try { createdPath = await handleInlineSubmit(value); }
    finally { if (pendingInputRef.current === input) { pendingInputRef.current = null; if (generation === inlineGeneration.current) setPendingInput(null); } }
    if (generation !== inlineGeneration.current) return;
    if (document.activeElement === document.body && !useWorkspaceStore.getState().inlineInput.visible) treeScrollRef.current?.focus();
    if (createdPath && onFileSelect) {
      onFileSelect(createdPath, true);
    }
  };

  const nameMatcher = useMemo(() => createTreeNameMatcher(searchQuery, isRegex, isMatchCase), [searchQuery, isRegex, isMatchCase]);
  const visibleNames = useMemo(() => (isRegex && searchQuery ? Array.from(new Set(flattenVisibleNodes(tree).map(({ node }) => node.name))) : []), [tree, isRegex, searchQuery]);
  const regexMatches = useRegexNameMatches(visibleNames, searchQuery, isMatchCase ? '' : 'i', isRegex && Boolean(searchQuery) && !nameMatcher.error);
  const searchError = nameMatcher.error ?? (isRegex ? regexMatches.error : null);

  // Renders the muted/accented extension beautifully
  const renderLabelWithHighlights = (name: string, isSelected: boolean) => {
    if (searchQuery) {
      const isMatch = isRegex ? regexMatches.matched.has(name) : nameMatcher.test(name);

      if (isMatch) {
        return <span className="nx-node-text nx-search-match">{name}</span>;
      }
    }

    const dotIndex = name.lastIndexOf('.');
    if (dotIndex === -1 || name.startsWith('.')) {
      return <span className="nx-node-text">{name}</span>;
    }
    const baseName = name.substring(0, dotIndex);
    const nameEnd = baseName.length > 22 ? baseName.slice(-10) : '';
    const nameStart = nameEnd ? baseName.slice(0, -10) : baseName;
    const extension = name.substring(dotIndex);
    return (
      <span className="nx-node-text">
        <span className="nx-file-name-start">{nameStart}</span>{nameEnd && <span className="nx-file-name-end">{nameEnd}</span>}
        <span className={`nx-file-ext ${isSelected ? 'active' : ''}`}>{extension}</span>
      </span>
    );
  };

  const scrollRowIntoView = (path: string) => {
    requestAnimationFrame(() => {
      treeScrollRef.current?.querySelector(`[data-path="${CSS.escape(path)}"]`)?.scrollIntoView({ block: 'nearest' });
    });
  };

  // VS Code-style tree keyboard navigation on the focused tree panel.
  const handleTreeKeyDown = (e: React.KeyboardEvent) => {
    if (inlineInput.visible || e.nativeEvent.isComposing || e.keyCode === 229 || e.ctrlKey || e.metaKey || e.altKey) return;
    if ((e.target as HTMLElement).closest('input,button')) return;
    const flat = flattenVisibleNodes(tree);
    if (e.key === 'ContextMenu' || (e.key === 'F10' && e.shiftKey)) {
      e.preventDefault();
      const node = lastSelectedNode ?? (rootPath ? {name:rootName,path:rootPath,type:'folder' as const} : null);
      if (node) {
        const row = treeScrollRef.current?.querySelector(`[data-path="${CSS.escape(node.path)}"]`);
        const rect = (row ?? treeScrollRef.current)?.getBoundingClientRect();
        setContextMenu({visible:true,node,x:rect?.left ?? 80,y:rect?.bottom ?? 120});
      }
      return;
    }
    if (!flat.length) return;
    const idx = flat.findIndex(f => f.node.path === lastSelectedNode?.path);

    if (e.key === 'Home' || e.key === 'End') {
      e.preventDefault();
      const node = flat[e.key === 'Home' ? 0 : flat.length - 1].node;
      setLastSelectedNode(node);
      scrollRowIntoView(node.path);
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      let targetIdx: number;
      if (idx === -1) targetIdx = e.key === 'ArrowDown' ? 0 : flat.length - 1;
      else targetIdx = e.key === 'ArrowDown' ? Math.min(idx + 1, flat.length - 1) : Math.max(idx - 1, 0);
      setLastSelectedNode(flat[targetIdx].node);
      scrollRowIntoView(flat[targetIdx].node.path);
    } else if (e.key === 'ArrowRight' && idx >= 0) {
      e.preventDefault();
      const { node } = flat[idx];
      if (node.type === 'folder') {
        if (!node.isOpen) toggleFolder(node.path);
        else if (node.children && node.children.length) {
          setLastSelectedNode(node.children[0]);
          scrollRowIntoView(node.children[0].path);
        }
      }
    } else if (e.key === 'ArrowLeft' && idx >= 0) {
      e.preventDefault();
      const { node, parent } = flat[idx];
      if (node.type === 'folder' && node.isOpen) toggleFolder(node.path);
      else if (parent) {
        setLastSelectedNode(parent);
        scrollRowIntoView(parent.path);
      }
    } else if (e.key === 'Enter' && idx >= 0) {
      e.preventDefault();
      const { node } = flat[idx];
      if (node.type === 'folder') toggleFolder(node.path);
      else if (onFileSelect) onFileSelect(node.path, true);
    } else if (e.key === 'F2' && idx >= 0) {
      e.preventDefault();
      triggerRename(flat[idx].node);
    } else if (e.key === 'Delete' && idx >= 0) {
      e.preventDefault();
      handleDeleteNode(flat[idx].node);
    }
  };

  // Tree recursive rendering
  const renderTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map((node, index) => {
      const rowState = explorerRowState(activeFilePath, lastSelectedNode?.path ?? null, node.path);
      const isFolder = node.type === 'folder';

      // Inline editing element placement
      const isInlineEditingThisNode = inlineInput.visible && inlineInput.nodePath === node.path && inlineInput.mode === 'rename';
      const showInlineCreationHere = inlineInput.visible && inlineInput.nodePath === node.path && (inlineInput.mode === 'new-file' || inlineInput.mode === 'new-folder');

      return (
        <div key={`${node.path}-${index}`} className="nx-node-block">
          {isInlineEditingThisNode ? (
            <form onSubmit={handleInlineSubmitWrapper} className="nx-inline-input-form" aria-busy={inlineBusy} style={{ paddingLeft: `${depth * 14 + 18}px` }}>
              <div className="nx-inline-input-wrapper">
                <span className="nx-inline-icon-indicator">
                  {node.type === 'folder' ? (
                    <svg className="nx-svg-icon folder open" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                    </svg>
                  ) : (
                    <svg className="nx-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                      <polyline points="13 2 13 9 20 9"></polyline>
                    </svg>
                  )}
                </span>
                <input
                  ref={inputRef}
                  aria-label={inlineInput.mode === 'rename' ? `Rename ${inlineInput.defaultValue}` : inlineInput.mode === 'new-folder' ? 'New folder name' : 'New file name'}
                  type="text"
                  defaultValue={inlineInput.defaultValue}
                  {...inlineKeyboardProps}
                  className="nx-inline-textbox"
                />
                {inlineBusy && <span className="nx-inline-progress" role="status">Working...</span>}
              </div>
            </form>
          ) : (
            <div 
              className={`nx-node-row ${rowState === 'active' ? 'nx-row-selected' : rowState === 'selected' ? 'nx-row-focused' : ''}`}
              title={node.path}
              role="treeitem"
              id={`nx-tree-${encodeURIComponent(node.path)}`}
              aria-label={node.name}
              aria-level={depth + 1}
              aria-expanded={isFolder ? !!node.isOpen : undefined}
              aria-selected={(lastSelectedNode?.path || activeFilePath) === node.path}
              data-path={node.path}
              data-ext={!isFolder && node.name.includes('.') ? node.name.split('.').pop()!.toLowerCase() : undefined}
              style={{ paddingLeft: `${depth * 14 + 18}px` }}
              draggable
              onDragStart={(e) => handleDragStart(e, node)}
              onDragOver={(e) => handleDragOver(e, node)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, node)}
              onContextMenu={(e) => handleContextMenu(e, node)}
              onClick={(e) => {
                e.stopPropagation();
                treeScrollRef.current?.focus();
                setLastSelectedNode(node);
                if (isFolder) {
                  toggleFolder(node.path);
                } else {
                  if (onFileSelect) onFileSelect(node.path, false);
                }
              }}
              onDoubleClick={(e) => {
                e.stopPropagation();
                treeScrollRef.current?.focus();
                setLastSelectedNode(node);
                if (!isFolder && onFileSelect) {
                  onFileSelect(node.path, true);
                }
              }}
            >
              {isFolder ? (
                <span className={`nx-chevron ${node.isOpen ? 'open' : ''}`}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 5l7 7-7 7"/></svg>
                </span>
              ) : (
                <span className="nx-chevron-spacer" />
              )}

              <span className="nx-icon-frame">
                {isFolder ? (
                  <svg className={`nx-svg-icon folder ${node.isOpen ? 'open' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                  </svg>
                ) : (
                  <svg className="nx-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                    <polyline points="13 2 13 9 20 9"></polyline>
                  </svg>
                )}
              </span>

              {renderLabelWithHighlights(node.name, rowState !== 'none')}

              {/* Hover quick shortcut overlay */}
              <div className="nx-row-actions">
                {isFolder && (
                  <button className="nx-row-act-btn" title="New File" onClick={(e) => { e.stopPropagation(); triggerNewFile(node); }}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
                  </button>
                )}
                <button className="nx-row-act-btn delete" title="Delete" onClick={(e) => { e.stopPropagation(); handleDeleteNode(node); }}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                </button>
              </div>
            </div>
          )}

          {/* Inline creation field inside matching folder tree */}
          {showInlineCreationHere && (
            <div style={{ paddingLeft: `${(depth + 1) * 14 + 18}px` }}>
              <form onSubmit={handleInlineSubmitWrapper} className="nx-inline-input-form" aria-busy={inlineBusy}>
                <div className="nx-inline-input-wrapper">
                  <span className="nx-inline-icon-indicator">
                    {inlineInput.mode === 'new-folder' ? (
                      <svg className="nx-svg-icon folder open" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                      </svg>
                    ) : (
                      <svg className="nx-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                        <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                        <polyline points="13 2 13 9 20 9"></polyline>
                      </svg>
                    )}
                  </span>
                  <input
                    ref={inputRef}
                    aria-label={inlineInput.mode === 'new-folder' ? 'New folder name' : 'New file name'}
                    type="text"
                    defaultValue={inlineInput.defaultValue}
                    {...inlineKeyboardProps}
                    className="nx-inline-textbox"
                  />
                  {inlineBusy && <span className="nx-inline-progress" role="status">Working...</span>}
                </div>
              </form>
            </div>
          )}

          {isFolder && node.isOpen && node.children && (
            <div className="nx-nested-children" role="group">
              {renderTree(node.children, depth + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="nx-explorer-wrapper">
      <div className="nx-explorer-header">
        <span className="nx-explorer-kicker">WORKSPACE / FILES</span>
        <button className="nx-explorer-title" onClick={openWorkspaceDir} title={rootPath || "Open a workspace folder"} aria-label={rootPath ? `Switch workspace from ${rootName}` : "Open a workspace folder"}>
          {rootName}
        </button>
        
        <div className="nx-action-bar">
          <button 
            className="nx-action-btn" 
            title="New File" 
            onClick={triggerHeaderNewFile}
            disabled={!rootPath}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
          </button>
          <button 
            className="nx-action-btn" 
            title="New Folder" 
            onClick={triggerHeaderNewFolder}
            disabled={!rootPath}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path><line x1="12" y1="11" x2="12" y2="17"></line><line x1="9" y1="14" x2="15" y2="14"></line></svg>
          </button>
          <button className="nx-action-btn" title="Refresh Tree" onClick={() => refreshTree()} disabled={!rootPath || isTreeLoading}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
          </button>
          <button className="nx-action-btn" title="Collapse All Folders" onClick={collapseAllFolders} disabled={tree.length === 0}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="20" rx="2.5"></rect><line x1="7" y1="12" x2="17" y2="12"></line></svg>
          </button>
        </div>
      </div>

      <div id="nx-document-index" className="nx-document-index-slot" />

      {/* Real-time Workspace Search/Filter belt */}
      {rootPath && (
        <div className="nx-search-belt">
          <div className="nx-search-input-frame">
            <input 
              type="text" 
              placeholder="Find in tree"
              aria-label="Highlight matching file names"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="nx-search-textbox"
              aria-invalid={searchError ? true : undefined}
              aria-describedby={searchError ? 'nx-search-error' : undefined}
            />
            <div className="nx-search-toggles">
              <button 
                className={`nx-search-tog-btn ${isMatchCase ? 'active' : ''}`}
                title="Match Case"
                aria-pressed={isMatchCase}
                onClick={() => setMatchCase(!isMatchCase)}
              >
                Aa
              </button>
              <button 
                className={`nx-search-tog-btn ${isRegex ? 'active' : ''}`}
                title="Use Regular Expression"
                aria-pressed={isRegex}
                onClick={() => setRegex(!isRegex)}
              >
                .*
              </button>
            </div>
          </div>
          {searchError && (
            <div id="nx-search-error" className="nx-search-error" role="status" title={searchError}>
              {nameMatcher.error ? 'Invalid pattern: ' : 'Pattern stopped: '}{searchError}
            </div>
          )}
        </div>
      )}

      {/* Sleek Bookmarks/Pinned shelf */}
      {pinnedPaths.length > 0 && (
        <div className="nx-pinned-shelf">
          <div className="nx-shelf-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
            PINNED WORKSPACE FILES
          </div>
          <div className="nx-shelf-items" ref={shelfRef} role="region" aria-label="Pinned workspace files">
            {pinnedPaths.map((pathStr) => {
              const nameStr = pathStr.split(/[\\/]/).pop() || '';
              const parents = pathStr.replace(/\\/g,'/').split('/').slice(0,-1).filter(Boolean);
              const siblings = pinnedPaths.filter(path => path !== pathStr && path.split(/[\\/]/).pop() === nameStr).map(path => path.replace(/\\/g,'/').split('/').slice(0,-1).filter(Boolean));
              let depth = 1;
              while(depth < parents.length && siblings.some(parts => parts.slice(-depth).join('/') === parents.slice(-depth).join('/'))) depth++;
              const parentLabel = siblings.length ? parents.slice(-depth).join('/') || 'root' : '';

              return (
                <div 
                  key={pathStr}
                  data-pin-path={pathStr}
                  className={`nx-shelf-item ${activeFilePath === pathStr ? 'active' : ''}`}
                  role="group"
                  aria-label={`Pinned file: ${pathStr}`}
                >
                  <span className="nx-shelf-icon-frame">
                    <svg className="nx-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                      <polyline points="13 2 13 9 20 9"></polyline>
                    </svg>
                  </span>
                  <button type="button" className="nx-shelf-open" title={pathStr} aria-label={`Open pinned file: ${pathStr}`} onClick={() => onFileSelect?.(pathStr, false)}><span className="nx-shelf-text">{nameStr}</span>{parentLabel && <span className="nx-shelf-parent">{parentLabel}</span>}</button>
                  <button 
                    className="nx-shelf-unpin-btn" 
                    title="Unpin File"
                    aria-label={`Unpin file: ${pathStr}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      togglePin(pathStr);
                    }}
                  >
                    ×
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Main tree list scroll panel */}
      <div 
        className="nx-tree-scroll"
        role="tree"
        aria-busy={isTreeLoading}
        aria-label="Workspace files"
        aria-activedescendant={lastSelectedNode && flattenVisibleNodes(tree).some(({node}) => node.path === lastSelectedNode.path) ? `nx-tree-${encodeURIComponent(lastSelectedNode.path)}` : undefined}
        ref={treeScrollRef}
        tabIndex={0}
        onKeyDown={handleTreeKeyDown}
        onContextMenu={handleEmptyAreaContextMenu}
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            setLastSelectedNode(null);
          }
        }}
      >
        {!rootPath ? (
          <div className="nx-empty-state">
            <button className="nx-open-prompt-btn" onClick={openWorkspaceDir}>Open Folder</button>
          </div>
        ) : (
          <>
            {/* Workspace is open but the folder is empty: offer creation entry points
                and let the root inline form (below) render here too. */}
            {isTreeLoading && <div className="nx-folder-load-state" role="status">Loading folder...</div>}
            {treeError && <div className="nx-folder-load-state nx-folder-load-state--error" role="alert"><span>{treeError}</span><button onClick={() => refreshTree()}>Try again</button></div>}
            {tree.length === 0 && !isTreeLoading && !treeError && !(inlineInput.visible && inlineInput.nodePath === rootPath && (inlineInput.mode === 'new-file' || inlineInput.mode === 'new-folder')) && (
              <div className="nx-empty-state nx-empty-state--ws">
                <span className="nx-empty-label">This folder is empty</span>
                <div className="nx-empty-actions">
                  <button className="nx-empty-action-btn" onClick={triggerHeaderNewFile}>New File</button>
                  <button className="nx-empty-action-btn" onClick={triggerHeaderNewFolder}>New Folder</button>
                </div>
              </div>
            )}
            {/* Render root level inline creation form */}
            {inlineInput.visible && inlineInput.nodePath === rootPath && (inlineInput.mode === 'new-file' || inlineInput.mode === 'new-folder') && (
              <div style={{ paddingLeft: '18px', margin: '2px 8px' }}>
                <form onSubmit={handleInlineSubmitWrapper} className="nx-inline-input-form" aria-busy={inlineBusy}>
                  <div className="nx-inline-input-wrapper">
                    <span className="nx-inline-icon-indicator">
                      {inlineInput.mode === 'new-folder' ? (
                        <svg className="nx-svg-icon folder open" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                        </svg>
                      ) : (
                        <svg className="nx-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                          <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                          <polyline points="13 2 13 9 20 9"></polyline>
                        </svg>
                      )}
                    </span>
                    <input
                      ref={inputRef}
                      aria-label={inlineInput.mode === 'new-folder' ? 'New folder name' : 'New file name'}
                      type="text"
                      defaultValue={inlineInput.defaultValue}
                      {...inlineKeyboardProps}
                      className="nx-inline-textbox"
                    />
                    {inlineBusy && <span className="nx-inline-progress" role="status">Working...</span>}
                  </div>
                </form>
              </div>
            )}

            {renderTree(tree)}
          </>
        )}
      </div>

      {/* Floating high-fidelity Context Menu */}
      {(lastSelectedNode?.path || activeFilePath) && <div className="nx-explorer-selection" role="status" title={lastSelectedNode?.path || activeFilePath || undefined}><span>IN FOCUS</span><strong>{lastSelectedNode?.name || activeFilePath?.split(/[\\/]/).pop()}</strong></div>}

      {contextMenu.visible && contextMenu.node && (
        <ExplorerContextMenu x={contextMenu.x} y={contextMenu.y} onClose={()=>setContextMenu(prev=>({...prev,visible:false}))} onRestoreFocus={()=>treeScrollRef.current?.focus()} actions={[
          ...(contextMenu.node.type === 'folder' ? [
            {label:'New File',run:()=>triggerNewFile(contextMenu.node!)},
            {label:'New Folder',run:()=>triggerNewFolder(contextMenu.node!)},
          ] : []),
          ...(contextMenu.node.path !== rootPath ? [
            {label:'Rename...',run:()=>triggerRename(contextMenu.node!)},
            {label:'Delete',danger:true,run:()=>handleDeleteNode(contextMenu.node!)},
            {label:pinnedPaths.includes(contextMenu.node.path)?'Unpin File':'Pin File to Shelf',run:()=>handleTogglePin(contextMenu.node!)},
          ] : []),
          {label:'Copy Path',run:()=>handleCopyPath(contextMenu.node!)},
        ]} />
      )}
      {pendingDelete && (
        <ConfirmDialog
          title={pendingDelete.isFolder ? 'Delete folder' : 'Delete file'}
          message={`Permanently delete ${pendingDelete.isFolder ? 'folder' : 'file'} "${pendingDelete.node.name}"${pendingDelete.isFolder ? ' and all of its contents' : ''}?`}
          detail={pendingDelete.dirtyNames.length
            ? `Warning: ${pendingDelete.dirtyNames.join(', ')} ${pendingDelete.dirtyNames.length === 1 ? 'has' : 'have'} unsaved changes in an open tab. The unsaved buffer stays open, but the file on disk is permanently removed.`
            : undefined}
          discardLabel="Delete"
          onDiscard={() => void confirmDeleteNode()}
          onCancel={cancelDeleteNode}
        />
      )}
    </div>
  );

  function handleTogglePin(node: FileNode) {
    setContextMenu(prev => ({ ...prev, visible: false }));
    togglePin(node.path);
  }

  async function handleCopyPath(node: FileNode) {
    setContextMenu(prev => ({ ...prev, visible: false }));
    const generation = ++copyGeneration.current;
    try {
      await navigator.clipboard.writeText(node.path);
      if (generation === copyGeneration.current) useStatusStore.getState().pushToast('File path copied.', 'success', 2600);
    } catch {
      if (generation === copyGeneration.current) useStatusStore.getState().pushToast('Could not copy this path. Clipboard access was not available. Try again.', 'error', 5000);
    }
  }
};
