import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { createWorkerRegexRunner, regexIsolationAvailable } from '../lib/regexRunner';
import { buildMatcher, isRiskyRegex, searchFiles, sourceFingerprint, type SearchReport, type SearchOptions } from '../lib/searchInFiles';
import { replaceInText } from '../lib/replaceInText';
import { useEditorStore } from '../stores/useEditorStore';
import { reserveDocumentWrite, reserveBulkReplacement } from '../lib/documentWriteLock';
import { waitForDocumentWrites, waitForAllDocumentWrites } from '../lib/saveDocument';
import { saveIfUnchanged } from '../lib/externalChange';
import './SearchPanel.css';

export interface SearchFile { path: string; name: string; }

/** Debounced (180 ms), abortable find-in-files overlay (Ctrl+Shift+F). */
export function SearchPanel({ files, onOpen, onClose }: { files: SearchFile[]; onOpen: (path: string, line: number, col: number) => void; onClose: () => void }) {
  const tabs = useEditorStore(s => s.tabs);
  const dirtyCount = tabs.reduce((n, t) => n + (t.isDirty ? 1 : 0), 0);
  const [q, setQ] = useState('');
  const [opts, setOpts] = useState<SearchOptions>({});
  const invalidPattern=Boolean(q.trim() && opts.regex && !buildMatcher(q,opts));
  const regexUnavailable = Boolean(q.trim() && opts.regex && !invalidPattern && !regexIsolationAvailable());
  const [res, setRes] = useState<SearchReport | null>(null);
  const [refresh, setRefresh] = useState(0);
  const [busy, setBusy] = useState(false);
  const [replacing, setReplacing] = useState(false);
  const replacementLock = useRef(false);
  const replacementScope = useRef(files);
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  replacementScope.current = files;
  const [sel, setSel] = useState(0);
  const [rep, setRep] = useState('');
  const [note, setNote] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [aliasOpenPaths, setAliasOpenPaths] = useState<Set<string>>(new Set());
  const [duplicatePaths, setDuplicatePaths] = useState<Set<string>>(new Set());
  const confirmationLock = useRef(false);
  const confirmedPaths = useRef(new Set<string>());
  const querySnapshot = useRef({ q, rep, opts });
  querySnapshot.current = { q, rep, opts };
  const confirmedQuery = useRef(querySnapshot.current);
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const listId = useId();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    inputRef.current?.focus();
    return () => {
      const fallback=Array.from(document.querySelectorAll<HTMLButtonElement>('.nx-menu-trigger-btn')).find(button=>button.textContent==='Edit');
      if(previous?.isConnected && previous!==document.body) previous.focus();
      else fallback?.focus();
    };
  }, []);
  useEffect(() => {
    boxRef.current?.querySelector<HTMLElement>('.sf-hit.active')?.scrollIntoView?.({ block: 'nearest' });
  }, [sel]);

  useEffect(() => { setNote(''); }, [q, opts, files]);

  useEffect(() => {
    if (!q.trim() || invalidPattern || regexUnavailable) { setRes(null); setBusy(false); setSel(0); setConfirming(false); return; }
    const ac = new AbortController();
    setBusy(true); setRes(null); setSel(0); setConfirming(false);
    const t = window.setTimeout(async () => {
      const runner = opts.regex ? createWorkerRegexRunner() : undefined;
      let r;
      try { r = await searchFiles(files, p => window.nexelAPI.readFileContent(p), q, opts, ac.signal, undefined, undefined, runner); }
      finally { runner?.dispose(); }
      if (!ac.signal.aborted) { setRes(r); setBusy(false); setSel(0); }
    }, 180);
    return () => { ac.abort(); window.clearTimeout(t); };
  }, [q, opts, files, refresh]);

  const flat = useMemo(() => (res?.results ?? []).flatMap(f => f.matches.map(m => ({ f, m }))), [res]);
  const go = (i: number) => { if (busy || replacementLock.current) return; const x = flat[i]; if (x) { onClose(); onOpen(x.f.path, x.m.line, x.m.col); } };
  const doReplace = async () => {
    if (replacementLock.current || !res?.total || res.truncated || !confirming) return;
    if (confirmedQuery.current.q !== q || confirmedQuery.current.rep !== rep || confirmedQuery.current.opts !== opts) { setConfirming(false); return; }
    replacementLock.current = true; setReplacing(true);
    const scope = files;
    let releaseBulk: (() => void) | undefined;
    let n = 0, fc = 0, skipped = 0, failed = 0, slow = 0, unavailable = 0;
    const replaceRunner = opts.regex ? createWorkerRegexRunner() : undefined;
    const replaceRe = replaceRunner ? buildMatcher(q, opts) : null;
    const assertClosed = (path: string) => {
      if (useEditorStore.getState().tabs.some(t => t.filePath === path)) throw new Error('open-buffer');
      if (!mounted.current || replacementScope.current !== scope) throw new Error('scope-changed');
    };
    try {
      releaseBulk = reserveBulkReplacement();
      // Compare actual filesystem identity, not labels: symlink and hardlink tabs
      // must protect the same underlying file. Unverifiable identity fails closed.
      await waitForAllDocumentWrites();
      const openIdentities = new Set(await Promise.all(useEditorStore.getState().tabs.map(t => window.nexelAPI.fileIdentity(t.filePath))));
      const seenIdentities = new Set<string>();
      for (const f of res.results) {
        if (!confirmedPaths.current.has(f.path)) { skipped++; continue; }
        if (!mounted.current || replacementScope.current !== scope) break;
        let release: (() => void) | undefined;
        try {
          assertClosed(f.path);
          const identity = await window.nexelAPI.fileIdentity(f.path);
          if (openIdentities.has(identity) || seenIdentities.has(identity)) { skipped++; continue; }
          seenIdentities.add(identity);
          release = reserveDocumentWrite(f.path);
          await waitForDocumentWrites(f.path);
          assertClosed(f.path);
          const src = await window.nexelAPI.readFileContent(f.path);
          assertClosed(f.path);
          // The user confirmed the preview, not a fresh broader set of matches.
          // Baseline-write guarding below protects only the later read/write gap.
          if (!f.sourceFingerprint || await sourceFingerprint(src) !== f.sourceFingerprint) { skipped++; continue; }
          assertClosed(f.path);
          let r: { text: string; count: number };
          if (replaceRunner && replaceRe) {
            const out = await replaceRunner.replace(src, replaceRe.source, replaceRe.flags, rep, true);
            if (out === 'unavailable') { unavailable++; continue; }
            if (out === 'timeout') { slow++; continue; }
            r = out;
          } else r = replaceInText(src, q, rep, opts);
          assertClosed(f.path);
          if (r.count > 0) {
            // Guarded write: if the file changed on disk after we read it, the
            // replacement would clobber that edit. Skip instead of overwrite.
            // Residual race: the baseline check in the main process is not
            // atomic with its write - a disk edit landing inside that one
            // main-process turn can still be overwritten (see externalChange.ts).
            const saveRes = await saveIfUnchanged(f.path, r.text, src);
            if (saveRes === 'conflict') { skipped++; continue; }
            n += r.count; fc++;
          }
        } catch (error) {
          if (error instanceof Error && ['open-buffer','scope-changed'].includes(error.message)) skipped++;
          else failed++;
        } finally { release?.(); }
      }
      setNote(`Replaced ${n} in ${fc} file${fc === 1 ? '' : 's'}${skipped ? ` · ${skipped} skipped (open, duplicate or changed)` : ''}${failed ? ` · ${failed} failed` : ''}${slow ? ` · ${slow} left unchanged: pattern too slow (750ms)` : ''}${unavailable ? ` · ${unavailable} left unchanged: background matching unavailable. Try again.` : ''}`);
      setConfirming(false); setRes(null); setRefresh(value => value + 1);
    } catch (error) { setNote(error instanceof Error && error.message.includes('Another file operation') ? 'Replacement not started: another file operation is running. Try again when it finishes.' : 'Replacement stopped: could not verify open-file identity. No further files changed.'); setConfirming(false);
    } finally { replaceRunner?.dispose(); releaseBulk?.(); replacementLock.current = false; setReplacing(false); window.setTimeout(() => inputRef.current?.focus(), 0); }
  };
  const replaceAll = async () => {
    if (busy || replacing || !res?.total || res.truncated || confirmationLock.current) return;
    confirmationLock.current = true;
    const snapshot = querySnapshot.current;
    const current = () => mounted.current && replacementScope.current === files && querySnapshot.current.q === snapshot.q && querySnapshot.current.rep === snapshot.rep && querySnapshot.current.opts === snapshot.opts;
    try {
      const ids = new Set(await Promise.all(useEditorStore.getState().tabs.map(t => window.nexelAPI.fileIdentity(t.filePath))));
      const aliases = new Set<string>(), duplicates = new Set<string>(), seen = new Set<string>();
      for (const f of res.results) {
        const id = await window.nexelAPI.fileIdentity(f.path);
        if (ids.has(id)) aliases.add(f.path);
        else if (seen.has(id)) duplicates.add(f.path);
        else seen.add(id);
      }
      if (!current()) return;
      confirmedQuery.current = snapshot;
      confirmedPaths.current = new Set(res.results.filter(f => !aliases.has(f.path) && !duplicates.has(f.path)).map(f => f.path));
      setAliasOpenPaths(aliases); setDuplicatePaths(duplicates); setConfirming(true);
    } catch { if (current()) setNote('Cannot replace: file identity could not be verified. Try again after checking the files.'); }
    finally { confirmationLock.current = false; }
  };
  const openResults = (res?.results ?? []).filter(f => aliasOpenPaths.has(f.path) || tabs.some(t => t.filePath === f.path));
  const duplicateResults = (res?.results ?? []).filter(f => duplicatePaths.has(f.path));
  const duplicateMatches = duplicateResults.reduce((n,f) => n + f.matches.length, 0);
  const openMatches = openResults.reduce((n,f) => n + f.matches.length, 0);
  const flag = (k: keyof SearchOptions, label: string, title: string) => (
    <button type="button" aria-label={title} disabled={replacing} className={'sp2-flag' + (opts[k] ? ' on' : '')} title={title} aria-pressed={!!opts[k]} onClick={() => setOpts(o => ({ ...o, [k]: !o[k] }))}>{label}</button>
  );
  let idx = -1;
  return (
    <div className="sf-backdrop" onMouseDown={() => { if (!replacementLock.current) onClose(); }}>
      <div ref={boxRef} className="sf-box" role="dialog" aria-modal="true" aria-label="Find in files" onMouseDown={e => e.stopPropagation()} onKeyDown={e => {
        if (e.nativeEvent.isComposing || e.keyCode === 229) { e.stopPropagation(); return; }
        if (e.key === 'Escape') { e.preventDefault(); if (replacementLock.current) return; e.stopPropagation(); if (confirming) { setConfirming(false); inputRef.current?.focus(); } else onClose(); }
        if (e.key === 'Tab') {
          const root = confirming ? boxRef.current?.querySelector('.sf-confirm') : boxRef.current;
          const items = root?.querySelectorAll<HTMLElement>('button:not(:disabled),input');
          if (!items?.length) return;
          const first = items[0], last = items[items.length - 1];
          if (e.shiftKey && (document.activeElement === first || !root?.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
          else if (!e.shiftKey && (document.activeElement === last || !root?.contains(document.activeElement))) { e.preventDefault(); first.focus(); }
        }
      }}>
        <div className="sf-heading"><span>FIND IN FILES</span><button type="button" aria-label="Close find in files" disabled={replacing} onClick={onClose}>Esc</button></div>
        <div className="sf-bar">
          <span className={'sf-glyph' + (busy ? ' busy' : '')} aria-hidden>⌕</span>
          <input ref={inputRef} disabled={replacing} aria-label="Search workspace" aria-invalid={invalidPattern} aria-describedby={invalidPattern ? `${listId}-pattern-error` : undefined} role="combobox" aria-expanded={flat.length > 0} aria-controls={listId} aria-activedescendant={flat[sel] ? `${listId}-${sel}` : undefined} className="sf-input" placeholder="Find in files…" value={q} onChange={e => setQ(e.target.value)}
            onKeyDown={e => {
              if (e.nativeEvent.isComposing || e.keyCode === 229) { e.stopPropagation(); return; }
              if (e.key === 'ArrowDown') { e.preventDefault(); setSel(s => Math.max(0, Math.min(s + 1, flat.length - 1))); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setSel(s => Math.max(s - 1, 0)); }
              else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); go(sel); }
            }} />
          {flag('caseSensitive', 'Aa', 'Match case')}{flag('wholeWord', 'ab', 'Whole word')}{flag('regex', '.*', 'Regular expression')}
        </div>
        <div className="sf-bar sf-rep">
          <span className="sf-glyph" aria-hidden>↳</span>
          <input aria-label="Replace with" disabled={replacing} className="sf-input" placeholder="Replace with…" value={rep} onChange={e => setRep(e.target.value)} onKeyDown={e => { if (e.nativeEvent.isComposing || e.keyCode === 229) { e.stopPropagation(); return; } if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) replaceAll(); }} />
          <button type="button" className="sp2-flag sf-repbtn" disabled={busy || replacing || !res || !res.total || res.truncated} title="Replace all (Ctrl+Enter)" onClick={replaceAll}>Replace all</button>
        </div>
        {dirtyCount > 0 && <div className="sf-hint" role="status">Searching saved files - unsaved edits in {dirtyCount} file{dirtyCount === 1 ? '' : 's'} not included.</div>}
        {confirming && res && (
          <div className="sf-confirm" role="alertdialog" aria-modal="true" aria-label="Confirm replace all">
            <span>Replace <b>{res.total - openMatches - duplicateMatches}</b> match{res.total - openMatches - duplicateMatches === 1 ? '' : 'es'} in <b>{res.results.length - openResults.length - duplicateResults.length}</b> closed file{res.results.length - openResults.length - duplicateResults.length === 1 ? '' : 's'}? {openResults.length > 0 && <small>{openResults.length} open file path{openResults.length === 1 ? '' : 's'} ({openMatches} match{openMatches === 1 ? '' : 'es'}) will be skipped, including clean tabs.</small>} {duplicateResults.length > 0 && <small>{duplicateResults.length} duplicate file path{duplicateResults.length === 1 ? '' : 's'} will be skipped.</small>}</span>
            <button type="button" className="sf-cf-yes" disabled={replacing} autoFocus onClick={() => void doReplace()}>{replacing ? 'Replacing...' : 'Replace'}</button>
            <button type="button" className="sf-cf-no" disabled={replacing} onClick={() => { setConfirming(false); inputRef.current?.focus(); }}>Cancel</button>
          </div>
        )}
        <div className="sf-list" id={listId} role="listbox" aria-label="Search results" aria-busy={busy}>
          {regexUnavailable && <div className="sf-empty sf-pattern-error" role="alert">Regular expression search is unavailable here because it cannot run in the background safely. Turn off Regular expression to search literally.</div>}
          {invalidPattern && <div id={`${listId}-pattern-error`} className="sf-empty sf-pattern-error" role="alert">{opts.regex && isRiskyRegex(q) ? 'Pattern not run: a repeated group containing a repeat, like (a+)+, can freeze the app. Simplify it or turn off Regular expression.' : 'Invalid regular expression. Check brackets, groups and escapes, or turn off Regular expression.'}</div>}
          {busy && <div className="sf-empty" role="status">Searching workspace…</div>}
          {!q.trim() && <div className="sf-empty">Search across {files.length} file{files.length === 1 ? '' : 's'} in this workspace</div>}
          {q.trim() && res && res.total === 0 && !busy && !res.timedOut && !res.regexUnavailable && <div className="sf-empty">{res.unreadable ? 'No matches in readable files.' : 'No results'}</div>}
          {res?.results.map(f => (
            <div key={f.path} className="sf-group">
              <div className="sf-file" title={f.path}><span className="sf-file-identity"><b>{f.name}</b><small>{f.path.replace(/[/\\][^/\\]+$/, "")}</small></span><em aria-label={`${f.matches.length} matches`}>{f.matches.length}</em></div>
              {f.matches.map(m => { idx++; const my = idx; const previewCol = m.col - 1 - (m.previewOffset ?? 0); return (
                <div role="option" aria-selected={my === sel} aria-label={`${f.path}, line ${m.line}, column ${m.col}: ${m.text}`} id={`${listId}-${my}`} key={m.line + ':' + m.col} className={'sf-hit' + (my === sel ? ' active' : '')} style={{ animationDelay: `${Math.min(my, 10) * 16}ms` }} onMouseMove={() => setSel(my)} onClick={() => go(my)}>
                  <span className="sf-ln">{m.line}</span>
                  <code>{m.text.slice(Math.max(0, previewCol - 12), previewCol)}<mark>{m.text.slice(previewCol, previewCol + m.length)}</mark>{m.text.slice(previewCol + m.length, previewCol + m.length + 80)}</code>
                </div>); })}
            </div>
          ))}
        </div>
        {res && (res.truncated || res.unreadable>0 || res.skippedContent>0 || res.regexUnavailable || (res.timedOut ?? 0)>0) && <div className="sf-search-warning" role="status">{res.regexUnavailable && <span>Regular expression search could not start. Nothing was searched.</span>}{res.truncated && !res.regexUnavailable && <span>Results are limited. Narrow your search before using Replace all.</span>}{res.unreadable>0 && <span>{res.unreadable} file{res.unreadable===1?' could':'s could'} not be read. Search is incomplete.</span>}{(res.timedOut ?? 0)>0 && <span>{res.timedOut} file{res.timedOut===1?'':'s'} stopped after 750ms because the pattern is too slow. Search is incomplete; simplify the pattern.</span>}{res.skippedContent>0 && <span>{res.skippedContent} large or binary file{res.skippedContent===1?' was':'s were'} skipped.</span>}</div>}
        <div className="sf-foot" role="status" aria-live="polite"><span><kbd>↑↓</kbd> navigate</span><span><kbd>↵</kbd> open</span><span><kbd>esc</kbd> close</span>
          <span className="sf-count">{note ? note : res ? `${res.total}${res.truncated ? '+' : ''} match${res.total === 1 ? '' : 'es'} · ${res.results.length} file${res.results.length === 1 ? '' : 's'}` : ''}</span></div>
      </div>
    </div>
  );
}
