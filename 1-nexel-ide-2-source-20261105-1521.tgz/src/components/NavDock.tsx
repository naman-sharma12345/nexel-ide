import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import './NavDock.css';

export interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
}

interface NavDockProps {
  activeSection: string;
  onSelect: (id: string) => void;
  sidebarCollapsed?: boolean;
  /** Extra dock entries contributed by enabled plugins. */
  pluginItems?: NavItem[];
}

export const NavDock: React.FC<NavDockProps> = ({ activeSection, onSelect, sidebarCollapsed, pluginItems = [] }) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [focusedItem,setFocusedItem] = useState<string|null>(null);
  // Labels follow keyboard navigation (Tab / arrows) and hover, not focus the
  // app moves programmatically (e.g. Escape closing the drawer returns focus
  // to its trigger so Enter reopens it; the label would sit over the editor).
  const lastKeyRef = useRef('');
  useEffect(()=>{const h=(e:KeyboardEvent)=>{lastKeyRef.current=e.key;};const m=()=>{lastKeyRef.current='';};window.addEventListener('keydown',h,true);window.addEventListener('pointerdown',m,true);return()=>{window.removeEventListener('keydown',h,true);window.removeEventListener('pointerdown',m,true);};},[]);
  const [dismissedFocus,setDismissedFocus] = useState<string|null>(null);
  const [tooltip,setTooltip] = useState<{text:string;left:number;top:number}|null>(null);
  useEffect(()=>{
    const id=hoveredItem??(focusedItem!==dismissedFocus?focusedItem:null);
    // An open drawer already names its active tool. Repeating the label over
    // its controls obscures them, especially on narrow windows.
    if(!id || (id===activeSection && !sidebarCollapsed)){setTooltip(null);return;}
    const update=()=>{const button=[...document.querySelectorAll<HTMLButtonElement>('.nd-item-row')].find(node=>node.dataset.navId===id);if(!button){setTooltip(null);return;}const r=button.getBoundingClientRect();setTooltip({text:button.getAttribute('aria-label')??'',left:r.right+12,top:Math.max(18,Math.min(innerHeight-18,r.top+r.height/2))});};
    update();window.addEventListener('resize',update);window.addEventListener('scroll',update,true);return()=>{window.removeEventListener('resize',update);window.removeEventListener('scroll',update,true);};
  },[hoveredItem,focusedItem,dismissedFocus,activeSection,sidebarCollapsed,pluginItems.map(item=>item.id).join('|')]);
  // A focus-only label (for example after Escape returns focus here) is
  // dismissible and fades on its own so it never sits over the editor text.
  useEffect(()=>{if(!focusedItem||hoveredItem||dismissedFocus===focusedItem)return;const t=window.setTimeout(()=>setDismissedFocus(focusedItem),2500);return()=>window.clearTimeout(t);},[focusedItem,hoveredItem,dismissedFocus]);
  const [isDockHovered, setIsDockHovered] = useState<boolean>(false);

  const navItems: NavItem[] = [
    {
      id: 'workspace',
      label: 'Workspace Explorer',
      icon: (
        <svg className="nd-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
        </svg>
      ),
    },
    ...pluginItems,
  ];

  return (
    <><nav className="nd-wrapper-axis" aria-label="Workspace navigation">
      <div 
        className={`nd-dock ${isDockHovered ? 'nd-dock-expanded' : ''}`}
        onMouseEnter={() => setIsDockHovered(true)}
        onMouseLeave={() => {
          setIsDockHovered(false);
          setHoveredItem(null);
        }}
      >


        {/* Navigation Core stack */}
        <div className="nd-items-stack">
          {navItems.map((item) => {
            const isItemHovered = hoveredItem === item.id;
            const isItemActive = activeSection === item.id && !sidebarCollapsed;

            return (
              <button
                type="button" data-nav-id={item.id} aria-label={item.label} onFocus={()=>{setDismissedFocus(null);setFocusedItem(/^(Tab|Arrow)/.test(lastKeyRef.current)?item.id:null);}} onBlur={()=>{setFocusedItem(null);setDismissedFocus(null);}} onKeyDown={e=>{if(e.key==='Escape'&&tooltip)setDismissedFocus(item.id);}} aria-pressed={isItemActive}
                key={item.id}
                className={`nd-item-row ${isItemHovered ? 'nd-row-hovered' : ''} ${isItemActive ? 'nd-row-active' : ''}`}
                onMouseEnter={() => setHoveredItem(item.id)}
                onMouseLeave={() => setHoveredItem(null)}
                onClick={() => onSelect(item.id)}
              >

                <div className="nd-active-indicator" />

                <div className="nd-capsule-container">
                  <div className="nd-glow-layer" />
                  <div className="nd-icon-fluid">
                    {item.icon}
                  </div>
                </div>


              </button>
            );
          })}
        </div>

      </div>
    </nav>{tooltip&&createPortal(<div className="nd-floating-tooltip" style={{left:tooltip.left,top:tooltip.top}}>{tooltip.text}</div>,document.body)}</>
  );
};

export default NavDock;
