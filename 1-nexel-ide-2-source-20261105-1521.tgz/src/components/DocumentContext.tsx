import {utilityTabLabel} from '../lib/utilityTab';
import {useMemo} from 'react';
import {countDocumentLines} from '../lib/documentStats';
import { toCrumbs } from '../lib/breadcrumbs';
import type { EditorTab } from '../stores/useEditorStore';

interface DocumentContextProps {
  tab: EditorTab;
  rootPath: string | null;
  rootName: string;
  onReveal: (path: string) => void;
}

/** The active document gets one identity, above the code and below the tab index. */
export function DocumentContext({ tab, rootPath, rootName, onReveal }: DocumentContextProps) {
  const crumbs = toCrumbs(tab.filePath, rootPath).filter(crumb => !crumb.isFile);
  const lines = useMemo(() => countDocumentLines(tab.content), [tab.content]);
  const name = tab.filePath.split(/[\\/]/).pop() || tab.name;
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const extension = dot > 0 ? name.slice(dot) : '';
  const utility = utilityTabLabel(tab.filePath);
  if (utility) return <header className="nx-document-context">
    <div className="nx-document-identity"><h1 className="nx-document-name">{tab.name}</h1></div>
    <div className="nx-document-details" aria-label="View details"><span>{utility}</span><span>Read-only</span></div>
  </header>;
  return <header className="nx-document-context">
    <div className="nx-document-identity">
      <nav className="nx-crumbs" aria-label="File location" title={tab.filePath}>
        {crumbs.map((crumb, index) => <span className="nx-crumb-segment" key={`${crumb.path}-${index}`}>
          {index > 0 && <span className="nx-crumb-sep" aria-hidden="true">/</span>}
          {crumb.path ? <button type="button" className="nx-crumb nx-crumb-btn"
            title={`Reveal ${crumb.label} in Explorer`} onClick={() => onReveal(crumb.path!)}>
            {index === 0 && crumb.path === rootPath && rootName ? rootName : crumb.label}
          </button> : <span className="nx-crumb">{crumb.label}</span>}
        </span>)}
      </nav>
      <h1 className="nx-document-name"><button type="button" aria-current="page" aria-label={name} title={`Reveal ${name} in Explorer`} onClick={() => onReveal(tab.filePath)}><span>{stem}</span><i>{extension}</i></button></h1>
    </div>
    <div className="nx-document-details" aria-label="Document details">
      {tab.isOrphaned ? <span className="nx-document-warning">Deleted on disk</span> : tab.isDirty ? <span className="nx-document-unsaved">Unsaved</span> : null}
      <span>{lines} {lines === 1 ? 'line' : 'lines'}</span><span className="nx-document-chars">{tab.content.length} chars</span>
    </div>
  </header>;
}
