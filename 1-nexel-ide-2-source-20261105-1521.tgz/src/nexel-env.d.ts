export interface IFileNode {
  name: string;       // e.g., "main.cpp"
  path: string;       // e.g., "C:/contests/main.cpp"
  type: 'file' | 'folder';
  children?: IFileNode[]; // Recursive: folders can have more files/folders inside
}

export interface IContest {
  id: number;
  name: string;
  type: string;
  phase: 'BEFORE' | 'CODING' | 'FINISHED' | 'PENDING_SYSTEM_TEST' | 'SYSTEM_TEST';
  durationSeconds: number;
  startTimeSeconds: number;
  relativeTimeSeconds?: number;
}

export interface ICategorizedContests {
  active: IContest[];
  upcoming: IContest[];
  passed: IContest[];
}

export interface INexelAPI {
  readClipboardText?: () => string;
  writeClipboardText?: (text: string) => void;
  minimizeWindow: () => void;
  maximizeWindow: () => void;
  closeWindow: () => void;
  // App-close guard: main asks the renderer before destroying the window so dirty tabs can be confirmed.
  onAppCloseRequested?: (callback: () => void) => void;
  confirmAppClose?: () => void;
  openWorkspaceDir: () => Promise<string | null>;
  readWorkspaceFiles: (dirPath: string) => Promise<IFileNode[]>;
  createFile: (parentPath: string, fileName: string) => Promise<string>;
  createFolder: (parentPath: string, folderName: string) => Promise<string>;
  renameNode: (oldPath: string, newPath: string) => Promise<string>;
  deleteNode: (targetPath: string) => Promise<boolean>;
  fileIdentity: (filePath: string) => Promise<string>;
  realPath: (filePath: string) => Promise<string>;
  readFileContent: (filePath: string) => Promise<string>;
  writeFileContent: (filePath: string, content: string) => Promise<boolean>;
        writeFileIfBaseline: (filePath: string, content: string, baseline: string) => Promise<'written' | 'conflict'>;
  createTerminal: (cwd?: string) => Promise<boolean>;
  writeTerminal: (data: string) => void;
  resizeTerminal: (cols: number, rows: number) => void;
  onTerminalData: (callback: (data: string) => void) => (() => void) | void;
  runJudge: (
    filePath: string,
    testCases: Array<{ id: number; input: string; expected: string }>,
    timeLimit?: number,
    memoryLimit?: number,
    runId?: string
  ) => Promise<Array<{
    id: number;
    verdict: 'AC' | 'WA' | 'TLE' | 'MLE' | 'RE' | 'CE' | 'CANCELLED';
    metrics: { time: number; memory: number; memoryMeasured?: boolean; exitCode: number | null };
    actual: string;
    expected?: string;
    passed?: boolean;
    diff?: string;
  }>>;
  cancelJudge: (runId: string) => Promise<void>;
  fetchContests: (
    workspaceDir?: string | null
  ) => Promise<ICategorizedContests>;
  fetchContestProblems: (
    contestId: number | string
  ) => Promise<Record<string, unknown>>;
  // Git integration (optional in browser previews/tests)
  gitStatus?: (root: string) => Promise<{ repositoryRoot?: string; isRepo: boolean; branch: string | null; hasUpstream: boolean; ahead: number; behind: number; entries: Array<{ path: string; code: string; staged: boolean; unstaged: boolean; untracked: boolean }> }>;
  gitInit?: (root: string) => Promise<{ ok: boolean; error?: string }>;
  gitStage?: (root: string, paths: string[]) => Promise<{ ok: boolean; error?: string }>;
  gitUnstage?: (root: string, paths: string[]) => Promise<{ ok: boolean; error?: string }>;
  gitCommit?: (root: string, message: string) => Promise<{ ok: boolean; error?: string }>;
  gitBranches?: (root: string) => Promise<{ ok: boolean; branches: string[]; error?: string }>;
  gitDiff?: (root: string, path: string, staged: boolean, origPath?: string) => Promise<{ ok: boolean; error?: string; diff?: string }>;
  gitSwitch?: (root: string, branch: string) => Promise<{ ok: boolean; error?: string }>;
  gitFetch?: (root: string) => Promise<{ ok: boolean; error?: string }>;
  gitPull?: (root: string) => Promise<{ ok: boolean; error?: string }>;
  gitLog?: (root: string, limit?: number) => Promise<{ ok: boolean; commits: Array<{ hash: string; subject: string; author: string; date: string }>; error?: string }>;
  gitPush?: (root: string) => Promise<{ ok: boolean; error?: string }>;
  gitRemotes?: (root: string) => Promise<{ ok: boolean; remotes: string[]; error?: string }>;
  gitPublish?: (root: string, remote: string, branch: string) => Promise<{ ok: boolean; error?: string }>;
  gitCreateBranch?: (root: string, name: string) => Promise<{ ok: boolean; error?: string }>;
    gitWatch?: (root: string | null) => Promise<{ ok: boolean; watching?: boolean; error?: string }>;
    onGitExternalChange?: (cb: (root: string) => void) => () => void;
  onCompanionProblem?: (callback: (problem: {
    name: string; group: string; url: string; timeLimit: number; memoryLimit: number; fileName: string;
    tests: Array<{ input: string; output: string }>;
  }) => void) => (() => void);
  // clangd bridge (optional: absent in browser previews and unit tests -> offline IntelliSense)
  lspStart?: (root: string, opts?: { std?: string; extraFlags?: string[] }) => Promise<{ ok: boolean; reason?: string; source?: string; compiler?: string | null; config?: string }>;
  lspSend?: (msg: unknown) => Promise<boolean>;
  lspRestart?: () => Promise<boolean>;
  lspStop?: () => Promise<boolean>;
  onLspMessage?: (cb: (msg: unknown) => void) => void;
  onLspStatus?: (cb: (status: 'off' | 'starting' | 'ready' | 'crashed' | 'failed') => void) => void;
  getStoreSync: (key: string) => any;
  setStoreSync: (key: string, value: any) => boolean;
  deleteStoreSync: (key: string) => boolean;
}

declare global {
  interface Window {
    nexelAPI: INexelAPI;
  }
}
