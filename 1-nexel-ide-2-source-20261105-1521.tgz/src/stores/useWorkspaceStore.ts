import { parentDirectory } from '../lib/parentDirectory';
import { relocatePath } from '../lib/relocatePath';
import {reserveFileMove} from '../lib/moveDocumentGuard';
import {invalidateDocumentOpen} from '../lib/openRequest';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { useEditorStore } from './useEditorStore';
import { useStatusStore } from './useStatusStore';
import { electronStorage } from './electronStorage';

export interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  isOpen?: boolean;
  children?: FileNode[];
}

export interface InlineInputState {
  visible: boolean;
  nodePath: string;
  mode: 'new-file' | 'new-folder' | 'rename';
  defaultValue: string;
}

interface WorkspaceState {
  rootPath: string | null;
  rootName: string;
  activeDir: string | null;
  tree: FileNode[];
  isTreeLoading: boolean;
  treeError: string | null;
  pinnedPaths: string[];
  recentWorkspaces: string[];
  openRecent: (path: string) => Promise<void>;
  searchQuery: string;
  isRegex: boolean;
  isMatchCase: boolean;
  lastSelectedNode: FileNode | null;
  inlineInput: InlineInputState;

  setRootPath: (path: string | null) => void;
  setActiveDir: (path: string | null) => void;
  setTree: (tree: FileNode[]) => void;
  togglePin: (path: string) => void;
  relocatePinnedPaths: (source: string, target: string, workspace: string | null) => void;
  relocateTreePaths: (source: string, target: string, workspace: string | null) => void;
  setSearchQuery: (query: string) => void;
  setRegex: (isRegex: boolean) => void;
  setMatchCase: (isMatchCase: boolean) => void;
  setLastSelectedNode: (node: FileNode | null) => void;
  setInlineInput: (input: Partial<InlineInputState>) => void;
  
  openWorkspaceDir: () => Promise<void>;
  refreshTree: (forceOpenPaths?: Set<string>) => Promise<void>;
  toggleFolder: (nodePath: string) => void;
  revealPath: (path: string) => void;
  collapseAllFolders: () => void;
  triggerHeaderNewFile: () => void;
  triggerHeaderNewFolder: () => void;
  handleDeleteNode: (node: FileNode) => Promise<void>;
  pendingDelete: { node: FileNode; isFolder: boolean; dirtyNames: string[] } | null;
  confirmDeleteNode: () => Promise<void>;
  cancelDeleteNode: () => void;
  handleInlineSubmit: (value: string) => Promise<string | null>;
}

/** MRU list: newest first, de-duplicated, capped so persisted state stays tiny. */
export function pushRecent(list: string[], dir: string, max = 5): string[] {
  return [dir, ...list.filter(d => d !== dir)].slice(0, max);
}

// Helpers for tree transformation & state extraction
function getOpenFolderPaths(nodes: FileNode[]): Set<string> {
  const paths = new Set<string>();
  const traverse = (nodeList: FileNode[]) => {
    for (const node of nodeList) {
      if (node.type === 'folder' && node.isOpen) {
        paths.add(node.path);
      }
      if (node.children) {
        traverse(node.children);
      }
    }
  };
  traverse(nodes);
  return paths;
}

function transformNodes(nodes: FileNode[], openPaths: Set<string> = new Set()): FileNode[] {
  return nodes.map((node) => ({
    name: node.name,
    path: node.path,
    type: node.type,
    isOpen: node.type === 'folder' && openPaths.has(node.path),
    children: node.children ? transformNodes(node.children, openPaths) : [],
  }));
}

/** Keep keyboard selection on a visible ancestor when folders hide its row. */
function visibleSelection(nodes: FileNode[], selectedPath: string): FileNode | null {
  const find = (items: FileNode[], hiddenBy: FileNode | null): FileNode | null => {
    for (const node of items) {
      if (node.path === selectedPath) return hiddenBy ?? node;
      const nested = node.children && find(node.children, hiddenBy ?? (node.type === 'folder' && !node.isOpen ? node : null));
      if (nested) return nested;
    }
    return null;
  };
  return find(nodes, null);
}

// In-flight reads may finish out of order, including A -> B -> A workspace switches.
let treeReadVersion = 0;
const pendingInlineInputs = new WeakSet<InlineInputState>();

export const useWorkspaceStore = create<WorkspaceState>()(
  persist(
    (set, get) => ({
      rootPath: null,
      rootName: 'NO WORKSPACE',
      activeDir: null,
      tree: [],
      isTreeLoading: false,
      treeError: null,
      pinnedPaths: [],
      searchQuery: '',
      isRegex: false,
      isMatchCase: false,
      lastSelectedNode: null,
      inlineInput: {
        visible: false,
        nodePath: '',
        mode: 'new-file',
        defaultValue: '',
      },

      setRootPath: (rootPath) => {
        invalidateDocumentOpen();
        const rootName = rootPath ? (rootPath.split(/[\\/]/).pop() || rootPath).toUpperCase() : 'NO WORKSPACE';
        if (rootPath !== get().rootPath) {
          treeReadVersion++;
          // Never show a new workspace title above the previous workspace tree.
          set({ rootPath, rootName, tree: [], isTreeLoading: false, treeError: null, lastSelectedNode: null, activeDir: rootPath,
            inlineInput: { visible: false, nodePath: '', mode: 'new-file', defaultValue: '' }, pendingDelete: null });
        } else {
          set({ rootPath, rootName });
        }
      },
      setActiveDir: (activeDir) => set({ activeDir }),
      setTree: (tree) => set({ tree }),
      
      togglePin: (path) =>
        set((state) => ({
          pinnedPaths: state.pinnedPaths.includes(path)
            ? state.pinnedPaths.filter((p) => p !== path)
            : [...state.pinnedPaths, path],
        })),

      relocatePinnedPaths: (source, target, workspace) => {
        if (get().rootPath !== workspace) return;
        set(state => ({ pinnedPaths: [...new Set(state.pinnedPaths.map(path => relocatePath(path, source, target)))] }));
      },

      relocateTreePaths: (source, target, workspace) => {
        if (get().rootPath !== workspace) return;
        const relocateNode = (node: FileNode): FileNode => {
          const path = relocatePath(node.path, source, target);
          return {...node, path, name:path !== node.path ? path.split('/').pop() || node.name : node.name,
            children:node.children?.map(relocateNode)};
        };
        const selected = get().lastSelectedNode;
        set(state => ({tree:state.tree.map(relocateNode),
          lastSelectedNode:selected ? relocateNode(selected) : null,
          activeDir:state.activeDir ? relocatePath(state.activeDir,source,target) : null}));
      },

      setSearchQuery: (searchQuery) => set({ searchQuery }),
      setRegex: (isRegex) => set({ isRegex }),
      setMatchCase: (isMatchCase) => set({ isMatchCase }),
      
      setLastSelectedNode: (node) => {
        set({ lastSelectedNode: node });
        const { rootPath } = get();
        if (!rootPath) {
          set({ activeDir: null });
          return;
        }
        let activeDir = rootPath;
        if (node) {
          if (node.type === 'folder') {
            activeDir = node.path;
          } else {
            activeDir = parentDirectory(node.path, rootPath) || rootPath;
          }
        }
        set({ activeDir });
      },

      setInlineInput: (input) =>
        set((state) => ({
          inlineInput: { ...state.inlineInput, ...input },
        })),

      openWorkspaceDir: async () => {
        try {
          const selectedDir = await window.nexelAPI.openWorkspaceDir();
          if (!selectedDir) return;
          
          get().setRootPath(selectedDir);
          set(st => ({ recentWorkspaces: pushRecent(st.recentWorkspaces, selectedDir) }));
          set({ lastSelectedNode: null, activeDir: selectedDir });
          
          await get().refreshTree();
        } catch (error) {
          console.error("Workspace mount failure:", error);
        }
      },

      recentWorkspaces: [],
      openRecent: async (dir) => {
        get().setRootPath(dir);
        set(st => ({ lastSelectedNode: null, activeDir: dir, recentWorkspaces: pushRecent(st.recentWorkspaces, dir) }));
        await get().refreshTree();
      },

      refreshTree: async (forceOpenPaths) => {
        const { rootPath } = get();
        if (!rootPath) return;
        const version = ++treeReadVersion;
        set({ isTreeLoading: true, treeError: null });
        try {
          const data = await window.nexelAPI.readWorkspaceFiles(rootPath);
          if (version !== treeReadVersion || get().rootPath !== rootPath) return;
          if (!data) throw new Error('No workspace result received');

          let nodesArray: FileNode[] = [];
          if (Array.isArray(data)) {
            nodesArray = data as unknown as FileNode[];
          } else if (data && typeof data === 'object') {
            const d = data as Record<string, unknown>;
            if (d.children && Array.isArray(d.children)) {
              nodesArray = d.children as unknown as FileNode[];
            } else {
              nodesArray = [data as unknown as FileNode];
            }
          }

          const openPaths = getOpenFolderPaths(get().tree);
          if (forceOpenPaths) {
            forceOpenPaths.forEach((p) => openPaths.add(p));
          }

          const updatedTree = transformNodes(nodesArray, openPaths);
          const selectedPath = get().lastSelectedNode?.path;
          const selected = selectedPath ? visibleSelection(updatedTree, selectedPath) : null;
          set({ tree: updatedTree });
          if (selectedPath) get().setLastSelectedNode(selected ?? null);
        } catch (e) {
          console.error("Workspace tree hydration failure:", e);
          if (version === treeReadVersion && get().rootPath === rootPath) {
            set({ treeError: 'Could not load this folder. Check access and try again.' });
          }
        } finally {
          if (version === treeReadVersion && get().rootPath === rootPath) set({ isTreeLoading: false });
        }
      },

      toggleFolder: (nodePath) => {
        const { tree } = get();
        const deepToggle = (nodes: FileNode[]): FileNode[] => {
          return nodes.map((node) => {
            if (node.path === nodePath && node.type === 'folder') {
              return { ...node, isOpen: !node.isOpen };
            }
            if (node.children) {
              return { ...node, children: deepToggle(node.children) };
            }
            return node;
          });
        };
        const updated = deepToggle(tree);
        const selected = get().lastSelectedNode;
        set({ tree: updated });
        if (selected) get().setLastSelectedNode(visibleSelection(updated, selected.path));
      },

      collapseAllFolders: () => {
        const { tree } = get();
        const deepCollapse = (nodes: FileNode[]): FileNode[] => {
          return nodes.map((node) => {
            if (node.type === 'folder') {
              return { ...node, isOpen: false, children: node.children ? deepCollapse(node.children) : [] };
            }
            return node;
          });
        };
        const updated = deepCollapse(tree);
        const selected = get().lastSelectedNode;
        set({ tree: updated });
        if (selected) get().setLastSelectedNode(visibleSelection(updated, selected.path));
      },

      revealPath: (targetPath) => {
        const norm = (path: string) => path.replace(/\\/g, '/').replace(/\/+$/, '');
        const target = norm(targetPath || '');
        if (!target) return;
        const windows = /^[A-Za-z]:\//.test(target) || target.startsWith('//');
        const identity = (path: string) => windows ? norm(path).toLowerCase() : norm(path);
        const find = (nodes: FileNode[]): FileNode | undefined => {
          for (const node of nodes) {
            if (identity(node.path) === identity(target)) return node;
            const nested = node.children && find(node.children);
            if (nested) return nested;
          }
        };
        const found = find(get().tree);
        // A stale breadcrumb must not expand an unrelated partial ancestor path.
        if (!found) return;
        const openAlong = (nodes: FileNode[]): FileNode[] => nodes.map(node => {
          const current = identity(node.path), destination = identity(found.path);
          if (node.type === 'folder' && (current === destination || destination.startsWith(current + '/'))) {
            return {...node, isOpen:true, children:node.children && openAlong(node.children)};
          }
          return node;
        });
        set({tree:openAlong(get().tree)});
        get().setLastSelectedNode(found);
      },

      triggerHeaderNewFile: () => {
        const { rootPath, rootName, lastSelectedNode } = get();
        if (!rootPath) return;
        let parentNode: FileNode = { name: rootName, path: rootPath, type: 'folder' };
        if (lastSelectedNode) {
          if (lastSelectedNode.type === 'folder') {
            parentNode = lastSelectedNode;
          } else {
            const parentPath = parentDirectory(lastSelectedNode.path, rootPath) || rootPath;
            parentNode = { name: '', path: parentPath, type: 'folder' };
          }
        }
        get().revealPath(parentNode.path);
        set({
          inlineInput: {
            visible: true,
            nodePath: parentNode.path,
            mode: 'new-file',
            defaultValue: 'untitled.txt',
          },
        });
      },

      triggerHeaderNewFolder: () => {
        const { rootPath, rootName, lastSelectedNode } = get();
        if (!rootPath) return;
        let parentNode: FileNode = { name: rootName, path: rootPath, type: 'folder' };
        if (lastSelectedNode) {
          if (lastSelectedNode.type === 'folder') {
            parentNode = lastSelectedNode;
          } else {
            const parentPath = parentDirectory(lastSelectedNode.path, rootPath) || rootPath;
            parentNode = { name: '', path: parentPath, type: 'folder' };
          }
        }
        get().revealPath(parentNode.path);
        set({
          inlineInput: {
            visible: true,
            nodePath: parentNode.path,
            mode: 'new-folder',
            defaultValue: 'NewFolder',
          },
        });
      },

      pendingDelete: null,
      cancelDeleteNode: () => set({ pendingDelete: null }),
      confirmDeleteNode: async () => {
        const pd = get().pendingDelete;
        if (!pd) return;
        set({ pendingDelete: null });
        const { node, isFolder } = pd;
        const { rootPath } = get();
        try {
          await window.nexelAPI.deleteNode(node.path);
          const orphanedCount = useEditorStore.getState().markTabsOrphanedForPath(node.path, isFolder);
          if (orphanedCount > 0) {
            useStatusStore.getState().pushToast(
              `Deleted ${node.name}. ${orphanedCount} open tab${orphanedCount === 1 ? '' : 's'} kept ${orphanedCount === 1 ? 'its' : 'their'} buffer - save to recreate the file.`,
              'info',
              6000
            );
          }
          set((state) => ({
            pinnedPaths: state.pinnedPaths.filter((p) => p !== node.path),
          }));
          if (rootPath) await get().refreshTree();
        } catch (err) {
          console.error("Deletion failed:", err);
          const msg = err instanceof Error ? err.message : String(err);
          useStatusStore.getState().pushToast(
            `Could not delete ${node.name}${msg ? `: ${msg}` : ''}. Some files may remain.`,
            'error',
            6000
          );
          // A recursive folder delete can partially fail (permissions, I/O):
          // reconcile tree and open tabs with what actually remains on disk.
          if (rootPath) await get().refreshTree();
          const nodePath = node.path.replace(/\\/g, '/');
          const prefix = nodePath + '/';
          for (const t of useEditorStore.getState().tabs) {
            const p = t.filePath.replace(/\\/g, '/');
            if (!(isFolder ? p.startsWith(prefix) : p === nodePath)) continue;
            // Tree refresh can fail too. Only a confirmed missing path makes a
            // tab orphaned; permission and I/O errors do not prove deletion.
            try {
              await window.nexelAPI.readFileContent(t.filePath);
            } catch (readError) {
              // Error tokens belong to the error, never the path in its text.
              // Electron may wrap the message without preserving its code.
              const reason = readError instanceof Error
                ? readError.message.replace(/^Error invoking remote method '[^']+': (?:Error: )?/, '') : '';
              const missing = readError instanceof Error && ('code' in readError
                ? readError.code === 'ENOENT' || readError.code === 'ENOTDIR'
                : /^(?:ENOENT|ENOTDIR)(?=:|$)/.test(reason));
              if (missing) {
                useEditorStore.getState().markTabsOrphanedForPath(t.filePath, false);
              }
            }
          }
        }
      },
      handleDeleteNode: async (node) => {
        const isFolder = node.type === 'folder';
        const prefix = node.path.replace(/\\/g, '/') + '/';
        const dirtyOpen = useEditorStore.getState().tabs.filter((t) =>
          t.isDirty && (isFolder ? t.filePath.replace(/\\/g, '/').startsWith(prefix) : t.filePath === node.path)
        );
        set({ pendingDelete: { node, isFolder, dirtyNames: dirtyOpen.map((t) => t.filePath.split('/').pop() ?? '') } });
      },

      handleInlineSubmit: async (value) => {
        const { inlineInput, rootPath } = get();
        if (pendingInlineInputs.has(inlineInput)) return null;
        pendingInlineInputs.add(inlineInput);
        let succeeded = false;
        const stillCurrent = () => get().inlineInput === inlineInput && get().rootPath === rootPath;
        try {
          if (!value.trim() || value === '.' || value === '..' || /[/\\\0]/.test(value)) throw new Error('Choose a name without path separators.');
          let createdPath = '';
          const forceOpenPaths = new Set<string>();

          if (inlineInput.mode === 'new-file') {
            createdPath = await window.nexelAPI.createFile(inlineInput.nodePath, value);
            if (inlineInput.nodePath) {
              forceOpenPaths.add(inlineInput.nodePath.replace(/\\/g, '/'));
            }
            if (value.toLowerCase().endsWith('.cpp')) {
              const cppTemplate = useEditorStore.getState().cppTemplate;
              if (cppTemplate) {
                await window.nexelAPI.writeFileContent(createdPath, cppTemplate);
              }
            }
          } else if (inlineInput.mode === 'new-folder') {
            createdPath = await window.nexelAPI.createFolder(inlineInput.nodePath, value);
            if (inlineInput.nodePath) {
              forceOpenPaths.add(inlineInput.nodePath.replace(/\\/g, '/'));
            }
          } else if (inlineInput.mode === 'rename') {
            const oldPath = inlineInput.nodePath.replace(/\\/g, '/');
            const lastSlash = oldPath.lastIndexOf('/');
            if (lastSlash < 0) throw new Error('Could not find the parent folder for this rename.');
            const targetNewPath = `${oldPath.slice(0, lastSlash + 1)}${value}`;
            const release = await reserveFileMove(inlineInput.nodePath,stillCurrent);
            try { await window.nexelAPI.renameNode(inlineInput.nodePath, targetNewPath); } finally { release(); }

            get().relocatePinnedPaths(inlineInput.nodePath, targetNewPath, rootPath);
            get().relocateTreePaths(inlineInput.nodePath, targetNewPath, rootPath);
          }

          succeeded = true;
          if (!stillCurrent()) return null;
          if (rootPath) {
            await get().refreshTree(forceOpenPaths);
          }

          if (!stillCurrent()) return null;
          if (inlineInput.mode === 'new-file' && createdPath) {
            return createdPath.replace(/\\/g, '/');
          }
        } catch (err) {
          console.error("Inline fs write execution failed:", err);
          const reason = err instanceof Error ? err.message : String(err);
          const action = inlineInput.mode === 'rename' ? 'rename' : 'create';
          // EEXIST names the colliding new name; other failures name the file being renamed.
          const originalName = inlineInput.nodePath.split(/[\\/]/).pop() || value;
          useStatusStore.getState().pushToast(
            /\bEEXIST\b/.test(reason)
              ? `Could not ${action} "${value}": that name already exists. Existing content was not changed.`
              : `Could not ${action} "${inlineInput.mode === 'rename' ? originalName : value}"${reason ? `: ${reason}` : '.'}`,
            'error',
            6000
          );
        } finally {
          pendingInlineInputs.delete(inlineInput);
          if (succeeded && get().inlineInput === inlineInput) set({ inlineInput: { ...inlineInput, visible: false } });
        }
        return null;
      },
    }),
    {
      name: 'nexel-workspace-store',
      storage: createJSONStorage(() => electronStorage),
      partialize: (state) => ({
        rootPath: state.rootPath,
        rootName: state.rootName,
        activeDir: state.activeDir,
        pinnedPaths: state.pinnedPaths,
        recentWorkspaces: state.recentWorkspaces,
        searchQuery: state.searchQuery,
        isRegex: state.isRegex,
        isMatchCase: state.isMatchCase,
      }),
      // Persisted data is untrusted: validate every persisted key's shape.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Record<string, unknown>;
        const strOrNull = (v: unknown, d: string | null) => (typeof v === 'string' || v === null) ? v as string | null : d;
        const strArr = (v: unknown, d: string[]) => Array.isArray(v) && v.every((x) => typeof x === 'string') ? v : d;
        return { ...current,
          rootPath: strOrNull(p.rootPath, current.rootPath),
          rootName: typeof p.rootName === 'string' ? p.rootName : current.rootName,
          activeDir: strOrNull(p.activeDir, current.activeDir),
          pinnedPaths: strArr(p.pinnedPaths, current.pinnedPaths),
          recentWorkspaces: strArr(p.recentWorkspaces, current.recentWorkspaces),
          searchQuery: typeof p.searchQuery === 'string' ? p.searchQuery : current.searchQuery,
          isRegex: typeof p.isRegex === 'boolean' ? p.isRegex : current.isRegex,
          isMatchCase: typeof p.isMatchCase === 'boolean' ? p.isMatchCase : current.isMatchCase };
      },
    }
  )
);
