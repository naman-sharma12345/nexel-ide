import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { electronStorage } from './electronStorage';

export interface TestCase {
  id: number;
  name: string;
  input: string;
  expected: string;
  actual: string;
  verdict?: 'AC' | 'WA' | 'TLE' | 'MLE' | 'RE' | 'CE' | 'CANCELLED' | 'RUNNING' | 'IDLE';
  time?: number;
  memory?: number;
  memoryMeasured?: boolean;
  exitCode?: number | null;
  errorMsg?: string;
  resultSourcePath?: string;
}

interface JudgeState {
  testCases: TestCase[];
  activeTCId: number;
  activeTab: 'input' | 'expected' | 'actual' | 'diff';
  isRunning: boolean;
  
  addTestCase: () => void;
  deleteTestCase: (id: number) => void;
  updateTestCase: (id: number, fields: Partial<TestCase>) => void;
  setTestCases: (testCases: TestCase[]) => void;
  setActiveTCId: (id: number) => void;
  setActiveTab: (tab: 'input' | 'expected' | 'actual' | 'diff') => void;
  setRunning: (running: boolean) => void;
  importSamples: (samples: Array<{ input: string; output: string }>) => void;
}

const defaultTestCases: TestCase[] = [
  { id: 1, name: 'TC 1', input: '', expected: '', actual: '', verdict: 'IDLE' }
];

export const useJudgeStore = create<JudgeState>()(
  persist(
    (set, get) => ({
      testCases: defaultTestCases,
      activeTCId: 1,
      activeTab: 'input',
      isRunning: false,

      addTestCase: () => {
        const { testCases } = get();
        const nextId = testCases.length > 0 ? Math.max(...testCases.map((tc) => tc.id)) + 1 : 1;
        const newTC: TestCase = {
          id: nextId,
          name: `TC ${nextId}`,
          input: '',
          expected: '',
          actual: '',
          verdict: 'IDLE',
        };
        set({
          testCases: [...testCases, newTC],
          activeTCId: nextId,
        });
      },

      deleteTestCase: (idToDelete) => {
        const { testCases, activeTCId } = get();
        if (testCases.length <= 1) {
          alert("At least one testcase must remain.");
          return;
        }
        const updated = testCases.filter((tc) => tc.id !== idToDelete);
        let nextActiveId = activeTCId;
        if (activeTCId === idToDelete) {
          nextActiveId = updated[0].id;
        }
        set({
          testCases: updated,
          activeTCId: nextActiveId,
        });
      },

      updateTestCase: (id, fields) => {
        const { testCases } = get();
        set({
          testCases: testCases.map((tc) => {
            if (tc.id !== id) return tc;
            const changed = (fields.input !== undefined && fields.input !== tc.input) ||
              (fields.expected !== undefined && fields.expected !== tc.expected);
            const updated = { ...tc, ...fields };
            if (!changed) return updated;
            // Results describe the previous input/expected pair, not this edit.
            return { ...updated, verdict: 'IDLE' as const, actual: '', time: undefined,
              memory: undefined, memoryMeasured: undefined, exitCode: undefined, errorMsg: undefined, resultSourcePath: undefined };
          }),
        });
      },

      setTestCases: (testCases) => set({ testCases }),

      setActiveTCId: (activeTCId) => set({ activeTCId }),

      setActiveTab: (activeTab) => set({ activeTab }),

      setRunning: (isRunning) => set({ isRunning }),

      importSamples: (samples) => {
        const mapped: TestCase[] = samples.map((tc, idx) => ({
          id: idx + 1,
          name: `TC ${idx + 1}`,
          input: tc.input,
          expected: tc.output,
          actual: '',
          verdict: 'IDLE',
        }));
        set({
          testCases: mapped,
          activeTCId: 1,
          activeTab: 'input',
        });
      },
    }),
    {
      name: 'nexel-judge-store',
      storage: createJSONStorage(() => electronStorage),
      partialize: (state) => ({
        testCases: state.testCases,
        activeTCId: state.activeTCId,
        activeTab: state.activeTab,
      }),
      // Persisted data is untrusted: malformed test cases must not crash
      // addTestCase/render; drop bad entries, keep defaults if none survive.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<JudgeState>;
        const VERDICTS = ['AC', 'WA', 'TLE', 'MLE', 'RE', 'CE', 'CANCELLED', 'RUNNING', 'IDLE'];
        const cases = Array.isArray(p.testCases)
          ? p.testCases
              .filter((tc): tc is TestCase => !!tc && typeof tc === 'object'
                && typeof (tc as TestCase).id === 'number' && Number.isFinite((tc as TestCase).id)
                && typeof (tc as TestCase).input === 'string' && typeof (tc as TestCase).expected === 'string')
              .map((tc) => ({
                ...tc,
                name: typeof tc.name === 'string' ? tc.name : `TC ${tc.id}`,
                actual: typeof tc.actual === 'string' ? tc.actual : '',
                resultSourcePath: typeof tc.resultSourcePath === 'string' && tc.resultSourcePath && !tc.resultSourcePath.includes('\0') ? tc.resultSourcePath : undefined,
                // A persisted RUNNING can never be live: the run died with the last
                // session, so hydrate it as IDLE instead of a permanent spinner.
                verdict: tc.verdict === 'RUNNING' ? 'IDLE' : (VERDICTS.includes(tc.verdict as string) ? tc.verdict : 'IDLE'),
              }))
          : current.testCases;
        const ids = new Set<number>();
        const deduped = cases.filter((tc) => !ids.has(tc.id) && (ids.add(tc.id), true));
        const tabs = ['input', 'expected', 'actual', 'diff'];
        return { ...current,
          testCases: deduped.length ? deduped : current.testCases,
          activeTCId: typeof p.activeTCId === 'number' && deduped.some((tc) => tc.id === p.activeTCId) ? p.activeTCId : (deduped[0]?.id ?? current.activeTCId),
          activeTab: tabs.includes(p.activeTab as string) ? (p.activeTab as JudgeState['activeTab']) : current.activeTab };
      },
    }
  )
);
