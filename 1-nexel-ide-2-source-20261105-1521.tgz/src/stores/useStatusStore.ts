import { create } from 'zustand';

export type ToastKind = 'success' | 'error' | 'info';
export interface Toast { id: number; kind: ToastKind; message: string; }

interface StatusState {
  line: number;
  col: number;
  selected: number;
  cursors: Record<string, {line: number; col: number; selected: number; count?: number}>;
  toasts: Toast[];
  setCursor: (line: number, col: number, selected?: number, filePath?: string, count?: number) => void;
  retainCursors: (filePaths: string[]) => void;
  pushToast: (message: string, kind?: ToastKind, ttlMs?: number) => number;
  dismissToast: (id: number) => void;
}

let nextId = 1;
const MAX_TOASTS = 4; // bounded queue: never let a burst of events flood the screen

export const useStatusStore = create<StatusState>()((set, get) => ({
  line: 1,
  col: 1,
  selected: 0,
  cursors: {},
  toasts: [],
  setCursor: (line, col, selected = 0, filePath, count = 1) => {
    const s = get();
    if (s.line === line && s.col === col && s.selected === selected && (!filePath || (s.cursors[filePath]?.line === line && s.cursors[filePath]?.col === col && s.cursors[filePath]?.selected === selected && (s.cursors[filePath]?.count ?? 1) === count))) return; // skip no-op renders
    set({ line, col, selected, ...(filePath ? {cursors:{...s.cursors,[filePath]:{line,col,selected,...(count > 1 ? {count} : {})}}} : {}) });
  },
  retainCursors: (filePaths) => {
    const cursors = get().cursors;
    const retained = new Set(filePaths);
    const entries = Object.entries(cursors);
    if (entries.every(([path]) => retained.has(path))) return;
    set({cursors: Object.fromEntries(entries.filter(([path]) => retained.has(path)))});
  },
  pushToast: (message, kind = 'info', ttlMs = 2600) => {
    const id = nextId++;
    set(s => ({ toasts: [...s.toasts.filter(t => t.message !== message).slice(-(MAX_TOASTS - 1)), { id, kind, message }] }));
    if (ttlMs > 0) setTimeout(() => get().dismissToast(id), ttlMs);
    return id;
  },
  dismissToast: (id) => set(s => ({ toasts: s.toasts.filter(t => t.id !== id) })),
}));
