import { beforeEach, expect, it, vi } from 'vitest';
import { useWorkspaceStore as store, type FileNode } from '../useWorkspaceStore';
const deferred = <T,>() => {let resolve!: (v:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};};
const file = (path:string):FileNode => ({path,name:path.split('/').pop()!,type:'file'});
beforeEach(()=>{store.setState({rootPath:null,tree:[],lastSelectedNode:null,activeDir:null});});
it('rejects late results from the previous workspace',async()=>{
 const old=deferred<FileNode[]>(),fresh=deferred<FileNode[]>();
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
 store.getState().setRootPath('/old');const first=store.getState().refreshTree();
 store.getState().setRootPath('/new');const second=store.getState().refreshTree();
 fresh.resolve([file('/new/current.py')]);await second;old.resolve([file('/old/stale.py')]);await first;
 expect(store.getState().tree.map(n=>n.path)).toEqual(['/new/current.py']);
});
it('latest same-root refresh wins even when reads finish in reverse',async()=>{
 const old=deferred<FileNode[]>(),fresh=deferred<FileNode[]>();
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
 store.getState().setRootPath('/root');const first=store.getState().refreshTree(),second=store.getState().refreshTree();
 fresh.resolve([file('/root/current.py')]);await second;old.resolve([file('/root/deleted.py')]);await first;
 expect(store.getState().tree.map(n=>n.path)).toEqual(['/root/current.py']);
});
it('preserves folder toggles made while refresh is in flight',async()=>{
 const read=deferred<FileNode[]>();window.nexelAPI.readWorkspaceFiles=vi.fn().mockReturnValue(read.promise);
 const folder:FileNode={path:'/root/src',name:'src',type:'folder',children:[],isOpen:false};
 store.getState().setRootPath('/root');store.setState({tree:[folder]});const refreshing=store.getState().refreshTree();
 store.getState().toggleFolder(folder.path);read.resolve([folder]);await refreshing;
 expect(store.getState().tree[0].isOpen).toBe(true);
});

it('clears old tree, selection and pending actions on workspace change',()=>{
 const node=file('/old/x.py');store.setState({rootPath:'/old',tree:[node],lastSelectedNode:node,pendingDelete:{node,isFolder:false,dirtyNames:[]},inlineInput:{visible:true,nodePath:'/old',mode:'new-file',defaultValue:''}});
 store.getState().setRootPath('/new');
 expect(store.getState()).toMatchObject({tree:[],lastSelectedNode:null,pendingDelete:null,inlineInput:{visible:false},activeDir:'/new'});
});
it('exposes loading, reports failure, and clears error on successful retry',async()=>{
 store.getState().setRootPath('/root');const read=deferred<FileNode[]>();
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockReturnValueOnce(read.promise);
 const loading=store.getState().refreshTree();expect(store.getState().isTreeLoading).toBe(true);
 read.resolve([]);await loading;expect(store.getState()).toMatchObject({isTreeLoading:false,treeError:null,tree:[]});
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockRejectedValueOnce(new Error('EACCES'));
 await store.getState().refreshTree();expect(store.getState().treeError).toContain('Could not load');
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockResolvedValueOnce([]);
 await store.getState().refreshTree();expect(store.getState()).toMatchObject({treeError:null,isTreeLoading:false});
});
it('clears removed selection so new files target current workspace root',async()=>{
 const removed:FileNode={path:'/root/deleted',name:'deleted',type:'folder',children:[]};
 store.getState().setRootPath('/root');store.setState({tree:[removed]});store.getState().setLastSelectedNode(removed);
 window.nexelAPI.readWorkspaceFiles=vi.fn().mockResolvedValue([]);
 await store.getState().refreshTree();
 expect(store.getState().lastSelectedNode).toBeNull();expect(store.getState().activeDir).toBe('/root');
 store.getState().triggerHeaderNewFile();expect(store.getState().inlineInput.nodePath).toBe('/root');
});
it.each(['triggerHeaderNewFile','triggerHeaderNewFolder'] as const)('shows %s inside a selected closed folder instead of hiding its input',action=>{
 const folder:FileNode={path:'/root/src',name:'src',type:'folder',isOpen:false,children:[]};store.setState({rootPath:'/root',tree:[folder],lastSelectedNode:folder});store.getState()[action]();expect(store.getState().tree[0].isOpen).toBe(true);expect(store.getState().inlineInput.nodePath).toBe('/root/src');
});
it.each(['triggerHeaderNewFile','triggerHeaderNewFolder'] as const)('uses a selected Windows file parent for %s',action=>{
 store.setState({rootPath:'C:\\work',tree:[],lastSelectedNode:{path:'C:\\work\\src\\main.py',name:'main.py',type:'file'}});store.getState()[action]();expect(store.getState().inlineInput.nodePath).toBe('C:/work/src');
});
it('updates active creation directory when revealing a previously hidden file',()=>{
 const child=file('/root/src/main.py');store.setState({rootPath:'/root',tree:[{path:'/root/src',name:'src',type:'folder',isOpen:false,children:[child]}],lastSelectedNode:null,activeDir:'/root'});store.getState().revealPath(child.path);expect(store.getState().tree[0].isOpen).toBe(true);expect(store.getState().lastSelectedNode?.path).toBe(child.path);expect(store.getState().activeDir).toBe('/root/src');
});
it.each(['/main.py','C:\\main.py'])('does not lose the root separator when selecting %s',path=>{
 store.setState({rootPath:path.startsWith('C:')?'C:/':'/',activeDir:null});store.getState().setLastSelectedNode(file(path));expect(store.getState().activeDir).toBe(path.startsWith('C:')?'C:/':'/');
});
it('moves hidden descendant selection to the collapsed ancestor and fixes creation context',()=>{
 const selected=file('/root/src/deep/main.py');const deep:FileNode={path:'/root/src/deep',name:'deep',type:'folder',isOpen:true,children:[selected]};store.setState({rootPath:'/root',tree:[{path:'/root/src',name:'src',type:'folder',isOpen:true,children:[deep]}],lastSelectedNode:selected,activeDir:'/root/src/deep'});store.getState().toggleFolder('/root/src');expect(store.getState().lastSelectedNode?.path).toBe('/root/src');expect(store.getState().activeDir).toBe('/root/src');
});
it('collapse all keeps selection on the visible top ancestor and preserves unrelated file selection',()=>{
 const selected=file('/root/src/main.py'),outside=file('/root/outside.py');store.setState({rootPath:'/root',tree:[{path:'/root/src',name:'src',type:'folder',isOpen:true,children:[selected]},outside],lastSelectedNode:selected});store.getState().collapseAllFolders();expect(store.getState().lastSelectedNode?.path).toBe('/root/src');store.getState().setLastSelectedNode(outside);store.getState().collapseAllFolders();expect(store.getState().lastSelectedNode).toEqual(outside);
});
it('refresh repairs a selected row that is inside an already-closed ancestor',async()=>{
 const selected=file('/root/src/main.py');store.setState({rootPath:'/root',tree:[{path:'/root/src',name:'src',type:'folder',isOpen:false,children:[selected]}],lastSelectedNode:selected,activeDir:'/root/src'});window.nexelAPI.readWorkspaceFiles=vi.fn().mockResolvedValue([{path:'/root/src',name:'src',type:'folder',children:[selected]}]);await store.getState().refreshTree();expect(store.getState().lastSelectedNode?.path).toBe('/root/src');expect(store.getState().tree[0].isOpen).toBe(false);
});
