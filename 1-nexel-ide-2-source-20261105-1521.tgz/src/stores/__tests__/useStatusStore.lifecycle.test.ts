import {beforeEach, describe, expect, it} from 'vitest';
import {useEditorStore} from '../useEditorStore';
import {useStatusStore} from '../useStatusStore';

beforeEach(() => {
  useEditorStore.setState({tabs: [], activeTabPath: null, focusedTabPath: null, isSplit: false, rightTabPath: null});
  useStatusStore.setState({cursors: {}, line: 1, col: 1, selected: 0});
});
const open = (path: string) => {
  useEditorStore.getState().openFile(path, path, 'text');
  useStatusStore.getState().setCursor(3, 7, 2, path);
};
describe('cursor lifetime follows open documents', () => {
  it('does not accumulate entries across 1000 sequential document closes', () => {
    for (let i = 0; i < 1000; i++) {
      const path = `/tmp/document-${i}.py`;
      open(path);
      useEditorStore.getState().closeTab(path);
    }
    expect(Object.keys(useStatusStore.getState().cursors)).toHaveLength(0);
  });
  it('keeps a surviving split document cursor', () => {
    open('/left.py'); open('/right.py');
    useEditorStore.getState().toggleSplit('/right.py');
    useEditorStore.getState().closeTab('/left.py');
    expect(useStatusStore.getState().cursors).toEqual({'/right.py': {line: 3, col: 7, selected: 2}});
  });
  it('close saved retains only dirty document cursor', () => {
    open('/saved.py'); open('/dirty.py');
    useEditorStore.getState().updateTabContent('/dirty.py', 'changed');
    useEditorStore.getState().closeSavedTabs();
    expect(Object.keys(useStatusStore.getState().cursors)).toEqual(['/dirty.py']);
  });
  it('close all clears cursor records', () => {
    open('/first.py'); open('/second.py');
    useEditorStore.getState().closeAllTabs();
    expect(useStatusStore.getState().cursors).toEqual({});
  });
  it('pruning an unchanged path set does not notify subscribers', () => {
    open('/keep.py');
    const previous = useStatusStore.getState();
    useStatusStore.getState().retainCursors(['/keep.py']);
    expect(useStatusStore.getState()).toBe(previous);
  });
});

it('notifies when cursor count changes even if primary position and selected length match', () => {
  open('/multi.py');
  useStatusStore.getState().setCursor(3, 7, 2, '/multi.py', 2);
  expect(useStatusStore.getState().cursors['/multi.py'].count).toBe(2);
  const previous = useStatusStore.getState();
  useStatusStore.getState().setCursor(3, 7, 2, '/multi.py', 2);
  expect(useStatusStore.getState()).toBe(previous);
  useStatusStore.getState().setCursor(3, 7, 2, '/multi.py', 1);
  expect(useStatusStore.getState().cursors['/multi.py'].count).toBeUndefined();
});

it('close saved is a true no-op when both split documents are dirty',()=>{open('/left');open('/right');useEditorStore.getState().updateTabContent('/left','dirty');useEditorStore.getState().updateTabContent('/right','dirty');useEditorStore.setState({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});const prior=useEditorStore.getState();useEditorStore.getState().closeSavedTabs();expect(useEditorStore.getState()).toBe(prior);});
it('close saved preserves right focus when another saved document closes',()=>{open('/saved');open('/left');open('/right');for(const path of ['/left','/right'])useEditorStore.getState().updateTabContent(path,'dirty');useEditorStore.setState({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});useEditorStore.getState().closeSavedTabs();expect(useEditorStore.getState()).toMatchObject({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});});
it('close saved promotes the only dirty right document without duplicate panes',()=>{open('/left');open('/right');useEditorStore.getState().updateTabContent('/right','dirty');useEditorStore.setState({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});useEditorStore.getState().closeSavedTabs();expect(useEditorStore.getState()).toMatchObject({activeTabPath:'/right',focusedTabPath:'/right',rightTabPath:null,isSplit:false});});
