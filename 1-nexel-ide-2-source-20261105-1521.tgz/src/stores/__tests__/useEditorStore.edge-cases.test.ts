import { describe, it, expect, beforeEach } from 'vitest';
import { useEditorStore } from '../useEditorStore';

describe('useEditorStore concurrency and edge cases', () => {
  beforeEach(() => {
    // Reset Zustand store state before each test
    useEditorStore.setState({
      tabs: [],
      activeTabPath: null,
      isSplit: false,
      rightTabPath: null,
      splitRatio: 50,
      autoSave: false,
      cppTemplate: '',
      enableSnippets: true,
      acCelebration: false
    });
  });

  it('handles rapid open and close operations without desyncing tabs list (Test A)', () => {
    // 1. Open File A
    useEditorStore.getState().openFile('C:/project/FileA.cpp', 'FileA.cpp', 'content A');
    
    // 2. Open File B (simulating rapid user click)
    useEditorStore.getState().openFile('C:/project/FileB.cpp', 'FileB.cpp', 'content B');
    
    // 3. Close File A
    useEditorStore.getState().closeTab('C:/project/FileA.cpp');

    const state = useEditorStore.getState();

    // Verify File A is completely removed, tabs count is 1, and activeTab falls back to File B
    expect(state.tabs.length).toBe(1);
    expect(state.tabs[0].filePath).toBe('C:/project/FileB.cpp');
    expect(state.activeTabPath).toBe('C:/project/FileB.cpp');
  });

  it('manages tab dirty state and originalContent on update and successful save (Test B)', () => {
    // 1. Open empty file
    useEditorStore.getState().openFile('C:/project/code.cpp', 'code.cpp', 'initial');

    // 2. Update buffer content (isDirty should flip to true)
    useEditorStore.getState().updateTabContent('C:/project/code.cpp', 'modified content');
    let state = useEditorStore.getState();
    expect(state.tabs[0].isDirty).toBe(true);

    // 3. Revert back to match originalContent (isDirty should revert to false)
    useEditorStore.getState().updateTabContent('C:/project/code.cpp', 'initial');
    state = useEditorStore.getState();
    expect(state.tabs[0].isDirty).toBe(false);

    // 4. Update content again and save
    useEditorStore.getState().updateTabContent('C:/project/code.cpp', 'saved changes');
    useEditorStore.getState().saveTabSuccess('C:/project/code.cpp');
    state = useEditorStore.getState();

    // Verify isDirty resets to false and originalContent updates to match new content
    expect(state.tabs[0].isDirty).toBe(false);
    expect(state.tabs[0].originalContent).toBe('saved changes');
    expect(state.tabs[0].content).toBe('saved changes');
  });
});

it('closing an unrelated tab keeps focused right document and left model',()=>{
 const s=useEditorStore; s.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});
 for(const name of ['left','right','third'])s.getState().openFile('/'+name,name,'content');
 s.setState({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});
 s.getState().closeTab('/third');expect(s.getState()).toMatchObject({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});
});
it('closing left chooses another left tab, or folds remaining right into single editor',()=>{
 const s=useEditorStore;s.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});
 for(const name of ['left','third','right'])s.getState().openFile('/'+name,name,'content');
 s.setState({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});
 s.getState().closeTab('/left');expect(s.getState()).toMatchObject({activeTabPath:'/third',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});
 s.getState().closeTab('/third');expect(s.getState()).toMatchObject({activeTabPath:'/right',focusedTabPath:'/right',rightTabPath:null,isSplit:false});
});
it('reopening a right-owned document focuses it without replacing left',()=>{
 const s=useEditorStore;s.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});
 for(const name of ['left','right'])s.getState().openFile('/'+name,name,'original');
 s.setState({activeTabPath:'/left',focusedTabPath:'/left',rightTabPath:'/right',isSplit:true});
 s.getState().updateTabContent('/right','unsaved');s.getState().openFile('/right','right','stale disk');
 expect(s.getState()).toMatchObject({activeTabPath:'/left',focusedTabPath:'/right',rightTabPath:'/right',isSplit:true});
 expect(s.getState().tabs.find(t=>t.filePath==='/right')?.content).toBe('unsaved');
});

describe('stale save completion', () => {
  it('edits typed after the save snapshot stay dirty when the snapshot lands', () => {
    const store = useEditorStore.getState();
    store.openFile('C:/project/stale.py', 'stale.py', 'v1\n');
    store.updateTabContent('C:/project/stale.py', 'v1\n# snapshot\n');
    // simulate newer typing while the snapshot write is in flight
    store.updateTabContent('C:/project/stale.py', 'v1\n# snapshot\n# newer\n');
    useEditorStore.getState().saveTabSuccess('C:/project/stale.py', 'v1\n# snapshot\n');
    const tab = useEditorStore.getState().tabs.find(t => t.filePath === 'C:/project/stale.py');
    expect(tab?.isDirty).toBe(true);
    expect(tab?.originalContent).toBe('v1\n# snapshot\n');
  });
  it('a matching completion clears the external-conflict badge', () => {
    const store = useEditorStore.getState();
    store.openFile('C:/project/conf.py', 'conf.py', 'v1\n');
    store.updateTabContent('C:/project/conf.py', 'v2\n');
    useEditorStore.getState().markExternalConflict('C:/project/conf.py');
    expect(useEditorStore.getState().tabs.find(t => t.filePath === 'C:/project/conf.py')?.hasExternalConflict).toBe(true);
    useEditorStore.getState().saveTabSuccess('C:/project/conf.py', 'v2\n');
    const tab = useEditorStore.getState().tabs.find(t => t.filePath === 'C:/project/conf.py');
    expect(tab?.hasExternalConflict).toBe(false);
    expect(tab?.isDirty).toBe(false);
  });
});
