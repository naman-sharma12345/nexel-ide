import { describe, it, expect, beforeEach } from 'vitest';
import { useEditorStore } from '../useEditorStore';

describe('useEditorStore state management', () => {
  beforeEach(() => {
    // Reset Zustand store state before each test
    useEditorStore.getState().closeAllTabs();
  });

  it('verifies openFile adds a tab, updates activeTabPath, and isDirty is false', () => {
    const store = useEditorStore.getState();
    expect(store.tabs.length).toBe(0);
    expect(store.activeTabPath).toBeNull();

    // Open first file
    useEditorStore.getState().openFile('C:/project/main.cpp', 'main.cpp', 'int main() {}');
    
    const updatedStore = useEditorStore.getState();
    expect(updatedStore.tabs.length).toBe(1);
    expect(updatedStore.tabs[0].filePath).toBe('C:/project/main.cpp');
    expect(updatedStore.tabs[0].name).toBe('main.cpp');
    expect(updatedStore.tabs[0].content).toBe('int main() {}');
    expect(updatedStore.tabs[0].isDirty).toBe(false);
    expect(updatedStore.activeTabPath).toBe('C:/project/main.cpp');
  });

  it('verifies updateTabContent handles dirty states correctly', () => {
    // Open file
    useEditorStore.getState().openFile('C:/project/main.cpp', 'main.cpp', 'int main() {}');

    // Update with changes
    useEditorStore.getState().updateTabContent('C:/project/main.cpp', 'int main() { return 0; }');
    let store = useEditorStore.getState();
    expect(store.tabs[0].content).toBe('int main() { return 0; }');
    expect(store.tabs[0].isDirty).toBe(true);

    // Revert changes back to originalContent
    useEditorStore.getState().updateTabContent('C:/project/main.cpp', 'int main() {}');
    store = useEditorStore.getState();
    expect(store.tabs[0].isDirty).toBe(false);
  });

  it('verifies closeTab removes the tab and activeTabPath falls back to last tab or null', () => {
    // Open 3 files
    useEditorStore.getState().openFile('1.cpp', '1.cpp', '1');
    useEditorStore.getState().openFile('2.cpp', '2.cpp', '2');
    useEditorStore.getState().openFile('3.cpp', '3.cpp', '3');

    let store = useEditorStore.getState();
    expect(store.tabs.length).toBe(3);
    expect(store.activeTabPath).toBe('3.cpp');

    // Close 3.cpp -> active falls back to 2.cpp
    useEditorStore.getState().closeTab('3.cpp');
    store = useEditorStore.getState();
    expect(store.tabs.length).toBe(2);
    expect(store.activeTabPath).toBe('2.cpp');

    // Close 1.cpp -> active tab remains 2.cpp
    useEditorStore.getState().closeTab('1.cpp');
    store = useEditorStore.getState();
    expect(store.tabs.length).toBe(1);
    expect(store.activeTabPath).toBe('2.cpp');

    // Close 2.cpp -> active tab becomes null
    useEditorStore.getState().closeTab('2.cpp');
    store = useEditorStore.getState();
    expect(store.tabs.length).toBe(0);
    expect(store.activeTabPath).toBeNull();
  });
});

 it('reopening Snippets requests search focus without duplicating its tab', () => {
  useEditorStore.getState().closeAllTabs();
  useEditorStore.getState().openSnippets();
  const request = useEditorStore.getState().snippetsFocusRequest;
  useEditorStore.getState().openSnippets();
  expect(useEditorStore.getState().tabs).toHaveLength(1);
  expect(useEditorStore.getState().snippetsFocusRequest).toBe(request + 1);
 });
 it('reopening right-pane Snippets preserves the left document and split', () => {
  useEditorStore.getState().closeAllTabs();
  useEditorStore.getState().openFile('/fixture/source.cpp','source.cpp','untouched');
  useEditorStore.getState().openSnippets();
  useEditorStore.setState({isSplit:true,rightTabPath:'nexel://snippets',activeTabPath:'/fixture/source.cpp',focusedTabPath:'/fixture/source.cpp'});
  useEditorStore.getState().openSnippets();
  expect(useEditorStore.getState()).toMatchObject({activeTabPath:'/fixture/source.cpp',focusedTabPath:'nexel://snippets',rightTabPath:'nexel://snippets',isSplit:true});
  expect(useEditorStore.getState().tabs[0].content).toBe('untouched');
  useEditorStore.getState().closeAllTabs();
 });

it('reopening a right-pane problem preserves the left source instead of blanking it',()=>{
 useEditorStore.getState().closeAllTabs();useEditorStore.getState().openFile('/fixture/left.cpp','left.cpp','left source');useEditorStore.getState().openCfProblem(123,{index:'A',title:'Fixture'});useEditorStore.setState({isSplit:true,rightTabPath:'cf://123/A',activeTabPath:'/fixture/left.cpp',focusedTabPath:'/fixture/left.cpp'});useEditorStore.getState().openCfProblem(123,{index:'A',title:'Fixture'});expect(useEditorStore.getState()).toMatchObject({isSplit:true,rightTabPath:'cf://123/A',activeTabPath:'/fixture/left.cpp',focusedTabPath:'cf://123/A'});expect(useEditorStore.getState().tabs).toHaveLength(2);useEditorStore.getState().closeAllTabs();
});

it('refreshes existing read-only problem data without duplicating tabs',()=>{useEditorStore.getState().closeAllTabs();useEditorStore.getState().openCfProblem(123,{index:'A',title:'Old statement',statement:'old'});useEditorStore.getState().openCfProblem(123,{index:'A',title:'New statement',statement:'fresh'});const s=useEditorStore.getState();expect(s.tabs).toHaveLength(1);expect(JSON.parse(s.tabs[0].content).statement).toBe('fresh');expect(s.tabs[0].originalContent).toBe(s.tabs[0].content);expect(s.tabs[0].isDirty).toBe(false);useEditorStore.getState().closeAllTabs();});
