import { beforeEach, expect, it } from 'vitest';
import { useWorkspaceStore as store } from '../useWorkspaceStore';
import { createOpenRequestGuard } from '../../lib/openRequest';
// Binds the production wiring the App open-request guard relies on: ANY
// setRootPath call must invalidate pending document reads, so a slow read
// started before a workspace transition can never open its stale result into
// the transitioned workspace - including a same-root close/reopen, where the
// guard's captured workspace string alone would still compare equal.
beforeEach(()=>{store.setState({rootPath:null,tree:[],lastSelectedNode:null,activeDir:null});});
it('switching to a different root invalidates a pending document read',()=>{
 store.getState().setRootPath('/wk');
 const guard=createOpenRequestGuard(),pending=guard.begin(store.getState().rootPath);
 store.getState().setRootPath('/other');
 expect(pending(store.getState().rootPath)).toBe(false);
});
it('reopening the SAME root also invalidates a pending document read',()=>{
 store.getState().setRootPath('/wk');
 const guard=createOpenRequestGuard(),pending=guard.begin(store.getState().rootPath);
 store.getState().setRootPath('/wk');
 expect(pending(store.getState().rootPath)).toBe(false);
});
