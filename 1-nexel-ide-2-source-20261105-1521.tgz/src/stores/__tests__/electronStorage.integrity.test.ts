import { describe, it, expect, vi, beforeEach } from 'vitest';
import { electronStorage } from '../electronStorage';

describe('electronStorage Zustand persistence adapter integrity', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    
    // Setup clean window.nexelAPI mock environment for integrity checks
    (global as any).window = {
      nexelAPI: {
        getStoreSync: vi.fn(),
        setStoreSync: vi.fn().mockReturnValue(true),
        deleteStoreSync: vi.fn().mockReturnValue(true),
      }
    };
  });

  it('prevents duplicate disk operations via Write Cache optimization (Test A)', () => {
    const mockSet = window.nexelAPI.setStoreSync as any;
    
    const jsonPayload = '{"theme":"cyberpunk","fontSize":14}';

    // First write should trigger disk operation (IPC)
    electronStorage.setItem('preferences-key', jsonPayload);
    expect(mockSet).toHaveBeenCalledTimes(1);
    expect(mockSet).toHaveBeenLastCalledWith('preferences-key', { theme: 'cyberpunk', fontSize: 14 });

    // Second write with identical payload should trigger write cache hit, skipping disk operation
    electronStorage.setItem('preferences-key', jsonPayload);
    expect(mockSet).toHaveBeenCalledTimes(1); // Call count should remain 1
  });

  it('handles invalid JSON payloads gracefully by falling back to raw string storage (Test B)', () => {
    const mockSet = window.nexelAPI.setStoreSync as any;

    const invalidJson = 'malformed-raw-string-preferences';

    // Verify it doesn't throw and safely falls back
    expect(() => {
      electronStorage.setItem('invalid-key', invalidJson);
    }).not.toThrow();

    expect(mockSet).toHaveBeenCalledTimes(1);
    expect(mockSet).toHaveBeenLastCalledWith('invalid-key', invalidJson);
  });
});

it('retries an identical payload after a failed write rather than caching it',()=>{
 const set=vi.fn().mockImplementationOnce(()=>{throw Error('disk unavailable');}).mockImplementation(()=>true);
 window.nexelAPI.setStoreSync=set;
 electronStorage.setItem('failed-write-retry','{"fontSize":15}');
 electronStorage.setItem('failed-write-retry','{"fontSize":15}');
 expect(set).toHaveBeenCalledTimes(2);
});
it('rejects false acknowledgements and keeps identical payload retryable',()=>{
 const set=vi.fn().mockReturnValueOnce(false).mockReturnValue(true);window.nexelAPI.setStoreSync=set;
 electronStorage.setItem('false-write-retry','{"fontSize":16}');electronStorage.setItem('false-write-retry','{"fontSize":16}');electronStorage.setItem('false-write-retry','{"fontSize":16}');
 expect(set).toHaveBeenCalledTimes(2);
});
it('invalidates cached success when a later read confirms the key is absent',()=>{
 const set=vi.fn().mockReturnValue(true);window.nexelAPI.setStoreSync=set;window.nexelAPI.getStoreSync=vi.fn().mockReturnValue(null);
 electronStorage.setItem('removed-key','{"fontSize":18}');expect(electronStorage.getItem('removed-key')).toBeNull();electronStorage.setItem('removed-key','{"fontSize":18}');expect(set).toHaveBeenCalledTimes(2);
});
it('keeps removal failure retryable and invalidates cache after confirmed removal',()=>{
 const set=vi.fn().mockReturnValue(true),del=vi.fn().mockReturnValueOnce(false).mockReturnValue(true);window.nexelAPI.setStoreSync=set;window.nexelAPI.deleteStoreSync=del;
 electronStorage.setItem('remove-retry','{"fontSize":19}');electronStorage.removeItem('remove-retry');electronStorage.removeItem('remove-retry');electronStorage.setItem('remove-retry','{"fontSize":19}');expect(del).toHaveBeenCalledTimes(2);expect(set).toHaveBeenCalledTimes(2);
});
