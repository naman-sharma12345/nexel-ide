import { describe, it, expect } from 'vitest';
import { useSettingsStore } from '../useSettingsStore';
import { useJudgeStore } from '../useJudgeStore';
import { useEditorStore } from '../useEditorStore';
import { useUIStore } from '../useUIStore';
import { useWorkspaceStore } from '../useWorkspaceStore';

// Invoke each store's actual wired persist merge with corrupt payloads.
const mergeOf = (store: any) => store.persist.getOptions().merge as (p: unknown, c: any) => any;

describe('persisted-state merge validation (corrupt config keys)', () => {
  it('settings: garbage fontSize/theme/booleans/plugins fall back, valid values kept', () => {
    const cur = useSettingsStore.getState();
    const m = mergeOf(useSettingsStore)({ theme: 'nonexistent', fontSize: 'huge', tabSize: 999, minimap: 'yes', plugins: { a: 1 }, cppStd: 'c++99', clangdFlags: ' -Wall  ' }, cur);
    expect(m.theme).toBe(cur.theme);
    expect(m.fontSize).toBe(cur.fontSize);
    expect(m.tabSize).toBe(8); // finite but out-of-range clamps like the setter
    expect(m.minimap).toBe(cur.minimap);
    expect(m.plugins).toEqual(cur.plugins);
    expect(m.cppStd).toBe(cur.cppStd);
    const ok = mergeOf(useSettingsStore)({ theme: 'midnight', fontSize: 18, minimap: true }, cur);
    expect(ok.theme).toBe('midnight');
    expect(ok.fontSize).toBe(18);
    expect(ok.minimap).toBe(true);
  });

  it('judge: malformed test cases dropped, duplicates removed, defaults survive total garbage', () => {
    const cur = useJudgeStore.getState();
    const m = mergeOf(useJudgeStore)({ testCases: [{ id: 'x' }, { id: 2, input: 'a', expected: 'b' }, { id: 2, input: 'dup', expected: 'dup' }, null], activeTCId: 99, activeTab: 'nope' }, cur);
    expect(m.testCases).toHaveLength(1);
    expect(m.testCases[0].id).toBe(2);
    expect(m.testCases[0].input).toBe('a');
    expect(m.activeTCId).toBe(2); // 99 not in cases -> first surviving
    expect(m.activeTab).toBe(cur.activeTab);
    // a quit-during-run leaves verdict RUNNING on disk; hydration must not resurrect a spinner
    const running = mergeOf(useJudgeStore)({ testCases: [{ id: 5, input: 'a', expected: 'b', verdict: 'RUNNING' }] }, cur);
    expect(running.testCases[0].verdict).toBe('IDLE');
    expect(mergeOf(useJudgeStore)({testCases:[{id:6,input:'',expected:'',verdict:'CE'}]},cur).testCases[0].verdict).toBe('CE');
    const total = mergeOf(useJudgeStore)({ testCases: 'broken', activeTCId: 'x' }, cur);
    expect(total.testCases).toStrictEqual(cur.testCases);
    // addTestCase must not crash on the merged state
    expect(() => Math.max(...m.testCases.map((t: any) => t.id))).not.toThrow();
  });

  it('editor: wrong types fall back to defaults', () => {
    const cur = useEditorStore.getState();
    const m = mergeOf(useEditorStore)({ autoSave: 'yes', cppTemplate: 42, enableSnippets: null }, cur);
    expect(m.autoSave).toBe(cur.autoSave);
    expect(m.cppTemplate).toBe(cur.cppTemplate);
    expect(m.enableSnippets).toBe(cur.enableSnippets);
    const ok = mergeOf(useEditorStore)({ autoSave: true, cppTemplate: '// t' }, cur);
    expect(ok.autoSave).toBe(true);
    expect(ok.cppTemplate).toBe('// t');
  });

  it('ui: garbage section/toggles fall back; modal never resurrected', () => {
    const cur = useUIStore.getState();
    const m = mergeOf(useUIStore)({ currentSection: 42, sidebarCollapsed: 'x', templateModalVisible: true }, cur);
    expect(m.currentSection).toBe(cur.currentSection);
    expect(m.sidebarCollapsed).toBe(cur.sidebarCollapsed);
    expect(m.templateModalVisible).toBe(false);
  });

  it('workspace: bad arrays/strings fall back, valid kept', () => {
    const cur = useWorkspaceStore.getState();
    const m = mergeOf(useWorkspaceStore)({ rootPath: 42, pinnedPaths: ['/ok', 7], recentWorkspaces: 'nope', isRegex: 'y' }, cur);
    expect(m.rootPath).toBe(cur.rootPath);
    expect(m.pinnedPaths).toBe(cur.pinnedPaths);
    expect(m.recentWorkspaces).toEqual(cur.recentWorkspaces);
    expect(m.isRegex).toBe(cur.isRegex);
    const ok = mergeOf(useWorkspaceStore)({ pinnedPaths: ['/a'], isRegex: true }, cur);
    expect(ok.pinnedPaths).toEqual(['/a']);
    expect(ok.isRegex).toBe(true);
  });
});

describe('persisted-state merge: valid roundtrip, partial corruption, hostile shapes', () => {
  it('settings: a fully valid customized state round-trips unchanged', () => {
    const cur = useSettingsStore.getState();
    const valid = { theme: 'midnight', fontSize: 18, tabSize: 4, minimap: true, ligatures: false, wordWrap: true,
      clangdEnabled: false, plugins: { 'competitive-programming': true, 'source-control': false },
      cppStd: 'c++20', clangdFlags: '-Wall -Wextra' };
    const m = mergeOf(useSettingsStore)(valid, cur);
    expect(m).toMatchObject(valid);
    expect(typeof m.setTheme).toBe('function'); // live actions survive
  });

  it('settings: partial corruption keeps independent valid keys', () => {
    const cur = useSettingsStore.getState();
    const m = mergeOf(useSettingsStore)({ fontSize: 'huge', theme: 'ember', plugins: { 'competitive-programming': true }, minimap: 'yes' }, cur);
    expect(m.fontSize).toBe(cur.fontSize); // garbage falls back
    expect(m.minimap).toBe(cur.minimap);
    expect(m.theme).toBe('ember'); // independent valid keys preserved
    expect(m.plugins).toEqual({ 'competitive-programming': true });
  });

  it('settings: null/array/unknown keys cannot override values or actions', () => {
    const cur = useSettingsStore.getState();
    const m = mergeOf(useSettingsStore)({ fontSize: null, theme: ['nexel'], tabSize: {}, setTheme: 'hijacked', evilKey: 'x' }, cur);
    expect(m.fontSize).toBe(cur.fontSize);
    expect(m.theme).toBe(cur.theme);
    expect(m.tabSize).toBe(cur.tabSize);
    expect(typeof m.setTheme).toBe('function');
    expect('evilKey' in m).toBe(false);
  });

  it('judge: valid custom cases + activeTCId round-trip unchanged', () => {
    const cur = useJudgeStore.getState();
    const cases = [
      { id: 1, name: 'TC 1', input: '1 2', expected: '3', verdict: 'AC' },
      { id: 7, name: 'Edge', input: '', expected: '', verdict: 'IDLE' },
    ];
    const m = mergeOf(useJudgeStore)({ testCases: cases, activeTCId: 7, activeTab: 'expected' }, cur);
    expect(m.testCases).toHaveLength(2);
    expect(m.activeTCId).toBe(7);
    expect(m.activeTab).toBe('expected');
    expect(typeof m.addTestCase).toBe('function');
  });

  it('editor + workspace + ui: valid custom values round-trip; hostile shapes fall back', () => {
    const eCur = useEditorStore.getState();
    const em = mergeOf(useEditorStore)({ autoSave: true, enableSnippets: false, cppTemplate: '// MY CUSTOM TEMPLATE\n' }, eCur);
    expect(em).toMatchObject({ autoSave: true, enableSnippets: false, cppTemplate: '// MY CUSTOM TEMPLATE\n' });
    const emBad = mergeOf(useEditorStore)({ autoSave: ['yes'], cppTemplate: null }, eCur);
    expect(emBad.autoSave).toBe(eCur.autoSave);
    expect(emBad.cppTemplate).toBe(eCur.cppTemplate);

    const wCur = useWorkspaceStore.getState();
    const wm = mergeOf(useWorkspaceStore)({ rootPath: '/home/u/proj', rootName: 'proj', pinnedPaths: ['/home/u/proj/a.cpp'], recentWorkspaces: ['/a', '/b'], searchQuery: 'foo', isRegex: true }, wCur);
    expect(wm).toMatchObject({ rootPath: '/home/u/proj', pinnedPaths: ['/home/u/proj/a.cpp'], recentWorkspaces: ['/a', '/b'], searchQuery: 'foo', isRegex: true });
    const wmBad = mergeOf(useWorkspaceStore)({ rootPath: 42, pinnedPaths: ['/ok', 5], recentWorkspaces: 'x' }, wCur);
    expect(wmBad.rootPath).toBe(wCur.rootPath);
    expect(wmBad.pinnedPaths).toEqual(wCur.pinnedPaths);
    expect(wmBad.recentWorkspaces).toEqual(wCur.recentWorkspaces);

    const uCur = useUIStore.getState();
    const um = mergeOf(useUIStore)({ currentSection: 'plugins', sidebarCollapsed: true, terminalVisible: true }, uCur);
    expect(um).toMatchObject({ currentSection: 'plugins', sidebarCollapsed: true, terminalVisible: true });
    expect(um.templateModalVisible).toBe(false);
  });
});
