import {afterEach,beforeEach,it,expect,vi} from 'vitest';
import {waitFor} from '@testing-library/react';
import {useWorkspaceStore} from '../useWorkspaceStore';
import {useStatusStore} from '../useStatusStore';
beforeEach(()=>{useWorkspaceStore.setState({rootPath:null,pinnedPaths:[],inlineInput:{visible:true,nodePath:'C:\\work\\src\\file.py',mode:'rename',defaultValue:'file.py'}});useStatusStore.setState({toasts:[]});});
afterEach(()=>vi.restoreAllMocks());
it('builds the sibling rename target from a Windows path instead of dropping its parent',async()=>{const rename=vi.spyOn(window.nexelAPI,'renameNode');await useWorkspaceStore.getState().handleInlineSubmit('new.py');expect(rename).toHaveBeenCalledExactlyOnceWith('C:\\work\\src\\file.py','C:/work/src/new.py');});
it('preserves a UNC parent when constructing a rename target',async()=>{useWorkspaceStore.setState({inlineInput:{visible:true,nodePath:'\\\\server\\share\\file.py',mode:'rename',defaultValue:'file.py'}});const rename=vi.spyOn(window.nexelAPI,'renameNode');await useWorkspaceStore.getState().handleInlineSubmit('new.py');expect(rename).toHaveBeenCalledExactlyOnceWith('\\\\server\\share\\file.py','//server/share/new.py');});
it.each(['../moved.py','nested/file.py','nested\\file.py','.','..','',String.fromCharCode(0)])('rejects non-name input %j before any filesystem action',async(value)=>{const rename=vi.spyOn(window.nexelAPI,'renameNode');await useWorkspaceStore.getState().handleInlineSubmit(value);expect(rename).not.toHaveBeenCalled();expect(useStatusStore.getState().toasts[0]?.message).toContain('Choose a name');});
it('preserves the filesystem root separator when renaming a root child',async()=>{useWorkspaceStore.setState({inlineInput:{visible:true,nodePath:'/file.py',mode:'rename',defaultValue:'file.py'}});const rename=vi.spyOn(window.nexelAPI,'renameNode');await useWorkspaceStore.getState().handleInlineSubmit('new.py');expect(rename).toHaveBeenCalledExactlyOnceWith('/file.py','/new.py');});

it('does not close a newer rename input after an older operation finishes',async()=>{
 let finish!:(path:string)=>void;vi.spyOn(window.nexelAPI,'renameNode').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));const pending=useWorkspaceStore.getState().handleInlineSubmit('first.py');await waitFor(()=>expect(finish).toBeTypeOf('function'));
 const newer={visible:true,nodePath:'/other.py',mode:'rename' as const,defaultValue:'other.py'};useWorkspaceStore.setState({inlineInput:newer});finish('/first.py');await pending;expect(useWorkspaceStore.getState().inlineInput).toBe(newer);
});
it('ignores repeated submission of the same pending inline operation',async()=>{
 let finish!:(path:string)=>void;const rename=vi.spyOn(window.nexelAPI,'renameNode').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));const first=useWorkspaceStore.getState().handleInlineSubmit('first.py');await waitFor(()=>expect(finish).toBeTypeOf('function'));await useWorkspaceStore.getState().handleInlineSubmit('second.py');expect(rename).toHaveBeenCalledOnce();finish('/first.py');await first;
});
it('does not refresh a different workspace after a pending rename finishes',async()=>{
 let finish!:(path:string)=>void;vi.spyOn(window.nexelAPI,'renameNode').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));const refresh=vi.spyOn(useWorkspaceStore.getState(),'refreshTree');const pending=useWorkspaceStore.getState().handleInlineSubmit('first.py');await waitFor(()=>expect(finish).toBeTypeOf('function'));useWorkspaceStore.setState({rootPath:'/new-workspace'});finish('/first.py');await pending;expect(refresh).not.toHaveBeenCalled();
});
it('does not issue a rename after its input changes while an earlier save is queued',async()=>{
 const{saveDocument}=await import('../../lib/saveDocument');let finish!:(ok:boolean)=>void;vi.spyOn(window.nexelAPI,'writeFileContent').mockImplementation(()=>new Promise(resolve=>{finish=resolve;}));const saving=saveDocument('/earlier.py','queued');await waitFor(()=>expect(finish).toBeTypeOf('function'));const rename=vi.spyOn(window.nexelAPI,'renameNode');const pending=useWorkspaceStore.getState().handleInlineSubmit('stale.py');const newer={visible:true,nodePath:'/current.py',mode:'rename' as const,defaultValue:'current.py'};useWorkspaceStore.setState({inlineInput:newer});finish(true);await saving;await pending;expect(rename).not.toHaveBeenCalled();expect(useWorkspaceStore.getState().inlineInput).toBe(newer);
});
it('retargets pinned descendants after a folder rename while preserving sibling pins',async()=>{
 useWorkspaceStore.setState({pinnedPaths:['/work/src/file.py','/work/src2/keep.py'],inlineInput:{visible:true,nodePath:'/work/src',mode:'rename',defaultValue:'src'}});await useWorkspaceStore.getState().handleInlineSubmit('lib');expect(useWorkspaceStore.getState().pinnedPaths).toEqual(['/work/lib/file.py','/work/src2/keep.py']);
});
it('does not mutate current workspace pins from an older move completion',()=>{
 useWorkspaceStore.setState({rootPath:'/new',pinnedPaths:['/old/src/file.py']});useWorkspaceStore.getState().relocatePinnedPaths('/old/src','/old/lib','/old');expect(useWorkspaceStore.getState().pinnedPaths).toEqual(['/old/src/file.py']);
});
it('preserves renamed folder expansion and selected descendant through filesystem refresh',async()=>{
 const selected={path:'/work/src/nested/file.py',name:'file.py',type:'file' as const};const nested={path:'/work/src/nested',name:'nested',type:'folder' as const,isOpen:true,children:[selected]};useWorkspaceStore.setState({rootPath:'/work',tree:[{path:'/work/src',name:'src',type:'folder',isOpen:true,children:[nested]}],lastSelectedNode:selected,activeDir:'/work/src/nested',inlineInput:{visible:true,nodePath:'/work/src',mode:'rename',defaultValue:'src'}});
 vi.spyOn(window.nexelAPI,'readWorkspaceFiles').mockResolvedValue([{path:'/work/lib',name:'lib',type:'folder',children:[{path:'/work/lib/nested',name:'nested',type:'folder',children:[{...selected,path:'/work/lib/nested/file.py'}]}]}]);await useWorkspaceStore.getState().handleInlineSubmit('lib');const state=useWorkspaceStore.getState();expect(state.tree[0].isOpen).toBe(true);expect(state.tree[0].children?.[0].isOpen).toBe(true);expect(state.lastSelectedNode?.path).toBe('/work/lib/nested/file.py');expect(state.activeDir).toBe('/work/lib/nested');
});
it('preserves a newer unrelated selection when a rename finishes',async()=>{
 const outside={path:'/work/outside.py',name:'outside.py',type:'file' as const};useWorkspaceStore.setState({rootPath:'/work',tree:[outside],lastSelectedNode:outside,activeDir:'/work'});useWorkspaceStore.getState().relocateTreePaths('/work/src','/work/lib','/work');expect(useWorkspaceStore.getState().lastSelectedNode).toEqual(outside);expect(useWorkspaceStore.getState().activeDir).toBe('/work');useWorkspaceStore.setState({rootPath:'/different'});useWorkspaceStore.getState().relocateTreePaths('/work','/changed','/work');expect(useWorkspaceStore.getState().lastSelectedNode).toEqual(outside);
});
it('keeps failed rename input available for correction and allows a successful retry',async()=>{
 const input={visible:true,nodePath:'/work/source.py',mode:'rename' as const,defaultValue:'source.py'};useWorkspaceStore.setState({rootPath:null,inlineInput:input});const rename=vi.spyOn(window.nexelAPI,'renameNode').mockRejectedValueOnce(Error('EEXIST: occupied')).mockResolvedValueOnce('/work/retry.py');await useWorkspaceStore.getState().handleInlineSubmit('occupied.py');expect(useWorkspaceStore.getState().inlineInput).toBe(input);expect(useWorkspaceStore.getState().inlineInput.visible).toBe(true);await useWorkspaceStore.getState().handleInlineSubmit('retry.py');expect(rename).toHaveBeenCalledTimes(2);expect(useWorkspaceStore.getState().inlineInput.visible).toBe(false);
});
