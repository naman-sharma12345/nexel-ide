import {invalidateDocumentOpen} from '../lib/openRequest';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { isDocumentWriteReserved } from '../lib/documentWriteLock';
import { useStatusStore } from './useStatusStore';
import { electronStorage } from './electronStorage';

export interface EditorTab {
  filePath: string;
  name: string;
  content: string;
  originalContent: string;
  isDirty: boolean;
  /** Set when the file was deleted on disk while this tab was open: the buffer is
      retained for recovery, but auto-save must not silently recreate the file. */
  isOrphaned?: boolean;
  /** Set when a guarded save found newer bytes on disk; cleared on the next successful save/revert. */
  hasExternalConflict?: boolean;
}

interface EditorState {
  tabs: EditorTab[];
  activeTabPath: string | null;
  focusedTabPath: string | null;
  isSplit: boolean;
  rightTabPath: string | null;
  splitRatio: number;
  autoSave: boolean;
  cppTemplate: string;
  enableSnippets: boolean;
  snippetsFocusRequest: number;
  problemFocusRequest: number;
  acCelebration: boolean;
  
  openFile: (filePath: string, name: string, content: string) => void;
  openBackgroundFiles: (files: Array<{ filePath: string; content: string }>) => void;
  closeTab: (filePath: string) => void;
  moveTab: (from: string, to: string) => void;
  updateTabContent: (filePath: string, content: string) => void;
  toggleSplit: (filePath: string) => void;
  setFocusedTabPath: (path: string | null) => void;
  setCppTemplate: (template: string) => void;
  setEnableSnippets: (enable: boolean) => void;
  setAutoSave: (autoSave: boolean) => void;
  setSplitRatio: (ratio: number) => void;
  triggerAcCelebration: () => void;
  openCfProblem: (contestId: number, problem: { index: string } & Record<string, unknown>) => void;
  openSnippets: () => void;
  closeAllTabs: () => void;
  closeSavedTabs: () => void;
  saveTabSuccess: (filePath: string, savedContent?: string) => void;
  markTabsOrphanedForPath: (path: string, isFolder: boolean) => number;
  markExternalConflict: (path: string) => void;
}

let modelDisposer: (closedPaths: string[], openPaths: () => string[]) => void = () => {};
/** Editor UI registers the Monaco-backed disposer; the store stays Monaco-free for tests. */
export function registerModelDisposer(fn: (closedPaths: string[], openPaths: () => string[]) => void) {
  modelDisposer = fn;
}

export const useEditorStore = create<EditorState>()(
  persist(
    (set, get) => ({
      tabs: [],
      activeTabPath: null,
      focusedTabPath: null,
      isSplit: false,
      rightTabPath: null,
      splitRatio: 50,
      autoSave: false,
      cppTemplate: '',
      enableSnippets: true,
      snippetsFocusRequest: 0,
      problemFocusRequest: 0,
      acCelebration: false,

      openFile: (filePath, name, content) => {
        invalidateDocumentOpen();
        if (isDocumentWriteReserved(filePath)) {
          useStatusStore.getState().pushToast('A file operation is running. Open this file again when it finishes.', 'info', 5000);
          return;
        }
        const { tabs } = get();
        const existingTab = tabs.find((t) => t.filePath === filePath);
        if (existingTab) {
          if (get().isSplit && get().rightTabPath === filePath) set({ focusedTabPath: filePath });
          else set({ activeTabPath: filePath, focusedTabPath: filePath });
          return;
        }
        const newTab: EditorTab = {
          filePath,
          name,
          content,
          originalContent: content,
          isDirty: false,
        };
        set({
          tabs: [...tabs, newTab],
          activeTabPath: filePath,
          focusedTabPath: filePath,
        });
      },

      // Refactors stage all target buffers together without stealing editor focus.
      openBackgroundFiles: (files) => {
        if (files.some(file => isDocumentWriteReserved(file.filePath))) {
          throw new Error('A file operation is running. Try Rename again afterward.');
        }
        const tabs = get().tabs;
        const additions = files.filter(file => !tabs.some(tab => tab.filePath === file.filePath))
          .map(file => ({ ...file, name: file.filePath.split(/[\\/]/).pop() || file.filePath,
            originalContent: file.content, isDirty: false }));
        if (additions.length) set({ tabs: [...tabs, ...additions] });
      },

      moveTab: (from, to) => {
        const { tabs } = get();
        const a = tabs.findIndex((t) => t.filePath === from);
        const b = tabs.findIndex((t) => t.filePath === to);
        if (a < 0 || b < 0 || a === b) return;
        const next = tabs.slice();
        const [m] = next.splice(a, 1);
        next.splice(b, 0, m);
        set({ tabs: next });
      },
      closeTab: (filePath) => {
        invalidateDocumentOpen();
        const { tabs, activeTabPath, focusedTabPath, rightTabPath } = get();
        let nextIsSplit = get().isSplit;
        let nextRightTabPath = rightTabPath;

        if (rightTabPath === filePath) {
          nextIsSplit = false;
          nextRightTabPath = null;
        }

        const remainingTabs = tabs.filter((t) => t.filePath !== filePath);
        let nextActiveTabPath = activeTabPath;

        if (activeTabPath === filePath) {
          if (remainingTabs.length > 0) {
            const leftCandidates = nextIsSplit ? remainingTabs.filter(tab => tab.filePath !== nextRightTabPath) : remainingTabs;
            nextActiveTabPath = (leftCandidates.at(-1) ?? remainingTabs.at(-1))!.filePath;
            if (nextActiveTabPath === nextRightTabPath) { nextIsSplit = false; nextRightTabPath = null; }
          } else {
            nextActiveTabPath = null;
          }
        }

        set({
          tabs: remainingTabs,
          activeTabPath: nextActiveTabPath,
          focusedTabPath: focusedTabPath !== filePath && remainingTabs.some(tab => tab.filePath === focusedTabPath)
            && (focusedTabPath === nextActiveTabPath || (nextIsSplit && focusedTabPath === nextRightTabPath))
              ? focusedTabPath : nextActiveTabPath,
          isSplit: nextIsSplit,
          rightTabPath: nextRightTabPath,
        });
        useStatusStore.getState().retainCursors(get().tabs.map(tab => tab.filePath));
        modelDisposer([filePath], () => get().tabs.map(tab => tab.filePath));
      },

      updateTabContent: (filePath, content) => {
        const { tabs } = get();
        set({
          tabs: tabs.map((t) =>
            t.filePath === filePath
              ? { ...t, content, isDirty: content !== t.originalContent }
              : t
          ),
        });
      },

      toggleSplit: (filePath) => {
        const { isSplit, rightTabPath, tabs, activeTabPath } = get();
        if (isSplit && rightTabPath === filePath) {
          set({ isSplit: false, rightTabPath: null, focusedTabPath: activeTabPath });
        } else {
          let nextActiveTabPath = activeTabPath;
          if (activeTabPath === filePath) {
            const otherTab = tabs.find((t) => t.filePath !== filePath);
            if (otherTab) {
              nextActiveTabPath = otherTab.filePath;
            }
          }
          set({ isSplit: true, rightTabPath: filePath, activeTabPath: nextActiveTabPath, focusedTabPath: filePath });
        }
      },

      setFocusedTabPath: (path) => { invalidateDocumentOpen(); set({ focusedTabPath: path }); },

      setCppTemplate: (template) => set({ cppTemplate: template }),
      
      setEnableSnippets: (enable) => set({ enableSnippets: enable }),

      setAutoSave: (autoSave) => set({ autoSave }),

      setSplitRatio: (splitRatio) => set({ splitRatio }),

      triggerAcCelebration: () => {
        set({ acCelebration: true });
        setTimeout(() => set({ acCelebration: false }), 1500);
      },

      openCfProblem: (contestId, problem) => {
        const { tabs } = get();
        const tabPath = `cf://${contestId}/${problem.index}`;
        const tabName = `CF ${contestId}${problem.index}`;
        const existingTab = tabs.find((t) => t.filePath === tabPath);
        if (existingTab) {
          const content = JSON.stringify(problem);
          set({ tabs: tabs.map(tab => tab.filePath === tabPath ? {...tab, content, originalContent: content} : tab),
            activeTabPath: get().isSplit && get().rightTabPath === tabPath ? get().activeTabPath : tabPath,
            focusedTabPath: tabPath, problemFocusRequest: get().problemFocusRequest + 1 });
          return;
        }
        const newTab: EditorTab = {
          filePath: tabPath,
          name: tabName,
          content: JSON.stringify(problem),
          originalContent: JSON.stringify(problem),
          isDirty: false,
        };
        set({
          tabs: [...tabs, newTab],
          activeTabPath: tabPath,
          focusedTabPath: tabPath,
          problemFocusRequest: get().problemFocusRequest + 1,
        });
      },

      openSnippets: () => {
        const state = get();
        const path = 'nexel://snippets';
        const tabs = state.tabs.some(tab => tab.filePath === path) ? state.tabs : [...state.tabs, {
          filePath: path, name: 'Code Snippets', content: '', originalContent: '', isDirty: false,
        }];
        // Reopening a visible right-pane viewer must not replace the left document.
        set({ tabs, activeTabPath: state.isSplit && state.rightTabPath === path ? state.activeTabPath : path,
          focusedTabPath: path, snippetsFocusRequest: state.snippetsFocusRequest + 1 });
      },

      closeAllTabs: () => {
        // Closing everything is navigation intent: an in-flight open must not
        // resurrect a tab afterwards. Deliberate later opens still work (they
        // begin after this invalidation).
        invalidateDocumentOpen();
        const closedPaths = get().tabs.map(tab => tab.filePath);
        set({
          tabs: [],
          activeTabPath: null,
          focusedTabPath: null,
          isSplit: false,
          rightTabPath: null,
        });
        useStatusStore.getState().retainCursors([]);
        modelDisposer(closedPaths, () => get().tabs.map(tab => tab.filePath));
      },

      closeSavedTabs: () => {
        // Reuse normal close semantics: preserve surviving split focus, promote
        // the right document when needed, and do nothing for an empty target set.
        const saved = get().tabs.filter(tab => !tab.isDirty).map(tab => tab.filePath);
        saved.forEach(path => get().closeTab(path));
      },

      saveTabSuccess: (filePath, savedContent) => {
        const { tabs } = get();
        set({
          tabs: tabs.map((t) =>
            t.filePath === filePath
              ? { ...t, originalContent: savedContent ?? t.content, isDirty: t.content !== (savedContent ?? t.content), isOrphaned: false, hasExternalConflict: false }
              : t
          ),
        });
      },

      markExternalConflict: (path) => {
        set({ tabs: get().tabs.map(t => (t.filePath === path || t.filePath.startsWith(path + '/')) ? { ...t, hasExternalConflict: true } : t) });
      },
      markTabsOrphanedForPath: (path, isFolder) => {
        const norm = path.replace(/\\/g, '/');
        const prefix = norm + '/';
        let marked = 0;
        set({
          tabs: get().tabs.map((t) => {
            const tp = t.filePath.replace(/\\/g, '/');
            const hit = isFolder ? tp.startsWith(prefix) : tp === norm;
            if (hit && !t.isOrphaned) marked++;
            return hit && !t.isOrphaned ? { ...t, isOrphaned: true } : t;
          }),
        });
        return marked;
      }
    }),
    {
      name: 'nexel-editor-store',
      storage: createJSONStorage(() => electronStorage),
      // We don't want to persist the editor tabs since their content is loaded dynamically,
      // but we do want to persist settings like autoSave, cppTemplate, and enableSnippets.
      partialize: (state) => ({
        autoSave: state.autoSave,
        cppTemplate: state.cppTemplate,
        enableSnippets: state.enableSnippets,
      }),
      // Persisted data is untrusted: wrong types fall back to defaults.
      merge: (persisted, current) => {
        const q = (persisted ?? {}) as { autoSave?: unknown; cppTemplate?: unknown; enableSnippets?: unknown };
        return { ...current,
          autoSave: typeof q.autoSave === 'boolean' ? q.autoSave : current.autoSave,
          cppTemplate: typeof q.cppTemplate === 'string' ? q.cppTemplate : current.cppTemplate,
          enableSnippets: typeof q.enableSnippets === 'boolean' ? q.enableSnippets : current.enableSnippets };
      },
    }
  )
);
