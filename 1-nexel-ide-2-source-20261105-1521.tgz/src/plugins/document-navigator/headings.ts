export interface Heading { line:number;level:number;text:string }
/** ATX Markdown headings, excluding fenced code. This is not a language symbol parser. */
export function markdownHeadings(source:string):Heading[] {
 const result:Heading[]=[];let fence='';let fenceLength=0;let offset=0;let line=1;
 while(offset<=source.length){let end=source.indexOf('\n',offset);if(end<0)end=source.length;const value=source.slice(offset,end).replace(/\r$/,'');
 const candidate=/^ {0,3}(`{3,}|~{3,})(.*)$/.exec(value);
 // Backticks in a backtick fence's info string make it inline text, not an opener.
 const invalidOpener=!fence&&candidate?.[1][0]==='`'&&candidate[2].includes('`');
 const marker=invalidOpener?null:candidate;
 if(marker){if(!fence){fence=marker[1][0];fenceLength=marker[1].length;}else if(marker[1][0]===fence&&marker[1].length>=fenceLength&&/^ {0,3}(?:`+|~+)[ \t]*$/.test(value))fence='';}
 else if(!fence){const heading=/^ {0,3}(#{1,6})(?:[ \t]+|$)(.*)$/.exec(value);if(heading)result.push({line,level:heading[1].length,text:heading[2].replace(/(?:^[#]+[ \t]*$|[ \t]+#+[ \t]*$)/,'').replace(/^[ \t]+|[ \t]+$/g,'')||'Untitled heading'});}
 if(end===source.length)break;offset=end+1;line++;
 if(result.length>=500)break;
 }return result;
}
