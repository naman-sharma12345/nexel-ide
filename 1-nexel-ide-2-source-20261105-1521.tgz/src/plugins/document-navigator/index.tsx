import {lazy} from 'react';
import {registerPlugin} from '../registry';
const Panel=lazy(()=>import('./DocumentNavigator'));
registerPlugin({id:'document-navigator',name:'Document Navigator',blurb:'Find open documents and jump to live Markdown headings without changing their contents.',defaultEnabled:false,sections:['document-navigator'],commandIds:[],panels:{'document-navigator':Panel},navItems:[{id:'document-navigator',label:'Document Navigator',icon:<svg className="nd-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M8 5h13M8 12h13M8 19h13M3 5h.01M3 12h.01M3 19h.01"/></svg>}]});
