import {describe,it,expect} from 'vitest';import {markdownHeadings} from './headings';
describe('Markdown heading navigator',()=>{
 it('finds live heading lines and levels, strips trailing markers',()=>expect(markdownHeadings('# Intro\r\ntext\r\n### Detail ###')).toEqual([{line:1,level:1,text:'Intro'},{line:3,level:3,text:'Detail'}]));
 it('ignores fences, inline hashes and indented code',()=>expect(markdownHeadings('```md\n# hidden\n```\n#no\n    # code\n## Real')).toEqual([{line:6,level:2,text:'Real'}]));
 it('keeps shorter fence markers inside longer fences',()=>expect(markdownHeadings('~~~~\n~~~\n# hidden\n~~~~\n# Visible')).toEqual([{line:5,level:1,text:'Visible'}]));
 it('caps navigation results',()=>expect(markdownHeadings('# item\n'.repeat(1000))).toHaveLength(500));
});
it('does not hide later headings after backtick-bearing inline code mistaken for a fence',()=>{
 expect(markdownHeadings('```inline `code` example\n# Visible\n## Next')).toEqual([{line:2,level:1,text:'Visible'},{line:3,level:2,text:'Next'}]);
 expect(markdownHeadings('```lang\n# Hidden\n```\n# Visible')).toEqual([{line:4,level:1,text:'Visible'}]);
 expect(markdownHeadings('~~~info `allowed`\n# Hidden\n~~~\n# Visible')).toEqual([{line:4,level:1,text:'Visible'}]);
});

it('recognizes empty ATX headings whose content is only closing markers',()=>{
 expect(markdownHeadings('# ###\n## ##  \n### title ###\n# title#')).toEqual([
 {line:1,level:1,text:'Untitled heading'}, {line:2,level:2,text:'Untitled heading'},
 {line:3,level:3,text:'title'}, {line:4,level:1,text:'title#'}]);
});
it('uses only ASCII spaces and tabs as ATX separators and fence-closing whitespace',()=>{
 expect(markdownHeadings('#\u00a0Not a heading\n# \u00a0Keep edges\u00a0\n#\tTabbed')).toEqual([
 {line:2,level:1,text:'\u00a0Keep edges\u00a0'}, {line:3,level:1,text:'Tabbed'}]);
 expect(markdownHeadings('```\n```\u00a0\n# Still code\n```\n# Visible')).toEqual([{line:5,level:1,text:'Visible'}]);
});
