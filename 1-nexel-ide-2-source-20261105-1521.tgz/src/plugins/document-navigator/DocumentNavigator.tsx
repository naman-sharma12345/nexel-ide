import {useUIStore} from '../../stores/useUIStore';
import {useMemo,useState} from 'react';
import {useEditorStore} from '../../stores/useEditorStore';
import {focusedDocument} from '../../lib/focusedDocument';
import {requestDocumentReveal} from '../../lib/documentReveal';
import {requestDocumentEditorFocus} from '../../lib/editorMenu';
import {markdownHeadings} from './headings';
import './DocumentNavigator.css';
export default function DocumentNavigator(){
 const active=useUIStore(state=>state.currentSection==='document-navigator'&&!state.sidebarCollapsed);
 const state=useEditorStore();const current=focusedDocument(state);const [tab,setTab]=useState<'documents'|'headings'>('documents');const [query,setQuery]=useState('');
 const isMarkdown=!!current&&/\.(md|markdown|mdx)$/i.test(current.name);
 const headings=useMemo(()=>active&&isMarkdown?markdownHeadings(current!.content):[],[active,current?.content,isMarkdown]);
 const needle=query.toLocaleLowerCase();const documents=state.tabs.filter(item=>(item.name+' '+item.filePath).toLocaleLowerCase().includes(needle));
 const shown=headings.filter(item=>item.text.toLocaleLowerCase().includes(needle));
 const activate=(path:string,line?:number)=>{const target=useEditorStore.getState().tabs.find(t=>t.filePath===path);if(!target)return;state.openFile(path,target.name,target.content);if(line)requestDocumentReveal({path,line,col:1});requestDocumentEditorFocus(path);};
 return <section className="dn-panel" aria-label="Document Navigator"><header><div className="dn-eyebrow">DOCUMENT NAVIGATOR</div><h2>Find your place</h2><p>Open buffers and Markdown headings.</p></header>
 <div className="dn-tabs" role="tablist" aria-label="Navigator view" onKeyDown={event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?'documents':event.key==='End'?'headings':tab==='documents'?'headings':'documents';setTab(next);event.currentTarget.querySelector<HTMLButtonElement>(`[data-tab="${next}"]`)?.focus();}}}>
 {(['documents','headings'] as const).map(id=><button key={id} data-tab={id} role="tab" id={`dn-tab-${id}`} aria-controls="dn-list" aria-selected={id===tab} tabIndex={id===tab?0:-1} onClick={()=>setTab(id)}>{id==='documents'?'Documents':'Headings'}<span>{id==='documents'?state.tabs.length:headings.length}</span></button>)}</div>
 <input className="dn-filter" type="search" aria-label="Filter navigator" placeholder={tab==='documents'?'Filter open documents':'Filter headings'} value={query} onChange={event=>setQuery(event.target.value)}/>
 <div className="dn-list" id="dn-list" role="tabpanel" aria-labelledby={`dn-tab-${tab}`}>
 {tab==='documents'?(documents.length?documents.map(item=><button className={`dn-entry ${item.filePath===current?.filePath?'is-current':''}`} key={item.filePath} onClick={()=>activate(item.filePath)} aria-label={`Focus ${item.name}`}><span className="dn-entry-title">{item.name}{item.isDirty&&<i aria-label="Unsaved changes"/>}</span><small title={item.filePath}>{item.filePath}</small></button>):<p className="dn-empty">{state.tabs.length?'No matching documents.':'Open a file to start navigating.'}</p>):(!isMarkdown?<p className="dn-empty">Heading navigation is available for Markdown files. Select one from Documents.</p>:shown.length?shown.map(item=><button key={item.line} className="dn-entry dn-heading" style={{paddingLeft:10+(item.level-1)*8}} onClick={()=>activate(current!.filePath,item.line)}><span>{item.text}</span><small>L{item.line}</small></button>):<p className="dn-empty">{headings.length?'No matching headings.':'No # headings in this document.'}</p>)}
 </div><footer>{tab==='documents'?'Click a document to focus its editor.':'Live buffer · # headings · up to 500'}</footer></section>;
}
