/** In-renderer invalidation bus for git state. Any surface that mutates the
    repository emits gitChanged so every other surface (panel, status-bar chip)
    re-reads immediately instead of waiting for its own poll. */
type Listener = (rootPath: string) => void;
const listeners = new Set<Listener>();

export function emitGitChanged(rootPath: string): void {
  for (const l of [...listeners]) {
    try { l(rootPath); } catch { /* a broken listener must not break the mutator */ }
  }
}

export function onGitChanged(l: Listener): () => void {
  listeners.add(l);
  return () => { listeners.delete(l); };
}
