import { useEditorStore } from '../../stores/useEditorStore';
import { useWorkspaceStore } from '../../stores/useWorkspaceStore';
import { isInside } from '../../lib/session';
import { readDocumentForOpen } from '../../lib/documentWriteLock';

/** Reload clean open tabs that live in rootPath from disk (after an in-app or
    EXTERNAL branch switch/pull), so the editor never silently shows another
    branch's content. Dirty buffers are never touched (no auto-overwrite).
    Deleted files are marked orphaned, which the close dialog already explains.
    Identity guards: workspace root, tab instance, and buffer/baseline bytes are
    re-checked after every async read before anything is replaced. */
/** Monotonic run counter: a newer reload supersedes every older in-flight one.
    Without this, an older slow read resolving AFTER a newer run completed could
    install stale bytes (e.g. switch forth and back quickly: the newer run sees
    content equal to baseline and writes nothing, leaving the tab object
    unchanged, so the older run's identity check would pass with stale data). */
let reloadEpoch = 0;

export async function reloadCleanRepoTabs(rootPath: string): Promise<void> {
  const epoch = ++reloadEpoch;
  let canonicalRoot: string | undefined;
  const rootAtStart = rootPath;
  for (const t of useEditorStore.getState().tabs) {
    if (t.isDirty) continue;
    if (!isInside(rootPath, t.filePath)) {
      // Tabs survive workspace alias changes. Resolve only membership, never
      // rename the tab/model or merge buffers. Unresolvable aliases stay intact.
      if (!window.nexelAPI.realPath) continue;
      try {
        if (canonicalRoot === undefined) canonicalRoot = await window.nexelAPI.realPath(rootPath);
        if (epoch !== reloadEpoch || useWorkspaceStore.getState().rootPath !== rootAtStart) return;
        const canonicalFile = await window.nexelAPI.realPath(t.filePath);
        if (epoch !== reloadEpoch || useWorkspaceStore.getState().rootPath !== rootAtStart) return;
        const latest = useEditorStore.getState().tabs.find(x => x.filePath === t.filePath);
        if (latest !== t || latest.isDirty || !isInside(canonicalRoot, canonicalFile)) continue;
      } catch { continue; }
    }
    try {
      const content = await readDocumentForOpen(t.filePath);
      if (epoch !== reloadEpoch) return; // a newer reload owns the outcome now
      const latest = useEditorStore.getState().tabs.find((x) => x.filePath === t.filePath);
      if (useWorkspaceStore.getState().rootPath !== rootAtStart) return;
      if (latest !== t || latest.isDirty || latest.content !== t.content || latest.originalContent !== t.originalContent) continue;
      if (content !== t.originalContent || t.isOrphaned) {
        useEditorStore.setState((s) => ({
          tabs: s.tabs.map((x) => x.filePath === t.filePath ? { ...x, content, originalContent: content, isDirty: false, isOrphaned: false, hasExternalConflict: false } : x),
        }));
      }
    } catch (error) {
      if (epoch !== reloadEpoch || useWorkspaceStore.getState().rootPath !== rootAtStart) return;
      const latest = useEditorStore.getState().tabs.find(x => x.filePath === t.filePath);
      if (latest !== t || latest.isDirty || latest.content !== t.content || latest.originalContent !== t.originalContent) continue;
      // Read failure is not proof of deletion: locks, permissions and invalid
      // text must not mark an existing file deleted. Electron preserves ENOENT
      // in the rejected IPC message even when the Error code is not retained.
      const message = error instanceof Error
        ? error.message.replace(/^Error invoking remote method '[^']+': (?:Error: )?/, '') : '';
      // A structured code takes precedence. In Electron's message-only wrapper,
      // match only the leading error token: a filename may itself be ENOENT.cpp.
      const missing = error instanceof Error && ('code' in error
        ? error.code === 'ENOENT' : /^ENOENT(?=:|$)/.test(message));
      if (missing) useEditorStore.getState().markTabsOrphanedForPath(t.filePath, false);
    }
  }
}
