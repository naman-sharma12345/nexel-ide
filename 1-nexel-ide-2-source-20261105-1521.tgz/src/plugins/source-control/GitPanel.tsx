import { useCallback, useEffect, useRef, useState } from 'react';
import { useWorkspaceStore } from '../../stores/useWorkspaceStore';
import { emitGitChanged, onGitChanged } from './gitEvents';
import { useEditorStore } from '../../stores/useEditorStore';
import { useStatusStore } from '../../stores/useStatusStore';
import { readDocumentForOpen } from '../../lib/documentWriteLock';
import { findAliasedTab } from '../../lib/aliasedTab';
import { createOpenRequestGuard } from '../../lib/openRequest';
import { reloadCleanRepoTabs } from './reloadRepoTabs';
import { withGitOp } from '../../lib/gitOpLock';
import { isInside } from '../../lib/session';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import './GitPanel.css';

interface GitEntry { path: string; code: string; staged: boolean; unstaged: boolean; untracked: boolean; conflicted?: boolean; origPath?: string }
interface GitStatus { repositoryRoot?: string; isRepo: boolean; branch: string | null; hasUpstream: boolean; ahead: number; behind: number; entries: GitEntry[] }

/** Source Control panel: status, staging, diff view, branch switching and
    fetch/pull for the workspace's git repo. Every mutating action is an
    explicit user click; pull is --ff-only and git switch refuses to clobber
    local changes, and nothing ever resets or forces. Unsaved editor buffers
    are never written or discarded by git actions: switching/pulling with
    dirty files asks first, and clean open tabs are reloaded from disk
    afterwards so the editor never silently shows stale content. */
export function GitPanel() {
  const [expandedConflict, setExpandedConflict] = useState<string | null>(null);
  const rootPath = useWorkspaceStore((s) => s.rootPath);
  const [status, setStatus] = useState<GitStatus | null>(null);
  const [branches, setBranches] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // Tracks whether the visible error came from a background refresh (safe to
  // clear on the next successful refresh) or from a user-clicked operation
  // (must persist until the next operation; a background refresh must never
  // erase the reason a click failed).
  const refreshErrorRef = useRef(false);
  const [message, setMessage] = useState('');
  const [diffView, setDiffView] = useState<{ path: string; staged: boolean; text: string } | null>(null);
  const [commits, setCommits] = useState<{ hash: string; subject: string; author: string; date: string }[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [remotes, setRemotes] = useState<string[]>([]);
  const [publishTarget, setPublishTarget] = useState('');
  const [metadataErrors, setMetadataErrors] = useState<{branches?:string;history?:string;remotes?:string}>({});
  const [creating, setCreating] = useState(false);
  const [newBranch, setNewBranch] = useState('');
  const [pending, setPending] = useState<{ label: string; dirty: string[]; run: () => Promise<void> } | null>(null);
  const toast = useStatusStore((s) => s.pushToast);

  const refreshRequest = useRef(0);
  const refresh = useCallback(async () => {
    const request = ++refreshRequest.current;
    if (!rootPath || !window.nexelAPI?.gitStatus) { setStatus(null); return; }
    const rootAtStart = rootPath;
    // Stale-response guard: if the workspace root changes while these reads are
    // in flight, the old root's data must never land in this panel.
    const stale = () => request !== refreshRequest.current || useWorkspaceStore.getState().rootPath !== rootAtStart;
    try {
      const s = await window.nexelAPI.gitStatus(rootPath);
      if (stale()) return;
      setStatus(s);
      if (refreshErrorRef.current) { refreshErrorRef.current = false; setError(''); }
      if (s.isRepo && !s.repositoryRoot && window.nexelAPI.gitBranches) {
        const b = await window.nexelAPI.gitBranches(rootPath).catch(e=>({ok:false,branches:[],error:e instanceof Error?e.message:String(e)}));
        if (stale()) return;
        setBranches(b.ok ? b.branches : []);setMetadataErrors(prev=>({...prev,branches:b.ok?undefined:`Could not read branches: ${b.error??'unknown error'}. Use Refresh to try again.`}));
        if (window.nexelAPI.gitLog) {
          const l = await window.nexelAPI.gitLog(rootPath, 50).catch(e=>({ok:false,commits:[],error:e instanceof Error?e.message:String(e)}));
          if (stale()) return;
          setCommits(l.ok ? l.commits : []);setMetadataErrors(prev=>({...prev,history:l.ok?undefined:`Could not read history: ${l.error??'unknown error'}. Use Refresh to try again.`}));
        }
        if (window.nexelAPI.gitRemotes) {
          const r = await window.nexelAPI.gitRemotes(rootPath).catch(e=>({ok:false,remotes:[] as string[],error:e instanceof Error?e.message:String(e)}));
          if (stale()) return;
          setRemotes(r.ok?r.remotes:[]);setPublishTarget(t=>r.ok?(t&&r.remotes.includes(t)?t:(r.remotes[0]??'')):'');setMetadataErrors(prev=>({...prev,remotes:r.ok?undefined:`Could not read remotes: ${r.error??'unknown error'}. Use Refresh to try again.`}));
        }
      }
    } catch (e) { if (!stale()) { refreshErrorRef.current = true; setStatus(null); diffRequest.current++; setDiffView(null); setError(e instanceof Error ? e.message : String(e)); } }
  }, [rootPath]);

  // Repository-local, session-only drafts. Root changes must neither carry a
  // commit/branch intent into another repository nor destroy the user's typing.
  const drafts = useRef(new Map<string, { message: string; newBranch: string; creating: boolean }>());
  const draftRoot = useRef(rootPath);
  const draftValue = useRef({ message, newBranch, creating });
  draftValue.current = { message, newBranch, creating };
  const operationScope = useRef(0);
  const activeOperation = useRef<object | null>(null);
  const queuedOperation = useRef<object | null>(null);
  const diffRequest = useRef(0);
  useEffect(() => {
    if (draftRoot.current !== rootPath) {
      if (draftRoot.current) drafts.current.set(draftRoot.current, draftValue.current);
      const saved = rootPath ? drafts.current.get(rootPath) : undefined;
      setMessage(saved?.message ?? ''); setNewBranch(saved?.newBranch ?? ''); setCreating(saved?.creating ?? false);
      draftRoot.current = rootPath;
    }
    activeOperation.current = null; queuedOperation.current = null;
    operationScope.current++;
    diffRequest.current++;
    refreshRequest.current++;
    setDiffView(null);
    setStatus(null); setBusy(false); setPending(null); setError(''); setExpandedConflict(null);
    // Repository-derived lists must not survive into a repository with no
    // corresponding result (an empty history or failed branch read).
    setBranches([]); setCommits([]); setRemotes([]); setPublishTarget('');setMetadataErrors({});
    return () => { operationScope.current++; diffRequest.current++; refreshRequest.current++; };
  }, [rootPath]);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => onGitChanged((changed) => { if (changed === rootPath) { diffRequest.current++; setDiffView(null); void refresh(); } }), [refresh, rootPath]);
  useEffect(() => useEditorStore.subscribe((next, previous) => {
    // A successful save/revert/reload changes a loaded tab's disk baseline.
    // Plain working-file saves do not emit metadata watcher events. Typing,
    // focus, open and close alone must not launch Git commands. Include foreign
    // spellings conservatively: retained tabs may alias this workspace.
    const baselines = new Map(previous.tabs.map(tab => [tab.filePath, tab.originalContent]));
    if (!next.tabs.some(tab => baselines.has(tab.filePath) && baselines.get(tab.filePath) !== tab.originalContent)) return;
    diffRequest.current++; setDiffView(null); void refresh();
  }), [refresh]);
  useEffect(() => {
    const onFocus = () => { diffRequest.current++; setDiffView(null); void refresh(); };
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [refresh]);

/** Credential failures surface git's verbatim error plus an actionable hint.
    Never asks for secrets anywhere in the app. */
const AUTH_FAILURE = /could not read (Username|Password)|terminal prompts disabled|Authentication failed|could not read from remote repository/i;
const withAuthHint = (msg: string) => AUTH_FAILURE.test(msg)
  ? `${msg}\nThe remote needs sign-in credentials that Nexel cannot ask for here. Set them up in your git configuration (for example a credential helper or an SSH agent), then try again.`
  : msg;

  const run = useCallback(async (action: () => Promise<{ ok: boolean; error?: string }>, failurePrefix: string) => {
    const scope = operationScope.current;
    const current = () => scope === operationScope.current && useWorkspaceStore.getState().rootPath === rootPath;
    if (!current() || activeOperation.current) return false;
    const operation = {};
    activeOperation.current = operation;
    setBusy(true); refreshErrorRef.current = false; setError('');
    try {
      const r = await action();
      if (r.ok && rootPath) emitGitChanged(rootPath);
      if (!current()) return false;
      if (!r.ok) { setError(withAuthHint(`${failurePrefix}: ${r.error ?? 'unknown error'}`)); return false; }
      await refresh();
      return current();
    } catch (e) { if (current()) setError(`${failurePrefix}: ${e instanceof Error ? e.message : String(e)}`); return false; }
    finally { if (activeOperation.current === operation) activeOperation.current = null; if (current()) setBusy(false); }
  }, [refresh, rootPath]);

  const refreshCleanRepoTabs = useCallback(async () => {
    if (rootPath) await reloadCleanRepoTabs(rootPath);
  }, [rootPath]);

  /** Run an operation that can change files on disk; ask first when unsaved
      repo buffers exist (they are never touched, but their files may change
      underneath them, and saving later will surface the conflict). */
  const guarded = useCallback((label: string, action: () => Promise<boolean>, after?: () => Promise<void>) => {
    if (!rootPath) return;
    const dirtyPaths = async () => {
      // Tabs keep their original spelling across workspace aliases. Resolve
      // membership only, never rename/merge buffers. Unknown identities are
      // included conservatively rather than silently bypassing consent.
      for (let attempt = 0; attempt < 3; attempt++) {
        const tabs = useEditorStore.getState().tabs;
        const paths: string[] = [];
        let canonicalRoot: string | undefined;
        for (const tab of tabs) {
          if (!tab.isDirty) continue;
          let inside = isInside(rootPath, tab.filePath);
          if (!inside) {
            try {
              if (!window.nexelAPI.realPath) throw new Error('No path identity');
              canonicalRoot ??= await window.nexelAPI.realPath(rootPath);
              inside = isInside(canonicalRoot, await window.nexelAPI.realPath(tab.filePath));
            } catch { inside = true; }
          }
          if (inside) paths.push(tab.filePath);
        }
        if (useEditorStore.getState().tabs === tabs) return paths;
      }
      throw new Error('Open buffers changed while checking unsaved edits. Try again.');
    };
    // Bind intent before the save gate. Capturing scope only inside run() would
    // let an obsolete queued action revive after an A -> B -> A root roundtrip.
    const scope = operationScope.current;
    const runIt = async (consented: string[]) => {
      if (queuedOperation.current || activeOperation.current || scope !== operationScope.current || useWorkspaceStore.getState().rootPath !== rootPath) return;
      const queued = {};
      queuedOperation.current = queued;
      setBusy(true);
      try {
        await withGitOp(async () => { // serialized against every app save
          if (scope !== operationScope.current || useWorkspaceStore.getState().rootPath !== rootPath) return;
          const currentDirty = await dirtyPaths();
          if (scope !== operationScope.current || useWorkspaceStore.getState().rootPath !== rootPath) return;
          if (currentDirty.some(path => !consented.includes(path))) {
            // Typing may have begun while the save gate was closed. Release
            // the gate before asking, then re-check on confirmation as well.
            setPending({ label, dirty: currentDirty, run: () => runIt(currentDirty) });
            return;
          }
          const ok = await action(); if (ok && after) await after();
        });
      } catch (e) {
        if (scope === operationScope.current && useWorkspaceStore.getState().rootPath === rootPath) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (queuedOperation.current === queued) {
          queuedOperation.current = null;
          if (!activeOperation.current && scope === operationScope.current) setBusy(false);
        }
      }
    };
    void runIt([]);
  }, [rootPath]);

  const openRequests = useRef(createOpenRequestGuard());
  const openFile = async (relPath: string) => {
    if (!rootPath) return;
    // Stale-row guard: if the workspace already changed since this render, the
    // clicked row belongs to the old workspace - abort instead of opening an
    // old-root file under the new root. Also keeps abs and the guard on one
    // consistent workspace basis.
    if (useWorkspaceStore.getState().rootPath !== rootPath) return;
    const abs = `${rootPath}/${relPath}`;
    // Shared navigation-intent guard (same tested semantics as handleFileSelect):
    // a newer open/focus/close on any surface, a root switch, or a same-root
    // workspace reopen during the awaits below cancels this stale open. Checks
    // read the LIVE workspace, never this render's closure.
    const current = openRequests.current.begin(useWorkspaceStore.getState().rootPath);
    const stillCurrent = () => current(useWorkspaceStore.getState().rootPath);
    try {
      let existing = useEditorStore.getState().tabs.find((t) => t.filePath === abs);
      if (!existing && typeof window.nexelAPI?.realPath === 'function') {
        // Same alias dedupe as the Explorer open route: one file can be spelled
        // through a symlinked ancestor, so focus the existing tab under ITS
        // spelling instead of opening a second buffer of it. No path
        // canonicalization and no model merge; unresolvable paths fall through.
        existing = await findAliasedTab(useEditorStore.getState().tabs, abs, window.nexelAPI.realPath) ?? undefined;
        if (!stillCurrent()) return;
        if (existing) {
          // The tab may have been closed during the realpath await: re-validate
          // against current state and fall through to a normal open if gone
          // (the user clicked to open this file).
          existing = useEditorStore.getState().tabs.find((t) => t.filePath === existing!.filePath);
        }
      }
      const content = existing ? existing.content : await readDocumentForOpen(abs);
      if (!stillCurrent()) return;
      useEditorStore.getState().openFile(existing ? existing.filePath : abs, existing ? existing.name : (relPath.split('/').pop() ?? relPath), content);
    } catch (e) {
      if (!stillCurrent()) return;
      toast(`Could not open ${relPath.split('/').pop()}: ${e instanceof Error ? e.message : String(e)}`, 'error', 4000);
    }
  };

  const closeDiff = () => { diffRequest.current++; setDiffView(null); };
  const viewDiff = async (e: GitEntry, staged: boolean) => {
    if (!rootPath || !window.nexelAPI.gitDiff || useWorkspaceStore.getState().rootPath !== rootPath) return;
    const request = ++diffRequest.current;
    const current = () => request === diffRequest.current && useWorkspaceStore.getState().rootPath === rootPath;
    try {
      const r = staged && e.code[0] === 'R' && e.origPath
        ? await window.nexelAPI.gitDiff(rootPath, e.path, staged, e.origPath)
        : await window.nexelAPI.gitDiff(rootPath, e.path, staged);
      if (!current()) return;
      if (r.ok) setDiffView({ path: e.path, staged, text: r.diff || '(no diff)' });
      else setError(`Diff failed: ${r.error ?? 'unknown error'}`);
    } catch (e) {
      if (current()) setError(`Diff failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  if (!rootPath) return <div className="nx-git"><div className="nx-git-empty">Open a workspace folder to use Source Control.</div></div>;
  if (!status) return <div className="nx-git"><div className="nx-git-empty">{error ? 'Git status unavailable.' : 'Reading git status...'}</div>{error && <><div className="nx-git-err" role="alert" tabIndex={0} aria-label="Git error">{`Git error: ${error}`}</div><button className="nx-git-refresh" onClick={() => void refresh()}>Retry git status</button></>}</div>;

  if (status.repositoryRoot) return <div className="nx-git"><div className="nx-git-empty nx-git-root-boundary" role="status" tabIndex={0} aria-label="Git repository root required">This workspace is inside a Git repository. Source Control needs the repository root to show correct paths and the full scope of commits and branch changes.<br/><br/>Repository root: <span style={{overflowWrap:'anywhere'}}>{status.repositoryRoot}</span><br/><br/>Open that folder using File &gt; Open Folder to use Source Control. Your current workspace has not changed.</div></div>;

  if (!status.isRepo) {
    return (
      <div className="nx-git">
        <div className="nx-git-empty">This workspace is not a git repository.</div>
        <div style={{ padding: '0 12px' }}>
          <button className="nx-git-commit-btn" disabled={busy} onClick={() => void run(() => window.nexelAPI.gitInit!(rootPath), 'git init failed')}>Initialize repository</button>
        </div>
        {Object.values(metadataErrors).some(Boolean)&&<div className="nx-git-err nx-git-metadata-errors" role="alert" tabIndex={0} aria-label="Git metadata errors">{Object.values(metadataErrors).filter(Boolean).map((message,i)=><div key={i}>{message}</div>)}</div>}
        {error && <div className="nx-git-err" role="alert" tabIndex={0} aria-label="Git error">{error}</div>}
      </div>
    );
  }

  // File headers live before hunks. Source text within a hunk may itself
  // begin with ++/-- (C++ increments, Markdown rules or patch examples).
  let inDiffHunk = false;
  const diffLines = diffView?.text.split('\n').map(text => {
    if (text.startsWith('diff --git ')) inDiffHunk = false;
    if (text.startsWith('@@')) { inDiffHunk = true; return { text, className: 'nx-git-hunk' }; }
    return { text, className: inDiffHunk && text.startsWith('+') ? 'nx-git-add' : inDiffHunk && text.startsWith('-') ? 'nx-git-del' : undefined };
  });

  const conflicted = status.entries.filter((e) => e.conflicted);
  const staged = status.entries.filter((e) => e.staged && !e.conflicted);
  const unstaged = status.entries.filter((e) => e.unstaged && !e.conflicted);
  const untracked = status.entries.filter((e) => e.untracked);

  const group = (title: string, entries: GitEntry[], isStaged: boolean) => entries.length > 0 && (
    <div className="nx-git-group" key={title}>
      <div className="nx-git-group-title">{title} ({entries.length})</div>
      {entries.map((e) => (
        <div className="nx-git-file" key={title + e.path}>
          <button className="nx-git-file-name" title={e.origPath ? `${e.origPath} → ${e.path}` : e.path} onClick={() => void openFile(e.path)}>{e.path}</button>
          {!e.untracked && <button className="nx-git-act" title={`View ${isStaged ? 'staged' : 'unstaged'} diff`} onClick={() => void viewDiff(e, isStaged)}>±</button>}
          <span className="nx-git-code">{e.code.trim() || 'M'}</span>
          {isStaged
            ? <button className="nx-git-act" disabled={busy} title="Unstage" onClick={() => void run(() => window.nexelAPI.gitUnstage!(rootPath, e.code[0] === 'R' && e.origPath ? [e.path, e.origPath] : [e.path]), 'Unstage failed')}>-</button>
            : <button className="nx-git-act" disabled={busy} title="Stage" onClick={() => void run(() => window.nexelAPI.gitStage!(rootPath, [e.path]), 'Stage failed')}>+</button>}
        </div>
      ))}
    </div>
  );

  const conflictHint = (code: string) => code === 'DD'
    ? 'Deleted on both sides - stage the deletion to accept it, or restore the file and stage it.'
    : code.includes('D')
      ? 'Modified on one side, deleted on the other - keep your version and stage it, or delete the file and stage the deletion.'
      : 'Resolve the conflict markers in the editor, then stage the file to mark it resolved.';
  const conflictGroup = conflicted.length > 0 && (
    <div className="nx-git-group nx-git-conflicts">
      <div className="nx-git-group-title">Merge conflicts ({conflicted.length})</div>
      {conflicted.map((e) => (
        <div className="nx-git-file nx-git-file-conflict" key={'conflict' + e.path}>
          <div className="nx-git-file-row">
            <button className="nx-git-file-name" title={`${e.path} - ${conflictHint(e.code)}`} onClick={() => void openFile(e.path)}>{e.path}</button>
            <span className="nx-git-code">{e.code}</span>
            <button
              className="nx-git-act nx-git-hint-toggle"
              aria-expanded={expandedConflict === e.path}
              aria-label={`How to resolve ${e.path}`}
              title="How to resolve"
              onClick={() => setExpandedConflict(expandedConflict === e.path ? null : e.path)}
            >?</button>
            <button className="nx-git-act" disabled={busy} title="Mark resolved (stage)" onClick={() => void run(() => window.nexelAPI.gitStage!(rootPath, [e.path]), 'Stage failed')}>+</button>
          </div>
          {expandedConflict === e.path && (
            <div className="nx-git-conflict-help" role="note">{conflictHint(e.code)}</div>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div className={`nx-git ${busy ? 'nx-git-busy' : ''}`}>
      <div className="nx-git-head">
        {branches.length > 0 ? (
          <select
            className="nx-git-select"
            title="Current branch - pick another to switch"
            value={status.branch ?? ''}
            disabled={busy}
            onChange={(ev) => {
              const branch = ev.target.value;
              if (branch && branch !== status.branch) {
                guarded(`switch to ${branch}`, () => run(() => window.nexelAPI.gitSwitch!(rootPath, branch), 'Switch failed'), refreshCleanRepoTabs);
              }
            }}
          >
            {status.branch === null && <option value="" disabled>(detached)</option>}
            {status.branch && !branches.includes(status.branch) && <option value={status.branch}>{status.branch}</option>}
            {branches.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
        ) : (
          <span className="nx-git-branch" title="Current branch">{status.branch ?? '(detached)'}</span>
        )}
        {window.nexelAPI.gitCreateBranch && (
          creating ? (
            <span className="nx-git-newbranch">
              <input
                className="nx-git-newbranch-input"
                placeholder="new branch"
                readOnly={busy}
                aria-busy={busy}
                value={newBranch}
                autoFocus
                onChange={(e) => setNewBranch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.nativeEvent.isComposing || e.keyCode === 229) { e.stopPropagation(); return; }
                  if (busy) return;
                  if (e.key === 'Escape') { setCreating(false); setNewBranch(''); }
                  if (e.key === 'Enter' && newBranch.trim()) {
                    const name = newBranch.trim();
                    guarded(`create and switch to ${name}`, async () => {
                      const ok = await run(() => window.nexelAPI.gitCreateBranch!(rootPath, name), 'Create branch failed');
                      if (ok) { setCreating(false); setNewBranch(''); }
                      return ok;
                    }, refreshCleanRepoTabs);
                  }
                }}
              />
            </span>
          ) : (
            <button className="nx-git-act" title="Create branch" disabled={busy} onClick={() => setCreating(true)}>+</button>
          )
        )}
        {(status.ahead > 0 || status.behind > 0) && (
          <span className="nx-git-sync">{status.ahead > 0 ? `↑${status.ahead}` : ''}{status.behind > 0 ? ` ↓${status.behind}` : ''}</span>
        )}
        {window.nexelAPI.gitPull && (
          <>
            <button className="nx-git-refresh" disabled={busy} title="Fetch all remotes" onClick={() => void run(() => window.nexelAPI.gitFetch!(rootPath), 'Fetch failed')}>Fetch</button>
            <button className="nx-git-refresh" disabled={busy} title="Pull (fast-forward only)" onClick={() => guarded('pull', () => run(() => window.nexelAPI.gitPull!(rootPath), 'Pull failed'), refreshCleanRepoTabs)}>Pull</button>
            {window.nexelAPI.gitPush && status.hasUpstream && <button className="nx-git-refresh" disabled={busy} title="Push to upstream" onClick={() => void run(() => window.nexelAPI.gitPush!(rootPath), 'Push failed')}>Push</button>}
          </>
        )}
        <button className="nx-git-refresh" onClick={() => { closeDiff(); void refresh(); }}>Refresh</button>
      </div>
      <div className="nx-git-body">
        {status.entries.length === 0 && <div className="nx-git-empty">Working tree clean.</div>}
        {conflictGroup}
        {group('Staged changes', staged, true)}
        {group('Changes', unstaged, false)}
        {group('Untracked', untracked, false)}
        {commits.length > 0 && (
          <div className="nx-git-group">
            <button className="nx-git-group-title nx-git-history-toggle" onClick={() => setShowHistory(!showHistory)}>
              {showHistory ? '▾' : '▸'} History ({commits.length})
            </button>
            {showHistory && commits.map((c) => (
              <div className="nx-git-commit-row" key={c.hash} title={`${c.hash} - ${c.subject}`}>
                <span className="nx-git-hash" title={c.hash}>{c.hash}</span>
                <span className="nx-git-subject">{c.subject || '(no message)'}</span>
                <span className="nx-git-meta" title={`${c.author} · ${c.date}`}>{c.author} · {c.date}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      {diffView && (
        <div className="nx-git-diff">
          <div className="nx-git-diff-head">
            <span className="nx-git-diff-title" title={diffView.path}>{diffView.path} {diffView.staged ? '(staged)' : ''}</span>
            <button className="nx-git-refresh" onClick={closeDiff}>Close</button>
          </div>
          <pre className="nx-git-diff-pre" tabIndex={0} role="region" aria-label={`${diffView.staged ? 'Staged' : 'Unstaged'} diff for ${diffView.path}`}>{diffLines?.map((line, i) => (
            <div key={i} className={line.className}>{line.text || ' '}</div>
          ))}</pre>
        </div>
      )}
      {status.branch && !status.hasUpstream && window.nexelAPI.gitPublish && (
        <div className="nx-git-publish">
          {remotes.length > 0 ? (
            <>
              <span className="nx-git-publish-label">Branch not published.</span>
              {remotes.length > 1 && (
                <select className="nx-git-select" value={publishTarget} onChange={(e) => setPublishTarget(e.target.value)} title="Publish target remote">
                  {remotes.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              )}
              <button className="nx-git-refresh" disabled={busy || !publishTarget} title={`Push -u ${publishTarget} ${status.branch}`}
                onClick={() => void run(() => window.nexelAPI.gitPublish!(rootPath, publishTarget, status.branch!), 'Publish failed')}>
                Publish to {publishTarget}
              </button>
            </>
          ) : (
            <span className="nx-git-publish-label">{metadataErrors.remotes?'Branch not published - remotes unavailable.':'Branch not published - no remote configured.'}</span>
          )}
        </div>
      )}
      <div className="nx-git-commit">
        {(error||Object.values(metadataErrors).some(Boolean))&&<div className="nx-git-notices" role="region" aria-label="Git notices" tabIndex={0}>
        {Object.values(metadataErrors).some(Boolean)&&<div className="nx-git-err nx-git-metadata-errors" role="alert" tabIndex={0} aria-label="Git metadata errors">{Object.values(metadataErrors).filter(Boolean).map((message,i)=><div key={i}>{message}</div>)}</div>}
        {error && <div className="nx-git-err" role="alert" tabIndex={0} aria-label="Git error">{error}</div>}
        </div>}
        <textarea
          className="nx-git-msg"
          placeholder={`Commit message${status.branch ? ` (${status.branch})` : ''}`}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button
          className="nx-git-commit-btn"
          disabled={busy || conflicted.length > 0 || staged.length === 0 || !message.trim()}
          title={conflicted.length > 0 ? 'Resolve conflicts first' : staged.length === 0 ? 'Stage changes first' : `Commit ${staged.length} staged file${staged.length === 1 ? '' : 's'}`}
          onClick={() => void run(() => window.nexelAPI.gitCommit!(rootPath, message), 'Commit failed').then((ok) => { if (ok) setMessage(current => current === message ? '' : current); })}
        >
          Commit{staged.length > 0 ? ` ${staged.length} file${staged.length === 1 ? '' : 's'}` : ''}
        </button>
      </div>
      {pending && (
        <ConfirmDialog
          title={`Unsaved changes - ${pending.label}?`}
          message={`${pending.dirty.length} file${pending.dirty.length === 1 ? '' : 's'} with unsaved changes: ${pending.dirty.join(', ')}. Your unsaved edits are kept in the editor; if a file's content on disk changes, saving afterwards will flag the conflict instead of overwriting it.`}
          discardLabel={`${pending.label === 'pull' ? 'Pull' : 'Switch'} anyway`}
          onDiscard={() => { const p = pending; setPending(null); void p.run(); }}
          onCancel={() => setPending(null)}
        />
      )}
    </div>
  );
}
