import { GitPanel } from './GitPanel';
import { GitStatusChip } from './GitStatusChip';
import { registerPlugin } from '../registry';

/** Source Control: git status, staging and commits for the workspace repository.
    Every mutating git action is an explicit user click in the panel; the plugin
    never stages, commits, or touches the repo on its own. Read-only refreshes
    happen on panel mount, window focus, and a 30s status-bar poll. */
registerPlugin({
  id: 'source-control',
  name: 'Source Control (Git)',
  blurb: 'Git status, staging and commits for the workspace repository. Commit actions run only when you click them.',
  defaultEnabled: true,
  sections: ['git'],
  navItems: [{
    id: 'git',
    label: 'Source Control',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="8" r="3"/><path d="M6 9v6M18 11c0 4-4 5-8 5"/></svg>
    ),
  }],
  panels: { git: GitPanel },
  statusItems: [GitStatusChip],
  commandIds: [],
});
