import { useEffect, useState } from 'react';
import { useWorkspaceStore } from '../../stores/useWorkspaceStore';
import { useUIStore } from '../../stores/useUIStore';
import { emitGitChanged, onGitChanged } from './gitEvents';
import { reloadCleanRepoTabs } from './reloadRepoTabs';

/** Status bar branch chip contributed while the Source Control plugin is enabled.
    Renders nothing outside a git repository. */
export function GitStatusChip() {
  const rootPath = useWorkspaceStore((s) => s.rootPath);
  const [info, setInfo] = useState<{ branch: string | null; changes: number } | null>(null);

  useEffect(() => {
    if (!rootPath || !window.nexelAPI?.gitStatus) { setInfo(null); return; }
    let alive = true;
    let request = 0;
    let watchArmed = false;
    let watchPending = false;
    setInfo(null);
    const load = async () => {
      const generation = ++request;
      const current = () => alive && generation === request && useWorkspaceStore.getState().rootPath === rootPath;
      try {
        const s = await window.nexelAPI.gitStatus!(rootPath);
        if (!current()) return;
        setInfo(s.isRepo && !s.repositoryRoot ? { branch: s.branch, changes: s.entries.length } : null);
        // Init can create .git after this effect mounted. Arm only once a
        // current status verifies this workspace is its repository root.
        if (s.isRepo && !s.repositoryRoot && !watchArmed && !watchPending && window.nexelAPI.gitWatch && window.nexelAPI.onGitExternalChange) {
          watchPending = true;
          try { const result = await window.nexelAPI.gitWatch(rootPath); if (alive && useWorkspaceStore.getState().rootPath === rootPath) {
            watchArmed = !!(result.ok && result.watching);
            // One reconciliation closes discovery-to-registration changes that
            // happened before the watcher could emit. No recurring extra poll.
            if (watchArmed) {
              emitGitChanged(rootPath);
              void reloadCleanRepoTabs(rootPath);
              void useWorkspaceStore.getState().refreshTree();
            }
          } }
          catch { /* status remains valid; a later refresh may retry watching */ }
          finally { watchPending = false; }
        }
      } catch { if (current()) setInfo(null); }
    };
    void load();
    const onFocus = () => void load();
    window.addEventListener('focus', onFocus);
    // Immediate invalidation when any surface mutates this repo; poll stays as fallback.
    const off = onGitChanged((changed) => { if (changed === rootPath) void load(); });
    // External git operations (terminal commit/checkout/stage/merge/fetch): main
    // watches the repo's git metadata and invalidates us; the bus fans it out.
    let offExternal: (() => void) | undefined;
    if (window.nexelAPI.gitWatch && window.nexelAPI.onGitExternalChange) {
      offExternal = window.nexelAPI.onGitExternalChange((changed) => {
        if (changed !== rootPath) return;
        emitGitChanged(changed);
        void load();
        // External checkout/merge changed files on disk: refresh clean open tabs
        // (dirty buffers are never touched by the reload) and the explorer tree
        // (file set may have changed; refreshTree is version/root guarded).
        void reloadCleanRepoTabs(changed);
        void useWorkspaceStore.getState().refreshTree();
      });
    }
    const t = setInterval(() => void load(), 30000); // one short git status per 30s
    return () => { alive = false; window.removeEventListener('focus', onFocus); off(); offExternal?.(); void window.nexelAPI.gitWatch?.(null); clearInterval(t); };
  }, [rootPath]);

  if (!info) return null;
  return (
    <button
      className="sb-item sb-btn nx-git-chip"
      title={`Branch ${info.branch ?? '(detached)'} - ${info.changes} uncommitted change${info.changes === 1 ? '' : 's'}. Open Source Control.`}
      onClick={() => useUIStore.getState().setSection('git')}
    >
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="8" r="3"/><path d="M6 9v6M18 11c0 4-4 5-8 5"/></svg>
      {info.branch ?? '(detached)'}{info.changes > 0 ? ` ±${info.changes}` : ''}
    </button>
  );
}
