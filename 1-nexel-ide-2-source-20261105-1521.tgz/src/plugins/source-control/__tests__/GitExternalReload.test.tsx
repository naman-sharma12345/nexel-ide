import { describe, it, expect, vi, beforeEach } from 'vitest';
import { reloadCleanRepoTabs } from '../reloadRepoTabs';
import { useEditorStore } from '../../../stores/useEditorStore';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';

const originalMarkOrphaned = useEditorStore.getState().markTabsOrphanedForPath;
beforeEach(() => useEditorStore.setState({markTabsOrphanedForPath:originalMarkOrphaned}));

const tab = (filePath: string, content: string, isDirty = false) => ({
  id: filePath, filePath, name: filePath.split('/').pop()!, content, originalContent: content,
  isDirty, language: 'typescript', hasExternalConflict: false, orphaned: false,
});

describe('reloadCleanRepoTabs (external checkout safety)', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [], activeTabId: null } as any);
  });

  it('clean tab picks up external branch content; dirty tab is never overwritten', async () => {
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(async (p: string) => {
      if (p === '/repo/clean.ts') return 'new branch content';
      if (p === '/repo/dirty.ts') return 'new branch content';
      throw new Error('unexpected ' + p);
    });
    useEditorStore.setState({ tabs: [tab('/repo/clean.ts', 'old branch content'), tab('/repo/dirty.ts', 'my edits', true)] } as any);
    await reloadCleanRepoTabs('/repo');
    const tabs = useEditorStore.getState().tabs;
    expect(tabs.find((t) => t.filePath === '/repo/clean.ts')!.content).toBe('new branch content');
    const dirty = tabs.find((t) => t.filePath === '/repo/dirty.ts')!;
    expect(dirty.content).toBe('my edits');
    expect(dirty.isDirty).toBe(true);
  });

  it('file deleted by external checkout is marked orphaned, not blanked', async () => {
    (window.nexelAPI.readFileContent as any) = vi.fn().mockRejectedValue(new Error('ENOENT'));
    const mark = vi.fn();
    useEditorStore.setState({ tabs: [tab('/repo/gone.ts', 'x')], markTabsOrphanedForPath: mark } as any);
    await reloadCleanRepoTabs('/repo');
    expect(mark).toHaveBeenCalledWith('/repo/gone.ts', false);
    expect(useEditorStore.getState().tabs[0].content).toBe('x'); // content preserved
  });

  it('aborts mid-run when the workspace root changes (stale response)', async () => {
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(async () => {
      useWorkspaceStore.setState({ rootPath: '/other' } as any); // root changes during read
      return 'new';
    });
    useEditorStore.setState({ tabs: [tab('/repo/a.ts', 'old')] } as any);
    await reloadCleanRepoTabs('/repo');
    expect(useEditorStore.getState().tabs[0].content).toBe('old');
  });
  it('out-of-order completion: older in-flight read never overwrites a newer reload', async () => {
    // Baseline v0. Event A starts reading (slow). Event B (disk back to v0)
    // completes first: content equals baseline -> no write, tab object unchanged.
    // Then A's stale read (v1) resolves: without an epoch guard its identity
    // check would pass and install v1 over the correct v0.
    let releaseA: (v: string) => void = () => {};
    let calls = 0;
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(() => {
      calls++;
      if (calls === 1) return new Promise<string>((res) => { releaseA = res; }); // A: slow
      return Promise.resolve('v0'); // B: instant, disk already back to baseline
    });
    useEditorStore.setState({ tabs: [tab('/repo/a.ts', 'v0')] } as any);
    const runA = reloadCleanRepoTabs('/repo');
    await new Promise((r) => setTimeout(r, 10)); // A is now parked in its read
    await reloadCleanRepoTabs('/repo'); // B completes: v0 === baseline, no write
    releaseA('v1-stale'); // A's stale read resolves late
    await runA;
    expect(useEditorStore.getState().tabs[0].content).toBe('v0');
  });

  it('newer reload still wins when it does change content', async () => {
    let releaseA: (v: string) => void = () => {};
    let calls = 0;
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(() => {
      calls++;
      if (calls === 1) return new Promise<string>((res) => { releaseA = res; });
      return Promise.resolve('v2');
    });
    useEditorStore.setState({ tabs: [tab('/repo/a.ts', 'v0')] } as any);
    const runA = reloadCleanRepoTabs('/repo');
    await new Promise((r) => setTimeout(r, 10));
    await reloadCleanRepoTabs('/repo'); // installs v2
    expect(useEditorStore.getState().tabs[0].content).toBe('v2');
    releaseA('v1-stale');
    await runA;
    expect(useEditorStore.getState().tabs[0].content).toBe('v2'); // A must not clobber
  });

});
it('clears deleted-file state when a clean file reappears with unchanged bytes',async()=>{
 window.nexelAPI={...mockNexelAPI,readFileContent:vi.fn().mockResolvedValue('restored')} as any;useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{...tab('/repo/a.ts','restored'),isOrphaned:true}]} as any);
 await reloadCleanRepoTabs('/repo');expect(useEditorStore.getState().tabs[0].isOrphaned).toBe(false);expect(useEditorStore.getState().tabs[0].content).toBe('restored');
});
it('does not label unreadable files deleted or mark a newer tab after a late missing-file read',async()=>{
 window.nexelAPI={...mockNexelAPI,readFileContent:vi.fn().mockRejectedValue(Error('EACCES: permission denied'))} as any;useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[tab('/repo/a.ts','old')]} as any);await reloadCleanRepoTabs('/repo');expect(useEditorStore.getState().tabs[0].isOrphaned).not.toBe(true);
 let reject!:(reason:Error)=>void;window.nexelAPI.readFileContent=vi.fn(()=>new Promise<string>((_r,j)=>{reject=j;}));const pending=reloadCleanRepoTabs('/repo');const replacement={...tab('/repo/a.ts','new')};useEditorStore.setState({tabs:[replacement]} as any);reject(Error('ENOENT'));await pending;expect(useEditorStore.getState().tabs[0].isOrphaned).not.toBe(true);expect(useEditorStore.getState().tabs[0].content).toBe('new');
});
it('does not infer missing status from ENOENT in an unreadable filename or message',async()=>{
 useWorkspaceStore.setState({rootPath:'/repo'});
 for(const error of [Error("Error invoking remote method 'fs:read-file-content': Error: EACCES: permission denied, open '/repo/ENOENT.cpp'"),Object.assign(Error('ENOENT: misleading text'),{code:'EACCES'})]){
  window.nexelAPI={...mockNexelAPI,readFileContent:vi.fn().mockRejectedValue(error)} as any;
  useEditorStore.setState({tabs:[tab('/repo/ENOENT.cpp','old')]} as any);
  await reloadCleanRepoTabs('/repo');expect(useEditorStore.getState().tabs[0].isOrphaned).not.toBe(true);
 }
 window.nexelAPI.readFileContent=vi.fn().mockRejectedValue(Error("Error invoking remote method 'fs:read-file-content': Error: ENOENT: no such file or directory, open '/repo/ENOENT.cpp'"));
 await reloadCleanRepoTabs('/repo');expect(useEditorStore.getState().tabs[0].isOrphaned).toBe(true);
});
it('reloads clean canonical in-repo tabs without changing their alias spelling or touching dirty/foreign buffers',async()=>{
 const read=vi.fn().mockResolvedValue('external');const resolve=vi.fn(async(p:string)=>p==='/alias'?'/real':p);
 window.nexelAPI={...mockNexelAPI,realPath:resolve,readFileContent:read} as any;useWorkspaceStore.setState({rootPath:'/alias'});
 useEditorStore.setState({tabs:[tab('/real/a.ts','old'),tab('/real/dirty.ts','mine',true),tab('/really/foreign.ts','foreign')]} as any);
 await reloadCleanRepoTabs('/alias');expect(read).toHaveBeenCalledTimes(1);expect(read).toHaveBeenCalledWith('/real/a.ts');
 expect(useEditorStore.getState().tabs.map(t=>({path:t.filePath,content:t.content,dirty:t.isDirty}))).toEqual([{path:'/real/a.ts',content:'external',dirty:false},{path:'/real/dirty.ts',content:'mine',dirty:true},{path:'/really/foreign.ts',content:'foreign',dirty:false}]);
});
it('abandons canonical membership discovery when its tab changes or workspace switches',async()=>{
 let finish!:(s:string)=>void;const read=vi.fn().mockResolvedValue('external');
 window.nexelAPI={...mockNexelAPI,realPath:vi.fn(async(p:string)=>p==='/alias'?'/real':new Promise<string>(r=>finish=r)),readFileContent:read} as any;useWorkspaceStore.setState({rootPath:'/alias'});useEditorStore.setState({tabs:[tab('/real/a.ts','old')]} as any);
 const pending=reloadCleanRepoTabs('/alias');await new Promise(r=>setTimeout(r,0));useWorkspaceStore.setState({rootPath:'/other'});finish('/real/a.ts');await pending;expect(read).not.toHaveBeenCalled();expect(useEditorStore.getState().tabs[0].content).toBe('old');
});
it('preserves a buffer edited during alias lookup and skips aliases that cannot be resolved',async()=>{
 let finish!:(s:string)=>void;const read=vi.fn().mockResolvedValue('external');
 window.nexelAPI={...mockNexelAPI,realPath:vi.fn(async(p:string)=>p==='/alias'?'/real':new Promise<string>(r=>finish=r)),readFileContent:read} as any;useWorkspaceStore.setState({rootPath:'/alias'});useEditorStore.setState({tabs:[tab('/real/a.ts','old')]} as any);
 const pending=reloadCleanRepoTabs('/alias');await new Promise(r=>setTimeout(r,0));useEditorStore.getState().updateTabContent('/real/a.ts','typing');finish('/real/a.ts');await pending;expect(read).not.toHaveBeenCalled();expect(useEditorStore.getState().tabs[0].content).toBe('typing');
 window.nexelAPI.realPath=vi.fn().mockRejectedValue(Error('ENOENT'));useEditorStore.setState({tabs:[tab('/real/a.ts','old')]} as any);await reloadCleanRepoTabs('/alias');expect(read).not.toHaveBeenCalled();expect(useEditorStore.getState().tabs[0].content).toBe('old');expect(useEditorStore.getState().tabs[0].isOrphaned).not.toBe(true);
});
it('newer alias reload supersedes an older canonical lookup before disk reading',async()=>{
 let first!:(s:string)=>void;let calls=0;const read=vi.fn().mockResolvedValue('current');
 window.nexelAPI={...mockNexelAPI,realPath:vi.fn(async(p:string)=>{if(p==='/alias')return '/real';if(++calls===1)return new Promise<string>(r=>first=r);return p;}),readFileContent:read} as any;
 useWorkspaceStore.setState({rootPath:'/alias'});useEditorStore.setState({tabs:[tab('/real/a.ts','old')]} as any);
 const older=reloadCleanRepoTabs('/alias');await new Promise(r=>setTimeout(r,0));await reloadCleanRepoTabs('/alias');first('/real/a.ts');await older;expect(read).toHaveBeenCalledTimes(1);expect(useEditorStore.getState().tabs[0].content).toBe('current');
});
