import { describe, it, expect, vi, beforeEach } from 'vitest';
import { act, render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GitPanel } from '../GitPanel';
import { GitStatusChip } from '../GitStatusChip';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';
import { emitGitChanged } from '../gitEvents';

const conflictStatus = {
  isRepo: true, branch: 'main', ahead: 0, behind: 0, hasUpstream: true,
  entries: [
    { path: 'both.ts', code: 'UU', staged: false, unstaged: false, untracked: false, conflicted: true },
    { path: 'gone.ts', code: 'UD', staged: false, unstaged: false, untracked: false, conflicted: true },
  ],
};

describe('git surface synchronization', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
  });

  it('chip re-reads immediately when a git mutation is emitted (no poll wait)', async () => {
    let branch = 'master';
    (window.nexelAPI.gitStatus as any) = vi.fn().mockImplementation(async () => ({
      isRepo: true, branch, ahead: 0, behind: 0, entries: [],
    }));
    const { container } = render(<GitStatusChip />);
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('master'));
    branch = 'very-long-feature-branch';
    emitGitChanged('/repo');
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('very-long-feature-branch'));
    // event for a different root is ignored
    branch = 'wrong';
    emitGitChanged('/other');
    await new Promise((r) => setTimeout(r, 50));
    expect(container.querySelector('.nx-git-chip')!.textContent).toBe('very-long-feature-branch');
  });

  it('panel mutation emits gitChanged so the chip updates without its poll', async () => {
    let branch = 'master';
    (window.nexelAPI.gitStatus as any) = vi.fn().mockImplementation(async () => ({
      isRepo: true, branch, ahead: 0, behind: 0, hasUpstream: true, entries: [],
    }));
    (window.nexelAPI.gitBranches as any) = vi.fn().mockResolvedValue({ ok: true, branches: ['master'], current: 'master' });
    (window.nexelAPI.gitCreateBranch as any) = vi.fn().mockImplementation(async () => { branch = 'created-via-panel'; return { ok: true }; });
    const { container } = render(<><GitStatusChip /><GitPanel /></>);
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('master'));
    fireEvent.click(screen.getByTitle('Create branch'));
    fireEvent.change(screen.getByPlaceholderText(/new branch/i), { target: { value: 'created-via-panel' } });
    fireEvent.keyDown(screen.getByPlaceholderText(/new branch/i), { key: 'Enter' });
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('created-via-panel'));
    expect(window.nexelAPI.gitCreateBranch).toHaveBeenCalledWith('/repo', 'created-via-panel');
  });
});

describe('accessible conflict hints', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(conflictStatus);
  });

  it('hint toggle reveals visible per-code guidance, keyboard accessible, aria-expanded', async () => {
    render(<GitPanel />);
    const toggle = await screen.findByRole('button', { name: /how to resolve both\.ts/i });
    expect(toggle.getAttribute('aria-expanded')).toBe('false');
    expect(screen.queryByRole('note')).toBeNull();
    fireEvent.click(toggle);
    const note = await screen.findByRole('note');
    expect(note.textContent).toContain('conflict markers');
    expect(toggle.getAttribute('aria-expanded')).toBe('true');
    // per-code: modify/delete file gets the keep-or-delete guidance, not marker text;
    // opening another file's hint collapses the first (single expansion)
    const goneToggle = screen.getByRole('button', { name: /how to resolve gone\.ts/i });
    fireEvent.click(goneToggle);
    expect(screen.getAllByRole('note').some((n) => n.textContent!.includes('deleted on the other'))).toBe(true);
    expect(toggle.getAttribute('aria-expanded')).toBe('false');
    // toggle off
    fireEvent.click(goneToggle);
    await waitFor(() => expect(goneToggle.getAttribute('aria-expanded')).toBe('false'));
    expect(screen.queryByRole('note')).toBeNull();
  });
});

describe('external git changes', () => {
  it('chip and panel refresh when main reports an external git metadata change', async () => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    let branch = 'master';
    let changes = 0;
    (window.nexelAPI.gitStatus as any) = vi.fn().mockImplementation(async () => ({
      isRepo: true, branch, ahead: 0, behind: 0, entries: Array.from({ length: changes }, (_, i) => ({ path: 'f' + i, code: ' M', staged: false, unstaged: true, untracked: false })),
    }));
    (window.nexelAPI.gitBranches as any) = vi.fn().mockImplementation(async () => ({ ok: true, branches: [branch], current: branch }));
    let externalCb: ((root: string) => void) | null = null;
    (window.nexelAPI.gitWatch as any) = vi.fn().mockResolvedValue({ ok: true, watching: true });
    (window.nexelAPI.onGitExternalChange as any) = (cb: (root: string) => void) => { externalCb = cb; return () => { externalCb = null; }; };
    const { container } = render(<GitStatusChip />);
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('master'));
    expect(window.nexelAPI.gitWatch).toHaveBeenCalledWith('/repo');
    branch = 'terminal-branch'; // user ran: git switch -c terminal-branch
    externalCb!('/repo');
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('terminal-branch'));
    changes = 2; // user staged/edited in terminal
    externalCb!('/repo');
    await waitFor(() => expect(container.querySelector('.nx-git-chip')!.textContent).toBe('terminal-branch ±2'));
  });
});

it('keeps the latest chip status when older reads resolve or reject later',async()=>{
 let resolve!:(value:any)=>void;let reject!:(reason:Error)=>void;
 const old=new Promise(r=>{resolve=r;});const failed=new Promise((_r,j)=>{reject=j;});
 const status=(branch:string)=>({isRepo:true,branch,entries:[],ahead:0,behind:0});
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue(status('initial'))} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});const {container}=render(<GitStatusChip/>);await screen.findByTitle(/Branch initial/);await act(async()=>{});(window.nexelAPI.gitStatus as any).mockReset().mockReturnValueOnce(old).mockResolvedValueOnce(status('current')).mockReturnValueOnce(failed).mockResolvedValueOnce(status('newest'));
 act(()=>emitGitChanged('/repo'));act(()=>emitGitChanged('/repo'));await screen.findByTitle(/Branch current/);await act(async()=>resolve(status('stale')));expect(container.querySelector('.nx-git-chip')).toHaveTextContent('current');
 act(()=>emitGitChanged('/repo'));act(()=>emitGitChanged('/repo'));await screen.findByTitle(/Branch newest/);await act(async()=>reject(Error('old failure')));expect(container.querySelector('.nx-git-chip')).toHaveTextContent('newest');
});

it('arms metadata watching after this folder becomes a repository, without restarting on each refresh',async()=>{
 let isRepo=false;const watch=vi.fn().mockResolvedValue({ok:true,watching:true});
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn(async()=>({isRepo,branch:'main',hasUpstream:false,ahead:0,behind:0,entries:[]})),gitWatch:watch,onGitExternalChange:vi.fn(()=>()=>{})} as any;
 useWorkspaceStore.setState({rootPath:'/new-folder'});const {unmount}=render(<GitStatusChip/>);
 await waitFor(()=>expect(window.nexelAPI.gitStatus).toHaveBeenCalled());await act(async()=>{});
 expect(watch).not.toHaveBeenCalledWith('/new-folder');
 isRepo=true;act(()=>emitGitChanged('/new-folder'));await screen.findByTitle(/Branch main/);await waitFor(()=>expect(watch).toHaveBeenCalledWith('/new-folder'));
 act(()=>emitGitChanged('/new-folder'));await act(async()=>{});expect(watch.mock.calls.filter(args=>args[0]==='/new-folder')).toHaveLength(1);
 unmount();expect(watch).toHaveBeenLastCalledWith(null);
});
it('retries a refused watch on a later refresh but does not watch a nested-root boundary',async()=>{
 const watch=vi.fn().mockResolvedValueOnce({ok:true,watching:false}).mockRejectedValueOnce(Error('fixture watch unavailable')).mockResolvedValue({ok:true,watching:true});
 let nested=false;window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn(async()=>({isRepo:true,repositoryRoot:nested?'/parent':undefined,branch:'main',hasUpstream:false,ahead:0,behind:0,entries:[]})),gitWatch:watch,onGitExternalChange:vi.fn(()=>()=>{})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});render(<GitStatusChip/>);await waitFor(()=>expect(watch).toHaveBeenCalledTimes(1));await act(async()=>{});
 act(()=>emitGitChanged('/repo'));await waitFor(()=>expect(watch).toHaveBeenCalledTimes(2));await act(async()=>{});
 act(()=>emitGitChanged('/repo'));await waitFor(()=>expect(watch).toHaveBeenCalledTimes(3));await act(async()=>{});
 nested=true;act(()=>useWorkspaceStore.setState({rootPath:'/parent/child'}));await act(async()=>{});expect(watch).not.toHaveBeenCalledWith('/parent/child');
});
it('does not arm a stale discovery response after workspace change',async()=>{
 let resolve!:(v:any)=>void;const watch=vi.fn().mockResolvedValue({ok:true,watching:true});
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockReturnValueOnce(new Promise(r=>resolve=r)).mockResolvedValue({isRepo:false,entries:[]}),gitWatch:watch,onGitExternalChange:vi.fn(()=>()=>{})} as any;
 useWorkspaceStore.setState({rootPath:'/old'});render(<GitStatusChip/>);act(()=>useWorkspaceStore.setState({rootPath:'/new'}));await act(async()=>resolve({isRepo:true,branch:'old',entries:[]}));expect(watch).not.toHaveBeenCalledWith('/old');expect(watch).not.toHaveBeenCalledWith('/new');
});
it('reconciles changes that land between discovery and successful watch registration',async()=>{
 let branch='before-watch';let finish!:(v:any)=>void;
 const watch=vi.fn().mockReturnValue(new Promise(r=>finish=r));
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn(async()=>({isRepo:true,branch,entries:[],hasUpstream:false,ahead:0,behind:0})),gitWatch:watch,onGitExternalChange:vi.fn(()=>()=>{})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});render(<GitStatusChip/>);await screen.findByTitle(/Branch before-watch/);await waitFor(()=>expect(watch).toHaveBeenCalledWith('/repo'));
 branch='during-watch';await act(async()=>finish({ok:true,watching:true}));await screen.findByTitle(/Branch during-watch/);expect(watch.mock.calls.filter(args=>args[0]==='/repo')).toHaveLength(1);
});
it('reconciles clean open buffers as well as status after watch registration',async()=>{
 const {useEditorStore}=await import('../../../stores/useEditorStore');let finish!:(v:any)=>void;
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue({isRepo:true,branch:'main',entries:[]}),gitWatch:vi.fn().mockReturnValue(new Promise(r=>finish=r)),onGitExternalChange:vi.fn(()=>()=>{}),readFileContent:vi.fn().mockResolvedValue('after registration gap')} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{id:'/repo/a.ts',filePath:'/repo/a.ts',name:'a.ts',content:'before',originalContent:'before',isDirty:false,language:'typescript'}]} as any);
 render(<GitStatusChip/>);await screen.findByTitle(/Branch main/);await act(async()=>finish({ok:true,watching:true}));await waitFor(()=>expect(useEditorStore.getState().tabs[0].content).toBe('after registration gap'));useEditorStore.setState({tabs:[]} as any);
});
