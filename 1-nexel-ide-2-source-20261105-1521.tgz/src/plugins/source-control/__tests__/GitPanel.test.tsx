import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GitPanel } from '../GitPanel';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';

const cleanStatus = { isRepo: true, branch: 'main', ahead: 0, behind: 0, entries: [] as any[] };
const dirtyStatus = {
  isRepo: true, branch: 'main', ahead: 1, behind: 0,
  entries: [
    { path: 'a.ts', code: 'M ', staged: true, unstaged: false, untracked: false },
    { path: 'b.ts', code: ' M', staged: false, unstaged: true, untracked: false },
    { path: 'c.ts', code: '??', staged: false, unstaged: false, untracked: true },
  ],
};

describe('GitPanel', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
  });

  it('prompts to open a workspace when none is open', () => {
    useWorkspaceStore.setState({ rootPath: null } as any);
    render(<GitPanel />);
    expect(screen.getByText(/open a workspace folder/i)).toBeTruthy();
  });

  it('offers git init when the workspace is not a repository', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ ...cleanStatus, isRepo: false });
    (window.nexelAPI.gitInit as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    const btn = await screen.findByRole('button', { name: /initialize/i });
    fireEvent.click(btn);
    await waitFor(() => expect(window.nexelAPI.gitInit).toHaveBeenCalledWith('/repo'));
  });

  it('groups staged, unstaged and untracked entries and stages on click', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(dirtyStatus);
    (window.nexelAPI.gitStage as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    await screen.findByText('Staged changes (1)');
    expect(screen.getByText('Changes (1)')).toBeTruthy();
    expect(screen.getByText('Untracked (1)')).toBeTruthy();
    fireEvent.click(screen.getAllByTitle('Stage')[0]);
    await waitFor(() => expect(window.nexelAPI.gitStage).toHaveBeenCalledWith('/repo', ['b.ts']));
  });

  it('disables commit with nothing staged and commits staged files with the message', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(dirtyStatus);
    (window.nexelAPI.gitCommit as any) = vi.fn().mockResolvedValue({ ok: true, output: '1 file changed' });
    render(<GitPanel />);
    const btn = await screen.findByRole('button', { name: /commit 1 file/i });
    expect((btn as HTMLButtonElement).disabled).toBe(true); // empty message
    fireEvent.change(screen.getByPlaceholderText(/commit message/i), { target: { value: 'fix a' } });
    expect((btn as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(btn);
    await waitFor(() => expect(window.nexelAPI.gitCommit).toHaveBeenCalledWith('/repo', 'fix a'));
  });

  it('shows git errors inline without throwing', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(dirtyStatus);
    (window.nexelAPI.gitStage as any) = vi.fn().mockResolvedValue({ ok: false, error: 'index.lock exists' });
    render(<GitPanel />);
    fireEvent.click(await screen.findAllByTitle('Stage').then((b) => b[0]));
    await screen.findByText(/index\.lock exists/);
  });
});
it('shows failed status as unknown and offers retry instead of stale clean rows',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValueOnce(cleanStatus).mockRejectedValueOnce(Error('index unreadable')).mockResolvedValue(cleanStatus)} as any;
 render(<GitPanel/>);await screen.findByText('Working tree clean.');fireEvent.click(screen.getByRole('button',{name:'Refresh'}));await screen.findByText(/Git error: index unreadable/);expect(screen.queryByText('Working tree clean.')).toBeNull();fireEvent.click(screen.getByRole('button',{name:'Retry git status'}));await screen.findByText('Working tree clean.');
});
