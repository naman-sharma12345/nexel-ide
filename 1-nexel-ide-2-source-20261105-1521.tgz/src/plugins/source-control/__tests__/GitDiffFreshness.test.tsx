import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, expect, it, vi } from 'vitest';
import { GitPanel } from '../GitPanel';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';
const deferred = () => { let resolve!: (value: { ok: boolean; diff: string }) => void;const promise = new Promise<{ok:boolean;diff:string}>(r => { resolve=r; });return {promise,resolve}; };
beforeEach(() => {
  vi.restoreAllMocks();window.nexelAPI = { ...mockNexelAPI } as any;
  useWorkspaceStore.setState({rootPath:'/repo'});
  window.nexelAPI.gitStatus = vi.fn().mockResolvedValue({isRepo:true,branch:'main',hasUpstream:true,ahead:0,behind:0,entries:['a.cpp','b.cpp'].map(path=>({path,code:' M',staged:false,unstaged:true,untracked:false}))});
});
it('keeps the most recently requested diff when responses arrive out of order', async () => {
  const a=deferred(),b=deferred();window.nexelAPI.gitDiff=vi.fn().mockImplementationOnce(()=>a.promise).mockImplementationOnce(()=>b.promise);
  const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');
  const buttons=screen.getAllByTitle('View unstaged diff');fireEvent.click(buttons[0]);fireEvent.click(buttons[1]);
  await act(async()=>b.resolve({ok:true,diff:'+NEW B'}));await act(async()=>a.resolve({ok:true,diff:'+OLD A'}));
  expect(container.querySelector('.nx-git-diff-title')?.textContent).toContain('b.cpp');expect(screen.queryByText('+OLD A')).toBeNull();
});
it('does not reopen a closed diff when an older request resolves', async () => {
  const a=deferred();window.nexelAPI.gitDiff=vi.fn().mockImplementationOnce(()=>a.promise).mockResolvedValueOnce({ok:true,diff:'+NEW B'});
  const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');const buttons=screen.getAllByTitle('View unstaged diff');
  fireEvent.click(buttons[0]);fireEvent.click(buttons[1]);await screen.findByText('+NEW B');fireEvent.click(screen.getByRole('button',{name:/^Close$/}));
  await act(async()=>a.resolve({ok:true,diff:'+OLD A'}));expect(container.querySelector('.nx-git-diff')).toBeNull();
});
it('drops visible and pending old-workspace diffs on root change', async () => {
  const a=deferred();window.nexelAPI.gitDiff=vi.fn().mockResolvedValueOnce({ok:true,diff:'+OLD VISIBLE'}).mockImplementationOnce(()=>a.promise);
  const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+OLD VISIBLE');
  fireEvent.click(screen.getAllByTitle('View unstaged diff')[1]);act(()=>useWorkspaceStore.setState({rootPath:'/other'}));
  await act(async()=>a.resolve({ok:true,diff:'+OLD LATE'}));await waitFor(()=>expect(container.querySelector('.nx-git-diff')).toBeNull());
});

it('ignores late failures and handles a current rejected diff without reopening the viewer', async () => {
  const a=deferred();window.nexelAPI.gitDiff=vi.fn().mockImplementationOnce(()=>a.promise).mockResolvedValueOnce({ok:true,diff:'+NEW B'}).mockRejectedValueOnce(new Error('read failed'));
  const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');const buttons=screen.getAllByTitle('View unstaged diff');
  fireEvent.click(buttons[0]);fireEvent.click(buttons[1]);await screen.findByText('+NEW B');
  await act(async()=>a.resolve({ok:false,diff:''}));expect(screen.queryByText(/Diff failed/)).toBeNull();
  fireEvent.click(buttons[0]);await screen.findByText('Diff failed: read failed');expect(container.querySelector('.nx-git-diff-title')?.textContent).toContain('b.cpp');
});

it('clears old repository metadata when the next repository has an empty history', async () => {
  window.nexelAPI.gitLog=vi.fn().mockResolvedValueOnce({ok:true,commits:[{hash:'abc',subject:'old repository commit',author:'Fixture',date:'today'}]}).mockResolvedValue({ok:true,commits:[]});
  render(<GitPanel/>);await screen.findByText(/History \(1\)/);act(()=>useWorkspaceStore.setState({rootPath:'/other'}));
  await waitFor(()=>expect(screen.queryByText(/History \(1\)/)).toBeNull());
});
it('does not offer old repository file actions while new repository status is loading', async () => {
  let resolve!: (value: any) => void;
  const next = new Promise(r => { resolve=r; });
  window.nexelAPI.gitStatus=vi.fn().mockResolvedValueOnce({isRepo:true,branch:'old',hasUpstream:true,ahead:0,behind:0,entries:[{path:'old.cpp',code:' M',staged:false,unstaged:true,untracked:false}]}).mockReturnValue(next);
  render(<GitPanel/>);await screen.findByText('old.cpp');act(()=>useWorkspaceStore.setState({rootPath:'/other'}));
  expect(screen.queryByTitle('Stage')).toBeNull();
  await act(async()=>resolve({isRepo:true,branch:'new',hasUpstream:false,ahead:0,behind:0,entries:[]}));
});
it('does not let an older status refresh replace the newest repository status', async () => {
  let resolve!: (value: any) => void;const late=new Promise(r=>{resolve=r;});
  const status=(path:string)=>({isRepo:true,branch:'main',hasUpstream:true,ahead:0,behind:0,entries:[{path,code:' M',staged:false,unstaged:true,untracked:false}]});
  window.nexelAPI.gitStatus=vi.fn().mockResolvedValueOnce(status('initial.cpp')).mockReturnValueOnce(late).mockResolvedValueOnce(status('current.cpp'));
  render(<GitPanel/>);await screen.findByText('initial.cpp');fireEvent.click(screen.getByRole('button',{name:'Refresh'}));fireEvent.click(screen.getByRole('button',{name:'Refresh'}));
  await screen.findByText('current.cpp');await act(async()=>resolve(status('stale.cpp')));expect(screen.queryByText('stale.cpp')).toBeNull();expect(screen.getByText('current.cpp')).toBeTruthy();
});
it('keeps an old operation failure out of the new repository panel',async()=>{
 let resolve!:(value:any)=>void;const pending=new Promise(r=>{resolve=r;});window.nexelAPI.gitStage=vi.fn().mockReturnValue(pending);
 render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('Stage')[0]);
 act(()=>useWorkspaceStore.setState({rootPath:'/other'}));await screen.findByText('a.cpp');
 await act(async()=>resolve({ok:false,error:'old repo failure'}));expect(screen.queryByText(/old repo failure/)).toBeNull();
});
it('keeps commit and branch drafts with their own repository and restores them on return',async()=>{
 render(<GitPanel/>);await screen.findByText('a.cpp');
 fireEvent.change(screen.getByPlaceholderText('Commit message (main)'),{target:{value:'repo A commit'}});
 fireEvent.click(screen.getByTitle('Create branch'));fireEvent.change(screen.getByPlaceholderText('new branch'),{target:{value:'repo-a-branch'}});
 act(()=>useWorkspaceStore.setState({rootPath:'/other'}));await screen.findByText('a.cpp');
 expect(screen.getByPlaceholderText('Commit message (main)')).toHaveValue('');expect(screen.queryByPlaceholderText('new branch')).toBeNull();
 fireEvent.change(screen.getByPlaceholderText('Commit message (main)'),{target:{value:'repo B commit'}});
 act(()=>useWorkspaceStore.setState({rootPath:'/repo'}));await screen.findByText('a.cpp');
 expect(screen.getByPlaceholderText('Commit message (main)')).toHaveValue('repo A commit');expect(screen.getByPlaceholderText('new branch')).toHaveValue('repo-a-branch');
 act(()=>useWorkspaceStore.setState({rootPath:'/other'}));await screen.findByText('a.cpp');expect(screen.getByPlaceholderText('Commit message (main)')).toHaveValue('repo B commit');
});
it('does not erase newer commit typing when an earlier commit completes',async()=>{
 let resolve!:(value:any)=>void;const pending=new Promise(r=>{resolve=r;});window.nexelAPI.gitCommit=vi.fn().mockReturnValue(pending);
 window.nexelAPI.gitStatus=vi.fn().mockResolvedValue({isRepo:true,branch:'main',hasUpstream:true,ahead:0,behind:0,entries:[{path:'a.cpp',code:'M ',staged:true,unstaged:false,untracked:false}]});
 render(<GitPanel/>);const field=await screen.findByPlaceholderText('Commit message (main)');fireEvent.change(field,{target:{value:'submitted'}});fireEvent.click(screen.getByRole('button',{name:'Commit 1 file'}));fireEvent.change(field,{target:{value:'next draft'}});
 await act(async()=>resolve({ok:true}));expect(field).toHaveValue('next draft');
});
it('invalidates visible and pending diffs after a repository mutation event',async()=>{
 const {emitGitChanged}=await import('../gitEvents');const late=deferred();window.nexelAPI.gitDiff=vi.fn().mockResolvedValueOnce({ok:true,diff:'+before stage'}).mockReturnValueOnce(late.promise);
 const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+before stage');
 fireEvent.click(screen.getAllByTitle('View unstaged diff')[1]);act(()=>emitGitChanged('/repo'));expect(container.querySelector('.nx-git-diff')).toBeNull();
 await act(async()=>late.resolve({ok:true,diff:'+obsolete pending'}));expect(container.querySelector('.nx-git-diff')).toBeNull();
});
it('starts only one operation for repeated Stage activation while pending',async()=>{
 let resolve!:(value:any)=>void;const pending=new Promise(r=>{resolve=r;});window.nexelAPI.gitStage=vi.fn().mockReturnValue(pending);
 render(<GitPanel/>);await screen.findByText('a.cpp');const stage=screen.getAllByTitle('Stage')[0];fireEvent.click(stage);fireEvent.click(stage);
 expect(window.nexelAPI.gitStage).toHaveBeenCalledTimes(1);await act(async()=>resolve({ok:false,error:'done'}));
});
it('does not let old-root completion unlock a newer-root operation',async()=>{
 let old!:(value:any)=>void,next!:(value:any)=>void;
 window.nexelAPI.gitStage=vi.fn().mockReturnValueOnce(new Promise(r=>{old=r;})).mockReturnValueOnce(new Promise(r=>{next=r;}));
 render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('Stage')[0]);act(()=>useWorkspaceStore.setState({rootPath:'/other'}));await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('Stage')[0]);
 await act(async()=>old({ok:false,error:'old'}));expect(screen.getAllByTitle('Stage')[0]).toBeDisabled();fireEvent.click(screen.getAllByTitle('Stage')[0]);expect(window.nexelAPI.gitStage).toHaveBeenCalledTimes(2);
 await act(async()=>next({ok:false,error:'next'}));expect(screen.getAllByTitle('Stage')[0]).not.toBeDisabled();
});
it('invalidates visible and pending old diffs when explicitly refreshing status',async()=>{
 const late=deferred();window.nexelAPI.gitDiff=vi.fn().mockResolvedValueOnce({ok:true,diff:'+old disk'}).mockReturnValueOnce(late.promise);
 const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+old disk');fireEvent.click(screen.getAllByTitle('View unstaged diff')[1]);fireEvent.click(screen.getByRole('button',{name:'Refresh'}));expect(container.querySelector('.nx-git-diff')).toBeNull();await act(async()=>late.resolve({ok:true,diff:'+late old disk'}));expect(container.querySelector('.nx-git-diff')).toBeNull();
});
it('preserves a rejected branch name for correction and clears it only after successful creation',async()=>{
 window.nexelAPI.gitCreateBranch=vi.fn().mockResolvedValueOnce({ok:false,error:'invalid branch'}).mockResolvedValueOnce({ok:true});render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getByTitle('Create branch'));const field=screen.getByPlaceholderText('new branch');fireEvent.change(field,{target:{value:'bad..branch'}});fireEvent.keyDown(field,{key:'Enter'});await screen.findByText(/invalid branch/);expect(screen.getByPlaceholderText('new branch')).toHaveValue('bad..branch');fireEvent.change(field,{target:{value:'valid-branch'}});fireEvent.keyDown(field,{key:'Enter'});await waitFor(()=>expect(screen.queryByPlaceholderText('new branch')).toBeNull());expect(window.nexelAPI.gitCreateBranch).toHaveBeenLastCalledWith('/repo','valid-branch');
});
it('exposes a named keyboard-focusable diff reader',async()=>{
 window.nexelAPI.gitDiff=vi.fn().mockResolvedValue({ok:true,diff:'+visible content'});render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+visible content');const reader=screen.getByRole('region',{name:'Unstaged diff for a.cpp'});expect(reader).toHaveAttribute('tabindex','0');reader.focus();expect(document.activeElement).toBe(reader);
});
it('drops stale same-root metadata on structured failure and recovers on Refresh without hiding operation errors',async()=>{
 window.nexelAPI.gitBranches=vi.fn().mockResolvedValueOnce({ok:true,branches:['main','topic']}).mockResolvedValueOnce({ok:false,branches:[],error:'branch read denied'}).mockResolvedValue({ok:true,branches:['main','fresh']});
 window.nexelAPI.gitLog=vi.fn().mockResolvedValueOnce({ok:true,commits:[{hash:'abc',subject:'old',author:'Fixture',date:'today'}]}).mockResolvedValueOnce({ok:false,commits:[],error:'history read denied'}).mockResolvedValue({ok:true,commits:[]});
 window.nexelAPI.gitRemotes=vi.fn().mockResolvedValueOnce({ok:true,remotes:['origin']}).mockResolvedValueOnce({ok:false,remotes:[],error:'remote read denied'}).mockResolvedValue({ok:true,remotes:['new-origin']});window.nexelAPI.gitStatus=vi.fn().mockResolvedValue({isRepo:true,branch:'main',hasUpstream:false,ahead:0,behind:0,entries:[{path:'a.cpp',code:' M',staged:false,unstaged:true,untracked:false}]});window.nexelAPI.gitStage=vi.fn().mockResolvedValue({ok:false,error:'stage denied'});
 render(<GitPanel/>);await screen.findByRole('button',{name:'Publish to origin'});await screen.findByText(/History \(1\)/);fireEvent.click(screen.getByTitle('Stage'));await screen.findByText(/Stage failed: stage denied/);fireEvent.click(screen.getByRole('button',{name:'Refresh'}));await screen.findByText(/branch read denied/);expect(screen.queryByRole('option',{name:'topic'})).toBeNull();expect(screen.queryByText(/History \(1\)/)).toBeNull();expect(screen.queryByRole('button',{name:'Publish to origin'})).toBeNull();expect(screen.getByText(/Stage failed: stage denied/)).toBeInTheDocument();expect(screen.getByRole('region',{name:'Git notices'})).toHaveAttribute('tabindex','0');expect(screen.getByText(/history read denied/)).toBeInTheDocument();expect(screen.getByText(/remote read denied/)).toBeInTheDocument();expect(screen.queryByText(/no remote configured/)).toBeNull();fireEvent.click(screen.getByRole('button',{name:'Refresh'}));await screen.findByRole('button',{name:'Publish to new-origin'});expect(screen.queryByText(/read denied/)).toBeNull();expect(screen.getByRole('option',{name:'fresh'})).toBeInTheDocument();expect(screen.getByText(/Stage failed: stage denied/)).toBeInTheDocument();
});
it('keeps current status and continues other metadata reads after a rejected branch read',async()=>{
 window.nexelAPI.gitBranches=vi.fn().mockRejectedValue(new Error('transport refused'));window.nexelAPI.gitLog=vi.fn().mockResolvedValue({ok:true,commits:[{hash:'new',subject:'still readable',author:'Fixture',date:'today'}]});window.nexelAPI.gitRemotes=vi.fn().mockResolvedValue({ok:true,remotes:[]});render(<GitPanel/>);await screen.findByText(/Could not read branches: transport refused/);expect(screen.getByText('a.cpp')).toBeInTheDocument();await screen.findByText(/History \(1\)/);expect(window.nexelAPI.gitRemotes).toHaveBeenCalledWith('/repo');expect(screen.queryByText('Git status unavailable.')).toBeNull();expect(screen.getByRole('alert',{name:'Git metadata errors'})).toHaveAttribute('tabindex','0');
});
it('explains nested-root scope instead of offering file or repository mutation controls',async()=>{
 window.nexelAPI.gitStatus=vi.fn().mockResolvedValue({isRepo:true,repositoryRoot:'/parent/repo',branch:null,hasUpstream:false,ahead:0,behind:0,entries:[]});window.nexelAPI.gitBranches=vi.fn();window.nexelAPI.gitLog=vi.fn();window.nexelAPI.gitRemotes=vi.fn();render(<GitPanel/>);await screen.findByText(/Repository root:/);expect(screen.getByText('/parent/repo')).toBeInTheDocument();expect(screen.queryByRole('button')).toBeNull();expect(window.nexelAPI.gitBranches).not.toHaveBeenCalled();expect(window.nexelAPI.gitLog).not.toHaveBeenCalled();expect(window.nexelAPI.gitRemotes).not.toHaveBeenCalled();expect(useWorkspaceStore.getState().rootPath).toBe('/repo');
});
it('invalidates visible and pending diffs when window focus refreshes working-tree state',async()=>{
 const late=deferred();window.nexelAPI.gitDiff=vi.fn().mockResolvedValueOnce({ok:true,diff:'+old disk'}).mockReturnValueOnce(late.promise);
 const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+old disk');fireEvent.click(screen.getAllByTitle('View unstaged diff')[1]);fireEvent(window,new Event('focus'));expect(container.querySelector('.nx-git-diff')).toBeNull();await act(async()=>late.resolve({ok:true,diff:'+late old disk'}));expect(container.querySelector('.nx-git-diff')).toBeNull();
});
it('invalidates old diffs and refreshes only after a loaded buffer baseline changes, not each edit',async()=>{
 const {useEditorStore}=await import('../../../stores/useEditorStore');useEditorStore.setState({tabs:[{filePath:'/repo/a.cpp',name:'a.cpp',content:'old',originalContent:'old',isDirty:false}]});
 window.nexelAPI.gitDiff=vi.fn().mockResolvedValue({ok:true,diff:'+old disk'});const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+old disk');const reads=vi.mocked(window.nexelAPI.gitStatus!).mock.calls.length;
 act(()=>useEditorStore.getState().updateTabContent('/repo/a.cpp','saved current'));expect(container.querySelector('.nx-git-diff')).not.toBeNull();expect(vi.mocked(window.nexelAPI.gitStatus!).mock.calls).toHaveLength(reads);
 act(()=>useEditorStore.getState().saveTabSuccess('/repo/a.cpp','saved current'));expect(container.querySelector('.nx-git-diff')).toBeNull();await waitFor(()=>expect(vi.mocked(window.nexelAPI.gitStatus!).mock.calls.length).toBeGreaterThan(reads));
});
it('invalidates a pending patch after an aliased baseline changes, but not ordinary open/close',async()=>{
 const {useEditorStore}=await import('../../../stores/useEditorStore');useEditorStore.setState({tabs:[{filePath:'/real/a.cpp',name:'a.cpp',content:'old',originalContent:'old',isDirty:false}]});const late=deferred();window.nexelAPI.gitDiff=vi.fn().mockReturnValue(late.promise);
 const {container}=render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);const reads=vi.mocked(window.nexelAPI.gitStatus!).mock.calls.length;
 act(()=>useEditorStore.getState().openFile('/foreign/new.cpp','new.cpp','new'));act(()=>useEditorStore.getState().closeTab('/foreign/new.cpp'));expect(vi.mocked(window.nexelAPI.gitStatus!).mock.calls).toHaveLength(reads);
 act(()=>useEditorStore.getState().saveTabSuccess('/real/a.cpp','saved via alias'));await act(async()=>late.resolve({ok:true,diff:'+obsolete disk'}));expect(container.querySelector('.nx-git-diff')).toBeNull();
});
it('keeps full history metadata in a title when the visual row is truncated',async()=>{
 const author='Long fixture author '+ 'Abcdefghij'.repeat(18);window.nexelAPI.gitLog=vi.fn().mockResolvedValue({ok:true,commits:[{hash:'abcdef0',subject:'Visible subject',author,date:'2026-11-05'}]});render(<GitPanel/>);fireEvent.click(await screen.findByRole('button',{name:/History \(1\)/}));expect(screen.getByText(`${author} · 2026-11-05`)).toHaveAttribute('title',`${author} · 2026-11-05`);expect(screen.getByText('Visible subject')).toBeInTheDocument();expect(screen.getByText('abcdef0')).toHaveAttribute('title','abcdef0');
});
it('colors increment/decrement and header-like source inside hunks, not actual file headers',async()=>{
 window.nexelAPI.gitDiff=vi.fn().mockResolvedValue({ok:true,diff:'diff --git a/a.cpp b/a.cpp\n--- a/a.cpp\n+++ b/a.cpp\n@@ -1,2 +1,2 @@\n---count;\n+++count;\n--- a/source-like-header\n+++ b/source-like-header\ndiff --git a/b.cpp b/b.cpp\n--- a/b.cpp\n+++ b/b.cpp\n@@ -1 +1 @@\n-before\n+after'});
 render(<GitPanel/>);await screen.findByText('a.cpp');fireEvent.click(screen.getAllByTitle('View unstaged diff')[0]);await screen.findByText('+++count;');
 for(const line of ['+++count;','+++ b/source-like-header','+after'])expect(screen.getByText(line,{exact:true})).toHaveClass('nx-git-add');
 for(const line of ['---count;','--- a/source-like-header','-before'])expect(screen.getByText(line,{exact:true})).toHaveClass('nx-git-del');
 for(const line of ['--- a/a.cpp','+++ b/a.cpp','--- a/b.cpp','+++ b/b.cpp']){expect(screen.getByText(line,{exact:true})).not.toHaveClass('nx-git-add');expect(screen.getByText(line,{exact:true})).not.toHaveClass('nx-git-del');}
});
