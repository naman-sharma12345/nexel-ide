import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GitPanel } from '../GitPanel';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { useEditorStore } from '../../../stores/useEditorStore';
import { saveIfUnchanged } from '../../../lib/externalChange';
import { overwriteDocumentIfUnchanged } from '../../../lib/saveDocument';
import { withGitOp, withSaveLock } from '../../../lib/gitOpLock';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';

const status = { isRepo: true, branch: 'master', ahead: 0, behind: 0, entries: [] as any[] };
const deferred = <T,>() => { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r; }); return { promise, resolve }; };

describe('save/git-op serialization through the panel (controlled delayed IO)', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null } as any);
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(status);
    (window.nexelAPI.gitBranches as any) = vi.fn().mockResolvedValue({ ok: true, branches: ['master', 'feature'] });
  });

  it('branch switch waits for an inflight save write to finish first', async () => {
    const write = deferred<'written'>();
    (window.nexelAPI.writeFileIfBaseline as any) = vi.fn().mockReturnValue(write.promise);
    const switched = deferred<{ ok: boolean }>();
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockReturnValue(switched.promise);
    render(<GitPanel />);
    await screen.findByTitle('Current branch - pick another to switch');

    const order: string[] = [];
    const saveDone = saveIfUnchanged('/repo/a.ts', 'new', 'old').then(() => order.push('save'));
    await new Promise((r) => setTimeout(r, 20)); // save is now inflight
    fireEvent.change(screen.getByTitle('Current branch - pick another to switch'), { target: { value: 'feature' } });
    await new Promise((r) => setTimeout(r, 20));
    expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled(); // op still gated behind the save
    write.resolve('written');
    await saveDone;
    await waitFor(() => expect(window.nexelAPI.gitSwitch).toHaveBeenCalled());
    order.push('op');
    expect(order).toEqual(['save', 'op']);
    switched.resolve({ ok: true });
  });

  it('a save requested during a branch switch waits for the op, then conflicts-safe writes', async () => {
    const switched = deferred<{ ok: boolean }>();
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockReturnValue(switched.promise);
    (window.nexelAPI.writeFileIfBaseline as any) = vi.fn().mockResolvedValue('conflict');
    render(<GitPanel />);
    await screen.findByTitle('Current branch - pick another to switch');
    fireEvent.change(screen.getByTitle('Current branch - pick another to switch'), { target: { value: 'feature' } });
    await new Promise((r) => setTimeout(r, 20)); // op inflight
    const saveDone = saveIfUnchanged('/repo/a.ts', 'new', 'old');
    await new Promise((r) => setTimeout(r, 20));
    expect(window.nexelAPI.writeFileIfBaseline).not.toHaveBeenCalled(); // save gated behind the op
    switched.resolve({ ok: true });
    await waitFor(() => expect(window.nexelAPI.writeFileIfBaseline).toHaveBeenCalled());
    await saveDone;
  });

  it('clean-tab reload does not clobber a buffer edited while the disk read was inflight', async () => {
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockResolvedValue({ ok: true });
    const read = deferred<string>();
    (window.nexelAPI.readFileContent as any) = vi.fn().mockReturnValue(read.promise);
    useEditorStore.setState({ tabs: [{ filePath: '/repo/a.ts', name: 'a.ts', content: 'orig', originalContent: 'orig', isDirty: false }] } as any);
    render(<GitPanel />);
    await screen.findByTitle('Current branch - pick another to switch');
    fireEvent.change(screen.getByTitle('Current branch - pick another to switch'), { target: { value: 'feature' } });
    await new Promise((r) => setTimeout(r, 20)); // switch done, reload read inflight
    useEditorStore.getState().updateTabContent('/repo/a.ts', 'user typed');
    read.resolve('disk after switch');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs[0]).toMatchObject({ content: 'user typed', isDirty: true });
  });
});

describe('overwrite consent binding inside the serialized write', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useEditorStore.setState({ tabs: [{ filePath: '/repo/a.ts', name: 'a.ts', content: 'USER EDITS', originalContent: 'v0', isDirty: true }], activeTabPath: '/repo/a.ts', focusedTabPath: '/repo/a.ts' } as any);
  });

  it('a queued git op changing disk before the overwrite lock is acquired forces reconfirmation, never overwrites v2', async () => {
    let disk = 'v1';
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(async () => disk);
    (window.nexelAPI.writeFileContent as any) = vi.fn().mockImplementation(async (_p: string, c: string) => { disk = c; return true; });
    const gate = deferred<void>();
    // git op enters its critical section first; the overwrite queues behind it
    const op = withGitOp(async () => { await gate.promise; disk = 'v2'; });
    await new Promise((r) => setTimeout(r, 10));
    const result = overwriteDocumentIfUnchanged('/repo/a.ts', 'USER EDITS', 'v1');
    gate.resolve();
    await op;
    const r = await result;
    expect(r).toEqual({ status: 'mismatch', observed: 'v2' });
    expect(disk).toBe('v2'); // old consent did not overwrite the new disk bytes
    expect(useEditorStore.getState().tabs[0].isDirty).toBe(true);
  });

  it('matching observed bytes inside the lock writes and marks the tab saved', async () => {
    let disk = 'v1';
    (window.nexelAPI.readFileContent as any) = vi.fn().mockImplementation(async () => disk);
    (window.nexelAPI.writeFileContent as any) = vi.fn().mockImplementation(async (_p: string, c: string) => { disk = c; return true; });
    const r = await overwriteDocumentIfUnchanged('/repo/a.ts', 'USER EDITS', 'v1');
    expect(r).toEqual({ status: 'written' });
    expect(disk).toBe('USER EDITS');
    expect(useEditorStore.getState().tabs[0].isDirty).toBe(false);
  });

  it('clean-tab reload skips a close/reopened tab even with byte-identical content', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(status);
    (window.nexelAPI.gitBranches as any) = vi.fn().mockResolvedValue({ ok: true, branches: ['master', 'feature'] });
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockResolvedValue({ ok: true });
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [{ filePath: '/repo/a.ts', name: 'a.ts', content: 'orig', originalContent: 'orig', isDirty: false }], activeTabPath: null, focusedTabPath: null } as any);
    const read = deferred<string>();
    (window.nexelAPI.readFileContent as any) = vi.fn().mockReturnValue(read.promise);
    render(<GitPanel />);
    await screen.findByTitle('Current branch - pick another to switch');
    fireEvent.change(screen.getByTitle('Current branch - pick another to switch'), { target: { value: 'feature' } });
    await new Promise((r) => setTimeout(r, 20)); // switch done, reload read inflight
    // close + reopen with byte-identical content (stale reopen read): a NEW tab instance
    useEditorStore.getState().closeTab('/repo/a.ts');
    useEditorStore.getState().openFile('/repo/a.ts', 'a.ts', 'orig');
    read.resolve('disk after switch');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs[0]).toMatchObject({ content: 'orig', isDirty: false });
  });
});

it('cancels a queued branch switch across a workspace roundtrip before the save gate opens',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[]} as any);
 const gate=deferred<void>();const save=withSaveLock(()=>gate.promise);
 const {rerender}=render(<GitPanel/>);await screen.findByTitle('Current branch - pick another to switch');
 fireEvent.change(screen.getByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 useWorkspaceStore.setState({rootPath:'/other'});rerender(<GitPanel/>);await waitFor(()=>expect(window.nexelAPI.gitStatus).toHaveBeenCalledWith('/other'));
 useWorkspaceStore.setState({rootPath:'/repo'});rerender(<GitPanel/>);await screen.findByTitle('Current branch - pick another to switch');
 gate.resolve();await save;await new Promise(r=>setTimeout(r,30));expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();
});
it('does not enqueue repeated branch creation keys while waiting for a save',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master']}),gitCreateBranch:vi.fn().mockResolvedValue({ok:false,error:'fixture refusal'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[]} as any);
 const gate=deferred<void>();const save=withSaveLock(()=>gate.promise);render(<GitPanel/>);
 fireEvent.click(await screen.findByTitle('Create branch'));const input=screen.getByPlaceholderText('new branch');fireEvent.change(input,{target:{value:'new-target'}});fireEvent.keyDown(input,{key:'Enter'});fireEvent.keyDown(input,{key:'Enter'});
 gate.resolve();await save;await new Promise(r=>setTimeout(r,30));expect(window.nexelAPI.gitCreateBranch).toHaveBeenCalledTimes(1);
});
it('an obsolete queue release cannot unlock a new-root queue waiting on the same save',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master']}),gitCreateBranch:vi.fn().mockResolvedValue({ok:false,error:'fixture refusal'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[]} as any);
 const gate=deferred<void>();const save=withSaveLock(()=>gate.promise);const view=render(<GitPanel/>);
 fireEvent.click(await screen.findByTitle('Create branch'));fireEvent.change(screen.getByPlaceholderText('new branch'),{target:{value:'obsolete'}});fireEvent.keyDown(screen.getByPlaceholderText('new branch'),{key:'Enter'});
 useWorkspaceStore.setState({rootPath:'/other'});view.rerender(<GitPanel/>);await waitFor(()=>expect(window.nexelAPI.gitStatus).toHaveBeenCalledWith('/other'));
 fireEvent.click(await screen.findByTitle('Create branch'));fireEvent.change(screen.getByPlaceholderText('new branch'),{target:{value:'current'}});fireEvent.keyDown(screen.getByPlaceholderText('new branch'),{key:'Enter'});
 expect(screen.getByPlaceholderText('new branch')).toHaveAttribute('readonly');gate.resolve();await save;await waitFor(()=>expect(window.nexelAPI.gitCreateBranch).toHaveBeenCalledExactlyOnceWith('/other','current'));
 await waitFor(()=>expect(screen.getByPlaceholderText('new branch')).not.toHaveAttribute('readonly'));
});
it('asks about buffers edited while a branch switch waits for the save gate',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{filePath:'/repo/a.ts',name:'a.ts',content:'orig',originalContent:'orig',isDirty:false}]} as any);
 const gate=deferred<void>();const save=withSaveLock(()=>gate.promise);render(<GitPanel/>);await screen.findByTitle('Current branch - pick another to switch');fireEvent.change(screen.getByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 useEditorStore.getState().updateTabContent('/repo/a.ts','typed during wait');gate.resolve();await save;await new Promise(r=>setTimeout(r,30));expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();expect(screen.getByText(/Unsaved changes - switch to feature/)).toBeInTheDocument();
 fireEvent.click(screen.getByRole('button',{name:'Switch anyway'}));await waitFor(()=>expect(window.nexelAPI.gitSwitch).toHaveBeenCalledExactlyOnceWith('/repo','feature'));
});

it('asks before switching with a dirty real-spelled tab under a workspace alias',async()=>{
 window.nexelAPI={...mockNexelAPI,realPath:vi.fn().mockImplementation(async(p:string)=>p==='/repo'?'/real':p),gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{filePath:'/real/a.ts',name:'a.ts',content:'typed',originalContent:'orig',isDirty:true}]} as any);
 render(<GitPanel/>);fireEvent.change(await screen.findByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 await screen.findByText(/Unsaved changes - switch to feature/);expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();
 fireEvent.click(screen.getByRole('button',{name:'Switch anyway'}));await waitFor(()=>expect(window.nexelAPI.gitSwitch).toHaveBeenCalledExactlyOnceWith('/repo','feature'));
});
it('skips a verified foreign dirty tab but asks when its identity cannot be read',async()=>{
 const realPath=vi.fn().mockImplementation(async(p:string)=>p==='/repo'?'/real':p);
 window.nexelAPI={...mockNexelAPI,realPath,gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{filePath:'/foreign/a.ts',name:'a.ts',content:'typed',originalContent:'orig',isDirty:true}]} as any);
 render(<GitPanel/>);fireEvent.change(await screen.findByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 await waitFor(()=>expect(window.nexelAPI.gitSwitch).toHaveBeenCalledTimes(1));
 await waitFor(()=>expect(screen.getByTitle('Current branch - pick another to switch')).not.toBeDisabled());
 realPath.mockRejectedValue(new Error('unavailable'));fireEvent.change(screen.getByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 await screen.findByText(/Unsaved changes - switch to feature/);expect(window.nexelAPI.gitSwitch).toHaveBeenCalledTimes(1);
});
it('does not switch after workspace changes during dirty alias resolution',async()=>{
 const identity=deferred<string>();window.nexelAPI={...mockNexelAPI,realPath:vi.fn().mockReturnValue(identity.promise),gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{filePath:'/real/a.ts',name:'a.ts',content:'typed',originalContent:'orig',isDirty:true}]} as any);
 const view=render(<GitPanel/>);fireEvent.change(await screen.findByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 await waitFor(()=>expect(window.nexelAPI.realPath).toHaveBeenCalled());useWorkspaceStore.setState({rootPath:'/other'});view.rerender(<GitPanel/>);identity.resolve('/real');
 await new Promise(r=>setTimeout(r,30));expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();expect(screen.queryByText(/Unsaved changes - switch to feature/)).not.toBeInTheDocument();
});
it('rescans when a buffer becomes dirty during alias lookup',async()=>{
 const identity=deferred<string>();window.nexelAPI={...mockNexelAPI,realPath:vi.fn().mockImplementation((p:string)=>p==='/repo'?identity.promise:Promise.resolve(p)),gitStatus:vi.fn().mockResolvedValue(status),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master','feature']}),gitSwitch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[{filePath:'/foreign/a.ts',name:'a.ts',content:'typed',originalContent:'orig',isDirty:true},{filePath:'/repo/new.ts',name:'new.ts',content:'orig',originalContent:'orig',isDirty:false}]} as any);
 render(<GitPanel/>);fireEvent.change(await screen.findByTitle('Current branch - pick another to switch'),{target:{value:'feature'}});
 await waitFor(()=>expect(window.nexelAPI.realPath).toHaveBeenCalled());useEditorStore.getState().updateTabContent('/repo/new.ts','new edit');identity.resolve('/real');
 await screen.findByText(/Unsaved changes - switch to feature/);expect(screen.getByText(/1 file with unsaved changes: \/repo\/new.ts/)).toBeInTheDocument();expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();
});
