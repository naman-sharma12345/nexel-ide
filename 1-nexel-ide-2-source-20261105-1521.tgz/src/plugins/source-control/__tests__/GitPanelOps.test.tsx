import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GitPanel } from '../GitPanel';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { useEditorStore } from '../../../stores/useEditorStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';

const dirty = {
  isRepo: true, branch: 'master', ahead: 0, behind: 0,
  entries: [
    { path: 'a.ts', code: 'M ', staged: true, unstaged: false, untracked: false },
    { path: 'b.ts', code: ' M', staged: false, unstaged: true, untracked: false },
    { path: 'c.ts', code: '??', staged: false, unstaged: false, untracked: true },
  ],
};

describe('GitPanel diff/branch/pull', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null } as any);
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(dirty);
    (window.nexelAPI.gitBranches as any) = vi.fn().mockResolvedValue({ ok: true, branches: ['master', 'feature'] });
  });

  it('unstages both sides of a rename, but only the destination of a copy',async()=>{
    const unstage=vi.fn().mockResolvedValue({ok:true});window.nexelAPI.gitUnstage=unstage;
    window.nexelAPI.gitStatus=vi.fn().mockResolvedValue({...dirty,entries:[{path:'new.ts',origPath:'old.ts',code:'R ',staged:true,unstaged:false,untracked:false},{path:'copied.ts',origPath:'source.ts',code:'C ',staged:true,unstaged:false,untracked:false}]});
    render(<GitPanel/>);await screen.findByText('Staged changes (2)');fireEvent.click(screen.getAllByTitle('Unstage')[0]);await waitFor(()=>expect(unstage).toHaveBeenCalledWith('/repo',['new.ts','old.ts']));
    await waitFor(()=>expect(screen.getAllByTitle('Unstage')[1]).not.toBeDisabled());fireEvent.click(screen.getAllByTitle('Unstage')[1]);await waitFor(()=>expect(unstage).toHaveBeenCalledWith('/repo',['copied.ts']));
  });

  it('passes original path only for a staged rename review',async()=>{
    const diff=vi.fn().mockResolvedValue({ok:true,diff:'rename from old.ts\nrename to new.ts'});window.nexelAPI.gitDiff=diff;
    window.nexelAPI.gitStatus=vi.fn().mockResolvedValue({...dirty,entries:[{path:'new.ts',origPath:'old.ts',code:'RM',staged:true,unstaged:true,untracked:false}]});
    render(<GitPanel/>);await screen.findByText('Staged changes (1)');fireEvent.click(screen.getByTitle('View staged diff'));await waitFor(()=>expect(diff).toHaveBeenCalledWith('/repo','new.ts',true,'old.ts'));
    fireEvent.click(screen.getByTitle('View unstaged diff'));await waitFor(()=>expect(diff).toHaveBeenCalledWith('/repo','new.ts',false));
  });

  it('shows the staged diff inline and closes it', async () => {
    (window.nexelAPI.gitDiff as any) = vi.fn().mockResolvedValue({ ok: true, diff: '@@ -1 +1 @@\n-old\n+new' });
    render(<GitPanel />);
    await screen.findByText('Staged changes (1)');
    const diffBtns = screen.getAllByTitle('View staged diff');
    fireEvent.click(diffBtns[0]);
    await screen.findByText('+new');
    expect(screen.getByText('-old')).toBeTruthy();
    expect((window.nexelAPI.gitDiff as any).mock.calls[0]).toEqual(['/repo', 'a.ts', true]);
    fireEvent.click(screen.getByRole('button', { name: 'Close' }));
    expect(screen.queryByText('+new')).toBeNull();
  });

  it('keeps a failed op error visible across a later successful background refresh', async () => {
    (window.nexelAPI.gitFetch as any) = vi.fn().mockResolvedValue({ ok: false, error: 'some network failure' });
    render(<GitPanel />);
    await screen.findByText('Staged changes (1)');
    fireEvent.click(screen.getByRole('button', { name: 'Fetch' }));
    await screen.findByText(/Fetch failed: some network failure/);
    // A background refresh (git watcher / window focus) succeeds afterwards.
    fireEvent(window, new Event('focus'));
    await waitFor(() => expect((window.nexelAPI.gitStatus as any).mock.calls.length).toBeGreaterThanOrEqual(2));
    expect(screen.getByText(/Fetch failed: some network failure/)).toBeTruthy();
  });

  it('adds an actionable hint to credential failures without asking for secrets', async () => {
    (window.nexelAPI.gitFetch as any) = vi.fn().mockResolvedValue({ ok: false, error: "fatal: could not read Username for 'http://x': terminal prompts disabled" });
    render(<GitPanel />);
    await screen.findByText('Staged changes (1)');
    fireEvent.click(screen.getByRole('button', { name: 'Fetch' }));
    await screen.findByText(/terminal prompts disabled/);
    expect(screen.getByText(/Set them up in your git configuration/)).toBeTruthy();
    expect(screen.queryByText(/enter your password/i)).toBeNull();
  });

  it('untracked files have no diff button', async () => {
    render(<GitPanel />);
    await screen.findByText('Untracked (1)');
    expect(screen.queryAllByTitle(/view.*diff/i).length).toBe(2);
  });

  it('switches branches immediately when no dirty tabs', async () => {
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    const sel = await screen.findByTitle('Current branch - pick another to switch');
    fireEvent.change(sel, { target: { value: 'feature' } });
    await waitFor(() => expect(window.nexelAPI.gitSwitch).toHaveBeenCalledWith('/repo', 'feature'));
  });

  it('asks before switching with unsaved repo buffers; cancel aborts, continue proceeds', async () => {
    (window.nexelAPI.gitSwitch as any) = vi.fn().mockResolvedValue({ ok: true });
    useEditorStore.setState({ tabs: [{ filePath: '/repo/b.ts', name: 'b.ts', content: 'x', originalContent: 'y', isDirty: true }] } as any);
    render(<GitPanel />);
    const sel = await screen.findByTitle('Current branch - pick another to switch');
    fireEvent.change(sel, { target: { value: 'feature' } });
    await screen.findByText(/unsaved changes - switch/i);
    expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(window.nexelAPI.gitSwitch).not.toHaveBeenCalled();
    fireEvent.change(sel, { target: { value: 'feature' } });
    await screen.findByText(/unsaved changes - switch/i);
    fireEvent.click(screen.getByRole('button', { name: /switch anyway/i }));
    await waitFor(() => expect(window.nexelAPI.gitSwitch).toHaveBeenCalledWith('/repo', 'feature'));
    // dirty buffer content untouched
    expect(useEditorStore.getState().tabs[0]).toMatchObject({ content: 'x', isDirty: true });
  });

  it('pull calls gitPull and reloads a clean open tab whose file changed on disk', async () => {
    (window.nexelAPI.gitPull as any) = vi.fn().mockResolvedValue({ ok: true });
    useEditorStore.setState({ tabs: [{ filePath: '/repo/b.ts', name: 'b.ts', content: 'old', originalContent: 'old', isDirty: false }] } as any);
    (window.nexelAPI.readFileContent as any) = vi.fn().mockResolvedValue('new from disk');
    render(<GitPanel />);
    fireEvent.click(await screen.findByRole('button', { name: 'Pull' }));
    await waitFor(() => expect(window.nexelAPI.gitPull).toHaveBeenCalledWith('/repo'));
    await waitFor(() => expect(useEditorStore.getState().tabs[0]).toMatchObject({ content: 'new from disk', isDirty: false }));
  });
});

describe('GitPanel conflicts/history/push', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null } as any);
  });

  it('shows merge conflicts in their own group with a resolve hint, staging marks resolved', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({
      isRepo: true, branch: 'master', ahead: 0, behind: 0,
      entries: [
        { path: 'c.ts', code: 'UU', staged: true, unstaged: true, untracked: false, conflicted: true },
        { path: 'ok.ts', code: ' M', staged: false, unstaged: true, untracked: false },
      ],
    });
    (window.nexelAPI.gitStage as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    await screen.findByText('Merge conflicts (1)');
    expect(screen.getByText('c.ts').getAttribute('title')).toContain('conflict markers');
    // conflicted entry does not also appear in Staged/Changes groups
    expect(screen.queryByText('Staged changes (1)')).toBeNull();
    fireEvent.click(screen.getByTitle('Mark resolved (stage)'));
    await waitFor(() => expect(window.nexelAPI.gitStage).toHaveBeenCalledWith('/repo', ['c.ts']));
  });

  it('history toggle lists commits newest first', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ isRepo: true, branch: 'master', ahead: 0, behind: 0, entries: [] });
    (window.nexelAPI.gitLog as any) = vi.fn().mockResolvedValue({ ok: true, commits: [
      { hash: 'bbb2222', subject: 'second commit', author: 'Tester', date: '2026-11-04' },
      { hash: 'aaa1111', subject: 'first commit', author: 'Tester', date: '2026-11-03' },
    ] });
    render(<GitPanel />);
    fireEvent.click(await screen.findByText(/History \(2\)/));
    await screen.findByText('second commit');
    expect(screen.getByText('first commit')).toBeTruthy();
    expect(screen.getByText('aaa1111')).toBeTruthy();
  });

  it('push button calls gitPush and surfaces failures inline', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ isRepo: true, branch: 'master', hasUpstream: true, ahead: 1, behind: 0, entries: [] });
    (window.nexelAPI.gitPush as any) = vi.fn().mockResolvedValue({ ok: false, error: 'no upstream' });
    render(<GitPanel />);
    fireEvent.click(await screen.findByRole('button', { name: 'Push' }));
    await screen.findByText(/no upstream/);
    expect(window.nexelAPI.gitPush).toHaveBeenCalledWith('/repo');
  });
});

describe('GitPanel publish/branch-create/merge-gating', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = mockNexelAPI as any;
    useWorkspaceStore.setState({ rootPath: '/repo' } as any);
    useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null } as any);
    (window.nexelAPI.gitBranches as any) = vi.fn().mockResolvedValue({ ok: true, branches: ['master'] });
  });

  it('unpublished branch offers Publish to the only remote; Push button hidden', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ isRepo: true, branch: 'master', hasUpstream: false, ahead: 0, behind: 0, entries: [] });
    (window.nexelAPI.gitRemotes as any) = vi.fn().mockResolvedValue({ ok: true, remotes: ['origin'] });
    (window.nexelAPI.gitPublish as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    expect(screen.queryByRole('button', { name: 'Push' })).toBeNull();
    fireEvent.click(await screen.findByRole('button', { name: /publish to origin/i }));
    await waitFor(() => expect(window.nexelAPI.gitPublish).toHaveBeenCalledWith('/repo', 'origin', 'master'));
  });

  it('no remote configured says so instead of publishing', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ isRepo: true, branch: 'master', hasUpstream: false, ahead: 0, behind: 0, entries: [] });
    (window.nexelAPI.gitRemotes as any) = vi.fn().mockResolvedValue({ ok: true, remotes: [] });
    render(<GitPanel />);
    await screen.findByText(/no remote configured/i);
    expect(screen.queryByRole('button', { name: /publish/i })).toBeNull();
  });

  it('create branch via + and Enter calls gitCreateBranch', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({ isRepo: true, branch: 'master', hasUpstream: true, ahead: 0, behind: 0, entries: [] });
    (window.nexelAPI.gitCreateBranch as any) = vi.fn().mockResolvedValue({ ok: true });
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('Create branch'));
    fireEvent.change(screen.getByPlaceholderText('new branch'), { target: { value: 'feature-2' } });
    fireEvent.keyDown(screen.getByPlaceholderText('new branch'), { key: 'Enter' });
    await waitFor(() => expect(window.nexelAPI.gitCreateBranch).toHaveBeenCalledWith('/repo', 'feature-2'));
  });

  it('commit disabled while conflicts are unmerged', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({
      isRepo: true, branch: 'master', hasUpstream: true, ahead: 0, behind: 0,
      entries: [
        { path: 'c.ts', code: 'UU', staged: true, unstaged: true, untracked: false, conflicted: true },
        { path: 'ok.ts', code: 'M ', staged: true, unstaged: false, untracked: false },
      ],
    });
    render(<GitPanel />);
    await screen.findByText('Merge conflicts (1)');
    const btn = screen.getByRole('button', { name: /commit 1 file/i });
    expect((btn as HTMLButtonElement).disabled).toBe(true);
    expect(btn.getAttribute('title')).toBe('Resolve conflicts first');
  });

  it('delete-type conflicts get a deletion-specific hint, not a markers hint', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({
      isRepo: true, branch: 'master', hasUpstream: true, ahead: 0, behind: 0,
      entries: [{ path: 'd.ts', code: 'DU', staged: true, unstaged: true, untracked: false, conflicted: true }],
    });
    render(<GitPanel />);
    await screen.findByText('Merge conflicts (1)');
    const file = screen.getByText('d.ts');
    expect(file.getAttribute('title')).toContain('deleted on the other');
    expect(file.getAttribute('title')).not.toContain('conflict markers');
  });
});
it('branch-name composition Enter and Escape do not create or discard the draft',async()=>{
 window.nexelAPI={...mockNexelAPI,gitStatus:vi.fn().mockResolvedValue({isRepo:true,branch:'master',entries:[],ahead:0,behind:0}),gitBranches:vi.fn().mockResolvedValue({ok:true,branches:['master']}),gitCreateBranch:vi.fn().mockResolvedValue({ok:false,error:'fixture'})} as any;
 useWorkspaceStore.setState({rootPath:'/repo'});useEditorStore.setState({tabs:[]} as any);render(<GitPanel/>);
 fireEvent.click(await screen.findByTitle('Create branch'));const input=screen.getByPlaceholderText('new branch');fireEvent.change(input,{target:{value:'नाम'}});
 fireEvent.keyDown(input,{key:'Enter',isComposing:true});await new Promise(r=>setTimeout(r,10));expect(window.nexelAPI.gitCreateBranch).not.toHaveBeenCalled();
 fireEvent.keyDown(input,{key:'Escape',keyCode:229});expect(screen.getByPlaceholderText('new branch')).toHaveValue('नाम');
 fireEvent.keyDown(input,{key:'Enter'});await waitFor(()=>expect(window.nexelAPI.gitCreateBranch).toHaveBeenCalledExactlyOnceWith('/repo','नाम'));
});
