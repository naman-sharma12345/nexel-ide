import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GitPanel } from '../GitPanel';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { useEditorStore } from '../../../stores/useEditorStore';
import { mockNexelAPI } from '../../../__mocks__/nexelAPI';

// The workspace is mounted through a symlink spelling (/repo/link) while a tab
// is already open under the resolved spelling (/repo/real/a.ts). Clicking the
// file in Source Control builds abs = rootPath + '/' + relPath (the LINK
// spelling) and must focus the existing tab instead of duplicating it.
const status = {
  isRepo: true, branch: 'main', ahead: 0, behind: 0,
  entries: [{ path: 'a.ts', code: ' M', staged: false, unstaged: true, untracked: false }],
};

describe('GitPanel alias open', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = { ...mockNexelAPI } as any;
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(status);
    useWorkspaceStore.setState({ rootPath: '/repo/link' } as any);
    useEditorStore.getState().closeAllTabs();
  });

  it('focuses the existing aliased tab under its own spelling, preserving dirty content', async () => {
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p.replace('/link/', '/real/'));
    useEditorStore.getState().openFile('/repo/real/a.ts', 'a.ts', 'original');
    useEditorStore.getState().updateTabContent('/repo/real/a.ts', 'edited-dirty');
    render(<GitPanel />);
    const btn = await screen.findByTitle('a.ts');
    fireEvent.click(btn);
    await waitFor(() => expect(useEditorStore.getState().focusedTabPath).toBe('/repo/real/a.ts'));
    const s = useEditorStore.getState();
    expect(s.tabs).toHaveLength(1);
    expect(s.tabs[0].filePath).toBe('/repo/real/a.ts');
    expect(s.tabs[0].isDirty).toBe(true);
    expect(s.tabs[0].content).toBe('edited-dirty');
    useEditorStore.getState().closeAllTabs();
  });

  it('opens normally when the aliased tab vanishes via a non-invalidating removal during the realpath await', async () => {
    // Defensive depth: a tab removal that does NOT go through a navigation-intent
    // path (here a direct store setState) is caught by the existence re-validation
    // and the click falls through to a normal open of the clicked spelling.
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => {
      const r = p.replace('/link/', '/real/');
      if (p === '/repo/link/a.ts') useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null });
      return r;
    });
    useEditorStore.getState().openFile('/repo/real/a.ts', 'a.ts', 'original');
    render(<GitPanel />);
    const btn = await screen.findByTitle('a.ts');
    fireEvent.click(btn);
    await waitFor(() => expect(useEditorStore.getState().tabs).toHaveLength(1));
    const s = useEditorStore.getState();
    expect(s.tabs[0].filePath).toBe('/repo/link/a.ts'); // fresh open under the clicked spelling
    expect(s.tabs[0].isDirty).toBe(false);
    expect(s.tabs[0].content).toContain('#include <iostream>'); // read from disk via mock
    useEditorStore.getState().closeAllTabs();
  });

  it('a navigation close (closeTab) of the aliased tab during the realpath await cancels the open', async () => {
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => {
      const r = p.replace('/link/', '/real/');
      if (p === '/repo/link/a.ts') useEditorStore.getState().closeTab('/repo/real/a.ts'); // navigation close invalidates
      return r;
    });
    useEditorStore.getState().openFile('/repo/real/a.ts', 'a.ts', 'original');
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.realPath).toHaveBeenCalled());
    await waitFor(() => expect(useEditorStore.getState().tabs).toHaveLength(0));
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(0); // no fresh open, no focus steal
  });

  it('opens normally when no alias exists', async () => {
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    render(<GitPanel />);
    const btn = await screen.findByTitle('a.ts');
    fireEvent.click(btn);
    await waitFor(() => expect(useEditorStore.getState().tabs).toHaveLength(1));
    expect(useEditorStore.getState().tabs[0].filePath).toBe('/repo/link/a.ts');
    useEditorStore.getState().closeAllTabs();
  });
});

function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r; }); return { promise, resolve }; }

describe('GitPanel open navigation guards', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.nexelAPI = { ...mockNexelAPI } as any;
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue(status);
    useWorkspaceStore.setState({ rootPath: '/repo/link' } as any);
    useEditorStore.getState().closeAllTabs();
  });

  it('root switch during the realpath await cancels the alias focus', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(() => d.promise);
    useEditorStore.getState().openFile('/repo/real/a.ts', 'a.ts', 'original');
    useEditorStore.getState().setFocusedTabPath(null);
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.realPath).toHaveBeenCalled());
    useWorkspaceStore.setState({ rootPath: '/other' } as any);
    d.resolve('/repo/real/a.ts');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(1); // untouched
    expect(useEditorStore.getState().focusedTabPath).toBe(null); // no focus steal
    useEditorStore.getState().closeAllTabs();
  });

  it('root switch during the read await cancels a fresh open', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn(() => d.promise);
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalled());
    useWorkspaceStore.setState({ rootPath: '/other' } as any);
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(0); // old-workspace file never opened
  });

  it('a newer Git click invalidates the older pending open', async () => {
    (window.nexelAPI.gitStatus as any) = vi.fn().mockResolvedValue({
      ...status,
      entries: [...status.entries, { path: 'b.ts', code: ' M', staged: false, unstaged: true, untracked: false }],
    });
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn((p: string) => (p.endsWith('/a.ts') ? d.promise : Promise.resolve('b content')));
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalledWith('/repo/link/a.ts'));
    fireEvent.click(await screen.findByTitle('b.ts'));
    await waitFor(() => expect(useEditorStore.getState().tabs.map((t) => t.filePath)).toEqual(['/repo/link/b.ts']));
    d.resolve('stale a content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs.map((t) => t.filePath)).toEqual(['/repo/link/b.ts']); // a.ts never lands
    expect(useEditorStore.getState().focusedTabPath).toBe('/repo/link/b.ts');
    useEditorStore.getState().closeAllTabs();
  });

  it('a tab open on another surface during the read await cancels the pending Git open', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn(() => d.promise);
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalled());
    useEditorStore.getState().openFile('/repo/link/other.ts', 'other.ts', 'x'); // Explorer-style open
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs.map((t) => t.filePath)).toEqual(['/repo/link/other.ts']);
    useEditorStore.getState().closeAllTabs();
  });

  it('a same-root workspace reopen during the read await cancels the pending Git open', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn(() => d.promise);
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalled());
    useWorkspaceStore.getState().setRootPath('/repo/link'); // same value: reopen still invalidates
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(0);
  });

  it('Close All during the read await cancels the pending Git open (no resurrected tab)', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn(() => d.promise);
    useEditorStore.getState().openFile('/repo/link/existing.ts', 'existing.ts', 'x');
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalled());
    useEditorStore.getState().closeAllTabs();
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(0); // nothing resurrected
  });

  it('a deliberate Git open after Close All still opens', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn((p: string) => (p.endsWith('/a.ts') ? d.promise : Promise.resolve('b content')));
    useEditorStore.getState().openFile('/repo/link/existing.ts', 'existing.ts', 'x');
    render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalledWith('/repo/link/a.ts'));
    useEditorStore.getState().closeAllTabs();
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs).toHaveLength(0);
    (window.nexelAPI.readFileContent as any) = vi.fn(async () => 'fresh a content');
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(useEditorStore.getState().tabs.map((t) => t.filePath)).toEqual(['/repo/link/a.ts']));
    expect(useEditorStore.getState().tabs[0].content).toBe('fresh a content');
    useEditorStore.getState().closeAllTabs();
  });

  it('switching panels does not cancel the open (matches handleFileSelect semantics)', async () => {
    const d = deferred<string>();
    (window.nexelAPI.realPath as any) = vi.fn(async (p: string) => p);
    (window.nexelAPI.readFileContent as any) = vi.fn(() => d.promise);
    const { unmount } = render(<GitPanel />);
    fireEvent.click(await screen.findByTitle('a.ts'));
    await waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalled());
    unmount(); // user switched to another panel: navigation intent stays valid
    d.resolve('late content');
    await new Promise((r) => setTimeout(r, 20));
    expect(useEditorStore.getState().tabs.map((t) => t.filePath)).toEqual(['/repo/link/a.ts']);
    useEditorStore.getState().closeAllTabs();
  });
});
