import {describe,it,expect} from 'vitest';import {textMetrics} from './textMetrics';
describe('buffer text metrics',()=>{
 it('measures empty editor as one line',()=>expect(textMetrics('')).toEqual({codeUnits:0,codePoints:0,utf8Bytes:0,words:0,lines:1,nonBlankLines:0,longestLine:0,lf:0,crlf:0}));
 it('separates Unicode points, UTF16 units and UTF8 bytes',()=>{const r=textMetrics('a 🌐');expect(r.codeUnits).toBe(4);expect(r.codePoints).toBe(3);expect(r.utf8Bytes).toBe(6);expect(r.words).toBe(2);});
 it('counts blank lines and CRLF without CR in line lengths',()=>{const r=textMetrics('abc\r\n  \nlast\n');expect(r.lines).toBe(4);expect(r.nonBlankLines).toBe(2);expect(r.longestLine).toBe(4);expect(r.lf).toBe(3);expect(r.crlf).toBe(1);});
 it('matches UTF8 replacement behavior for lone surrogates',()=>expect(textMetrics('\ud800').utf8Bytes).toBe(new TextEncoder().encode('\ud800').length));
});
