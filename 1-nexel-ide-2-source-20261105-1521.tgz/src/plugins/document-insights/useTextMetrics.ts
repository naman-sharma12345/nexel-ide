import {useCallback,useEffect,useMemo,useState} from 'react';
import {textMetrics,type TextMetrics} from './textMetrics';
const INLINE_LIMIT=50_000;
/** Small buffers are immediate; larger scans run off-thread after typing settles. */
export function useTextMetrics(source:string|undefined){
 const immediate=useMemo(()=>source!==undefined&&source.length<=INLINE_LIMIT?textMetrics(source):null,[source]);
 const [attempt,setAttempt]=useState(0);
 const retry=useCallback(()=>setAttempt(value=>value+1),[]);
 const [result,setResult]=useState<{source:string;attempt:number;metrics?:TextMetrics;error?:string}|null>(null);
 useEffect(()=>{
  if(source===undefined||source.length<=INLINE_LIMIT)return;
  let worker:Worker|undefined;let cancelled=false;let settled=false;let deadline:ReturnType<typeof setTimeout>|undefined;
  const finish=(value:{metrics?:TextMetrics;error?:string})=>{if(cancelled||settled)return;settled=true;clearTimeout(deadline);worker?.terminate();setResult({source,attempt,...value});};
  const timer=setTimeout(()=>{
   try{worker=new Worker(new URL('./metrics.worker.ts',import.meta.url),{type:'module'});
    worker.onmessage=event=>finish({metrics:event.data});
    worker.onerror=()=>finish({error:'Could not measure this buffer. Try again.'});
    deadline=setTimeout(()=>finish({error:'Text measurements did not finish within 5 seconds. Try again or use a smaller buffer.'}),5000);
    worker.postMessage(source);
   }catch{finish({error:'Could not start text measurements. Try again.'});}
  },150);
  return()=>{cancelled=true;clearTimeout(timer);clearTimeout(deadline);worker?.terminate();};
 },[source,attempt]);
 return {retry,metrics:immediate??(result && result.source===source&&result.attempt===attempt?result.metrics??null:null),pending:source!==undefined&&!immediate&&(result?.source!==source||result?.attempt!==attempt),error:result && result.source===source&&result.attempt===attempt?result.error:undefined};
}
