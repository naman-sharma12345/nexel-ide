import {textMetrics} from './textMetrics';
self.onmessage=(event:MessageEvent<string>)=>{self.postMessage(textMetrics(event.data));};
