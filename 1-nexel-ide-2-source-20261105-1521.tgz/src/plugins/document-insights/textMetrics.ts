export interface TextMetrics {codeUnits:number;codePoints:number;utf8Bytes:number;words:number;lines:number;nonBlankLines:number;longestLine:number;lf:number;crlf:number}
/** Text measurements, not syntax or complexity analysis. Words are whitespace-delimited. */
export function textMetrics(source:string):TextMetrics {
 let codePoints=0,utf8Bytes=0,words=0,inWord=false,lines=1,nonBlankLines=0,longestLine=0,lineLength=0,lineHasText=false,lf=0,crlf=0;
 for(const char of source){const point=char.codePointAt(0)!;codePoints++;utf8Bytes+=point<=0x7f?1:point<=0x7ff?2:point<=0xffff?3:4;
  const whitespace=/\s/u.test(char);if(!whitespace&&!inWord)words++;inWord=!whitespace;
  if(char==='\n'){lines++;lf++;longestLine=Math.max(longestLine,lineLength);if(lineHasText)nonBlankLines++;lineLength=0;lineHasText=false;}
  else {if(char!=='\r')lineLength++;if(!whitespace)lineHasText=true;}
 }
 for(let i=0;i<source.length-1;i++)if(source[i]==='\r'&&source[i+1]==='\n'){crlf++;}
 if(lineHasText)nonBlankLines++;longestLine=Math.max(longestLine,lineLength);
 return {codeUnits:source.length,codePoints,utf8Bytes,words,lines,nonBlankLines,longestLine,lf,crlf};
}
