export interface TimeResult {millis:number;seconds:string;iso:string;weekday:string}
export function convertTime(input:string,mode:'seconds'|'millis'|'iso'):TimeResult {
 const value=input.trim();if(!value)throw Error('Enter a timestamp or an ISO date with a timezone.');let millis:number;
 if(mode==='iso'){
  const match=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?(Z|[+-]\d{2}:\d{2})$/.exec(value);
  if(!match)throw Error('Use YYYY-MM-DDTHH:mm:ss[.sss]Z or an explicit offset such as +05:30.');
  const [,year,month,day,hour,minute,second,,zone]=match;const y=Number(year),m=Number(month),d=Number(day);const leap=y%4===0&&(y%100!==0||y%400===0);const days=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];
  if(m<1||m>12||d<1||d>days[m-1]||Number(hour)>23||Number(minute)>59||Number(second)>59)throw Error('This date or clock time does not exist. Leap seconds are not supported.');
  if(zone!=='Z'&&(Number(zone.slice(1,3))>23||Number(zone.slice(4))>59))throw Error('Invalid timezone offset.');
  millis=Date.parse(value);
 }else{
  if(!/^[+-]?\d+(?:\.\d+)?$/.test(value))throw Error('Use a plain number, without commas or exponent notation.');
  const negative=value.startsWith('-');const unsigned=value.replace(/^[+-]/,'');const [whole,fraction='']=unsigned.split('.');const places=mode==='seconds'?3:0;
  if(fraction.slice(places).replace(/0/g,''))throw Error('Use a timestamp that is exact to a whole millisecond.');
  const integer=BigInt(whole)*BigInt(mode==='seconds'?1000:1)+BigInt((fraction.slice(0,places).padEnd(places,'0'))||'0');
  millis=Number(negative?-integer:integer);
  if(!Number.isSafeInteger(millis))throw Error('Timestamp is outside the supported date range.');
 }
 if(!Number.isFinite(millis)||Math.abs(millis)>8_640_000_000_000_000)throw Error('Timestamp is outside the supported date range.');
 const date=new Date(millis);const absolute=Math.abs(millis);const fraction=String(absolute%1000).padStart(3,'0').replace(/0+$/,'');const seconds=(millis<0?'-':'')+String(Math.floor(absolute/1000))+(fraction?'.'+fraction:'');return {millis,seconds,iso:date.toISOString(),weekday:new Intl.DateTimeFormat('en-US',{weekday:'long',timeZone:'UTC'}).format(date)};
}
