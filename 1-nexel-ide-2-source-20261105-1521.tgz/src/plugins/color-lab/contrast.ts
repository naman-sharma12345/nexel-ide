import {parseColor} from './parseColor';
/** WCAG sRGB luminance and ratio. Opaque solid colors only. */
export function colorContrast(foreground:string,background:string){
 const colors=[parseColor(foreground),parseColor(background)];
 if(colors.some(color=>color.alpha!==1))throw Error('Contrast requires two opaque colors. Remove alpha first.');
 const luminance=colors.map(color=>{const [r,g,b]=[color.r,color.g,color.b].map(value=>{const channel=value/255;return channel<=0.04045?channel/12.92:((channel+0.055)/1.055)**2.4;});return .2126*r+.7152*g+.0722*b;});
 const ratio=(Math.max(...luminance)+.05)/(Math.min(...luminance)+.05);
 return {ratio,normalAA:ratio>=4.5,largeAA:ratio>=3,normalAAA:ratio>=7,foreground:colors[0].hex,background:colors[1].hex};
}
