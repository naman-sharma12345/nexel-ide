export function parseColor(input:string){
 const value=input.trim().replace(/^#/,'');if(!/^(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})$/i.test(value))throw Error('Enter 3, 4, 6 or 8 hex digits, with or without #.');
 const full=value.length<5?[...value].map(char=>char+char).join(''):value;const r=parseInt(full.slice(0,2),16),g=parseInt(full.slice(2,4),16),b=parseInt(full.slice(4,6),16),a=full.length===8?parseInt(full.slice(6,8),16):255;
 const [red,green,blue]=[r,g,b].map(channel=>channel/255);const high=Math.max(red,green,blue),low=Math.min(red,green,blue),delta=high-low;const lightness=(high+low)/2;let hue=0;if(delta){hue=high===red?((green-blue)/delta)%6:high===green?(blue-red)/delta+2:(red-green)/delta+4;hue=(hue*60+360)%360;}const saturation=delta===0?0:delta/(1-Math.abs(2*lightness-1));
 const alpha=Number((a/255).toFixed(5));const hex='#'+full.slice(0,6).toUpperCase()+(a===255?'':a.toString(16).padStart(2,'0').toUpperCase());
 return {hex,r,g,b,alpha,rgb:`rgb(${r} ${g} ${b}${a===255?'':` / ${alpha}`})`,hsl:`hsl(${Number(hue.toFixed(2))} ${Number((saturation*100).toFixed(2))}% ${Number((lightness*100).toFixed(2))}%${a===255?'':` / ${alpha}`})`};
}
