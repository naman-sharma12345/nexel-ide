import {it,expect} from 'vitest';import {colorContrast} from './contrast';
it('calculates blackwhite21 and identical1 ratios',()=>{expect(colorContrast('#000','#fff')).toMatchObject({ratio:21,normalAA:true,largeAA:true,normalAAA:true});expect(colorContrast('#777','#777')).toMatchObject({ratio:1,normalAA:false});});
it('uses unrounded thresholds and order-independent ratio',()=>{expect(colorContrast('#777','#fff').normalAA).toBe(false);expect(colorContrast('#767676','#fff').normalAA).toBe(true);expect(colorContrast('#fff','#777').ratio).toBe(colorContrast('#777','#fff').ratio);});
it('rejects alpha rather than assuming a backdrop',()=>{expect(()=>colorContrast('#fff8','#000')).toThrow(/opaque/);expect(()=>colorContrast('#fff','bad-input')).toThrow();});
