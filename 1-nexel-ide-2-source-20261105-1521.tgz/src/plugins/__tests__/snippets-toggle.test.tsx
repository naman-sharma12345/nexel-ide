import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { getPlugin } from '../registry';
import { useEditorStore } from '../../stores/useEditorStore';
import '../competitive-programming';
import { useUIStore } from '../../stores/useUIStore';

afterEach(cleanup);
describe('plugin snippets autocomplete switch', () => {
  it('exposes its name and live state without relying on the narrow-window label', () => {
    useEditorStore.setState({ enableSnippets: false });
    const Toggle = getPlugin('competitive-programming')!.titlebarItems![0];
    render(<Toggle />);
    const toggle = screen.getByRole('switch', { name: 'Snippets autocomplete' });
    expect(toggle.tagName).toBe('BUTTON');
    expect(toggle.getAttribute('type')).toBe('button');
    expect(toggle.getAttribute('aria-checked')).toBe('false');
    toggle.focus();
    fireEvent.click(toggle);
    expect(useEditorStore.getState().enableSnippets).toBe(true);
    expect(toggle.getAttribute('aria-checked')).toBe('true');
    expect(document.activeElement).toBe(toggle);
    fireEvent.click(toggle);
    expect(toggle.getAttribute('aria-checked')).toBe('false');
  });
});

describe('plugin Judge status shortcut', () => {
  it('opens the Judge drawer without toggling it closed on repeat activation', () => {
    useUIStore.setState({ currentSection: 'workspace', sidebarCollapsed: true, isHoverRevealed: true });
    const Chip = getPlugin('competitive-programming')!.statusItems![0];
    render(<Chip />);
    const chip = screen.getByRole('button', { name: 'Open Judge: Judge ready' });
    fireEvent.click(chip);
    expect(useUIStore.getState()).toMatchObject({ currentSection: 'judge', sidebarCollapsed: false, isHoverRevealed: false });
    fireEvent.click(chip);
    expect(useUIStore.getState().sidebarCollapsed).toBe(false);
  });
});
