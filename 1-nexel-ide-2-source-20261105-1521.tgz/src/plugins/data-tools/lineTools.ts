export type LineOperation='sort'|'unique'|'trim'|'nonblank'|'reverse';
export function transformLines(source:string,operation:LineOperation){
 if(source.length>200000)throw Error('Use up to 200,000 UTF-16 units.');
 const ending=source.includes('\r\n')?'\r\n':'\n';const trailing=/\r?\n$/.test(source);const lines=source.split(/\r?\n/);if(trailing)lines.pop();
 let out:string[];
 switch(operation){case 'sort':out=[...lines].sort();break;case 'unique':out=[...new Set(lines)];break;case 'trim':out=lines.map(line=>line.trim());break;case 'nonblank':out=lines.filter(line=>line.trim()!=='');break;case 'reverse':out=[...lines].reverse();break;}
 return out.join(ending)+(trailing&&out.length?ending:'');
}
