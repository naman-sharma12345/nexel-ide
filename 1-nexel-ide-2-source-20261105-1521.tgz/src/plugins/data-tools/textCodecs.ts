export type Codec = 'base64-encode'|'base64-decode'|'url-encode'|'url-decode';
export function transformText(source:string,codec:Codec):{ok:true;text:string}|{ok:false;error:string}{
 if(source.length>1_000_000)return {ok:false,error:'Input exceeds the 1,000,000 character limit.'};
 try{
  if(codec==='url-encode')return {ok:true,text:encodeURIComponent(source)};
  if(codec==='url-decode')return {ok:true,text:decodeURIComponent(source)};
  if(codec==='base64-encode'){
   // TextEncoder replaces isolated UTF-16 surrogates; reject rather than lose input.
   for(let i=0;i<source.length;i++){
    const unit=source.charCodeAt(i);
    if(unit>=0xd800&&unit<=0xdbff){const next=source.charCodeAt(++i);if(!(next>=0xdc00&&next<=0xdfff))throw Error('Incomplete Unicode');}
    else if(unit>=0xdc00&&unit<=0xdfff)throw Error('Incomplete Unicode');
   }
   const bytes=new TextEncoder().encode(source);let binary='';
   for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
   return {ok:true,text:btoa(binary)};
  }
  // Base64 is a text codec, not a file reader: preserve leading U+FEFF as data.
  const binary=atob(source);const bytes=Uint8Array.from(binary,char=>char.charCodeAt(0));
  return {ok:true,text:new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes)};
 }catch{return {ok:false,error:codec==='base64-decode'?'Invalid Base64 or non-UTF-8 data. This tool decodes text only.':codec==='url-decode'?'Invalid URL encoding. Check percent escapes and UTF-8 bytes.':'Could not encode this text. Check for incomplete Unicode characters.'};}
}
