import { useRef, useState } from 'react';
import { useNoticeInView } from './useNoticeInView';
import { create } from 'zustand';
import { transformJson } from './jsonTools';
import './DataTools.css';
import TextCodecs from './TextCodecs';
import LineTools from './LineTools';
import HashTools from './HashTools';
const useDataTools = create<{source:string;output:string;fresh:boolean;mode:'json'|'codecs'|'lines'|'hash';set:(value:Partial<{source:string;output:string;fresh:boolean;mode:'json'|'codecs'|'lines'|'hash'}>)=>void}>(set=>({source:'',output:'',fresh:false,mode:'json',set:value=>set(value)}));
export default function DataTools() {
  const {source,output,fresh,mode,set}=useDataTools();
  const setMode=(mode:'json'|'codecs'|'lines'|'hash')=>set({mode});
  const [tab,setTab]=useState<'source'|'result'>('source');
  const [notice,setNotice]=useState('');useNoticeInView(notice);const [error,setError]=useState(false);
  const generation=useRef(0);
  const tabs=useRef<HTMLDivElement>(null);
  const run=(compact=false)=>{generation.current++;const result=transformJson(source,compact);if(!result.ok){set({fresh:false});setError(true);setNotice(result.error);setTab('source');return;}set({output:result.text,fresh:true});setError(false);setNotice(compact?'Valid JSON. Compacted.':'Valid JSON. Formatted.');setTab('result');};
  const choose=(next:'source'|'result')=>{setTab(next);tabs.current?.querySelector<HTMLButtonElement>(`[data-tab="${next}"]`)?.focus();};
  return <section className="dt-panel" aria-label="JSON tools" onKeyDown={event=>{if(event.nativeEvent.isComposing||event.keyCode===229){event.stopPropagation();return;}if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();if(mode==='json')run();}}}>
    <header className="dt-header"><div className="dt-eyebrow">DATA TOOLS</div><h2>{mode==='json'?'JSON studio':mode==='lines'?'Line workshop':mode==='hash'?'Text fingerprints':'Text codecs'}</h2><p>{mode==='json'?'Inspect, format and compact JSON locally.':mode==='lines'?'Clean and reorder lines without changing a file.':mode==='hash'?'Create a digest of exact UTF-8 text.':'Convert UTF-8 text without leaving the IDE.'}</p></header>
    <div className="dt-modes" role="group" aria-label="Data tool"><button aria-pressed={mode==='json'} onClick={()=>{generation.current++;setNotice('');setError(false);setMode('json');}}>JSON</button><button aria-pressed={mode==='codecs'} onClick={()=>{generation.current++;setNotice('');setError(false);setMode('codecs');}}>Text codecs</button><button aria-pressed={mode==='lines'} onClick={()=>{generation.current++;setNotice('');setError(false);setMode('lines');}}>Lines</button><button aria-pressed={mode==='hash'} onClick={()=>{generation.current++;setNotice('');setError(false);setMode('hash');}}>Hashes</button></div>
    {mode==='hash'?<HashTools/>:mode==='lines'?<LineTools/>:mode==='codecs'?<TextCodecs/>:<div className="dt-json">
    <div className="dt-actions"><button onClick={()=>run()}>Format</button><button onClick={()=>run(true)}>Compact</button></div>
    <div ref={tabs} className="dt-tabs" role="tablist" aria-label="JSON view" onKeyDown={event=>{if(event.nativeEvent.isComposing||event.keyCode===229){event.stopPropagation();return;}if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();choose(event.key==='Home'?'source':event.key==='End'?'result':tab==='source'?'result':'source');}}}>
      {(['source','result'] as const).map(id=><button key={id} id={`dt-tab-${id}`} data-tab={id} role="tab" aria-selected={tab===id} aria-controls={`dt-pane-${id}`} tabIndex={tab===id?0:-1} onClick={()=>setTab(id)}>{id==='source'?'Input':'Result'}<span>{(id==='source'?source:output).length.toLocaleString()}</span></button>)}
    </div>
    <div className="dt-body" id={`dt-pane-${tab}`} role="tabpanel" aria-labelledby={`dt-tab-${tab}`}>
      <textarea aria-label={tab==='source'?'JSON input':'JSON result'} spellCheck={false} readOnly={tab==='result'} value={tab==='source'?source:output} placeholder={tab==='source'?'Paste JSON here\n\nCtrl+Enter to format':'Formatted JSON appears here'} onChange={event=>{generation.current++;set({source:event.target.value,fresh:false});setNotice('');}} />
    </div>
    {output&&!fresh&&<div className="dt-stale" role="status">Result is from an earlier input. Format or Compact again.</div>}
    {notice&&<div className={`dt-notice ${error?'is-error':''}`} role={error?'alert':'status'}>{notice}</div>}
    <footer className="dt-footer"><span>Session only · no network</span><button disabled={!output||!fresh} onClick={async()=>{const attempt=++generation.current;setError(false);setNotice('Copying result...');try{await navigator.clipboard.writeText(output);if(attempt===generation.current){setError(false);setNotice('Result copied.');}}catch{if(attempt===generation.current){setError(true);setNotice('Copy failed. Select and copy the result instead.');}}}}>Copy result</button></footer>
  </div>}
  </section>;
}
