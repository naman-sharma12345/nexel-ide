import {describe,it,expect} from 'vitest';import {transformText} from './textCodecs';
describe('text codecs',()=>{
 it('round trips multilingual UTF8 and emoji',()=>{const input='Nexel नमस्ते 🌐';const encoded=transformText(input,'base64-encode');expect(encoded.ok).toBe(true);if(encoded.ok)expect(transformText(encoded.text,'base64-decode')).toEqual({ok:true,text:input});});
 it('encodes URL components without interpreting plus as space',()=>{expect(transformText('a+b /?','url-encode')).toEqual({ok:true,text:'a%2Bb%20%2F%3F'});expect(transformText('a+b%20c','url-decode')).toEqual({ok:true,text:'a+b c'});});
 it('rejects corrupt encodings and binary data',()=>{expect(transformText('%%','base64-decode').ok).toBe(false);expect(transformText('/w==','base64-decode').ok).toBe(false);expect(transformText('%xx','url-decode').ok).toBe(false);});
 it('handles empty and bounded large input',()=>{expect(transformText('','base64-encode')).toEqual({ok:true,text:''});expect(transformText('a'.repeat(1000001),'url-encode').ok).toBe(false);});
});

it('preserves leading U+FEFF text through Base64 round trips',()=>{
 for(const input of ['\uFEFF', '\uFEFFNexel नमस्ते 🌐', '\uFEFF\uFEFFbody', 'body\uFEFF']){
  const encoded=transformText(input,'base64-encode');
  expect(encoded.ok).toBe(true);
  if(encoded.ok)expect(transformText(encoded.text,'base64-decode')).toEqual({ok:true,text:input});
 }
});

it('rejects incomplete Unicode before Base64 encoding rather than replacing it',()=>{
 for(const input of ['\uD800', '\uDC00', 'A\uD800B', '\uDC00\uD800']){
  const result=transformText(input,'base64-encode');expect(result.ok).toBe(false);
  if(!result.ok)expect(result.error).toMatch(/incomplete Unicode/);
 }
 const replacement='A\uFFFDB';const result=transformText(replacement,'base64-encode');
 if(!result.ok)throw Error();expect(transformText(result.text,'base64-decode')).toEqual({ok:true,text:replacement});
});
