import {render,screen,fireEvent,cleanup,act} from '@testing-library/react';import {afterEach,it,expect,vi} from 'vitest';import DataTools from './DataTools';afterEach(cleanup);
it('blocks stale JSON copies until recomputed',()=>{render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'JSON'}));fireEvent.change(screen.getByRole('textbox',{name:'JSON input'}),{target:{value:'{"a":1}'}});fireEvent.click(screen.getByRole('button',{name:'Format'}));expect(screen.getByRole('button',{name:'Copy result'})).not.toBeDisabled();fireEvent.click(screen.getByRole('tab',{name:/Input/}));fireEvent.change(screen.getByRole('textbox',{name:'JSON input'}),{target:{value:'{"b":2}'}});expect(screen.getByRole('button',{name:'Copy result'})).toBeDisabled();expect(screen.getByText(/Result is from an earlier input/)).toBeInTheDocument();fireEvent.click(screen.getByRole('button',{name:'Format'}));expect(screen.getByRole('button',{name:'Copy result'})).not.toBeDisabled();});
it('retains codec choice and stale state across mode changes',()=>{render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'JSON'}));fireEvent.click(screen.getByRole('button',{name:'Text codecs'}));fireEvent.change(screen.getByRole('textbox',{name:'Codec input'}),{target:{value:'hello'}});fireEvent.click(screen.getByRole('button',{name:'Convert'}));fireEvent.change(screen.getByRole('combobox',{name:'Text conversion'}),{target:{value:'url-encode'}});expect(screen.getByRole('button',{name:'Copy output'})).toBeDisabled();expect(screen.getByRole('button',{name:'Use output'})).toBeDisabled();fireEvent.click(screen.getByRole('button',{name:'JSON'}));fireEvent.click(screen.getByRole('button',{name:'Text codecs'}));expect(screen.getByRole('combobox',{name:'Text conversion'})).toHaveValue('url-encode');expect(screen.getByRole('button',{name:'Copy output'})).toBeDisabled();});
it('ignores JSON clipboard completion after input edit or newer format',async()=>{let finish!:()=>void;Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>new Promise<void>(resolve=>{finish=resolve;})}});render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'JSON'}));fireEvent.change(screen.getByRole('textbox',{name:'JSON input'}),{target:{value:'{"a":1}'}});fireEvent.click(screen.getByRole('button',{name:'Format'}));fireEvent.click(screen.getByRole('button',{name:'Copy result'}));expect(screen.getByText('Copying result...')).toBeInTheDocument();fireEvent.click(screen.getByRole('tab',{name:/Input/}));fireEvent.change(screen.getByRole('textbox',{name:'JSON input'}),{target:{value:'{"a":2}'}});fireEvent.click(screen.getByRole('button',{name:'Format'}));await act(async()=>finish());expect(screen.queryByText('Result copied.')).not.toBeInTheDocument();expect(screen.getByText('Valid JSON. Formatted.')).toBeInTheDocument();});
it('ignores codec copy completion after changing conversion',async()=>{let finish!:()=>void;Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>new Promise<void>(resolve=>{finish=resolve;})}});render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'JSON'}));fireEvent.click(screen.getByRole('button',{name:'Text codecs'}));fireEvent.change(screen.getByRole('combobox',{name:'Text conversion'}),{target:{value:'base64-encode'}});fireEvent.change(screen.getByRole('textbox',{name:'Codec input'}),{target:{value:'hello'}});fireEvent.click(screen.getByRole('button',{name:'Convert'}));fireEvent.click(screen.getByRole('button',{name:'Copy output'}));fireEvent.change(screen.getByRole('combobox',{name:'Text conversion'}),{target:{value:'url-encode'}});await act(async()=>finish());expect(screen.queryByText('Output copied.')).not.toBeInTheDocument();expect(screen.getByRole('button',{name:'Copy output'})).toBeDisabled();});

it('retains selected tool mode on remount',()=>{const first=render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'Lines'}));first.unmount();render(<DataTools/>);expect(screen.getByRole('button',{name:'Lines'})).toHaveAttribute('aria-pressed','true');expect(screen.getByRole('textbox',{name:'Lines input'})).toBeInTheDocument();});

it('allows fresh empty codec results to be copied and reused, then blocks them when stale',async()=>{
 const writeText=vi.fn().mockResolvedValue(undefined);
 Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText}});
 render(<DataTools/>);
 fireEvent.click(screen.getByRole('button',{name:'Text codecs'}));
 fireEvent.change(screen.getByRole('combobox',{name:'Text conversion'}),{target:{value:'base64-encode'}});
 fireEvent.change(screen.getByRole('textbox',{name:'Codec input'}),{target:{value:''}});
 fireEvent.click(screen.getByRole('button',{name:'Convert'}));
 expect(screen.getByRole('textbox',{name:'Codec output'})).toHaveValue('');
 expect(screen.getByRole('button',{name:'Copy output'})).not.toBeDisabled();
 expect(screen.getByRole('button',{name:'Use output'})).not.toBeDisabled();
 fireEvent.click(screen.getByRole('button',{name:'Copy output'}));
 await act(async()=>{});expect(writeText).toHaveBeenCalledWith('');
 fireEvent.click(screen.getByRole('button',{name:'Use output'}));
 expect(screen.getByRole('button',{name:'Copy output'})).toBeDisabled();
 expect(screen.getByRole('button',{name:'Use output'})).toBeDisabled();
});

it('keeps earlier codec output stale and uncopyable after invalid input, then recovers',()=>{
 render(<DataTools/>);fireEvent.click(screen.getByRole('button',{name:'Text codecs'}));
 const input=screen.getByRole('textbox',{name:'Codec input'});
 const conversion=screen.getByRole('combobox',{name:'Text conversion'});
 fireEvent.change(conversion,{target:{value:'base64-encode'}});
 fireEvent.change(input,{target:{value:'valid'}});fireEvent.click(screen.getByRole('button',{name:'Convert'}));
 expect(screen.getByRole('textbox',{name:'Codec output'})).toHaveValue('dmFsaWQ=');
 fireEvent.change(input,{target:{value:'A\uD800B'}});fireEvent.click(screen.getByRole('button',{name:'Convert'}));
 expect(screen.getByRole('alert')).toHaveTextContent('incomplete Unicode');
 expect(screen.getByRole('textbox',{name:'Codec output'})).toHaveValue('dmFsaWQ=');
 expect(screen.getByRole('button',{name:'Copy output'})).toBeDisabled();
 expect(screen.getByRole('button',{name:'Use output'})).toBeDisabled();
 fireEvent.change(input,{target:{value:'🌐'}});fireEvent.click(screen.getByRole('button',{name:'Convert'}));
 expect(screen.queryByRole('alert')).not.toBeInTheDocument();
 expect(screen.getByRole('textbox',{name:'Codec output'})).toHaveValue('8J+MkA==');
 expect(screen.getByRole('button',{name:'Copy output'})).not.toBeDisabled();
});
