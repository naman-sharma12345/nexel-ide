import {describe,it,expect} from 'vitest';
import {transformJson} from './jsonTools';
describe('JSON tools',()=>{
 it('formats without changing number lexemes, duplicate keys or escaped strings',()=>{expect(transformJson('{"n":9007199254740993123,"n":1e+300,"s":"a\\\"b","v":[]}')).toEqual({ok:true,text:'{\n  "n": 9007199254740993123,\n  "n": 1e+300,\n  "s": "a\\\"b",\n  "v": []\n}'});});
 it('compacts preserving whitespace inside strings',()=>expect(transformJson(' { "x" : [ "a b", {} ] } ',true)).toEqual({ok:true,text:'{"x":["a b",{}]}'}));
 it('rejects invalid and bounded oversized input',()=>{expect(transformJson('{x:1}').ok).toBe(false);expect(transformJson(' '.repeat(1000001)).ok).toBe(false);});
 it('bounds deeply nested formatting but keeps compact available',()=>{const input='['.repeat(101)+'0'+']'.repeat(101);expect(transformJson(input).ok).toBe(false);expect(transformJson(input,true)).toEqual({ok:true,text:input});});
 it('formats primitives and nested arrays',()=>{expect(transformJson('null')).toEqual({ok:true,text:'null'});expect(transformJson('[[1],{}]')).toEqual({ok:true,text:'[\n  [\n    1\n  ],\n  {}\n]'});});
});
