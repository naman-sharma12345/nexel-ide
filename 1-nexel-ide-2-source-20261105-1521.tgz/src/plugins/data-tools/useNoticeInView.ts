import { useEffect } from 'react';
// Keep a new status or error notice inside a short scrolling panel.
export function useNoticeInView(notice: string) {
  useEffect(() => {
    if (!notice) return;
    document.querySelector('.dt-notice')?.scrollIntoView?.({ block: 'nearest' });
  }, [notice]);
}
