import {it,expect} from 'vitest';import {transformLines} from './lineTools';
it('deduplicates exact lines retaining first order and trailing newline',()=>{expect(transformLines('B\na\nB\nA\n','unique')).toBe('B\na\nA\n');expect(transformLines('','unique')).toBe('');});
it('sorts by UTF16 and reverses without changing content',()=>{expect(transformLines('z\nA\na','sort')).toBe('A\na\nz');expect(transformLines(' a \n\nb','reverse')).toBe('b\n\n a ');});
it('trims/removes blanks with explicit line ending normalization',()=>{expect(transformLines(' a \r\n \n b\r\n','trim')).toBe('a\r\n\r\nb\r\n');expect(transformLines(' \n\t\n','nonblank')).toBe('');expect(transformLines('a\n\nb\n','nonblank')).toBe('a\nb\n');});
it('rejects over limit input',()=>{expect(()=>transformLines('a'.repeat(200001),'sort')).toThrow();});
