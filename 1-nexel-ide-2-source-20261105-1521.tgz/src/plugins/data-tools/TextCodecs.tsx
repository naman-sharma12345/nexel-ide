import {useRef,useState} from 'react';
import { useNoticeInView } from './useNoticeInView';
import {create} from 'zustand';
import {transformText,type Codec} from './textCodecs';
const useCodecState=create<{source:string;output:string;fresh:boolean;codec:Codec;set:(value:Partial<{source:string;output:string;fresh:boolean;codec:Codec}>)=>void}>(set=>({source:'',output:'',fresh:false,codec:'base64-encode',set:value=>set(value)}));
export default function TextCodecs(){
 const {source,output,fresh,codec,set}=useCodecState();const [notice,setNotice]=useState('');useNoticeInView(notice);const [error,setError]=useState(false);
 const generation=useRef(0);
 const run=()=>{generation.current++;const result=transformText(source,codec);setError(!result.ok);if(result.ok){set({output:result.text,fresh:true});setNotice('Done. Output is ready.');}else {set({fresh:false});setNotice(result.error);};};
 return <div className="dt-codecs" onKeyDown={event=>{if(event.nativeEvent.isComposing||event.keyCode===229){event.stopPropagation();return;}if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();run();}}}>
  <label className="dt-codec-label">Conversion<select aria-label="Text conversion" value={codec} onChange={event=>{generation.current++;set({codec:event.target.value as Codec,fresh:false});setNotice('');}}><option value="base64-encode">Text to Base64</option><option value="base64-decode">Base64 to text</option><option value="url-encode">URL component encode</option><option value="url-decode">URL component decode</option></select></label>
  <label className="dt-codec-label dt-codec-editor">Input<textarea aria-label="Codec input" spellCheck={false} placeholder="Enter text to convert" value={source} onChange={event=>{generation.current++;set({source:event.target.value,fresh:false});setNotice('');}}/></label>
  <div className="dt-actions"><button onClick={run}>Convert</button><button disabled={!fresh} onClick={()=>{generation.current++;set({source:output,fresh:false});setNotice('Output moved to input. Choose the reverse conversion to decode.');}}>Use output</button></div>
  <label className="dt-codec-label dt-codec-editor">Output<textarea aria-label="Codec output" spellCheck={false} readOnly value={output} placeholder="Converted text appears here"/></label>
  {output&&!fresh&&<div className="dt-stale" role="status">Output is from an earlier input or conversion. Convert again.</div>}
  {notice&&<div className={`dt-notice ${error?'is-error':''}`} role={error?'alert':'status'}>{notice}</div>}
  <footer className="dt-footer"><span>UTF-8 text · local only</span><button disabled={!fresh} onClick={async()=>{const attempt=++generation.current;setError(false);setNotice('Copying output...');try{await navigator.clipboard.writeText(output);if(attempt===generation.current){setError(false);setNotice('Output copied.');}}catch{if(attempt===generation.current){setError(true);setNotice('Copy failed. Select and copy the output instead.');}}}}>Copy output</button></footer>
 </div>;
}
