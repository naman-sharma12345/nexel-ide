import { lazy } from 'react';
import { registerPlugin } from '../registry';
const DataTools=lazy(()=>import('./DataTools'));
registerPlugin({id:'data-tools',name:'Data Tools',blurb:'Local JSON formatting, UTF-8 Base64/URL conversion line transformations and SHA text digests. Session-only, no network.',defaultEnabled:false,sections:['data-tools'],commandIds:[],panels:{'data-tools':DataTools},navItems:[{id:'data-tools',label:'Data Tools',icon:<svg className="nd-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M8 3H6a2 2 0 0 0-2 2v4l-2 3 2 3v4a2 2 0 0 0 2 2h2m8-18h2a2 2 0 0 1 2 2v4l2 3-2 3v4a2 2 0 0 1-2 2h-2M10 9l4 6m0-6-4 6"/></svg>}]});
