export type HashAlgorithm='SHA-256'|'SHA-384'|'SHA-512';
export async function hashText(source:string,algorithm:HashAlgorithm){
 if(source.length>200000)throw Error('Use up to 200,000 UTF-16 units.');
 for(let i=0;i<source.length;i++){
  const unit=source.charCodeAt(i);
  if(unit>=0xd800&&unit<=0xdbff){const next=source.charCodeAt(++i);if(!(next>=0xdc00&&next<=0xdfff))throw Error('Input contains an incomplete Unicode character. Fix it before hashing.');}
  else if(unit>=0xdc00&&unit<=0xdfff)throw Error('Input contains an incomplete Unicode character. Fix it before hashing.');
 }
 const bytes=new TextEncoder().encode(source);const hash=await crypto.subtle.digest(algorithm,bytes);
 return {hex:Array.from(new Uint8Array(hash),byte=>byte.toString(16).padStart(2,'0')).join(''),bytes:bytes.length};
}
