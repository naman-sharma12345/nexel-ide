export type JsonResult = { ok: true; text: string } | { ok: false; error: string };
/** Validate with JSON.parse, but format original tokens so large numbers and duplicate keys survive. */
export function transformJson(source: string, compact = false): JsonResult {
  if (source.length > 1_000_000) return { ok: false, error: 'Input exceeds the 1,000,000 character limit.' };
  try { JSON.parse(source); } catch (error) { return { ok: false, error: error instanceof Error ? error.message : 'Invalid JSON' }; }
  const tokens = source.match(/"(?:[^"\\]|\\.)*"|[^\s"{}[\],:]+|[{}[\],:]/g) ?? [];
  if (compact) return { ok: true, text: tokens.join('') };
  let depth = 0, text = '';
  const newline = () => '\n' + '  '.repeat(depth);
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token === '{' || token === '[') {
      if (depth >= 100) return { ok: false, error: 'Formatting is limited to 100 nesting levels. Compact output is still available.' };
      text += token; depth++;
      if (tokens[i + 1] !== '}' && tokens[i + 1] !== ']') text += newline();
    } else if (token === '}' || token === ']') {
      depth--;
      if (tokens[i - 1] !== '{' && tokens[i - 1] !== '[') text += newline();
      text += token;
    } else if (token === ',') text += ',' + newline();
    else if (token === ':') text += ': ';
    else text += token;
    if (text.length > 2_000_000) return { ok: false, error: 'Formatted output exceeds 2,000,000 characters. Try Compact instead.' };
  }
  return { ok: true, text };
}
