import { describe, it, expect, vi, afterEach } from 'vitest';
import { useWorkspaceStore } from '../../../stores/useWorkspaceStore';
import { useEditorStore } from '../../../stores/useEditorStore';
import { useStatusStore } from '../../../stores/useStatusStore';
import { queueCompanionImport } from '..';

const P = (name: string, fileName: string, input: string) => ({ name, fileName, tests: [{ input, output: '1' }] });

afterEach(() => { vi.restoreAllMocks(); });

function seedWorkspace(root: string, names: string[] = []) {
  useWorkspaceStore.setState({
    rootPath: root, activeDir: null,
    tree: names.map(name => ({ name, path: `${root}/${name}`, type: 'file' as const, children: [] })),
  });
  useEditorStore.setState({ cppTemplate: '', tabs: [], activeTabPath: null });
  useStatusStore.setState({ toasts: [] });
}

describe('companion import queue', () => {
  it('serializes same-name arrivals: the second import gets a suffixed file and both open', async () => {
    seedWorkspace('/ws');
    const created: string[] = [];
    vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir: string, name: string) => {
      created.push(name);
      const st = useWorkspaceStore.getState();
      useWorkspaceStore.setState({ tree: [...st.tree, { name, path: `${dir}/${name}`, type: 'file' as const, children: [] }] });
      return `${dir}/${name}`;
    });
    vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockImplementation(async () => useWorkspaceStore.getState().tree as never);
    const opened: string[] = [];
    vi.spyOn(useEditorStore.getState(), 'openFile').mockImplementation((path: string) => { opened.push(path); });

    await Promise.all([queueCompanionImport(P('Same Problem', 'Same_Problem', 'a')), queueCompanionImport(P('Same Problem', 'Same_Problem', 'b'))]);
    expect(created).toEqual(['Same_Problem.cpp', 'Same_Problem_2.cpp']);
    expect(opened).toEqual(['/ws/Same_Problem.cpp', '/ws/Same_Problem_2.cpp']);
    expect(useStatusStore.getState().toasts.filter(t => t.kind === 'error')).toEqual([]);
  });

  it('retries once with a fresh name on EEXIST from a stale tree, never overwriting', async () => {
    seedWorkspace('/ws');
    let attempts = 0;
    const created: string[] = [];
    vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir: string, name: string) => {
      attempts++;
      if (attempts === 1) throw new Error('EEXIST: destination already exists; rename was not performed');
      created.push(name);
      return `${dir}/${name}`;
    });
    // The refresh after EEXIST reveals the colliding external file.
    vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockImplementation(async () => [
      { name: 'Prob.cpp', path: '/ws/Prob.cpp', type: 'file' as const, children: [] },
    ] as never);
    await queueCompanionImport(P('Prob', 'Prob', 'x'));
    expect(attempts).toBe(2);
    expect(created).toEqual(['Prob_2.cpp']);
    expect(useStatusStore.getState().toasts.some(t => t.kind === 'error')).toBe(false);
  });

  it('a failed import toasts and does not poison later queue entries', async () => {
    seedWorkspace('/ws');
    let calls = 0;
    vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir: string, name: string) => {
      calls++;
      if (calls === 1) throw new Error('disk full');
      return `${dir}/${name}`;
    });
    vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockImplementation(async () => useWorkspaceStore.getState().tree as never);
    await Promise.all([queueCompanionImport(P('First', 'First', 'a')), queueCompanionImport(P('Second', 'Second', 'b'))]);
    expect(calls).toBe(2);
    expect(useStatusStore.getState().toasts.some(t => t.message === 'Could not import problem from Competitive Companion')).toBe(true);
    expect(useStatusStore.getState().toasts.some(t => t.message.startsWith('Imported Second'))).toBe(true);
  });

  it('lands a queued import in the workspace it was received in, not a later one', async () => {
    seedWorkspace('/ws-a');
    let release!: () => void;
    const gate = new Promise<void>(r => { release = r; });
    const dirs: string[] = [];
    let first = true;
    vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir: string, name: string) => {
      dirs.push(dir);
      if (first) { first = false; await gate; }
      return `${dir}/${name}`;
    });
    vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockImplementation(async () => useWorkspaceStore.getState().tree as never);
    const run1 = queueCompanionImport(P('One', 'One', 'a'));
    const run2 = queueCompanionImport(P('Two', 'Two', 'b'));
    // Workspace switches while import 1 is in flight and import 2 is queued.
    useWorkspaceStore.setState({ rootPath: '/ws-b', tree: [] });
    release();
    await Promise.all([run1, run2]);
    expect(dirs).toEqual(['/ws-a', '/ws-a']); // both captured at receipt, before the switch
  });
});

it('keeps the new workspace editor and samples when an older import finishes', async () => {
  seedWorkspace('/ws-a');
  let release!: () => void;
  vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir, name) => {
    await new Promise<void>(r => { release = r; });
    return `${dir}/${name}`;
  });
  vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockResolvedValue([] as never);
  const opened = vi.spyOn(useEditorStore.getState(), 'openFile');
  const { useJudgeStore } = await import('../../../stores/useJudgeStore');
  const pending = queueCompanionImport(P('Older', 'Older', 'old sample'));
  await vi.waitFor(() => expect(release).toBeTypeOf('function'));
  useWorkspaceStore.setState({ rootPath: '/ws-b', activeDir: '/ws-b', tree: [] });
  useEditorStore.getState().openFile('/ws-b/current.py', 'current.py', 'keep current');
  useJudgeStore.getState().importSamples([{ input: 'keep samples', output: 'new' }]);
  const before = useJudgeStore.getState().testCases;
  opened.mockClear();
  release(); await pending;
  expect(opened).not.toHaveBeenCalled();
  expect(useEditorStore.getState().activeTabPath).toBe('/ws-b/current.py');
  expect(useJudgeStore.getState().testCases).toEqual(before);
  expect(useStatusStore.getState().toasts.some(t => t.message.includes('/ws-a/Older.cpp') && t.message.includes('workspace changed'))).toBe(true);
});

it('reads captured destination names for same-name imports queued before switching workspaces', async () => {
  seedWorkspace('/ws-a');
  let release!: () => void;
  const disk = new Set<string>(); let first = true;
  vi.spyOn(window.nexelAPI, 'createFile').mockImplementation(async (dir, name) => {
    if (first) { first = false; await new Promise<void>(r => { release = r; }); }
    const path = `${dir}/${name}`;
    if (disk.has(path)) throw new Error('EEXIST: already exists');
    disk.add(path); return path;
  });
  const read = vi.spyOn(window.nexelAPI, 'readWorkspaceFiles').mockImplementation(async dir =>
    [...disk].filter(path => path.startsWith(`${dir}/`)).map(path => ({ path, name: path.split('/').pop()!, type: 'file' as const })) as never);
  const one = queueCompanionImport(P('Same', 'Same', 'one'));
  const two = queueCompanionImport(P('Same', 'Same', 'two'));
  await vi.waitFor(() => expect(release).toBeTypeOf('function'));
  useWorkspaceStore.setState({ rootPath: '/ws-b', activeDir: '/ws-b', tree: [] });
  release(); await Promise.all([one, two]);
  expect([...disk]).toEqual(['/ws-a/Same.cpp', '/ws-a/Same_2.cpp']);
  expect(read).toHaveBeenCalledWith('/ws-a');
  expect(useStatusStore.getState().toasts.some(t => t.kind === 'error')).toBe(false);
});
