import { lazy, useEffect } from 'react';
import cpDataset from './cp-dataset.json';
import snippets from './snippets.json';
import { registerPlugin } from '../registry';
import { useJudgeStore } from '../../stores/useJudgeStore';
import { useWorkspaceStore, type FileNode } from '../../stores/useWorkspaceStore';
import { useEditorStore } from '../../stores/useEditorStore';
import { useStatusStore } from '../../stores/useStatusStore';
import { useUIStore } from '../../stores/useUIStore';

/** Panels are lazy-loaded here so the shell never imports CP modules. */
const JudgeSystem = lazy(() => import('../../components/JudgeSystem'));
const ContestsSystem = lazy(() => import('../../components/ContestsSystem'));

/**
 * Competitive Companion: browser extension -> new solution file + judge samples.
 * Attached only while the plugin is enabled; no listener exists when disabled.
 */
// Imports run one at a time: two problems arriving together must not choose
// the same filename from a tree snapshot that predates the first import.
let importChain: Promise<void> = Promise.resolve();

function walkNames(ns: FileNode[]): string[] { return ns.flatMap(n => [n.name, ...walkNames(n.children ?? [])]); }

// dir is captured at receipt by the listener: a queued import must land where
// the problem arrived, not in whatever workspace is active when it executes.
async function importCompanionProblem(p: { name: string; fileName: string; tests: { input: string; output: string }[] }, dir: string, root: string | null): Promise<void> {
  const toast = useStatusStore.getState().pushToast;
  const pickName = async () => {
    // A queued import can outlive its workspace selection. Read that captured
    // destination without publishing its tree into the current workspace.
    const tree = useWorkspaceStore.getState().rootPath === root
      ? useWorkspaceStore.getState().tree
      : await window.nexelAPI.readWorkspaceFiles(dir);
    const taken = new Set(walkNames(tree));
    let name = `${p.fileName}.cpp`, i = 2;
    while (taken.has(name)) name = `${p.fileName}_${i++}.cpp`; // never overwrite an existing solution
    return name;
  };
  try {
    let name = await pickName();
    let filePath: string;
    try {
      filePath = await window.nexelAPI.createFile(dir, name);
    } catch (first) {
      // The tree was stale (external file or a race the chain cannot see):
      // refresh, pick a fresh name, retry once. createFile never overwrites,
      // so the failed first attempt changed nothing on disk.
      if (!/EEXIST/i.test(first instanceof Error ? first.message : String(first))) throw first;
      await useWorkspaceStore.getState().refreshTree();
      name = await pickName();
      filePath = await window.nexelAPI.createFile(dir, name);
    }
    const body = useEditorStore.getState().cppTemplate;
    if (body) await window.nexelAPI.writeFileContent(filePath, body);
    await useWorkspaceStore.getState().refreshTree();
    if (useWorkspaceStore.getState().rootPath !== root) {
      toast(`Imported ${p.name} to ${filePath}. The workspace changed, so the current editor and test cases were kept.`, 'success', 6000);
      return;
    }
    useEditorStore.getState().openFile(filePath, name, body);
    useJudgeStore.getState().importSamples(p.tests);
    toast(`Imported ${p.name} · ${p.tests.length} sample${p.tests.length === 1 ? '' : 's'}`, 'success', 4000);
  } catch (e) { console.error(e); toast('Could not import problem from Competitive Companion', 'error', 4000); }
}

/** Queue one received problem; exported for tests. Never rejects: a failed
    import toasts and resolves so later queued imports still run. */
export function queueCompanionImport(p: { name: string; fileName: string; tests: { input: string; output: string }[] }): Promise<void> {
  const ws = useWorkspaceStore.getState();
  const dir = ws.activeDir ?? ws.rootPath;
  if (!dir) {
    useStatusStore.getState().pushToast('Open a workspace folder first, then re-send the problem', 'error', 4000);
    return Promise.resolve();
  }
  importChain = importChain.catch(() => {}).then(() => importCompanionProblem(p, dir, ws.rootPath));
  return importChain;
}

function useCompanionImport(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    let active = true;
    const unsubscribe = window.nexelAPI.onCompanionProblem?.((p) => { if (active) void queueCompanionImport(p); });
    return () => { active = false; unsubscribe?.(); };
  }, [enabled]);
}

/** Summarises the judge: a pulsing dot while running, otherwise passed/total of the last run. */
export function judgeSummary(cases: { verdict?: string }[], running: boolean): { tone: 'run' | 'ok' | 'bad' | 'idle'; text: string } {
  if (running) return { tone: 'run', text: 'Judging…' };
  // Cancelled cases are neither passes nor fails; only completed cases count.
  const ran = cases.filter(c => c.verdict && c.verdict !== 'IDLE' && c.verdict !== 'RUNNING' && c.verdict !== 'CANCELLED');
  if (!ran.length) {
    return cases.some(c => c.verdict === 'CANCELLED') ? { tone: 'idle', text: 'Canceled' } : { tone: 'idle', text: 'Judge ready' };
  }
  const ac = ran.filter(c => c.verdict === 'AC').length;
  return { tone: ac === ran.length ? 'ok' : 'bad', text: `Last run: ${ac}/${ran.length} passed` };
}

/** Title bar snippets on/off toggle contributed while the plugin is enabled. */
function SnippetsToggle() {
  const enableSnippets = useEditorStore(s => s.enableSnippets);
  const setEnableSnippets = useEditorStore(s => s.setEnableSnippets);
  return (
    <div className="nx-titlebar-toggle-wrapper" title="Toggle Snippets Autocomplete">
      <span className="nx-titlebar-toggle-label">Snippets</span>
      <button
        type="button"
        role="switch"
        aria-label="Snippets autocomplete"
        aria-checked={enableSnippets}
        title={enableSnippets ? 'Turn snippets autocomplete off' : 'Turn snippets autocomplete on'}
        className={`nx-titlebar-switch-track ${enableSnippets ? 'active' : ''}`}
        onClick={() => setEnableSnippets(!enableSnippets)}
      >
        <span className="nx-titlebar-switch-thumb" aria-hidden="true" />
      </button>
    </div>
  );
}

/** Title bar button contributed while the plugin is enabled. */
function SnippetsButton() {
  const openSnippets = useEditorStore(s => s.openSnippets);
  return (
    <button
      className="nx-titlebar-snippets-btn"
      onClick={openSnippets}
      title="Show Available Snippets List"
      aria-label="Snippets list"
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" /><line x1="8" y1="18" x2="21" y2="18" />
        <line x1="3" y1="6" x2="3.01" y2="6" /><line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" />
      </svg>
    </button>
  );
}

/** Status bar chip contributed while the plugin is enabled. */
function JudgeStatusChip() {
  const cases = useJudgeStore(s => s.testCases);
  const running = useJudgeStore(s => s.isRunning);
  const judge = judgeSummary(cases, running);
  return <button type="button" className={`sb-item sb-btn sb-judge sb-${judge.tone}`} title={`Open Judge: ${judge.text}`} aria-label={`Open Judge: ${judge.text}`} onClick={() => useUIStore.setState({ currentSection: 'judge', sidebarCollapsed: false, isHoverRevealed: false })}><i className="sb-pulse" aria-hidden="true" />{judge.text}</button>;
}

/**
 * Competitive Programming: judge with sample tests, stress testing, Codeforces contests
 * and Competitive Companion import. Opt-in: Nexel is a general-purpose IDE by default;
 * enabling this adds the CP dock sections, palette commands and the companion listener.
 * No data is deleted when disabled - test cases and settings are kept for re-enabling.
 */
registerPlugin({
  id: 'competitive-programming',
  name: 'Competitive Programming',
  blurb: 'Judge with sample tests, stress testing, Codeforces contests and Competitive Companion import',
  sections: ['judge', 'contests'],
  commandIds: ['judge', 'contests'],
  defaultEnabled: false,
  panels: { judge: JudgeSystem, contests: ContestsSystem },
  useActivation: useCompanionImport,
  completions: { dataset: { cp: cpDataset }, snippets },
  statusItems: [JudgeStatusChip],
  titlebarItems: [SnippetsToggle, SnippetsButton],
  menuItems: { Options: [{ label: 'Snippets Manager...', action: () => useEditorStore.getState().openSnippets() }] },
  navItems: [
    {
      id: 'judge',
      label: 'Judge',
      icon: (
        <svg className="nd-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22V13m0 0l-4 2m4-2l4 2" />
          <path d="M12 7V2m0 5a3 3 0 1 0 0 6 3 3 0 1 0 0-6z" />
          <path d="M5 17h14M3 22h18" />
        </svg>
      ),
    },
    {
      id: 'contests',
      label: 'Codeforces Contests',
      icon: (
        <svg className="nd-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22h9M3 22h9M12 2v20M17 5H7a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z" />
        </svg>
      ),
    },
  ],
});
export {};
