import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import {it,expect,afterEach} from 'vitest';
import TextCompare from './TextCompare';
afterEach(cleanup);
it('does not compare or navigate during composing CtrlEnter or arrow keys',()=>{
 render(<TextCompare/>);const input=screen.getByRole('textbox',{name:'After text'});fireEvent.change(input,{target:{value:'नाम'}});fireEvent.keyDown(input,{key:'Enter',ctrlKey:true,isComposing:true});expect(screen.getByRole('textbox',{name:'After text'})).toHaveValue('नाम');
 fireEvent.keyDown(screen.getByRole('tab',{name:'Inputs'}),{key:'ArrowRight',keyCode:229});expect(screen.getByRole('tab',{name:'Inputs'})).toHaveAttribute('aria-selected','true');
 fireEvent.keyDown(input,{key:'Enter',ctrlKey:true});expect(screen.queryByRole('textbox',{name:'After text'})).toBeNull();expect(screen.getByRole('tab',{name:'Changes'})).toHaveAttribute('aria-selected','true');
});
