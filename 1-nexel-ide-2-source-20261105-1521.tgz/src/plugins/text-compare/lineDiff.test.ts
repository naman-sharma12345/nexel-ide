import {describe,it,expect} from 'vitest';import {lineDiff} from './lineDiff';
describe('bounded line diff',()=>{
 it('returns exact ordered removals and additions',()=>{const result=lineDiff('a\nb\nc','a\nx\nc');expect(result.ok).toBe(true);if(result.ok){expect(result.added).toBe(1);expect(result.removed).toBe(1);expect(result.lines.map(l=>l.kind)).toEqual(['same','remove','add','same']);}});
 it('retains whitespace, CR and trailing newline changes',()=>{const result=lineDiff('a\r\n','a');if(!result.ok)throw Error();expect(result.added+result.removed).toBeGreaterThan(0);expect(result.lines.filter(l=>l.kind!=='add').map(l=>l.text).join('\n')).toBe('a\r\n');});
 it('handles empty and equal texts',()=>{expect(lineDiff('','')).toEqual({ok:true,lines:[],added:0,removed:0});const same=lineDiff('🌐','🌐');if(!same.ok)throw Error();expect(same.added+same.removed).toBe(0);});
 it('bounds time and memory before allocation',()=>{expect(lineDiff('a\n'.repeat(401),'').ok).toBe(false);expect(lineDiff('x'.repeat(200001),'').ok).toBe(false);});
 it('reconstructs both inputs through duplicate line choices',()=>{const result=lineDiff('a\nb\na','b\na\nb');if(!result.ok)throw Error();expect(result.lines.filter(l=>l.kind!=='add').map(l=>l.text).join('\n')).toBe('a\nb\na');expect(result.lines.filter(l=>l.kind!=='remove').map(l=>l.text).join('\n')).toBe('b\na\nb');});
});
