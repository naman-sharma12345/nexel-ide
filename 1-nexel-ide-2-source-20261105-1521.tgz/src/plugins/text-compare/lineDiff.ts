export interface DiffLine {kind:'same'|'add'|'remove';text:string;left?:number;right?:number}
export type DiffResult={ok:true;lines:DiffLine[];added:number;removed:number}|{ok:false;error:string};
/** Bounded exact line LCS. Trailing newline is part of the input, not trimmed away. */
export function lineDiff(before:string,after:string):DiffResult{
 if(before.length+after.length>200000)return {ok:false,error:'Compare is limited to 200,000 combined characters.'};
 const a=before===''?[]:before.split('\n'),b=after===''?[]:after.split('\n');
 if(a.length>400||b.length>400)return {ok:false,error:'Compare is limited to 400 lines per side.'};
 const table=Array.from({length:a.length+1},()=>new Uint16Array(b.length+1));
 for(let i=a.length-1;i>=0;i--)for(let j=b.length-1;j>=0;j--)table[i][j]=a[i]===b[j]?1+table[i+1][j+1]:Math.max(table[i+1][j],table[i][j+1]);
 const lines:DiffLine[]=[];let i=0,j=0,added=0,removed=0;
 while(i<a.length||j<b.length){
  if(i<a.length&&j<b.length&&a[i]===b[j]){lines.push({kind:'same',text:a[i],left:i+1,right:j+1});i++;j++;}
  else if(i<a.length&&(j===b.length||table[i+1][j]>=table[i][j+1])){lines.push({kind:'remove',text:a[i],left:i+1});i++;removed++;}
  else{lines.push({kind:'add',text:b[j],right:j+1});j++;added++;}
 }return {ok:true,lines,added,removed};
}
