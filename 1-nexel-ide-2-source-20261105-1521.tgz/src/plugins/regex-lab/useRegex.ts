import {useCallback,useEffect,useState} from 'react';import type {RegexResult} from './matchRegex';
export function useRegex(pattern:string,flags:string,text:string,active:boolean){
 const [attempt,setAttempt]=useState(0);const retry=useCallback(()=>setAttempt(value=>value+1),[]);
 const key=JSON.stringify([pattern,flags,text,attempt]);const [out,setOut]=useState<{key:string;result?:RegexResult;error?:string}|null>(null);
 useEffect(()=>{if(!active)return;let worker:Worker|undefined;let cancelled=false;let limit:ReturnType<typeof setTimeout>|undefined;let settled=false;let ready=false;
 const finish=(value:{result?:RegexResult;error?:string})=>{if(settled||cancelled)return;settled=true;setOut({key,...value});clearTimeout(limit);worker?.terminate();};
 const timer=setTimeout(()=>{try{worker=new Worker(new URL('./regex.worker.ts',import.meta.url),{type:'module'});
  worker.onmessage=event=>{if(event.data.ready){if(ready||settled||cancelled)return;ready=true;clearTimeout(limit);limit=setTimeout(()=>finish({error:'Matching stopped after 750ms. Simplify this pattern or shorten the text.'}),750);try{worker?.postMessage({pattern,flags,text});}catch{finish({error:'Could not send text to pattern matching. Try again.'});}}else finish(event.data);};
  worker.onerror=()=>finish({error:'Could not run pattern matching. Try again.'});
  limit=setTimeout(()=>finish({error:'Matching worker could not start within 5 seconds. Try again.'}),5000);
 }catch{finish({error:'Could not start pattern matching. Try again.'});}},200);
 return()=>{cancelled=true;clearTimeout(timer);clearTimeout(limit);worker?.terminate();};
 },[pattern,flags,text,active,key]);
 return {retry,result:active&&out?.key===key?out.result:undefined,error:active&&out?.key===key?out.error:undefined,pending:active&&out?.key!==key};
}
