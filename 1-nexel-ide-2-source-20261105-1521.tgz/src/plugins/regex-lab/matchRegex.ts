export interface RegexMatch {start:number;end:number;text:string;previewTruncated:boolean;groupCount:number;groups:(string|null)[];named:Record<string,string|null>}
export interface RegexResult {matches:RegexMatch[];truncated:boolean}
export function matchRegex(pattern:string,flags:string,text:string):RegexResult {
 if(pattern.length>2000||text.length>50000)throw Error('Use up to 2,000 pattern UTF-16 units and 50,000 text UTF-16 units.');
 if(!/^[gimsu]*$/.test(flags)||new Set(flags).size!==flags.length)throw Error('Flags must be unique: g, i, m, s or u.');
 const regex=new RegExp(pattern,flags);const matches:RegexMatch[]=[];let item:RegExpExecArray|null;
 while((item=regex.exec(text))){
  if(matches.length===200)return {matches,truncated:true};
  matches.push({start:item.index,end:item.index+item[0].length,text:item[0].slice(0,500),previewTruncated:item[0].length>500,groupCount:item.length-1,groups:item.slice(1,21).map(value=>value===undefined?null:value.slice(0,500)),named:Object.fromEntries(Object.entries(item.groups??{}).slice(0,20).map(([key,value])=>[key,value===undefined?null:value.slice(0,500)]))});
  if(!regex.global)break;
  if(item[0]===''){const point=text.codePointAt(regex.lastIndex);regex.lastIndex+=regex.unicode&&point!==undefined&&point>0xffff?2:1;}
 }
 return {matches,truncated:false};
}
