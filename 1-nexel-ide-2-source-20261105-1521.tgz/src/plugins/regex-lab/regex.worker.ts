import {matchRegex} from './matchRegex';
self.onmessage=({data}:{data:{pattern:string;flags:string;text:string}})=>{try{self.postMessage({result:matchRegex(data.pattern,data.flags,data.text)});}catch(error){self.postMessage({error:error instanceof Error?error.message:'Could not evaluate this pattern.'});}};
self.postMessage({ready:true});
