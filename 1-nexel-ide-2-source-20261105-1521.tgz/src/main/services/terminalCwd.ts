import * as fs from 'fs';

/** Integrated-terminal working directory: use the workspace root the renderer
    asked for when it is an existing directory; otherwise fall back to the user
    home. This narrows, but cannot eliminate, bad-cwd spawn failures: the
    directory can be removed after validation (the caller retries a failed
    spawn once in HOME), and HOME itself is not separately validated. The
    caller's spelling is preserved (a symlinked root stays under its own
    spelling). */
export function resolveTerminalCwd(requested: unknown, home: string): string {
  if (typeof requested !== 'string' || !requested) return home;
  try {
    if (fs.statSync(requested).isDirectory()) return requested;
  } catch { /* fall through to home */ }
  return home;
}
