// @vitest-environment node
import { describe, it, expect } from 'vitest';
import { parsePorcelainStatusZ } from '../GitService';
import type { GitStatusEntry } from '../GitService';

const z = (...lines: string[]) => lines.join('\0') + '\0';
const by = (entries: GitStatusEntry[]) => Object.fromEntries(entries.map(e => [e.path, e]));

describe('parsePorcelainStatusZ', () => {
  it('parses branch with ahead/behind', () => {
    const s = parsePorcelainStatusZ(z('## main...origin/main [ahead 2, behind 1]'));
    expect(s).toMatchObject({ isRepo: true, branch: 'main', ahead: 2, behind: 1, entries: [] });
  });

  it('parses a clean branch without tracking info', () => {
    const s = parsePorcelainStatusZ(z('## feature-x'));
    expect(s).toMatchObject({ branch: 'feature-x', ahead: 0, behind: 0 });
  });

  it('detached HEAD yields branch null, never the literal "HEAD"', () => {
    const s = parsePorcelainStatusZ(z('## HEAD (no branch)', ' M dirty.py'));
    expect(s.branch).toBeNull();
    expect(s.entries[0]).toMatchObject({ path: 'dirty.py', unstaged: true });
  });

  it('parses an unborn branch (no commits yet)', () => {
    const s = parsePorcelainStatusZ(z('## No commits yet on main', '?? new.py'));
    expect(s.branch).toBe('main');
    expect(s.entries[0]).toMatchObject({ path: 'new.py', untracked: true, staged: false, unstaged: false });
  });

  it('classifies staged, unstaged, both, and untracked entries', () => {
    const s = parsePorcelainStatusZ(z('## main', 'M  staged.py', ' M unstaged.py', 'MM both.py', '?? fresh.py', 'A  added.py'));
    const m = by(s.entries);
    expect(m['staged.py']).toMatchObject({ staged: true, unstaged: false });
    expect(m['unstaged.py']).toMatchObject({ staged: false, unstaged: true });
    expect(m['both.py']).toMatchObject({ staged: true, unstaged: true });
    expect(m['fresh.py']).toMatchObject({ untracked: true });
    expect(m['added.py']).toMatchObject({ staged: true, unstaged: false });
  });

  it('keeps paths with spaces and newlines verbatim (no quoting with -z)', () => {
    const s = parsePorcelainStatusZ(z('## main', ' M dir/with space.py', '?? odd\nnewline.py'));
    const m = by(s.entries);
    expect(m['dir/with space.py']).toMatchObject({ unstaged: true });
    expect(m['odd\nnewline.py']).toMatchObject({ untracked: true });
  });

  it('parses renames as new path + origPath', () => {
    const s = parsePorcelainStatusZ(z('## main', 'R  new name.py', 'old name.py', ' M other.py'));
    expect(s.entries[0]).toMatchObject({ path: 'new name.py', code: 'R ', staged: true, origPath: 'old name.py' });
    expect(s.entries[1]).toMatchObject({ path: 'other.py', unstaged: true });
  });

  it('keeps leading-dash paths as paths, not flags', () => {
    const s = parsePorcelainStatusZ(z('## main', '?? -rf.py', '?? --force.py'));
    expect(s.entries.map(e => e.path)).toEqual(['-rf.py', '--force.py']);
  });
});

describe('conflict + log parsing', () => {
  it('marks unmerged codes as conflicted', () => {
    const s = parsePorcelainStatusZ(z('## main', 'UU both.py', 'AA added-both.py', 'DU deleted-upstream.py', ' M clean.py'));
    const m = by(s.entries);
    expect(m['both.py'].conflicted).toBe(true);
    expect(m['added-both.py'].conflicted).toBe(true);
    expect(m['deleted-upstream.py'].conflicted).toBe(true);
    expect(m['clean.py'].conflicted).toBe(false);
  });
});

describe('upstream parsing', () => {
  it('hasUpstream true with tracking ref, false without', () => {
    expect(parsePorcelainStatusZ(z('## main...origin/main [ahead 1]')).hasUpstream).toBe(true);
    expect(parsePorcelainStatusZ(z('## local-only')).hasUpstream).toBe(false);
    expect(parsePorcelainStatusZ(z('## No commits yet on dev')).hasUpstream).toBe(false);
  });
});
it('preserves branch and configured upstream when tracking reference is gone',()=>{
 expect(parsePorcelainStatusZ('## feature.v2...origin/feature.v2 [gone]\0')).toMatchObject({branch:'feature.v2',hasUpstream:true,ahead:0,behind:0});
});
