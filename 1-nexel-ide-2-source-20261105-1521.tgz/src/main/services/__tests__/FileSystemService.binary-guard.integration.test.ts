// @vitest-environment node
import { describe, it, expect, vi, afterEach } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';

vi.mock('electron', () => ({ dialog: { showOpenDialog: vi.fn() } }));

import { FileSystemService } from '../FileSystemService';

let dir: string | null = null;
afterEach(async () => {
  if (dir) { await fs.rm(dir, { recursive: true, force: true }); dir = null; }
});

describe('FileSystemService.readFileContent binary guard (real filesystem)', () => {
  it('rejects a file with NUL bytes and leaves it untouched', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'img.png');
    const orig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x00, 0xff]);
    await fs.writeFile(p, orig);
    await expect(new FileSystemService().readFileContent(p)).rejects.toThrow(/binary/);
    expect(orig.equals(await fs.readFile(p))).toBe(true);
  });

  it('rejects invalid UTF-8 without NUL bytes (e.g. a lone latin-1 accent)', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'notes.txt');
    const orig = Buffer.from([0x63, 0x61, 0x66, 0xe9]); // "café" in latin-1
    await fs.writeFile(p, orig);
    await expect(new FileSystemService().readFileContent(p)).rejects.toThrow(/UTF-8/);
    expect(orig.equals(await fs.readFile(p))).toBe(true);
  });

  it('still opens valid UTF-8 including emoji and multi-byte text', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'ok.py');
    await fs.writeFile(p, '# café 🚀\nprint("hi")\n', 'utf8');
    expect(await new FileSystemService().readFileContent(p)).toBe('# café 🚀\nprint("hi")\n');
  });

  it('opens an empty file', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'empty.txt');
    await fs.writeFile(p, '');
    expect(await new FileSystemService().readFileContent(p)).toBe('');
  });
});

  it('restriction, pinned: valid UTF-16LE text contains NUL bytes and is rejected too (bytes untouched)', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'utf16.txt');
    const orig = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from('hello', 'utf16le')]);
    await fs.writeFile(p, orig);
    // Documented behavior restriction: legacy encodings are refused rather than
    // transcoded, same as any binary. The file is never modified.
    await expect(new FileSystemService().readFileContent(p)).rejects.toThrow(/binary/);
    expect(orig.equals(await fs.readFile(p))).toBe(true);
  });

  it('valid UTF-8 that legitimately contains no NUL but multi-byte emoji is untouched', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-bg-'));
    const p = path.join(dir, 'ok2.txt');
    const orig = Buffer.from('# café 🚀\n', 'utf8');
    await fs.writeFile(p, orig);
    expect(await new FileSystemService().readFileContent(p)).toBe('# café 🚀\n');
    expect(orig.equals(await fs.readFile(p))).toBe(true);
  });
