// @vitest-environment node
import { describe, it, expect, vi, afterEach } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';

vi.mock('electron', () => ({ dialog: { showOpenDialog: vi.fn() } }));

import { FileSystemService } from '../FileSystemService';
// buildFileTree is the exact function the readFiles worker runs; calling it
// directly keeps this test on the real fs without spawning a Worker under vitest.
import { buildFileTree } from '../FileTreeWorker';

let dir: string | null = null;
afterEach(async () => {
  if (dir) { await fs.rm(dir, { recursive: true, force: true }); dir = null; }
});

async function listRoot(root: string) {
  const raw = await fs.readdir(root);
  const children = await Promise.all(raw.map(n => buildFileTree(path.join(root, n))));
  children.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'folder' ? -1 : 1));
  return children;
}

describe('FileSystemService against the real filesystem (empty folder flow)', () => {
  it('an empty dir lists no entries, then created files and folders appear', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fs-'));
    const svc = new FileSystemService();

    // Empty workspace folder lists as empty, not an error.
    expect(await listRoot(dir)).toEqual([]);

    // Create at the workspace root, exactly what the Explorer empty-state flow calls.
    const filePath = await svc.createFile(dir, 'solve.cpp');
    const folderPath = await svc.createFolder(dir, 'stress');
    await svc.createFile(folderPath, 'gen.cpp');
    await svc.writeFileContent(filePath, '// hello\n');

    const tree = await listRoot(dir);
    const byName = new Map(tree.map(n => [n.name, n]));
    expect([...byName.keys()].sort()).toEqual(['solve.cpp', 'stress']);
    expect(byName.get('solve.cpp')!.type).toBe('file');
    expect(byName.get('stress')!.type).toBe('folder');
    expect((byName.get('stress')!.children ?? []).map(c => c.name)).toContain('gen.cpp');
    expect(await svc.readFileContent(filePath)).toBe('// hello\n');

    // Reopen persistence: a completely fresh read from disk lists the same entries.
    const fresh = await listRoot(dir);
    expect(fresh.map(n => n.name).sort()).toEqual(['solve.cpp', 'stress']);
  });

  it('duplicate New File rejects without changing existing disk content', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fs-'));
    const svc = new FileSystemService();
    const file = await svc.createFile(dir, 'existing.txt');
    await fs.writeFile(file, 'keep this content\n');
    await expect(svc.createFile(dir, 'existing.txt')).rejects.toMatchObject({ code: 'EEXIST' });
    expect(await fs.readFile(file, 'utf8')).toBe('keep this content\n');
  });

  it('blocks traversal, rejects invalid names, and deleteNode removes entries', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fs-'));
    const svc = new FileSystemService();

    await expect(svc.createFile(dir, '../evil.txt')).rejects.toThrow(/traversal/i);
    await expect(svc.createFolder(dir, '../../evil')).rejects.toThrow(/traversal/i);
    await expect(svc.createFile(dir, 'bad\0name')).rejects.toThrow();

    const keep = await svc.createFile(dir, 'keep.txt');
    expect((await listRoot(dir)).map(n => n.name)).toEqual(['keep.txt']);
    await svc.deleteNode(keep);
    expect(await listRoot(dir)).toEqual([]);
  });
  it('rejects a sibling whose name starts with the parent name', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fs-boundary-'));
    const svc = new FileSystemService();
    const parent=path.join(dir,'workspace');
    const sibling=path.join(dir,'workspace-backup');
    await fs.mkdir(parent);await fs.mkdir(sibling);
    await expect(svc.createFile(parent,'../workspace-backup/escape.txt')).rejects.toThrow(/traversal/i);
    await expect(svc.createFolder(parent,'../workspace-backup/escape')).rejects.toThrow(/traversal/i);
    expect(await fs.readdir(sibling)).toEqual([]);
  });

  it('binds symlink and hardlink aliases to the same actual file identity', async () => {
    dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-fs-identity-'));
    const svc=new FileSystemService();const original=path.join(dir,'original.py');await fs.writeFile(original,'pass');
    await fs.symlink(original,path.join(dir,'alias.py'));await fs.link(original,path.join(dir,'hardlink.py'));
    const id=await svc.fileIdentity(original);
    expect(await svc.fileIdentity(path.join(dir,'alias.py'))).toBe(id);expect(await svc.fileIdentity(path.join(dir,'hardlink.py'))).toBe(id);
    await expect(svc.fileIdentity(dir)).rejects.toThrow(/identity/);await expect(svc.fileIdentity(path.join(dir,'missing'))).rejects.toThrow();
  });

  it('refuses a rename collision without changing either existing file',async()=>{
    dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-rename-collision-'));const svc=new FileSystemService();const from=path.join(dir,'from.txt'),to=path.join(dir,'to.txt');await fs.writeFile(from,'source');await fs.writeFile(to,'destination');await expect(svc.rename(from,to)).rejects.toMatchObject({code:'EEXIST'});expect(await fs.readFile(from,'utf8')).toBe('source');expect(await fs.readFile(to,'utf8')).toBe('destination');
  });
  it('refuses a dangling-symlink destination instead of replacing the link',async()=>{
    dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-rename-link-'));const svc=new FileSystemService();const from=path.join(dir,'from.txt'),to=path.join(dir,'link.txt');await fs.writeFile(from,'source');await fs.symlink(path.join(dir,'missing'),to);await expect(svc.rename(from,to)).rejects.toMatchObject({code:'EEXIST'});expect((await fs.lstat(to)).isSymbolicLink()).toBe(true);expect(await fs.readFile(from,'utf8')).toBe('source');
  });
  it('renames to a free destination and treats an unchanged path as a no-op',async()=>{
    dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-rename-free-'));const svc=new FileSystemService();const from=path.join(dir,'from.txt'),to=path.join(dir,'to.txt');await fs.writeFile(from,'source');await expect(svc.rename(from,from)).resolves.toBe(from);await expect(svc.rename(from,to)).resolves.toBe(to);expect(await fs.readFile(to,'utf8')).toBe('source');await expect(fs.stat(from)).rejects.toMatchObject({code:'ENOENT'});
  });

});
