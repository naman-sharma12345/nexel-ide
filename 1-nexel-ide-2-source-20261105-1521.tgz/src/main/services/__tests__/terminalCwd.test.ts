import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';
import { resolveTerminalCwd } from '../terminalCwd';

let fixture: string | null = null;
beforeEach(async () => { fixture = await fs.mkdtemp(path.join(os.tmpdir(), 'nexel-termcwd-')); });
afterEach(async () => { if (fixture) { await fs.rm(fixture, { recursive: true, force: true }); fixture = null; } });

describe('resolveTerminalCwd', () => {
  it('uses an existing directory, preserving its spelling', async () => {
    const real = path.join(fixture!, 'real'); await fs.mkdir(real);
    const link = path.join(fixture!, 'link'); await fs.symlink(real, link, 'dir');
    expect(resolveTerminalCwd(link, '/home/user')).toBe(link);
  });
  it('falls back to home for a missing path, a file, and non-string input', async () => {
    const file = path.join(fixture!, 'a.txt'); await fs.writeFile(file, 'x');
    expect(resolveTerminalCwd(path.join(fixture!, 'gone'), '/home/user')).toBe('/home/user');
    expect(resolveTerminalCwd(file, '/home/user')).toBe('/home/user');
    expect(resolveTerminalCwd(undefined, '/home/user')).toBe('/home/user');
    expect(resolveTerminalCwd('', '/home/user')).toBe('/home/user');
    expect(resolveTerminalCwd(42, '/home/user')).toBe('/home/user');
  });
});
