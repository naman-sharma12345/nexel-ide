// @vitest-environment node
import { it, expect, vi } from 'vitest';
const fixture = vi.hoisted(() => ({ output: '', code: 0, error: '' }));
vi.mock('child_process', async () => {
 const { EventEmitter } = await import('node:events');
 return { spawn: vi.fn(() => {
  const child = Object.assign(new EventEmitter(), { stdout: new EventEmitter(), stderr: new EventEmitter(), kill: vi.fn() });
  queueMicrotask(() => {
   for (const byte of Buffer.from(fixture.output)) child.stdout.emit('data', Buffer.from([byte]));
   for (const byte of Buffer.from(fixture.error)) child.stderr.emit('data', Buffer.from([byte]));
   child.emit('close', fixture.code);
  });
  return child;
 }) };
});
import { GitService } from '../GitService';
it('keeps UTF-8 diff and error text exact across transport chunk boundaries',async()=>{
 fixture.output='diff --git a/नाम🌐.txt b/नाम🌐.txt\n+नमस्ते 🌐\n';fixture.code=0;fixture.error='';
 expect(await new GitService().diff('/fixture','नाम🌐.txt',false)).toEqual({ok:true,diff:fixture.output});
 fixture.code=1;fixture.output='';fixture.error='fatal: नाम🌐 inaccessible';
 expect(await new GitService().diff('/fixture','नाम🌐.txt',false)).toEqual({ok:false,error:fixture.error});
});
it('preserves literal replacement characters as ordinary encoded data',async()=>{
 // A valid encoded U+FFFD is still ordinary data, not an error sentinel.
 fixture.code=0;fixture.error='';fixture.output='literal �\n';
 expect((await new GitService().diff('/fixture','x',false)).diff).toBe(fixture.output);
});
