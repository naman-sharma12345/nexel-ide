// @vitest-environment node
import { describe, it, expect, afterEach, vi } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';
import { execFileSync } from 'child_process';
import * as http from 'http';
import { GitService } from '../GitService';

let dir: string | null = null;
afterEach(async () => { if (dir) { await fs.rm(dir, { recursive: true, force: true }); dir = null; } });

const git = (args: string[]) => execFileSync('git', args, { cwd: dir!, stdio: 'pipe' }).toString();

describe('GitService against a real repository', () => {
  it('reports isRepo:false outside a work tree', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    expect((await new GitService().status(dir)).isRepo).toBe(false);
  });

  it('does not offer init when damaged repository metadata hides the work tree', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const headPath = path.join(dir, '.git', 'HEAD');
    const original = await fs.readFile(headPath);
    await fs.mkdir(path.join(dir, 'src'));
    await fs.writeFile(headPath, 'invalid fixture HEAD');
    await expect(svc.status(dir)).rejects.toThrow(/metadata found.*could not be read/i);
    await expect(svc.status(path.join(dir, 'src'))).rejects.toThrow(/metadata found.*could not be read/i);
    expect(await fs.readFile(headPath, 'utf8')).toBe('invalid fixture HEAD');
    await fs.writeFile(headPath, original);
    expect((await svc.status(dir)).isRepo).toBe(true);
  });

  it('refuses unreadable worktree pointers, missing workspaces, and bare repositories', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await fs.writeFile(path.join(dir, '.git'), 'gitdir: /missing/nexel-fixture-gitdir\n');
    await expect(svc.status(dir)).rejects.toThrow();
    await fs.unlink(path.join(dir, '.git'));
    await expect(svc.status(path.join(dir, 'missing'))).rejects.toThrow();
    git(['init', '--bare']);
    await expect(svc.status(dir)).rejects.toThrow(/not a working tree/i);
  });

  it('preserves unknown discovery failures rather than inferring a non-repository', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    for (const result of [
      { code: 1, stdout: '', stderr: 'spawn git ENOENT', stdoutTruncated: false },
      { code: 128, stdout: '', stderr: 'git timed out after 10000ms', stdoutTruncated: false },
      { code: 128, stdout: '', stderr: 'fatal: permission denied', stdoutTruncated: false },
      { code: 0, stdout: 'true', stderr: '', stdoutTruncated: true },
    ]) {
      const svc = new GitService();
      const mock = vi.spyOn(svc as unknown as { run: (...args: unknown[]) => Promise<typeof result> }, 'run').mockResolvedValue(result);
      await expect(svc.status(dir)).rejects.toThrow();
      expect(mock).toHaveBeenCalledTimes(1);
      mock.mockRestore();
    }
  });

  it('refuses capped commit history instead of returning a partial subject as complete', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const message = 'HISTORY_START_' + 'x'.repeat(1024 * 1024) + '_HISTORY_END';
    await fs.writeFile(path.join(dir, 'message.txt'), message);
    git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '--allow-empty', '-F', 'message.txt']);
    expect((await svc.log(dir)).ok).toBe(false);
    expect(await svc.log(dir)).toMatchObject({ commits: [], error: expect.stringMatching(/history.*output limit/i) });
  });

  it('refuses all capped metadata lists, including a clipped final branch or remote', async () => {
    const svc = new GitService();
    const response = { code: 0, stdout: 'refs/heads/topic\nrefs/heads/part', stderr: '', stdoutTruncated: true };
    const mock = vi.spyOn(svc as unknown as { run: (...args: unknown[]) => Promise<typeof response> }, 'run').mockResolvedValue(response);
    expect(await svc.branches('/fixture')).toMatchObject({ ok: false, branches: [], error: expect.stringMatching(/output limit/) });
    response.stdout = 'origin\npart';
    expect(await svc.remotes('/fixture')).toMatchObject({ ok: false, remotes: [], error: expect.stringMatching(/output limit/) });
    response.code = 1;
    expect(await svc.log('/fixture')).toMatchObject({ ok: false, commits: [], error: expect.stringMatching(/output limit/) });
    expect(mock).toHaveBeenCalledTimes(3);
    mock.mockRestore();
  });

  it('keeps record-separator characters inside a commit subject, never phantom commits', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const message = 'Subject before\x1eSubject after';
    await fs.writeFile(path.join(dir, 'message.txt'), message);
    git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '--allow-empty', '-F', 'message.txt']);
    const result = await svc.log(dir);
    expect(result.ok).toBe(true);
    expect(result.commits).toHaveLength(1);
    expect(result.commits[0]).toMatchObject({ subject: message, author: 'Fixture', date: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) });
  });

  it('rejects incomplete history fields and non-hash records without phantom entries', async () => {
    const svc = new GitService();
    const response = { code: 0, stdout: '', stderr: '', stdoutTruncated: false };
    const mock = vi.spyOn(svc as unknown as { run: (...args: unknown[]) => Promise<typeof response> }, 'run').mockResolvedValue(response);
    for (const output of ['abc123\0Fixture\0' + '2026-11-05\0', 'not-a-hash\0Fixture\0' + '2026-11-05\0Subject\0']) {
      response.stdout = output;
      expect(await svc.log('/fixture')).toMatchObject({ ok: false, commits: [], error: expect.stringMatching(/parse/) });
    }
    response.stdout = 'abc123\0Fixture\0' + '2026-11-05\0\0';
    expect(await svc.log('/fixture')).toEqual({ ok: true, commits: [{ hash: 'abc123', author: 'Fixture', date: '2026-11-05', subject: '' }] });
    mock.mockRestore();
  });

  it('reads UTF-8 history even when repository log output encoding is Latin-1', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    git(['config', 'i18n.logOutputEncoding', 'ISO-8859-1']);
    git(['-c', 'user.name=René', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '--allow-empty', '-m', 'Résumé café']);
    expect(await svc.log(dir)).toMatchObject({ ok: true, commits: [{ author: 'René', subject: 'Résumé café' }] });
    expect(git(['config', 'i18n.logOutputEncoding']).trim()).toBe('ISO-8859-1');
  });

  it('transcodes a legacy Latin-1 commit object without rewriting it or configuration', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const run = (args: string[], input?: Buffer) => execFileSync('git', args, { cwd: dir!, stdio: ['pipe', 'pipe', 'pipe'], input });
    const tree = run(['mktree'], Buffer.alloc(0)).toString().trim();
    const raw = Buffer.from(`tree ${tree}\nauthor René <fixture@example.invalid> 1793836800 +0000\ncommitter René <fixture@example.invalid> 1793836800 +0000\nencoding ISO-8859-1\n\nRésumé café\n`, 'latin1');
    const oid = run(['hash-object', '-t', 'commit', '-w', '--stdin'], raw).toString().trim();
    git(['symbolic-ref', 'HEAD', 'refs/heads/legacy']);
    git(['update-ref', 'refs/heads/legacy', oid]);
    git(['config', 'i18n.logOutputEncoding', 'ISO-8859-1']);
    expect(await svc.log(dir)).toMatchObject({ ok: true, commits: [{ author: 'René', subject: 'Résumé café' }] });
    expect(run(['cat-file', 'commit', oid])).toEqual(raw);
    expect(git(['config', 'i18n.logOutputEncoding']).trim()).toBe('ISO-8859-1');
  });

  it('reads signed history without verification prose, preserving objects and showSignature config', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-signed-'));
    const svc = new GitService(); await svc.init(dir);
    const key = path.join(dir, 'fixture-signing-key');
    execFileSync('ssh-keygen', ['-q', '-t', 'ed25519', '-N', '', '-C', 'disposable-fixture', '-f', key], { stdio: 'pipe' });
    git(['config', 'user.name', 'Fixture']);git(['config', 'user.email', 'fixture@example.invalid']);
    git(['config', 'gpg.format', 'ssh']);git(['config', 'user.signingkey', key]);git(['config', 'log.showSignature', 'true']);
    git(['commit', '--quiet', '--allow-empty', '-S', '-m', 'Signed fixture']);
    const before = git(['cat-file', 'commit', 'HEAD']);expect(before).toContain('gpgsig -----BEGIN SSH SIGNATURE-----');
    expect(await svc.log(dir)).toMatchObject({ ok: true, commits: [{ subject: 'Signed fixture', author: 'Fixture' }] });
    expect(git(['cat-file', 'commit', 'HEAD'])).toBe(before);expect(git(['config', 'log.showSignature']).trim()).toBe('true');
  });

  it('init -> untracked -> stage -> commit -> clean roundtrip', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    expect((await svc.init(dir)).ok).toBe(true);
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    let s = await svc.status(dir);
    expect(s.isRepo).toBe(true);
    expect(s.branch).toBeTruthy();
    expect(s.entries).toEqual([expect.objectContaining({ path: 'a.py', untracked: true })]);

    expect((await svc.stage(dir, ['a.py'])).ok).toBe(true);
    s = await svc.status(dir);
    expect(s.entries[0]).toMatchObject({ path: 'a.py', staged: true, untracked: false });

    expect((await svc.commit(dir, 'add a.py')).ok).toBe(true);
    s = await svc.status(dir);
    expect(s.entries).toEqual([]);

    // modify -> unstaged; unstage after add -> back to unstaged
    await fs.writeFile(path.join(dir, 'a.py'), 'a\nedit\n');
    s = await svc.status(dir);
    expect(s.entries[0]).toMatchObject({ path: 'a.py', unstaged: true, staged: false });
    await svc.stage(dir, ['a.py']);
    expect((await svc.unstage(dir, ['a.py'])).ok).toBe(true);
    s = await svc.status(dir);
    expect(s.entries[0]).toMatchObject({ staged: false, unstaged: true });
    expect(git(['log', '--oneline'])).toContain('add a.py');
  });

  it('rejects an empty commit message without invoking git', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const r = await new GitService().commit(dir, '   ');
    expect(r).toMatchObject({ ok: false, error: 'Commit message is empty' });
  });

  it('commit failure (nothing staged) surfaces the git error', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const r = await svc.commit(dir, 'nothing here');
    expect(r.ok).toBe(false);
    expect(r.error).toBeTruthy();
  });
});

describe('GitService network prompt safety', () => {
  it('fetch against an auth-requiring remote fails fast instead of prompting on a terminal', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    await svc.stage(dir, ['a.py']);
    await svc.commit(dir, 'init');
    // Local HTTP server that demands auth; git would prompt via /dev/tty when
    // a controlling terminal exists. The service must disable terminal prompts
    // so the failure surfaces immediately instead of burning the network
    // timeout on an unanswerable prompt.
    const srv = http.createServer((_req, res) => { res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="git"' }); res.end('auth required'); });
    await new Promise<void>(resolve => srv.listen(0, '127.0.0.1', resolve));
    const port = (srv.address() as { port: number }).port;
    try {
      await fs.appendFile(path.join(dir, '.git', 'config'),
        `\n[remote "origin"]\n\turl = http://127.0.0.1:${port}/repo.git\n\tfetch = +refs/heads/*:refs/remotes/origin/*\n`);
      const t0 = Date.now();
      const r = await svc.fetch(dir);
      expect(r.ok).toBe(false);
      expect(r.error).toMatch(/terminal prompts disabled/);
      expect(Date.now() - t0).toBeLessThan(15000);
    } finally {
      await new Promise(resolve => srv.close(resolve));
    }
  }, 30000);
});

describe('GitService diff/branch/pull increment', () => {
  const setup = async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    await svc.stage(dir, ['a.py']);
    await svc.commit(dir, 'first');
    return svc;
  };

  it('diff shows unstaged and staged changes for one path', async () => {
    const svc = await setup();
    await fs.writeFile(path.join(dir!, 'a.py'), 'a\nedit\n');
    let d = await svc.diff(dir!, 'a.py', false);
    expect(d.ok).toBe(true);
    expect(d.diff).toContain('+edit');
    expect((await svc.diff(dir!, 'a.py', true)).diff).toBe('');
    await svc.stage(dir!, ['a.py']);
    d = await svc.diff(dir!, 'a.py', true);
    expect(d.diff).toContain('+edit');
  });

  it('handles paths with spaces, newlines and leading dashes literally', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    const names = ['sp ace.py', 'new\nline.py', '-rf.py', '--force.py', 'glob[0].py'];
    for (const n of names) await fs.writeFile(path.join(dir, n), 'x\n');
    let s = await svc.status(dir);
    expect(s.entries.map(e => e.path).sort()).toEqual(names.sort());
    expect((await svc.stage(dir, names)).ok).toBe(true);
    s = await svc.status(dir);
    expect(s.entries.every(e => e.staged)).toBe(true);
    expect((await svc.commit(dir, 'weird names')).ok).toBe(true);
    // rename with spaces
    git(['mv', 'sp ace.py', 'ren amed.py']);
    s = await svc.status(dir);
    expect(s.entries[0]).toMatchObject({ path: 'ren amed.py', code: 'R ', origPath: 'sp ace.py' });
  });

  it('detached HEAD: branches() drops the pseudo-entry, status.branch is null', async () => {
    const svc = await setup();
    git(['branch', 'side']);
    git(['checkout', '--detach', 'master']);
    const b = await svc.branches(dir!);
    expect(b.ok).toBe(true);
    expect(b.branches.sort()).toEqual(['master', 'side']);
    expect(b.branches.some((x) => x.startsWith('('))).toBe(false);
    const s = await svc.status(dir!);
    expect(s.branch).toBeNull();
  });

  it('branches + switchBranch roundtrip, switch refuses to clobber local changes', async () => {
    const svc = await setup();
    expect((await svc.branches(dir!)).branches).toEqual(['master']);
    git(['branch', 'feature']);
    expect((await svc.branches(dir!)).branches.sort()).toEqual(['feature', 'master']);
    expect((await svc.switchBranch(dir!, 'feature')).ok).toBe(true);
    expect((await svc.status(dir!)).branch).toBe('feature');
    // diverge: commit a different a.py on feature
    await fs.writeFile(path.join(dir!, 'a.py'), 'feature-edit\n');
    git(['commit', '-am', 'on feature']);
    // dirty working-tree change that the switch back would clobber
    await fs.writeFile(path.join(dir!, 'a.py'), 'local dirty\n');
    const r = await svc.switchBranch(dir!, 'master');
    expect(r.ok).toBe(false); // git refuses; no force/reset fallback
    expect((await svc.status(dir!)).branch).toBe('feature');
    expect(await fs.readFile(path.join(dir!, 'a.py'), 'utf8')).toBe('local dirty\n'); // unsaved content untouched
    // clean tree switches fine
    git(['checkout', '--', 'a.py']);
    expect((await svc.switchBranch(dir!, 'master')).ok).toBe(true);
    expect((await svc.status(dir!)).branch).toBe('master');
  });

  it('pull --ff-only from a local remote updates the branch', async () => {
    const svc = await setup();
    const remote = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-remote-'));
    execFileSync('git', ['clone', '--bare', dir!, remote], { stdio: 'pipe' });
    git(['remote', 'add', 'origin', remote]);
    git(['fetch', 'origin']);
    git(['branch', '--set-upstream-to=origin/master']);
    // advance the remote via a second clone
    const other = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-other-'));
    execFileSync('git', ['clone', remote, other], { stdio: 'pipe' });
    execFileSync('git', ['-C', other, 'config', 'user.email', 't@t'], { stdio: 'pipe' });
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir!, stdio: 'pipe' });
    execFileSync('git', ['-C', other, 'config', 'user.name', 't'], { stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir!, stdio: 'pipe' });
    await fs.writeFile(path.join(other, 'b.py'), 'b\n');
    execFileSync('git', ['-C', other, 'add', 'b.py'], { stdio: 'pipe' });
    execFileSync('git', ['-C', other, 'commit', '-m', 'second'], { stdio: 'pipe' });
    execFileSync('git', ['-C', other, 'push'], { stdio: 'pipe' });
    expect((await svc.pull(dir!)).ok).toBe(true);
    const s = await svc.status(dir!);
    expect(s.behind).toBe(0);
    await fs.rm(remote, { recursive: true, force: true });
    await fs.rm(other, { recursive: true, force: true });
  });
});

describe('GitService conflicts/history/push increment', () => {
  it('surfaces a real merge conflict as conflicted entries', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'pipe' });
    await fs.writeFile(path.join(dir, 'c.py'), 'base\n');
    await svc.stage(dir, ['c.py']);
    await svc.commit(dir, 'base');
    git(['checkout', '-b', 'side']);
    await fs.writeFile(path.join(dir, 'c.py'), 'side\n');
    git(['commit', '-am', 'side']);
    await svc.switchBranch(dir, 'master');
    await fs.writeFile(path.join(dir, 'c.py'), 'master\n');
    git(['commit', '-am', 'master']);
    try { git(['merge', 'side']); } catch { /* conflict exit code 1 is expected */ }
    const s = await svc.status(dir);
    const c = s.entries.find(e => e.path === 'c.py');
    expect(c).toMatchObject({ code: 'UU', conflicted: true });
    expect(await fs.readFile(path.join(dir, 'c.py'), 'utf8')).toContain('<<<<<<<');
    // staging after resolving marks it resolved
    await fs.writeFile(path.join(dir, 'c.py'), 'resolved\n');
    await svc.stage(dir, ['c.py']);
    const s2 = await svc.status(dir);
    expect(s2.entries.find(e => e.path === 'c.py')?.conflicted).toBe(false);
  });

  it('log returns newest-first commits with hash/subject/author/date', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 'Tester'], { cwd: dir, stdio: 'pipe' });
    for (const [f, msg] of [['a.py', 'first commit'], ['b.py', 'second commit']]) {
      await fs.writeFile(path.join(dir, f as string), 'x\n');
      await svc.stage(dir, [f as string]);
      await svc.commit(dir, msg as string);
    }
    const l = await svc.log(dir, 10);
    expect(l.ok).toBe(true);
    expect(l.commits.map(c => c.subject)).toEqual(['second commit', 'first commit']);
    expect(l.commits[0].author).toBe('Tester');
    expect(l.commits[0].hash).toMatch(/^[0-9a-f]{7,}$/);
    expect(l.commits[0].date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it('push publishes to a bare remote; second push without new commits is fine', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'pipe' });
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    await svc.stage(dir, ['a.py']);
    await svc.commit(dir, 'first');
    const remote = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-remote-'));
    execFileSync('git', ['clone', '--bare', dir, remote], { stdio: 'pipe' });
    git(['remote', 'add', 'origin', remote]);
    git(['push', '-u', 'origin', 'master']); // first publish sets upstream, like a user would
    expect((await svc.push(dir)).ok).toBe(true);
    await fs.writeFile(path.join(dir, 'b.py'), 'b\n');
    await svc.stage(dir, ['b.py']);
    await svc.commit(dir, 'second');
    expect((await svc.push(dir)).ok).toBe(true);
    const remoteLog = execFileSync('git', ['--git-dir', remote, 'log', '--oneline', 'master'], { stdio: 'pipe' }).toString();
    expect(remoteLog).toContain('second');
    await fs.rm(remote, { recursive: true, force: true });
  });
});

describe('GitService publish/branch-create increment', () => {
  it('createBranch creates and switches; invalid names rejected without git', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    await svc.stage(dir, ['a.py']);
    await svc.commit(dir, 'first');
    expect((await svc.createBranch(dir, 'feature-2')).ok).toBe(true);
    expect((await svc.status(dir)).branch).toBe('feature-2');
    expect((await svc.branches(dir)).branches.sort()).toEqual(['feature-2', 'master']);
    expect((await svc.createBranch(dir, 'bad name')).ok).toBe(false);
    expect((await svc.createBranch(dir, '-x')).ok).toBe(false);
    expect((await svc.createBranch(dir, 'feature-2')).ok).toBe(false); // exists
  });

  it('publish -u sets upstream; status then reports hasUpstream', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    const svc = new GitService();
    await svc.init(dir);
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'pipe' });
    await fs.writeFile(path.join(dir, 'a.py'), 'a\n');
    await svc.stage(dir, ['a.py']);
    await svc.commit(dir, 'first');
    expect((await svc.status(dir)).hasUpstream).toBe(false);
    expect((await svc.remotes(dir)).remotes).toEqual([]);
    const remote = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-remote-'));
    execFileSync('git', ['clone', '--bare', dir, remote], { stdio: 'pipe' });
    git(['remote', 'add', 'origin', remote]);
    expect((await svc.remotes(dir)).remotes).toEqual(['origin']);
    expect((await svc.publish(dir, 'origin', 'master')).ok).toBe(true);
    const s = await svc.status(dir);
    expect(s.hasUpstream).toBe(true);
    await fs.rm(remote, { recursive: true, force: true });
  });
});

describe('GitService merge resolution leaves a clean tree', () => {
  const setupConflict = async (kind: 'modify-delete' | 'add-add') => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-git-'));
    execFileSync('git', ['init'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'pipe' });
    if (kind === 'modify-delete') {
      await fs.writeFile(path.join(dir, 'f.ts'), 'base\n');
      execFileSync('git', ['add', '.'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['commit', '-m', 'base'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['switch', '-c', 'side'], { cwd: dir, stdio: 'pipe' });
      await fs.rm(path.join(dir, 'f.ts'));
      execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['commit', '-m', 'delete f'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['switch', 'master'], { cwd: dir, stdio: 'pipe' });
      await fs.writeFile(path.join(dir, 'f.ts'), 'base\nmodified\n');
    } else {
      await fs.writeFile(path.join(dir, 'base.ts'), 'base\n');
      execFileSync('git', ['add', '.'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['commit', '-m', 'base'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['switch', '-c', 'side'], { cwd: dir, stdio: 'pipe' });
      await fs.writeFile(path.join(dir, 'f.ts'), 'side version\n');
      execFileSync('git', ['add', '.'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['commit', '-m', 'side adds f'], { cwd: dir, stdio: 'pipe' });
      execFileSync('git', ['switch', 'master'], { cwd: dir, stdio: 'pipe' });
      await fs.writeFile(path.join(dir, 'f.ts'), 'master version\n');
    }
    execFileSync('git', ['add', '.'], { cwd: dir, stdio: 'pipe' });
    execFileSync('git', ['commit', '-m', 'main change'], { cwd: dir, stdio: 'pipe' });
    try { execFileSync('git', ['merge', 'side'], { cwd: dir, stdio: 'pipe' }); } catch { /* conflict expected */ }
    return new GitService();
  };

  it('modify/delete resolved by keeping ours: merge commit leaves zero entries', async () => {
    const svc = await setupConflict('modify-delete');
    const before = await svc.status(dir!);
    expect(before.entries.some((e) => e.conflicted)).toBe(true);
    await svc.stage(dir!, ['f.ts']); // keep our modified version
    expect((await svc.commit(dir!, 'merge side')).ok).toBe(true);
    const after = await svc.status(dir!);
    expect(after.entries).toEqual([]);
    expect(after.branch).toBe('master');
  });

  it('modify/delete resolved by accepting the deletion: merge commit leaves zero entries', async () => {
    const svc = await setupConflict('modify-delete');
    await fs.rm(path.join(dir!, 'f.ts'), { force: true });
    await svc.stage(dir!, ['f.ts']); // stage the deletion
    expect((await svc.commit(dir!, 'merge side, drop f')).ok).toBe(true);
    const after = await svc.status(dir!);
    expect(after.entries).toEqual([]);
  });

  it('add/add resolved with merged content: merge commit leaves zero entries', async () => {
    const svc = await setupConflict('add-add');
    const before = await svc.status(dir!);
    expect(before.entries.find((e) => e.path === 'f.ts')?.conflicted).toBe(true);
    await fs.writeFile(path.join(dir!, 'f.ts'), 'master version\nside version\n');
    await svc.stage(dir!, ['f.ts']);
    expect((await svc.commit(dir!, 'merge side')).ok).toBe(true);
    const after = await svc.status(dir!);
    expect(after.entries).toEqual([]);
  });
});
it('refuses a clipped large diff instead of presenting a partial patch as complete',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-large-diff-'));git(['init']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'large.txt'),'baseline\n');git(['add','.']);git(['commit','-m','baseline']);await fs.writeFile(path.join(dir,'large.txt'),Array.from({length:10000},(_,i)=>String(i).padStart(5,'0')+'x'.repeat(100)).join('\n'));
 const result=await new GitService().diff(dir,'large.txt',false);expect(result.ok).toBe(false);expect(result.error).toMatch(/too large|limit/i);expect(result.diff).toBeUndefined();
});
it('does not report a clean worktree when status fails on an unreadable index',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-status-failure-'));git(['init']);await fs.writeFile(path.join(dir,'.git','index'),'invalid fixture index');
 await expect(new GitService().status(dir)).rejects.toThrow(/index|status/i);
});
it('keeps built-in diffs plain when repository color.ui is always',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-color-'));git(['init']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'a.txt'),'before\n');git(['add','.']);git(['commit','-m','base']);git(['config','color.ui','always']);await fs.writeFile(path.join(dir,'a.txt'),'after\n');
 const result=await new GitService().diff(dir,'a.txt',false);expect(result.ok).toBe(true);expect(result.diff).toContain('+after');expect(result.diff).not.toContain('\x1b');
});
it('keeps actual branch identity when configured upstream has no tracking ref',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-gone-'));git(['init','-b','main']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'a.txt'),'a\n');git(['add','.']);git(['commit','-m','fixture']);git(['config','remote.origin.url',path.join(dir,'missing-local-origin')]);git(['config','remote.origin.fetch','+refs/heads/*:refs/remotes/origin/*']);git(['config','branch.main.remote','origin']);git(['config','branch.main.merge','refs/heads/main']);
 expect(git(['status','--porcelain=v1','-z','--branch'])).toContain('[gone]');expect(await new GitService().status(dir)).toMatchObject({branch:'main',hasUpstream:true,ahead:0,behind:0});
});
it('reviews both sides of a staged literal rename without showing a false whole-file addition',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-renamediff-'));git(['init']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'old[1].txt'),'baseline\n'.repeat(10));git(['add','.']);git(['commit','-m','fixture']);git(['mv','old[1].txt','new[1].txt']);
 const result=await new GitService().diff(dir,'new[1].txt',true,'old[1].txt');expect(result.ok).toBe(true);expect(result.diff).toContain('rename from old[1].txt');expect(result.diff).toContain('rename to new[1].txt');expect(result.diff).not.toContain('new file mode');
 await fs.appendFile(path.join(dir,'new[1].txt'),'working edit\n');const unstaged=await new GitService().diff(dir,'new[1].txt',false,'old[1].txt');expect(unstaged.diff).toContain('+working edit');expect(unstaged.diff).not.toContain('rename from');
});
it('unstages one literal unborn-index path without touching bytes or other staged files',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-unborn-'));git(['init']);const name='-new[1].txt';await fs.writeFile(path.join(dir,name),'initial\r\n');await fs.writeFile(path.join(dir,'other.txt'),'other\n');git(['add','.']);const result=await new GitService().unstage(dir,[name]);expect(result.ok).toBe(true);expect(await fs.readFile(path.join(dir,name),'utf8')).toBe('initial\r\n');expect(await fs.readFile(path.join(dir,'other.txt'),'utf8')).toBe('other\n');expect(git(['diff','--cached','--name-only'])).toBe('other.txt\n');expect((await new GitService().status(dir)).entries).toEqual(expect.arrayContaining([expect.objectContaining({path:name,untracked:true}),expect.objectContaining({path:'other.txt',staged:true})]));
});
it('refuses unborn unstage when staged-only bytes would be lost, without force or file changes',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-unborn-dirty-'));git(['init']);await fs.writeFile(path.join(dir,'a.txt'),'staged bytes\n');git(['add','.']);await fs.writeFile(path.join(dir,'a.txt'),'working bytes\n');const result=await new GitService().unstage(dir,['a.txt']);expect(result.ok).toBe(false);expect(git(['show',':a.txt'])).toBe('staged bytes\n');expect(await fs.readFile(path.join(dir,'a.txt'),'utf8')).toBe('working bytes\n');
});
it('does not mistake a corrupt existing HEAD ref for an unborn index',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-bad-head-'));git(['init','-b','main']);await fs.writeFile(path.join(dir,'a.txt'),'keep\n');git(['add','.']);const index=await fs.readFile(path.join(dir,'.git','index'));await fs.writeFile(path.join(dir,'.git','refs','heads','main'),'broken-ref\n');expect((await new GitService().unstage(dir,['a.txt'])).ok).toBe(false);expect(await fs.readFile(path.join(dir,'.git','index'))).toEqual(index);expect(await fs.readFile(path.join(dir,'a.txt'),'utf8')).toBe('keep\n');
});
it('lists exact local branch names even when a tag shares the name',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-ambiguous-'));git(['init','-b','main']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'a.txt'),'base\n');git(['add','.']);git(['commit','-m','fixture']);git(['branch','topic']);git(['tag','topic']);const svc=new GitService();expect((await svc.branches(dir)).branches).toEqual(['main','topic']);expect((await svc.switchBranch(dir,'topic')).ok).toBe(true);expect(git(['branch','--show-current']).trim()).toBe('topic');git(['switch','--detach']);expect((await svc.branches(dir)).branches).toEqual(['main','topic']);
});
it('lists nested untracked files individually so staging one does not stage its siblings',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-nested-'));git(['init']);await fs.mkdir(path.join(dir,'src','new'),{recursive:true});await fs.writeFile(path.join(dir,'src/new/first.txt'),'first\r\n');await fs.writeFile(path.join(dir,'src/new/second.txt'),'second\n');await fs.writeFile(path.join(dir,'.git','info','exclude'),'ignored.txt\n');await fs.writeFile(path.join(dir,'src/new/ignored.txt'),'ignored\n');const svc=new GitService();const status=await svc.status(dir);expect(status.entries.map(e=>e.path)).toEqual(['src/new/first.txt','src/new/second.txt']);expect((await svc.stage(dir,['src/new/first.txt'])).ok).toBe(true);expect(git(['diff','--cached','--name-only'])).toBe('src/new/first.txt\n');expect((await svc.status(dir)).entries).toEqual(expect.arrayContaining([expect.objectContaining({path:'src/new/second.txt',untracked:true})]));expect(await fs.readFile(path.join(dir,'src/new/first.txt'),'utf8')).toBe('first\r\n');
});
it('uses the internal patch viewer without running the configured external diff tool',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-internal-diff-'));git(['init']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'a.txt'),'before\n');git(['add','.']);git(['commit','-m','base']);await fs.writeFile(path.join(dir,'a.txt'),'after\n');const script=path.join(dir,'external-diff.cjs');const marker=path.join(dir,'external-ran');await fs.writeFile(script,`require('fs').writeFileSync(${JSON.stringify(marker)},'ran');process.stdout.write('NOT_A_PATCH');`);const configured=`"${process.execPath}" "${script}"`;git(['config','diff.external',configured]);const svc=new GitService();const unstaged=await svc.diff(dir,'a.txt',false);expect(unstaged.ok).toBe(true);expect(unstaged.diff).toContain('-before');expect(unstaged.diff).toContain('+after');git(['add','a.txt']);const staged=await svc.diff(dir,'a.txt',true);expect(staged.diff).toContain('+after');await expect(fs.access(marker)).rejects.toThrow();expect(git(['config','diff.external']).trim()).toBe(configured);
});
it('treats verified unborn history as empty while keeping corrupt HEAD failures visible',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-empty-history-'));git(['init','-b','main']);const svc=new GitService();expect(await svc.log(dir)).toEqual({ok:true,commits:[]});await fs.writeFile(path.join(dir,'.git','refs','heads','main'),'broken-ref\n');expect((await svc.log(dir)).ok).toBe(false);
});
it('reports nested workspace boundary without exposing parent paths, while canonical aliases remain usable',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-root-boundary-'));git(['init']);await fs.mkdir(path.join(dir,'src'));await fs.writeFile(path.join(dir,'outside.txt'),'outside\n');await fs.writeFile(path.join(dir,'src','inside.txt'),'inside\n');const svc=new GitService();expect(await svc.status(path.join(dir,'src'))).toMatchObject({isRepo:true,repositoryRoot:await fs.realpath(dir),entries:[]});await fs.symlink(dir,path.join(dir,'alias'),'dir');expect((await svc.status(path.join(dir,'alias'))).repositoryRoot).toBeUndefined();
});
it('recognizes linked worktree roots and nested folders without changing their refs',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-git-worktree-boundary-'));git(['init']);git(['config','user.email','fixture@example.invalid']);git(['config','user.name','Fixture']);await fs.writeFile(path.join(dir,'base.txt'),'base\n');git(['add','.']);git(['commit','-m','base']);const linked=path.join(dir,'linked root ');git(['worktree','add','-b','linked-fixture',linked]);await fs.mkdir(path.join(linked,'src'));const svc=new GitService();expect((await svc.status(linked)).repositoryRoot).toBeUndefined();expect((await svc.status(path.join(linked,'src'))).repositoryRoot).toBe(await fs.realpath(linked));expect(execFileSync('git',['branch','--show-current'],{cwd:linked}).toString().trim()).toBe('linked-fixture');
});
