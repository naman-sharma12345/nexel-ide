// @vitest-environment node
import {expect,it,vi} from 'vitest';
import {StoreService} from '../StoreService';
it('does not confirm writes before initialization or after disk failure',()=>{
 const service=new StoreService();
 expect(service.setSync('nexel-ui-store',{})).toBe(false);
 expect(service.deleteSync('nexel-ui-store')).toBe(false);
 (service as any).store={set:()=>{throw Error('disk full')},delete:()=>{throw Error('disk full')}};
 expect(service.setSync('nexel-ui-store',{})).toBe(false);expect(service.deleteSync('nexel-ui-store')).toBe(false);
});
it('confirms only completed backing-store mutations',()=>{
 const service=new StoreService();const set=vi.fn(),del=vi.fn();(service as any).store={set,delete:del};
 expect(service.setSync('nexel-ui-store',{fontSize:14})).toBe(true);expect(set).toHaveBeenCalledWith('nexel-ui-store',{fontSize:14});
 expect(service.deleteSync('nexel-ui-store')).toBe(true);expect(del).toHaveBeenCalledWith('nexel-ui-store');
});
