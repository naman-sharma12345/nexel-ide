// @vitest-environment node
import { describe, it, expect, vi, beforeEach } from 'vitest';
import * as fs from 'fs/promises';

// Mock fs/promises partially
vi.mock('fs/promises', async (importOriginal) => {
  const original = await importOriginal<typeof import('fs/promises')>();
  return {
    ...original,
    lstat: vi.fn(),
    readdir: vi.fn(),
  };
});

import { buildFileTree } from '../FileTreeWorker';

describe('FileTreeWorker logic', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('correctly builds a tree, excluding .git, node_modules, and .vite', async () => {
    const mockStat = fs.lstat as any;
    const mockReaddir = fs.readdir as any;

    mockStat.mockImplementation(async (targetPath: string) => {
      const basename = targetPath.split(/[\\/]/).pop();
      if (basename === 'my-project' || basename === 'src' || basename === '.git' || basename === 'node_modules') {
        return { isSymbolicLink: () => false, isDirectory: () => true };
      }
      return { isSymbolicLink: () => false, isDirectory: () => false };
    });

    mockReaddir.mockImplementation(async (targetPath: string) => {
      const basename = targetPath.split(/[\\/]/).pop();
      if (basename === 'my-project') {
        return ['src', '.git', 'node_modules', 'file.txt'];
      }
      if (basename === 'src') {
        return ['main.cpp'];
      }
      return [];
    });

    const result = await buildFileTree('C:/my-project');

    expect(result.name).toBe('my-project');
    expect(result.type).toBe('folder');
    expect(result.children?.length).toBe(4);

    const gitNode = result.children?.find(c => c.name === '.git');
    expect(gitNode?.children?.length).toBe(0);

    const nodeModulesNode = result.children?.find(c => c.name === 'node_modules');
    expect(nodeModulesNode?.children?.length).toBe(0);

    const srcNode = result.children?.find(c => c.name === 'src');
    expect(srcNode?.children?.length).toBe(1);
    expect(srcNode?.children?.[0].name).toBe('main.cpp');
  });

  it('sorts folders before files, and alphabetically within the same type', async () => {
    const mockStat = fs.lstat as any;
    const mockReaddir = fs.readdir as any;

    mockStat.mockImplementation(async (targetPath: string) => {
      const basename = targetPath.split(/[\\/]/).pop();
      if (basename === 'root' || basename === 'beta-folder' || basename === 'alpha-folder') {
        return { isSymbolicLink: () => false, isDirectory: () => true };
      }
      return { isSymbolicLink: () => false, isDirectory: () => false };
    });

    mockReaddir.mockImplementation(async (targetPath: string) => {
      const basename = targetPath.split(/[\\/]/).pop();
      if (basename === 'root') {
        return ['zeta-file.txt', 'beta-folder', 'alpha-file.txt', 'alpha-folder'];
      }
      return [];
    });

    const result = await buildFileTree('C:/root');
    const childNames = result.children?.map(c => c.name);

    expect(childNames).toEqual([
      'alpha-folder',
      'beta-folder',
      'alpha-file.txt',
      'zeta-file.txt'
    ]);
  });
  it('keeps outstanding filesystem calls bounded on a wide tree', async () => {
    let active=0,peak=0;
    (fs.lstat as any).mockImplementation(async (target:string)=>{active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,1));active--;return {isSymbolicLink:()=>false,isDirectory:()=>target==='root'};});
    (fs.readdir as any).mockResolvedValue(Array.from({length:500},(_,i)=>'file'+i));
    const tree=await buildFileTree('root');
    expect(tree.children).toHaveLength(500);expect(peak).toBeLessThanOrEqual(32);expect(peak).toBeGreaterThan(1);
  });

});
