// @vitest-environment node
import {it,expect,vi} from 'vitest';
import {startPipeShell} from '../startPipeShell';
it('rejects a real missing executable without an unhandled process error',async()=>{
 await expect(startPipeShell('/nonexistent/nexel-shell-fixture',[],{},vi.fn())).rejects.toMatchObject({code:'ENOENT'});
});
it('returns a real started pipe shell and reports later stream errors',async()=>{
 const error=vi.fn();const child=await startPipeShell(process.execPath,['-e','process.stdout.write("PIPE_READY")'],{},error);const output:string[]=[];child.stdout.on('data',data=>output.push(data.toString()));await new Promise<void>(resolve=>child.on('close',()=>resolve()));expect(output.join('')).toBe('PIPE_READY');child.emit('error',Error('late fixture'));expect(error).toHaveBeenCalledOnce();child.stdin.emit('error',Error('pipe fixture'));expect(error).toHaveBeenCalledTimes(2);
});
it('decodes multibyte stdout and stderr across real timed one-byte writes',async()=>{
 const text='नमस्ते 🌐 �';
 const script=`const bytes=Buffer.from(${JSON.stringify(text)});let i=0;const t=setInterval(()=>{if(i===bytes.length){clearInterval(t);return;}process.stdout.write(bytes.subarray(i,i+1));process.stderr.write(bytes.subarray(i,i+1));i++;},3);`;
 const child=await startPipeShell(process.execPath,['-e',script],{},vi.fn());let out='',err='';child.stdout.on('data',d=>{out+=d.toString();});child.stderr.on('data',d=>{err+=d.toString();});await new Promise<void>(r=>child.on('close',()=>r()));expect(out).toBe(text);expect(err).toBe(text);
});
