import { describe, it, expect, vi } from 'vitest';
import { spawnPtyWithHomeRetry, type PtyProcLike } from '../terminalPtySpawn';

const proc = (): PtyProcLike => ({ onData: () => {}, onExit: () => {}, kill: () => {} });
const opts = { name: 'xterm-color', cols: 80, rows: 10, env: {} };

describe('spawnPtyWithHomeRetry', () => {
  it('retries once in HOME when the workspace cwd throws', () => {
    const p = proc();
    const spawn = vi.fn().mockImplementationOnce(() => { throw new Error('chdir failed'); }).mockReturnValueOnce(p);
    const r = spawnPtyWithHomeRetry({ spawn }, 'bash', '/work/gone', '/home/user', opts);
    expect(r?.cwdUsed).toBe('/home/user');
    expect(r?.proc).toBe(p);
    expect(spawn).toHaveBeenCalledTimes(2);
    expect(spawn.mock.calls[1][2]).toMatchObject({ cwd: '/home/user' });
  });
  it('returns null when both attempts fail (caller degrades to pipe shell)', () => {
    const spawn = vi.fn().mockImplementation(() => { throw new Error('nope'); });
    expect(spawnPtyWithHomeRetry({ spawn }, 'bash', '/work/gone', '/home/user', opts)).toBeNull();
    expect(spawn).toHaveBeenCalledTimes(2);
  });
  it('does not retry when cwd already is home', () => {
    const spawn = vi.fn().mockImplementation(() => { throw new Error('nope'); });
    expect(spawnPtyWithHomeRetry({ spawn }, 'bash', '/home/user', '/home/user', opts)).toBeNull();
    expect(spawn).toHaveBeenCalledTimes(1);
  });
  it('uses the requested cwd on first success', () => {
    const p = proc();
    const spawn = vi.fn().mockReturnValue(p);
    const r = spawnPtyWithHomeRetry({ spawn }, 'bash', '/work/ok', '/home/user', opts);
    expect(r?.cwdUsed).toBe('/work/ok');
    expect(spawn).toHaveBeenCalledTimes(1);
  });
});
