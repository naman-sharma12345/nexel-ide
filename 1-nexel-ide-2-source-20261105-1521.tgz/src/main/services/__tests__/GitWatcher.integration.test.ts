import { describe, it, expect, afterEach, vi } from 'vitest';
import fs from 'fs/promises';
import syncFs from 'fs';
import os from 'os';
import path from 'path';
import { execFileSync } from 'child_process';
import { GitWatcher, resolveGitDir, resolveCommonDir } from '../GitWatcher';

let dirs: string[] = [];
let watcher: GitWatcher | null = null;
afterEach(async () => {
  watcher?.stop(); watcher = null;
  for (const d of dirs) await fs.rm(d, { recursive: true, force: true });
  dirs = [];
});

const mkrepo = async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-gitwatch-'));
  dirs.push(dir);
  execFileSync('git', ['init'], { cwd: dir, stdio: 'pipe' });
  execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir, stdio: 'pipe' });
  execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'pipe' });
  await fs.writeFile(path.join(dir, 'a.ts'), 'a\n');
  execFileSync('git', ['add', '.'], { cwd: dir, stdio: 'pipe' });
  execFileSync('git', ['commit', '-m', 'base'], { cwd: dir, stdio: 'pipe' });
  return dir;
};

const waitFor = async (fn: () => boolean, ms = 3000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { if (fn()) return true; await new Promise((r) => setTimeout(r, 50)); }
  return false;
};

describe('resolveGitDir', () => {
  it('returns .git dir for a normal repo and null outside one', async () => {
    const dir = await mkrepo();
    expect(resolveGitDir(dir)).toBe(path.join(dir, '.git'));
    const plain = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-plain-'));
    dirs.push(plain);
    expect(resolveGitDir(plain)).toBeNull();
  });

  it('preserves trailing spaces in separate metadata and common-directory pointers', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-gitwatch-space-'));
    dirs.push(dir);
    const root = path.join(dir, 'workspace'), metadata = path.join(dir, 'metadata ');
    await fs.mkdir(root);
    execFileSync('git', ['init', '--separate-git-dir', metadata, root], { stdio: 'pipe' });
    expect(resolveGitDir(root)).toBe(metadata);
    let fires = 0;
    watcher = new GitWatcher();
    expect(watcher.start(root, () => fires++).watching).toBe(true);
    execFileSync('git', ['-C', root, 'symbolic-ref', 'HEAD', 'refs/heads/external-update'], { stdio: 'pipe' });
    expect(await waitFor(() => fires > 0)).toBe(true);
    const perWorktree = path.join(dir, 'per-worktree');
    await fs.mkdir(perWorktree);
    await fs.writeFile(path.join(perWorktree, 'commondir'), '../metadata \n');
    expect(resolveCommonDir(perWorktree)).toBe(metadata);
  });

  it('preserves embedded newlines in Git-generated separate-directory pointers', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-gitwatch-newline-'));
    dirs.push(dir);
    const root = path.join(dir, 'workspace'), metadata = path.join(dir, 'meta\ndata');
    await fs.mkdir(root);
    execFileSync('git', ['init', '--separate-git-dir', metadata, root], { stdio: 'pipe' });
    expect(resolveGitDir(root)).toBe(metadata);
    let fires = 0;
    watcher = new GitWatcher();
    expect(watcher.start(root, () => fires++).watching).toBe(true);
    execFileSync('git', ['-C', root, 'symbolic-ref', 'HEAD', 'refs/heads/external-update'], { stdio: 'pipe' });
    expect(await waitFor(() => fires > 0)).toBe(true);
  });

  it('follows a linked worktree .git file to its per-worktree gitdir', async () => {
    const dir = await mkrepo();
    const wt = path.join(dir, 'wt-link');
    execFileSync('git', ['worktree', 'add', wt, '-b', 'wt-branch'], { cwd: dir, stdio: 'pipe' });
    const gitdir = resolveGitDir(wt);
    expect(gitdir).not.toBeNull();
    expect(gitdir).not.toBe(path.join(dir, '.git'));
    expect(fs.stat(gitdir!)).resolves.toBeTruthy();
  });
});

describe('GitWatcher', () => {
  it('reports failed registration when every metadata watch refuses, then can retry', async () => {
    const dir = await mkrepo();
    watcher = new GitWatcher();
    const refused = vi.spyOn(syncFs, 'watch').mockImplementation(() => { throw new Error('fixture watch limit'); });
    try {
      expect(watcher.start(dir, () => {}).watching).toBe(false);
      expect(watcher.currentRoot).toBeNull();
    } finally { refused.mockRestore(); }
    let fires = 0;
    expect(watcher.start(dir, () => fires++).watching).toBe(true);
    execFileSync('git', ['-C', dir, 'switch', '-c', 'retry-watch'], { stdio: 'pipe' });
    expect(await waitFor(() => fires > 0)).toBe(true);
  });

  it('retains a successful metadata watch when optional directory registrations fail', async () => {
    const dir = await mkrepo();
    watcher = new GitWatcher();
    const original = syncFs.watch;
    const partial = vi.spyOn(syncFs, 'watch').mockImplementation(((...args: Parameters<typeof syncFs.watch>) => {
      if (String(args[0]) !== path.join(dir, '.git')) throw new Error('fixture optional directory refusal');
      return original(...args);
    }) as typeof syncFs.watch);
    let fires = 0;
    try { expect(watcher.start(dir, () => fires++).watching).toBe(true); }
    finally { partial.mockRestore(); }
    execFileSync('git', ['-C', dir, 'switch', '-c', 'partial-watch'], { stdio: 'pipe' });
    expect(await waitFor(() => fires > 0)).toBe(true);
  });

  it('fires on terminal commit, checkout and stage (real git, debounced)', async () => {
    const dir = await mkrepo();
    let fires = 0;
    watcher = new GitWatcher();
    expect(watcher.start(dir, (r) => { expect(r).toBe(dir); fires++; }).watching).toBe(true);
    await fs.writeFile(path.join(dir, 'b.ts'), 'b\n');
    execFileSync('git', ['add', 'b.ts'], { cwd: dir, stdio: 'pipe' }); // stage: index write
    expect(await waitFor(() => fires >= 1)).toBe(true);
    const afterStage = fires;
    execFileSync('git', ['commit', '-m', 'b'], { cwd: dir, stdio: 'pipe' }); // commit
    expect(await waitFor(() => fires > afterStage)).toBe(true);
    const afterCommit = fires;
    execFileSync('git', ['switch', '-c', 'other'], { cwd: dir, stdio: 'pipe' }); // checkout: HEAD write
    expect(await waitFor(() => fires > afterCommit)).toBe(true);
  });

  it('atomic index replacement (index.lock rename) still fires via directory watch', async () => {
    const dir = await mkrepo();
    let fires = 0;
    watcher = new GitWatcher();
    watcher.start(dir, () => { fires++; });
    // emulate git's atomic write: write index.lock, rename over index
    const data = await fs.readFile(path.join(dir, '.git', 'index'));
    await fs.writeFile(path.join(dir, '.git', 'index.lock'), data);
    await fs.rename(path.join(dir, '.git', 'index.lock'), path.join(dir, '.git', 'index'));
    expect(await waitFor(() => fires >= 1)).toBe(true);
  });

  it('fires for a linked worktree repo (per-worktree gitdir)', async () => {
    const dir = await mkrepo();
    const wt = path.join(dir, 'wt-link');
    execFileSync('git', ['worktree', 'add', wt, '-b', 'wt-branch'], { cwd: dir, stdio: 'pipe' });
    let fires = 0;
    watcher = new GitWatcher();
    expect(watcher.start(wt, (r) => { expect(r).toBe(wt); fires++; }).watching).toBe(true);
    await fs.writeFile(path.join(wt, 'c.ts'), 'c\n');
    execFileSync('git', ['add', 'c.ts'], { cwd: wt, stdio: 'pipe' });
    execFileSync('git', ['commit', '-m', 'c'], { cwd: wt, stdio: 'pipe' });
    expect(await waitFor(() => fires >= 1)).toBe(true);
  });

  it('start() replaces the previous watch; stop() silences it', async () => {
    const a = await mkrepo();
    const b = await mkrepo();
    let firesA = 0, firesB = 0;
    watcher = new GitWatcher();
    watcher.start(a, () => { firesA++; });
    watcher.start(b, () => { firesB++; });
    execFileSync('git', ['switch', '-c', 'x'], { cwd: a, stdio: 'pipe' });
    await new Promise((r) => setTimeout(r, 600));
    expect(firesA).toBe(0); // a's watch was disposed
    watcher.stop();
    execFileSync('git', ['switch', '-c', 'y'], { cwd: b, stdio: 'pipe' });
    await new Promise((r) => setTimeout(r, 600));
    expect(firesB).toBe(0); // stopped
  });
});

describe('GitWatcher common gitdir (linked worktrees)', () => {
  it('resolveCommonDir follows the commondir file; plain repo returns gitdir', async () => {
    const dir = await mkrepo();
    const gitdir = resolveGitDir(dir)!;
    expect(resolveCommonDir(gitdir)).toBe(gitdir);
    const wt = path.join(dir, 'wt-link');
    execFileSync('git', ['worktree', 'add', wt, '-b', 'wt-branch'], { cwd: dir, stdio: 'pipe' });
    const wtGitdir = resolveGitDir(wt)!;
    expect(resolveCommonDir(wtGitdir)).toBe(gitdir); // main .git is the common dir
  });

  it('branch created in ANOTHER worktree fires the watch (shared refs in commondir)', async () => {
    const dir = await mkrepo();
    const wt = path.join(dir, 'wt-link');
    execFileSync('git', ['worktree', 'add', wt, '-b', 'wt-branch'], { cwd: dir, stdio: 'pipe' });
    let fires = 0;
    watcher = new GitWatcher();
    watcher.start(wt, () => { fires++; });
    execFileSync('git', ['branch', 'from-main'], { cwd: dir, stdio: 'pipe' }); // writes refs/heads in COMMON dir
    expect(await waitFor(() => fires >= 1)).toBe(true);
  });
});
