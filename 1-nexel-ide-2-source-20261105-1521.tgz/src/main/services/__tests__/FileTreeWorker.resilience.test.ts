// @vitest-environment node
import { describe, it, expect, vi, beforeEach } from 'vitest';
import * as fs from 'fs/promises';
import { parentPort } from 'worker_threads';

// Mock worker_threads partially to avoid breaking Vitest runner
vi.mock('worker_threads', async (importOriginal) => {
  const original = await importOriginal<typeof import('worker_threads')>();
  const mockPort = {
    postMessage: vi.fn(),
  };
  return {
    ...original,
    parentPort: mockPort,
    workerData: {
      dirPath: 'C:/secure-root',
    },
  };
});

// Mock fs/promises partially
vi.mock('fs/promises', async (importOriginal) => {
  const original = await importOriginal<typeof import('fs/promises')>();
  return {
    ...original,
    lstat: vi.fn(),
    readdir: vi.fn(),
  };
});

import { run, serveScan } from '../FileTreeWorker';

describe('FileTreeWorker resilience and performance safety', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('fails gracefully when permission is denied (EACCES) (Test A)', async () => {
    const mockStat = fs.lstat as unknown as ReturnType<typeof vi.fn>;
    const mockPost = parentPort?.postMessage as unknown as ReturnType<typeof vi.fn>;

    // Simulate Permission Denied
    mockStat.mockRejectedValue(new Error('EACCES: permission denied, stat "C:/secure-root"'));

    await run();

    // Verify error is posted to the main thread instead of crashing
    expect(mockPost).toHaveBeenCalled();
    const sentData = mockPost.mock.calls[0][0];
    expect(sentData.error).toContain('EACCES');
  });

  it('returns all sorted entries for a wide directory (Test B)', async () => {
    const mockStat = fs.lstat as unknown as ReturnType<typeof vi.fn>;
    const mockReaddir = fs.readdir as unknown as ReturnType<typeof vi.fn>;
    const mockPost = parentPort?.postMessage as unknown as ReturnType<typeof vi.fn>;

    // Mock stats to identify the root as folder, others as files
    mockStat.mockImplementation(async (targetPath: string) => {
      if (targetPath === 'C:/secure-root') {
        return { isSymbolicLink: () => false, isDirectory: () => true };
      }
      return { isSymbolicLink: () => false, isDirectory: () => false };
    });

    // Mock readdir to return 500 files
    const largeFileList = Array.from({ length: 500 }, (_, i) => `file_${String(i).padStart(3, '0')}.cpp`);
    mockReaddir.mockResolvedValue(largeFileList);

    await run();

    // Verify sorting output structure is correct and contains all files
    expect(mockPost).toHaveBeenCalled();
    const sentData = mockPost.mock.calls[0][0];
    expect(sentData.children).toBeDefined();
    expect(sentData.children.length).toBe(500);
    expect(sentData.children[0].name).toBe('file_000.cpp');
    expect(sentData.children[499].name).toBe('file_499.cpp');
  });

  it('serveScan echoes the request id on success and on error (persistent server mode)', async () => {
    const mockStat = fs.lstat as unknown as ReturnType<typeof vi.fn>;
    const mockReaddir = fs.readdir as unknown as ReturnType<typeof vi.fn>;
    const mockPost = parentPort?.postMessage as unknown as ReturnType<typeof vi.fn>;

    mockStat.mockImplementation(async (targetPath: string) => ({
      isSymbolicLink: () => false,
      isDirectory: () => targetPath === '/root',
    }));
    mockReaddir.mockResolvedValue(['one.cpp']);

    await serveScan({ id: 41, dirPath: '/root' });
    let sent = mockPost.mock.calls[0][0];
    expect(sent.id).toBe(41);
    expect(sent.children[0].name).toBe('one.cpp');

    mockPost.mockClear();
    mockStat.mockRejectedValue(new Error('EIO: boom'));
    await serveScan({ id: 42, dirPath: '/root' });
    sent = mockPost.mock.calls[0][0];
    expect(sent.id).toBe(42);
    expect(sent.error).toContain('EIO');
  });
});
