// @vitest-environment node
import {it,expect,vi,beforeEach} from 'vitest';
import {EventEmitter} from 'node:events';

const spawnMock = vi.fn();
vi.mock('node:child_process', () => ({ spawn: (...a: unknown[]) => spawnMock(...a) }));
import {startPipeShellWithHomeRetry} from '../startPipeShell';

type Outcome = 'spawn' | 'error';
function makeChild(outcome: Outcome) {
  const child = new EventEmitter() as EventEmitter & { stdin: EventEmitter; stdout: {setEncoding: ReturnType<typeof vi.fn>}; stderr: {setEncoding: ReturnType<typeof vi.fn>} };
  child.stdin = new EventEmitter();
  child.stdout = {setEncoding: vi.fn()};child.stderr = {setEncoding: vi.fn()};
  queueMicrotask(() => child.emit(outcome, outcome === 'error' ? Object.assign(new Error('spawn fail'), { code: 'ENOENT' }) : undefined));
  return child;
}

beforeEach(() => { spawnMock.mockReset(); });

it('retries once in HOME when the workspace-cwd spawn rejects', async () => {
  spawnMock.mockImplementationOnce(() => makeChild('error')).mockImplementationOnce(() => makeChild('spawn'));
  const r = await startPipeShellWithHomeRetry('bash', [], { cwd: '/ws' }, '/home/u', vi.fn());
  expect(spawnMock).toHaveBeenCalledTimes(2);
  expect((spawnMock.mock.calls[1] as unknown[])[2]).toMatchObject({ cwd: '/home/u' });
  expect(r?.cwdUsed).toBe('/home/u');
});
it('returns null when both the workspace cwd and HOME fail', async () => {
  spawnMock.mockImplementation(() => makeChild('error'));
  const r = await startPipeShellWithHomeRetry('bash', [], { cwd: '/ws' }, '/home/u', vi.fn());
  expect(r).toBeNull();
  expect(spawnMock).toHaveBeenCalledTimes(2);
});
it('does not retry in HOME when HOME was already the requested cwd', async () => {
  spawnMock.mockImplementation(() => makeChild('error'));
  const r = await startPipeShellWithHomeRetry('bash', [], { cwd: '/home/u' }, '/home/u', vi.fn());
  expect(r).toBeNull();
  expect(spawnMock).toHaveBeenCalledTimes(1);
});
it('does not retry when HOME is unavailable', async () => {
  spawnMock.mockImplementation(() => makeChild('error'));
  const r = await startPipeShellWithHomeRetry('bash', [], { cwd: '/ws' }, undefined, vi.fn());
  expect(r).toBeNull();
  expect(spawnMock).toHaveBeenCalledTimes(1);
});
it('returns the first spawn with the requested cwd when it succeeds', async () => {
  spawnMock.mockImplementation(() => makeChild('spawn'));
  const r = await startPipeShellWithHomeRetry('bash', [], { cwd: '/ws' }, '/home/u', vi.fn());
  expect(r?.cwdUsed).toBe('/ws');
  expect(spawnMock).toHaveBeenCalledTimes(1);
});
