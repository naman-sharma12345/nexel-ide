// @vitest-environment node
import { describe, it, expect, vi, beforeEach } from 'vitest';

// Fake Worker: captures posted scan requests, lets each test drive responses,
// errors and exits. Every construction is recorded on globalThis so reuse vs
// respawn is provable. The mock factory is fully self-contained: importing the
// mocked module runs the factory before this file's top-level bindings exist.
interface FakeWorker {
  posted: { id: number; dirPath: string }[];
  terminated: boolean;
  emit(event: string, ...args: unknown[]): boolean;
  respond(id: number, msg: object): void;
}
const constructed = () => ((globalThis as Record<string, unknown>).__nxTreeWorkers as FakeWorker[]);

vi.mock('worker_threads', async (importOriginal) => {
  const original = await importOriginal<typeof import('worker_threads')>();
  const { EventEmitter } = await import('events');
  (globalThis as Record<string, unknown>).__nxTreeWorkers = [];
  class FakeWorkerImpl extends EventEmitter {
    posted: { id: number; dirPath: string }[] = [];
    terminated = false;
    constructor() { super(); ((globalThis as Record<string, unknown>).__nxTreeWorkers as unknown[]).push(this); }
    unref() {}
    postMessage(req: { id: number; dirPath: string }) { this.posted.push(req); }
    async terminate() { this.terminated = true; return 0; }
    respond(id: number, msg: object) { this.emit('message', { id, ...msg }); }
  }
  return { ...original, Worker: FakeWorkerImpl };
});

import { FileSystemService } from '../FileSystemService';

describe('FileSystemService persistent file-tree worker', () => {
  beforeEach(() => { constructed().length = 0; });

  it('reuses one worker across sequential scans and matches responses by id', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const p2 = svc.readFiles('/b');
    expect(constructed().length).toBe(1);
    const w = constructed()[0];
    expect(w.posted).toEqual([{ id: 1, dirPath: '/a' }, { id: 2, dirPath: '/b' }]);
    // Out-of-order completion resolves the correct callers.
    w.respond(2, { children: [{ name: 'b.cpp', path: '/b/b.cpp', type: 'file' }] });
    w.respond(1, { children: [{ name: 'a.cpp', path: '/a/a.cpp', type: 'file' }] });
    await expect(p1).resolves.toEqual([{ name: 'a.cpp', path: '/a/a.cpp', type: 'file' }]);
    await expect(p2).resolves.toEqual([{ name: 'b.cpp', path: '/b/b.cpp', type: 'file' }]);
    const p3 = svc.readFiles('/c');
    expect(constructed().length).toBe(1);
    w.respond(3, { children: [] });
    await expect(p3).resolves.toEqual([]);
  });

  it('maps worker-reported scan errors to that request only', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/denied');
    const p2 = svc.readFiles('/ok');
    const w = constructed()[0];
    w.respond(1, { error: 'EACCES: permission denied' });
    w.respond(2, { children: [] });
    await expect(p1).rejects.toThrow('EACCES');
    await expect(p2).resolves.toEqual([]);
  });

  it('rejects every pending scan on worker error and respawns lazily on next scan', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const p2 = svc.readFiles('/b');
    constructed()[0].emit('error', new Error('boom'));
    await expect(p1).rejects.toThrow('boom');
    await expect(p2).rejects.toThrow('boom');
    const p3 = svc.readFiles('/c');
    expect(constructed().length).toBe(2);
    constructed()[1].respond(3, { children: [] });
    await expect(p3).resolves.toEqual([]);
  });

  it('rejects pending scans on nonzero exit rather than hanging', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    constructed()[0].emit('exit', 1);
    await expect(p1).rejects.toThrow('exit status 1');
    const p2 = svc.readFiles('/b');
    expect(constructed().length).toBe(2);
    constructed()[1].respond(2, { children: [] });
    await expect(p2).resolves.toEqual([]);
  });

  it('rejects pending scans on a clean exit with results outstanding (no silent hang)', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    constructed()[0].emit('exit', 0);
    await expect(p1).rejects.toThrow('exited without a result');
  });

  it('dispose terminates the worker, rejects pending scans, and a later scan respawns', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    await svc.disposeTreeWorker();
    await expect(p1).rejects.toThrow('disposed');
    expect(constructed()[0].terminated).toBe(true);
    const p2 = svc.readFiles('/b');
    expect(constructed().length).toBe(2);
    constructed()[1].respond(2, { children: [] });
    await expect(p2).resolves.toEqual([]);
  });

  it('ignores responses with unknown or missing ids', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const w = constructed()[0];
    w.emit('message', { children: [] });            // no id
    w.emit('message', { id: 999, children: [] });   // unknown id
    w.respond(1, { children: [] });
    await expect(p1).resolves.toEqual([]);
  });

  it('rejects a malformed response for a known id instead of resolving garbage', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    constructed()[0].respond(1, { children: 'not-an-array' });
    await expect(p1).rejects.toThrow('invalid result');
  });

  it('coalesces same-root churn: one running + one trailing scan, trailing gets a FRESH scan', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const p2 = svc.readFiles('/a');
    const p3 = svc.readFiles('/a');
    const w = constructed()[0];
    // Three concurrent same-root callers -> exactly ONE scan posted.
    expect(w.posted).toEqual([{ id: 1, dirPath: '/a' }]);
    w.respond(1, { children: [{ name: 'old.cpp', path: '/a/old.cpp', type: 'file' }] });
    await expect(p1).resolves.toEqual([{ name: 'old.cpp', path: '/a/old.cpp', type: 'file' }]);
    // Trailing callers start ONE new scan (started after their requests => fresh).
    expect(w.posted[1]).toEqual({ id: 2, dirPath: '/a' });
    expect(w.posted.length).toBe(2);
    w.respond(2, { children: [{ name: 'new.cpp', path: '/a/new.cpp', type: 'file' }] });
    await expect(p2).resolves.toEqual([{ name: 'new.cpp', path: '/a/new.cpp', type: 'file' }]);
    await expect(p3).resolves.toEqual([{ name: 'new.cpp', path: '/a/new.cpp', type: 'file' }]);
    // Churn bounded: 3 callers, 2 scans total, nothing left queued.
    const p4 = svc.readFiles('/a');
    expect(w.posted.length).toBe(3);
    w.respond(3, { children: [] });
    await expect(p4).resolves.toEqual([]);
  });

  it('late events from an old worker generation cannot reject or crash the new one', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const w1 = constructed()[0];
    w1.emit('error', new Error('boom'));
    await expect(p1).rejects.toThrow('boom');
    const p2 = svc.readFiles('/b');
    expect(constructed().length).toBe(2);
    const w2 = constructed()[1];
    // Old generation fully silenced: repeated error/exit/message must not throw
    // (unhandled EventEmitter error would crash main) nor touch w2's requests.
    expect(() => w1.emit('error', new Error('late error'))).not.toThrow();
    expect(() => w1.emit('exit', 1)).not.toThrow();
    expect(() => w1.emit('message', { id: 2, error: 'poison' })).not.toThrow();
    w2.respond(2, { children: [] });
    await expect(p2).resolves.toEqual([]);
  });

  it('dispose rejects running AND trailing callers, then a later scan respawns', async () => {
    const svc = new FileSystemService();
    const p1 = svc.readFiles('/a');
    const p2 = svc.readFiles('/a'); // trailing
    const p3 = svc.readFiles('/b'); // running, other root
    await svc.disposeTreeWorker();
    await expect(p1).rejects.toThrow('disposed');
    await expect(p2).rejects.toThrow('disposed');
    await expect(p3).rejects.toThrow('disposed');
    const p4 = svc.readFiles('/a');
    expect(constructed().length).toBe(2);
    constructed()[1].respond(3, { children: [] });
    await expect(p4).resolves.toEqual([]);
  });
});
