// @vitest-environment node
import { expect, it } from 'vitest';
import { mkdtemp, mkdir, writeFile, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildFileTree } from '../FileTreeWorker';
it('finishes cyclic/external symlinks without enumerating their targets', async () => {
  const root=await mkdtemp(join(tmpdir(),'nx-tree-native-'));
  try {
    await mkdir(join(root,'src'));await writeFile(join(root,'src','main.py'),'pass');
    await symlink(root,join(root,'src','loop'),'dir');await symlink('/tmp',join(root,'external'),'dir');
    await symlink(join(root,'missing'),join(root,'broken'));
    await symlink(join(root,'src'),join(root,'selected-root'),'dir');
    const tree=await buildFileTree(root);
    expect(tree.children?.find(n=>n.name==='external')?.children).toEqual([]);
    const src=tree.children?.find(n=>n.name==='src');
    expect(src?.children?.map(n=>n.name)).toEqual(['loop','main.py']);
    expect(src?.children?.[0].children).toEqual([]);
    expect(tree.children?.find(n=>n.name==='broken')?.type).toBe('file');
    const selected=await buildFileTree(join(root,'selected-root'));
    expect(selected.children?.map(n=>n.name)).toEqual(['loop','main.py']);
  } finally {await rm(root,{recursive:true,force:true});}
});
