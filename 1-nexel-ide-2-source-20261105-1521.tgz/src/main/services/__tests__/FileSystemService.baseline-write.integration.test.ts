// @vitest-environment node
import { describe, it, expect, vi, afterEach } from 'vitest';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';

vi.mock('electron', () => ({ dialog: { showOpenDialog: vi.fn() } }));

import { FileSystemService } from '../FileSystemService';

let dir: string | null = null;
afterEach(async () => {
  if (dir) { await fs.rm(dir, { recursive: true, force: true }); dir = null; }
});

describe('FileSystemService.writeFileIfBaseline against the real filesystem', () => {
  it('writes when disk still matches the baseline', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fsb-'));
    const p = path.join(dir, 'a.py');
    await fs.writeFile(p, 'a = 1\n');
    const svc = new FileSystemService();
    expect(await svc.writeFileIfBaseline(p, 'a = 1\n# edit\n', 'a = 1\n')).toBe('written');
    expect(await fs.readFile(p, 'utf8')).toBe('a = 1\n# edit\n');
  });
  it('refuses and writes nothing when disk diverged from the baseline', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fsb-'));
    const p = path.join(dir, 'a.py');
    await fs.writeFile(p, 'external newer\n');
    const svc = new FileSystemService();
    expect(await svc.writeFileIfBaseline(p, 'buffer\n', 'a = 1\n')).toBe('conflict');
    expect(await fs.readFile(p, 'utf8')).toBe('external newer\n');
  });
  it('writes a missing file (orphan save-to-recreate)', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fsb-'));
    const p = path.join(dir, 'a.py');
    const svc = new FileSystemService();
    expect(await svc.writeFileIfBaseline(p, 'buffer\n', 'a = 1\n')).toBe('written');
    expect(await fs.readFile(p, 'utf8')).toBe('buffer\n');
  });
  it('rejects on read errors other than a missing file instead of writing', async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), 'nx-fsb-'));
    const p = path.join(dir, 'sub', 'a.py'); // parent missing -> ENOENT on read AND on write
    const svc = new FileSystemService();
    // read ENOENT counts as missing; write then fails with ENOENT -> caller blocks
    await expect(svc.writeFileIfBaseline(p, 'buffer\n', 'a = 1\n')).rejects.toThrow();
  });
});
it.skipIf(process.platform==='win32'||process.getuid?.()===0)('never treats ENOENT in a write-only filename as proof the file is missing',async()=>{
 dir=await fs.mkdtemp(path.join(os.tmpdir(),'nx-fsb-'));const p=path.join(dir,'ENOENT.cpp');await fs.writeFile(p,'external newer\n');await fs.chmod(p,0o200);
 try{await expect(new FileSystemService().writeFileIfBaseline(p,'buffer\n','old baseline\n')).rejects.toMatchObject({code:'EACCES'});}finally{await fs.chmod(p,0o600);}
 expect(await fs.readFile(p,'utf8')).toBe('external newer\n');
});
