// @vitest-environment node
import { it, expect } from 'vitest';
import { globSync, mkdtempSync, mkdirSync, copyFileSync, symlinkSync, rmSync, readFileSync, realpathSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';

it('loads JudgeService from the configured packaged file selection, not the development source tree', () => {
  const root = resolve(__dirname, '../../../..');
  const config = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  const staged = mkdtempSync(join(tmpdir(), 'nexel-package-runtime-'));
  try {
    const files = new Set<string>();
    for (const pattern of config.build.files as string[]) {
      if (pattern.startsWith('!')) {
        for (const file of globSync(pattern.slice(1), { cwd: root })) files.delete(file);
      } else {
        for (const file of globSync(pattern, { cwd: root })) files.add(file);
      }
    }
    for (const file of files) {
      if (!/\.(?:ts|cjs|json)$/.test(file)) continue;
      const target = join(staged, file); mkdirSync(dirname(target), { recursive: true });
      copyFileSync(join(root, file), target);
    }
    symlinkSync(realpathSync(join(root, 'node_modules')), join(staged, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
    const result = spawnSync(process.execPath, ['-e', `
      const fs = require('node:fs'), ts = require('typescript');
      require.extensions['.ts'] = (m, f) => m._compile(ts.transpileModule(fs.readFileSync(f, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText, f);
      const { JudgeService } = require('./src/main/services/JudgeService.ts');
      if (typeof JudgeService !== 'function') throw Error('Missing JudgeService export');
    `], { cwd: staged, encoding: 'utf8', timeout: 15000 });
    expect(result.error, result.stderr).toBeUndefined();
    expect(result.status, result.stderr).toBe(0);
  } finally { rmSync(staged, { recursive: true, force: true }); }
});
