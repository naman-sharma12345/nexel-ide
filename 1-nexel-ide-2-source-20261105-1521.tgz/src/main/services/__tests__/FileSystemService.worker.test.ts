// @vitest-environment node
// Lifecycle/teardown semantics of the persistent file-tree worker in
// FileSystemService. Supersedes the old per-scan-spawn assertions: the worker
// now survives successful scans and is only torn down on error/exit/dispose.
import { EventEmitter } from 'node:events';
import { beforeEach, expect, it, vi } from 'vitest';
const state=vi.hoisted(()=>({workers:[] as any[]}));
vi.mock('electron',()=>({dialog:{showOpenDialog:vi.fn()}}));
vi.mock('worker_threads',()=>({Worker:class extends EventEmitter{
 terminate=vi.fn().mockResolvedValue(0);
 unref(){}
 posted:any[]=[];
 postMessage(m:any){this.posted.push(m);}
 constructor(){super();state.workers.push(this);}
}}));
import {FileSystemService} from '../FileSystemService';
beforeEach(()=>{state.workers.length=0;});

it('keeps the shared worker alive after a successful scan (ready for reuse)',async()=>{
 const read=new FileSystemService().readFiles('/fixture');
 const w=state.workers[0];
 w.emit('message',{id:1,children:[]});
 await expect(read).resolves.toEqual([]);
 expect(w.listenerCount('message')).toBe(1);
 expect(w.listenerCount('error')).toBe(1);
 expect(w.listenerCount('exit')).toBe(1);
});

it('worker error teardown removes listeners and rejects pending; next scan respawns',async()=>{
 const svc=new FileSystemService();
 const read=svc.readFiles('/fixture');
 const w=state.workers[0];
 w.emit('error',new Error('fixture failure'));
 await expect(read).rejects.toThrow('fixture failure');
 // teardown/detach leaves exactly the no-op crash guard behind
 expect(w.eventNames()).toEqual(['error']);
 const next=svc.readFiles('/other');
 expect(state.workers.length).toBe(2);
 state.workers[1].emit('message',{id:2,children:[]});
 await expect(next).resolves.toEqual([]);
});

it('abnormal exit teardown removes listeners and rejects pending',async()=>{
 const svc=new FileSystemService();
 const read=svc.readFiles('/fixture');
 const w=state.workers[0];
 w.emit('exit',2);
 await expect(read).rejects.toThrow(/exit status 2/);
 // teardown/detach leaves exactly the no-op crash guard behind
 expect(w.eventNames()).toEqual(['error']);
});

it('a message arriving after teardown is ignored',async()=>{
 const svc=new FileSystemService();
 const read=svc.readFiles('/fixture');
 const w=state.workers[0];
 w.emit('exit',1);
 await expect(read).rejects.toThrow(/exit status 1/);
 expect(()=>w.emit('message',{id:1,children:[]})).not.toThrow();
});

it('dispose terminates the shared worker, rejects pending and removes listeners',async()=>{
 const svc=new FileSystemService();
 const read=svc.readFiles('/fixture');
 const w=state.workers[0];
 await svc.disposeTreeWorker();
 await expect(read).rejects.toThrow(/disposed/);
 expect(w.terminate).toHaveBeenCalled();
 // teardown/detach leaves exactly the no-op crash guard behind
 expect(w.eventNames()).toEqual(['error']);
});
