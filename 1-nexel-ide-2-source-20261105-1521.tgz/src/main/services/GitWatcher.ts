import fs from 'fs';
import path from 'path';

/** Watches a repository's git metadata directory so the renderer can invalidate
    git surfaces when the repo changes outside the app (terminal commit, checkout,
    stage, merge, fetch). Scope is deliberately metadata-only:
      - the gitdir directory itself, filtered to HEAD/index/packed-refs/MERGE_HEAD/
        FETCH_HEAD/ORIG_HEAD - atomic lock-then-rename writes surface here as events
        on the final name, so replaced files are still caught;
      - refs/heads, refs/remotes, refs/tags directories - branch/tag create/delete/
        update events.
    Pure working-tree edits with no git operation do NOT fire this watcher; those
    are still picked up by the renderer's focus refresh and 30s poll. */
// Per-worktree metadata (HEAD/index are per-worktree even for linked worktrees).
const META_FILES = new Set(['HEAD', 'index', 'MERGE_HEAD', 'FETCH_HEAD', 'ORIG_HEAD']);
// Shared metadata lives in the COMMON gitdir for linked worktrees (refs/,
// packed-refs); for a plain repo the common dir is the gitdir itself.
const COMMON_FILES = new Set(['packed-refs']);
const REFS_DIRS = ['refs/heads', 'refs/remotes', 'refs/tags'];

/** The shared object/refs store: for a linked worktree's per-worktree gitdir,
    the `commondir` file points at the main .git; otherwise gitdir itself. */
export function resolveCommonDir(gitDir: string): string {
  try {
    const text = fs.readFileSync(path.join(gitDir, 'commondir'), 'utf8').replace(/\r?\n$/, '');
    const resolved = path.isAbsolute(text) ? text : path.resolve(gitDir, text);
    if (fs.existsSync(resolved)) return resolved;
  } catch { /* no commondir file: plain repo */ }
  return gitDir;
}

export function resolveGitDir(root: string): string | null {
  const dotgit = path.join(root, '.git');
  try {
    const st = fs.statSync(dotgit);
    if (st.isDirectory()) return dotgit;
    if (st.isFile()) {
      // linked worktree / submodule: .git is a file containing "gitdir: <path>"
      const text = fs.readFileSync(dotgit, 'utf8');
      const m = /^gitdir: (.+?)(?:\r?\n)?$/s.exec(text);
      if (!m) return null;
      const p = m[1];
      const resolved = path.isAbsolute(p) ? p : path.resolve(root, p);
      return fs.existsSync(resolved) ? resolved : null;
    }
  } catch { /* not a repo */ }
  return null;
}

export class GitWatcher {
  private watchers: fs.FSWatcher[] = [];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private watching: string | null = null;

  /** Start watching root's gitdir; any previous watch is disposed first.
      onChange(root) fires once per debounce window (300ms trailing). */
  start(root: string, onChange: (root: string) => void): { watching: boolean } {
    this.stop();
    const gitDir = resolveGitDir(root);
    if (!gitDir) return { watching: false };
    this.watching = root;
    const fire = () => {
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => { this.timer = null; onChange(root); }, 300);
    };
    const watchDir = (dir: string, filter: (name: string) => boolean) => {
      try {
        const w = fs.watch(dir, { persistent: false }, (_evt, name) => {
          if (name && filter(name.toString())) fire();
        });
        w.on('error', () => { /* watched dir vanished (repo deleted) - stay quiet */ });
        this.watchers.push(w);
      } catch { /* dir missing (e.g. no refs/remotes yet) - skip */ }
    };
    watchDir(gitDir, (name) => META_FILES.has(name));
    const commonDir = resolveCommonDir(gitDir);
    watchDir(commonDir, (name) => COMMON_FILES.has(name));
    for (const rel of REFS_DIRS) watchDir(path.join(commonDir, rel), () => true);
    // A resolved metadata path is not a successful registration. Capacity or
    // permission failures may reject every watch; tell the caller to retry on
    // its existing refresh cadence instead of permanently arming a dead watch.
    if (this.watchers.length === 0) { this.watching = null; return { watching: false }; }
    return { watching: true };
  }

  stop(): void {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    for (const w of this.watchers) { try { w.close(); } catch { /* already closed */ } }
    this.watchers = [];
    this.watching = null;
  }

  get currentRoot(): string | null { return this.watching; }
}
