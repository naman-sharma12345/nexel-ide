import {spawn, type ChildProcessWithoutNullStreams, type SpawnOptionsWithoutStdio} from 'node:child_process';
/** A pipe fallback is ready only after spawn, not merely after allocating ChildProcess. */
export function startPipeShell(command:string,args:string[],options:SpawnOptionsWithoutStdio,onLateError:(error:Error)=>void):Promise<ChildProcessWithoutNullStreams> {
 return new Promise((resolve,reject)=>{
  const child=spawn(command,args,options);
  // Decode as a stream: OS pipe chunks can split a multibyte UTF-8 character.
  child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
  let started=false;
  child.on('error',(error)=>{if(started)onLateError(error);else reject(error);});
  child.stdin.on('error',error=>onLateError(error));
  child.once('spawn',()=>{started=true;resolve(child);});
 });
}
/**
 * Mirror of the PTY spawn retry: when the validated cwd was removed between
 * validation and spawn (TOCTOU), a first-spawn rejection retries once in HOME
 * before the terminal create fails. Narrows the race; cannot eliminate it.
 * Returns null when HOME was already the cwd, HOME is unavailable, or the
 * HOME retry also fails - the caller then surfaces the startup error as before.
 */
export async function startPipeShellWithHomeRetry(command:string,args:string[],options:SpawnOptionsWithoutStdio,home:string|undefined,onLateError:(error:Error)=>void):Promise<{child:ChildProcessWithoutNullStreams;cwdUsed:string|URL|undefined}|null> {
 try {
  return {child:await startPipeShell(command,args,options,onLateError),cwdUsed:options.cwd};
 } catch {
  if(!home||options.cwd===home)return null;
  try {
   return {child:await startPipeShell(command,args,{...options,cwd:home},onLateError),cwdUsed:home};
  } catch {
   return null;
  }
 }
}
