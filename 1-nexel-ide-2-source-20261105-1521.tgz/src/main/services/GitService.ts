import { spawn } from 'child_process';
import { StringDecoder } from 'node:string_decoder';
import { realpath, lstat } from 'node:fs/promises';
import * as nodePath from 'node:path';

export interface GitStatusEntry {
  path: string;
  /** Two-letter porcelain code, e.g. "M ", " M", "A ", "??". */
  code: string;
  staged: boolean;
  unstaged: boolean;
  untracked: boolean;
  /** Unmerged (merge conflict): UU, AA, DU, UD, AU, UA, DD. */
  conflicted: boolean;
  /** For renames/copies: the original path. */
  origPath?: string;
}

export interface GitStatus {
  /** Canonical repository root when workspace is a nested directory. No rows/actions. */
  repositoryRoot?: string;
  isRepo: boolean;
  branch: string | null;
  /** True when the branch tracks an upstream (has a push/pull target). */
  hasUpstream: boolean;
  ahead: number;
  behind: number;
  entries: GitStatusEntry[];
}

export interface GitResult { ok: boolean; error?: string }
export interface GitDiffResult extends GitResult { diff?: string }

const GIT_TIMEOUT_MS = 10000;
const GIT_NETWORK_TIMEOUT_MS = 60000; // fetch/pull: bounded so the UI never hangs indefinitely
const MAX_OUTPUT = 512 * 1024;

/** Parse `git status --porcelain=v1 -z --branch` output. Pure and unit-tested.
    -z fields are NUL-separated and never quoted; rename/copy entries are
    "XY new\0orig\0". Handles spaces, newlines and leading dashes in paths. */
export function parsePorcelainStatusZ(out: string): GitStatus {
  const status: GitStatus = { isRepo: true, branch: null, hasUpstream: false, ahead: 0, behind: 0, entries: [] };
  const fields = out.split('\0');
  for (let i = 0; i < fields.length; i++) {
    const field = fields[i];
    if (!field) continue;
    if (field.startsWith('## ')) {
      const head = field.slice(3);
      const m = head.match(/^([^ .]+(?:\.[^ .]+)*?)(?:\.\.\.(\S+))?(?: \[(?:gone|(?:ahead (\d+))?(?:, )?(?:behind (\d+))?)\])?$/);
      status.branch = m?.[1] ?? head.split(' ')[0];
      status.hasUpstream = !!m?.[2];
      status.ahead = m?.[3] ? parseInt(m[3], 10) : 0;
      status.behind = m?.[4] ? parseInt(m[4], 10) : 0;
      const noCommits = head.match(/^No commits yet on (.+)$/);
      if (noCommits) status.branch = noCommits[1];
      // Detached HEAD: header is "HEAD (no branch)"; branch stays null so the UI
      // renders (detached) and never offers HEAD as a push/switch branch name.
      if (/^HEAD \(no branch\)/.test(head)) status.branch = null;
      continue;
    }
    const code = field.slice(0, 2);
    const entry: GitStatusEntry = {
      path: field.slice(3),
      code,
      untracked: code === '??',
      staged: code[0] !== ' ' && code[0] !== '?' && code !== '!!',
      unstaged: code[1] !== ' ' && code !== '??' && code !== '!!',
      conflicted: code.includes('U') || code === 'AA' || code === 'DD',
    };
    if (code[0] === 'R' || code[0] === 'C') entry.origPath = fields[++i] ?? '';
    status.entries.push(entry);
  }
  return status;
}

/**
 * Thin git CLI wrapper scoped to a workspace root. No shell: every invocation
 * passes an argument array, and paths go after `--` with --literal-pathspecs,
 * so globs, pathspec magic and leading dashes in file names can never change
 * meaning. Mutating operations are only ever invoked from explicit UI clicks.
 */
export class GitService {
  private run(root: string, args: string[], timeoutMs = GIT_TIMEOUT_MS): Promise<{ code: number; stdout: string; stderr: string; stdoutTruncated: boolean }> {
    return new Promise((resolve) => {
      let stdout = '', stderr = '', done = false, stdoutTruncated = false;
      const finish = (code: number) => { if (!done) { done = true; resolve({ code, stdout, stderr, stdoutTruncated }); } };
      const stdoutDecoder = new StringDecoder('utf8'), stderrDecoder = new StringDecoder('utf8');
      let child;
      // Terminal prompts are disabled by default: git prompts via /dev/tty
      // (not stdin), so under a controlling terminal a credential prompt would
      // otherwise block until the timeout with no UI-visible way to answer
      // (proven: pty-held spawn hung on "Username for ..." until killed; with
      // GIT_TERMINAL_PROMPT=0 the same fetch fails in ~10ms). An explicitly
      // exported GIT_TERMINAL_PROMPT is honored.
      try { child = spawn('git', args, { cwd: root, stdio: ['ignore', 'pipe', 'pipe'], env: { ...process.env, GIT_TERMINAL_PROMPT: process.env.GIT_TERMINAL_PROMPT ?? '0' } }); }
      catch (err) { stderr = String(err); finish(1); return; }
      const timer = setTimeout(() => {
        stderr += `\ngit timed out after ${timeoutMs}ms`;
        try { child.kill('SIGKILL'); } catch { /* already exited */ }
      }, timeoutMs);
      child.stdout.on('data', (d: Buffer) => {
        const text = stdoutDecoder.write(d);
        if (stdout.length + text.length > MAX_OUTPUT) stdoutTruncated = true;
        // Preserve existing bounded capture for other Git consumers. A diff
        // must refuse the partial capture rather than present it as complete.
        if (stdout.length < MAX_OUTPUT) stdout += text;
      });
      child.stderr.on('data', (d: Buffer) => { if (stderr.length < MAX_OUTPUT) stderr += stderrDecoder.write(d); });
      child.on('error', (err: Error) => { stderr += `\n${err.message}`; clearTimeout(timer); finish(1); });
      child.on('close', (code: number | null) => {
        const tail = stdoutDecoder.end();
        if (stdout.length + tail.length > MAX_OUTPUT) stdoutTruncated = true;
        if (stdout.length < MAX_OUTPUT) stdout += tail;
        if (stderr.length < MAX_OUTPUT) stderr += stderrDecoder.end();
        clearTimeout(timer); finish(code ?? 1);
      });
    });
  }

  async status(root: string): Promise<GitStatus> {
    const probe = await this.run(root, ['rev-parse', '--is-inside-work-tree']);
    if (probe.code !== 0 || probe.stdoutTruncated || probe.stdout.trim() !== 'true') {
      // A failed discovery is not proof that initializing is appropriate. Git
      // can hide damaged repositories (including ancestor/worktree metadata).
      let current = await realpath(root);
      for (;;) {
        let marker = false;
        try { await lstat(nodePath.join(current, '.git')); marker = true; }
        catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error; }
        if (marker) throw new Error('Git metadata found but repository could not be read. ' + probe.stderr.trim());
        const parent = nodePath.dirname(current);
        if (parent === current) break;
        current = parent;
      }
      // A bare repository is a repository, but has no editable working tree.
      if (probe.code === 0 && probe.stdout.trim() === 'false') throw new Error('This Git repository is not a working tree. Open a working tree folder.');
      // Unknown errors (missing executable, timeout, permissions, configuration,
      // or localized diagnostics) must remain retryable, never become Init.
      if (probe.stdoutTruncated || probe.code !== 128 || !/not a git repository/i.test(probe.stderr)) {
        throw new Error(probe.stderr.trim() || 'Could not verify Git repository');
      }
      return { isRepo: false, branch: null, hasUpstream: false, ahead: 0, behind: 0, entries: [] };
    }
    const top = await this.run(root, ['rev-parse', '--show-toplevel']);
    if (top.code !== 0 || top.stdoutTruncated) throw new Error(top.stderr.trim() || 'Could not verify Git repository root');
    // Remove Git's one output terminator, not whitespace belonging to a path.
    const topPath = top.stdout.replace(/\n$/, '');
    const [workspaceCanonical, repositoryCanonical] = await Promise.all([realpath(root), realpath(topPath)]);
    if (nodePath.relative(workspaceCanonical, repositoryCanonical) !== '') {
      return { isRepo: true, repositoryRoot: repositoryCanonical, branch: null, hasUpstream: false, ahead: 0, behind: 0, entries: [] };
    }
    const r = await this.run(root, ['status', '--porcelain=v1', '-z', '--branch', '--untracked-files=all']);
    if (r.code !== 0) throw new Error(r.stderr.trim() || 'Could not read git status');
    if (r.stdoutTruncated) throw new Error('Git status output limit reached. Status is incomplete.');
    return parsePorcelainStatusZ(r.stdout);
  }

  async branches(root: string): Promise<{ ok: boolean; branches: string[]; error?: string }> {
    const r = await this.run(root, ['branch', '--format=%(refname)']);
    if (r.stdoutTruncated) return { ok: false, branches: [], error: 'Branch list output limit reached. Branches are incomplete' };
    if (r.code !== 0) return { ok: false, branches: [], error: r.stderr.trim() || 'git branch failed' };
    // Full refs avoid Git's :short disambiguation (a tag named topic makes
    // the local topic branch appear as heads/topic, which switch rejects).
    // Filter the detached pseudo-entry and remove exactly the local prefix.
    return { ok: true, branches: r.stdout.split('\n').filter((b) => b.startsWith('refs/heads/')).map((b) => b.slice('refs/heads/'.length)) };
  }

  async init(root: string): Promise<GitResult> {
    const r = await this.run(root, ['init']);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git init failed' };
  }

  async stage(root: string, paths: string[]): Promise<GitResult> {
    if (!paths.length) return { ok: true };
    const r = await this.run(root, ['--literal-pathspecs', 'add', '--', ...paths]);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git add failed' };
  }

  async unstage(root: string, paths: string[]): Promise<GitResult> {
    if (!paths.length) return { ok: true };
    // An unborn branch has no HEAD tree for restore. Confirm an absent named
    // branch ref, not merely a failed HEAD lookup (which may be corruption).
    const head = await this.run(root, ['rev-parse', '--verify', 'HEAD']);
    if (head.code !== 0) {
      const symbolic = await this.run(root, ['symbolic-ref', '-q', 'HEAD']);
      const ref = symbolic.stdout.trim();
      if (symbolic.code === 0 && ref.startsWith('refs/heads/')) {
        const exists = await this.run(root, ['show-ref', '--verify', '--quiet', ref]);
        if (exists.code === 1) {
          // Index only, no force: Git must refuse if staged-only bytes would
          // be discarded. Never retry a failed restore with this operation.
          const initial = await this.run(root, ['--literal-pathspecs', 'rm', '--cached', '--', ...paths]);
          return initial.code === 0 ? { ok: true } : { ok: false, error: initial.stderr.trim() || 'git unstage failed' };
        }
      }
      return { ok: false, error: head.stderr.trim() || 'Could not resolve HEAD for git unstage' };
    }
    const r = await this.run(root, ['--literal-pathspecs', 'restore', '--staged', '--', ...paths]);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git unstage failed' };
  }

  async commit(root: string, message: string): Promise<GitResult> {
    if (!message.trim()) return { ok: false, error: 'Commit message is empty' };
    const r = await this.run(root, ['commit', '-m', message]);
    return r.code === 0 ? { ok: true } : { ok: false, error: (r.stderr.trim() || r.stdout.trim() || 'git commit failed') };
  }

  /** Read-only diff for one path. staged=true diffs the index against HEAD. */
  async diff(root: string, path: string, staged: boolean, origPath?: string): Promise<GitDiffResult> {
    const args = ['--literal-pathspecs', 'diff', '--no-color', '--no-ext-diff', ...(staged ? ['--cached'] : []), '--', path, ...(staged && origPath ? [origPath] : [])];
    const r = await this.run(root, args);
    if (r.stdoutTruncated) return { ok: false, error: 'Diff is too large to display (output limit reached). Review it in an external Git tool.' };
    return r.code === 0 ? { ok: true, diff: r.stdout } : { ok: false, error: r.stderr.trim() || 'git diff failed' };
  }

  /** Switch branches. git refuses when the switch would overwrite local changes;
      that refusal is surfaced verbatim - there is no fallback, reset or force. */
  async switchBranch(root: string, branch: string): Promise<GitResult> {
    if (!branch || branch.startsWith('-')) return { ok: false, error: 'invalid branch name' };
    const r = await this.run(root, ['switch', branch]);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git switch failed' };
  }

  /** Fetch all remotes (prunes remote-tracking refs only). Bounded by the
      network timeout; the caller keeps the UI responsive via async IPC. */
  async fetch(root: string): Promise<GitResult> {
    const r = await this.run(root, ['fetch', '--all', '--prune'], GIT_NETWORK_TIMEOUT_MS);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git fetch failed' };
  }

  /** Recent commit history, newest first. Four NUL-terminated fields per
      commit; Git commit metadata cannot contain NUL, unlike control U+001E. */
  async log(root: string, limit = 50): Promise<{ ok: boolean; commits: { hash: string; subject: string; author: string; date: string }[]; error?: string }> {
    const fmt = '%h%x00%an%x00%ad%x00%s';
    const r = await this.run(root, ['log', '--no-show-signature', '--encoding=UTF-8', '-z', `-n${Math.min(Math.max(limit, 1), 200)}`, '--date=short', `--format=${fmt}`]);
    if (r.stdoutTruncated) return { ok: false, commits: [], error: 'History output limit reached. History is incomplete' };
    if (r.code !== 0) {
      // No commits on a verified unborn local branch is an empty history, not
      // a read failure. A failed/corrupt existing ref must still report failure.
      const symbolic = await this.run(root, ['symbolic-ref', '-q', 'HEAD']);
      const ref = symbolic.stdout.trim();
      if (symbolic.code === 0 && ref.startsWith('refs/heads/')) {
        const exists = await this.run(root, ['show-ref', '--verify', '--quiet', ref]);
        if (exists.code === 1) return { ok: true, commits: [] };
      }
      return { ok: false, commits: [], error: r.stderr.trim() || 'git log failed' };
    }
    const fields = r.stdout.split('\0');
    if (fields[fields.length - 1] === '') fields.pop();
    if (fields.length % 4 !== 0) return { ok: false, commits: [], error: 'Could not parse complete Git history' };
    const commits: { hash: string; subject: string; author: string; date: string }[] = [];
    for (let i = 0; i < fields.length; i += 4) {
      const [hash, author, date, subject] = fields.slice(i, i + 4);
      if (!/^[0-9a-f]+$/i.test(hash)) return { ok: false, commits: [], error: 'Could not parse Git history hash' };
      commits.push({ hash, author, date, subject });
    }
    return { ok: true, commits };
  }

  /** Explicit push to the branch's configured upstream. Terminal auth prompts
      are disabled by default (see run()): credential failures surface git's
      error verbatim. Never force-pushes. */
  async push(root: string): Promise<GitResult> {
    const r = await this.run(root, ['push'], GIT_NETWORK_TIMEOUT_MS);
    return r.code === 0 ? { ok: true } : { ok: false, error: (r.stderr.trim() || r.stdout.trim() || 'git push failed') };
  }

  /** Configured remote names, for explicit publish-target selection. */
  async remotes(root: string): Promise<{ ok: boolean; remotes: string[]; error?: string }> {
    const r = await this.run(root, ['remote']);
    if (r.stdoutTruncated) return { ok: false, remotes: [], error: 'Remote list output limit reached. Remotes are incomplete' };
    if (r.code !== 0) return { ok: false, remotes: [], error: r.stderr.trim() || 'git remote failed' };
    return { ok: true, remotes: r.stdout.split('\n').map((x) => x.trim()).filter(Boolean) };
  }

  /** First publish: push -u <remote> <branch>, only from an explicit user click
      with the target visible in the UI. */
  async publish(root: string, remote: string, branch: string): Promise<GitResult> {
    if (!remote || !branch || remote.startsWith('-') || branch.startsWith('-')) return { ok: false, error: 'invalid publish target' };
    const r = await this.run(root, ['push', '-u', remote, branch], GIT_NETWORK_TIMEOUT_MS);
    return r.code === 0 ? { ok: true } : { ok: false, error: (r.stderr.trim() || r.stdout.trim() || 'git publish failed') };
  }

  /** Create and switch to a new branch (git switch -c). Same working-tree rules
      as switchBranch: git refuses to clobber local changes; no force. */
  async createBranch(root: string, name: string): Promise<GitResult> {
    if (!name || name.startsWith('-') || /[\s~^:?*[\]\\]/.test(name)) return { ok: false, error: 'invalid branch name' };
    const r = await this.run(root, ['switch', '-c', name]);
    return r.code === 0 ? { ok: true } : { ok: false, error: r.stderr.trim() || 'git branch failed' };
  }

  /** Fast-forward-only pull. Never merges, rebases or overwrites local changes;
      a non-fast-forward situation surfaces git's own error. */
  async pull(root: string): Promise<GitResult> {
    const r = await this.run(root, ['pull', '--ff-only'], GIT_NETWORK_TIMEOUT_MS);
    return r.code === 0 ? { ok: true } : { ok: false, error: (r.stderr.trim() || r.stdout.trim() || 'git pull failed') };
  }
}
