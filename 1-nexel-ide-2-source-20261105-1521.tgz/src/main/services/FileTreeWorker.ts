import { parentPort, workerData, isMainThread } from 'worker_threads';
import * as path from 'path';
import * as fs from 'fs/promises';

interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  isOpen?: boolean;
  children?: FileNode[];
}

export const TREE_IO_CONCURRENCY = 32;
const excluded = new Set(['node_modules', '.git', '.vite']);

function sortNodes(nodes: FileNode[]) {
  nodes.sort((a, b) => {
    if (a.type === b.type) return a.name.localeCompare(b.name);
    return a.type === 'folder' ? -1 : 1;
  });
}

/** Bounded iterative traversal in the existing worker. Nested directory symlinks
 * stay visible but unexpanded, avoiding cycles and unexpected outside traversal.
 * A symlink explicitly selected as the workspace root can still be opened.
 */
export async function buildFileTree(targetPath: string): Promise<FileNode> {
  const root: FileNode = {
    name: path.basename(targetPath),
    path: targetPath.replace(/\\/g, '/'),
    type: 'file',
  };
  const queue = [{ target: targetPath, node: root }];
  let next = 0;
  while (next < queue.length) {
    const batch = queue.slice(next, next + TREE_IO_CONCURRENCY);
    next += batch.length;
    await Promise.all(batch.map(async ({ target, node }) => {
      const info = await fs.lstat(target);
      const link = info.isSymbolicLink();
      // Broken links are visible files, not failures of the entire workspace.
      const stats = link ? await fs.stat(target).catch(() => null) : info;
      if (!stats?.isDirectory()) return;
      node.type = 'folder';
      node.isOpen = false;
      node.children = [];
      if ((link && node !== root) || excluded.has(node.name)) return;
      const names = await fs.readdir(target);
      for (const name of names) {
        const target = path.join(node.path, name);
        const child: FileNode = { name, path: target.replace(/\\/g, '/'), type: 'file' };
        node.children.push(child);
        queue.push({ target, node: child });
      }
    }));
  }
  for (const { node } of queue) {
    if (node.children) sortNodes(node.children);
  }
  return root;
}

export interface ScanRequest {
  id: number;
  dirPath: string;
}

export interface ScanResponse {
  id?: number;
  children?: FileNode[];
  error?: string;
}

// Legacy single-shot entry, kept for direct unit coverage of scan + error mapping.
export async function run() {
  try {
    const tree = await buildFileTree(workerData.dirPath);
    parentPort?.postMessage({ children: tree.children ?? [] });
  } catch (err: unknown) {
    parentPort?.postMessage({ error: err instanceof Error ? err.message : String(err) });
  }
}

// One scan of the persistent server mode: response always echoes the request id
// so the main thread can match out-of-order completions and never resolve the
// wrong caller.
export async function serveScan(req: ScanRequest): Promise<void> {
  try {
    const tree = await buildFileTree(req.dirPath);
    parentPort?.postMessage({ id: req.id, children: tree.children ?? [] });
  } catch (err: unknown) {
    parentPort?.postMessage({ id: req.id, error: err instanceof Error ? err.message : String(err) });
  }
}

if (!isMainThread && !process.env.VITEST) {
  // Persistent server: the main thread keeps this worker alive and posts
  // ScanRequests; each is answered with a matching-id ScanResponse. Scans run
  // concurrently inside the worker; buildFileTree keeps all state closure-local.
  parentPort?.on('message', (req: ScanRequest) => {
    if (!req || typeof req.id !== 'number' || typeof req.dirPath !== 'string') {
      parentPort?.postMessage({ id: typeof req?.id === 'number' ? req.id : -1, error: 'Invalid scan request' });
      return;
    }
    void serveScan(req);
  });
}
