/** Minimal shape of node-pty used here, so tests can substitute a mock. */
export interface PtyProcLike {
  onData(cb: (data: string) => void): void;
  onExit(cb: () => void): void;
  kill(): void;
}
export interface PtyLike {
  spawn(shell: string, args: string[], opts: Record<string, unknown>): PtyProcLike;
}

/** Spawn the shell under `cwd`; on any synchronous spawn throw, retry once in
    `home` when the first attempt used a different cwd (a validated workspace
    root can be removed between validation and spawn). No duplicate retry when
    cwd already IS home. Returns the process and the cwd actually used, or null
    when every attempt failed - the caller then degrades to the pipe shell. */
export function spawnPtyWithHomeRetry(
  pty: PtyLike,
  shell: string,
  cwd: string,
  home: string,
  baseOpts: Record<string, unknown>,
): { proc: PtyProcLike; cwdUsed: string } | null {
  try {
    return { proc: pty.spawn(shell, [], { ...baseOpts, cwd }), cwdUsed: cwd };
  } catch {
    if (cwd === home) return null;
    try {
      return { proc: pty.spawn(shell, [], { ...baseOpts, cwd: home }), cwdUsed: home };
    } catch {
      return null;
    }
  }
}
