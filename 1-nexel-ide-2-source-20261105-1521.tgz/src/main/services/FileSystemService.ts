import { dialog } from 'electron';
import * as path from 'path';
import * as fs from 'fs/promises';
import { Worker } from 'worker_threads';

export interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  isOpen?: boolean;
  children?: FileNode[];
}

export class FileSystemService {
  async openDir(): Promise<string | null> {
    try {
      const result = await dialog.showOpenDialog({
        properties: ['openDirectory'],
        title: 'Select Nexel IDE Workspace Folder'
      });
      if (result.canceled) return null;
      return result.filePaths[0];
    } catch (err) {
      console.error("Native showOpenDialog call failed:", err);
      throw err;
    }
  }

  // Persistent file-tree worker: spawned lazily once, reused across scans so the
  // per-scan ~300ms isolate + TypeScript bootstrap is paid once per process, not
  // per refresh. Requests carry ids so overlapping scans resolve independently
  // out of order; responses for superseded roots are dropped renderer-side by
  // the store's treeReadVersion guard, unchanged. Scans run CONCURRENTLY in the
  // worker rather than serializing: a long scan of a huge tree cannot block an
  // interactive new-root scan, at the cost of shared IO bandwidth while they
  // overlap. Concurrency is bounded per root: at most one RUNNING plus one
  // TRAILING scan per dirPath - watcher churn collapses into the trailing slot,
  // and trailing callers always get a scan that STARTED after their request, so
  // a file created mid-scan is never hidden by a stale in-flight result.
  private treeWorker: Worker | null = null;
  private treeReqId = 0;
  private treePending = new Map<number, { dirPath: string; callers: { resolve: (n: FileNode[]) => void; reject: (e: Error) => void }[] }>();
  private treeRunningByPath = new Map<string, number>();
  private treeTrailing = new Map<string, { resolve: (n: FileNode[]) => void; reject: (e: Error) => void }[]>();

  private getTreeWorker(): Worker {
    if (this.treeWorker) return this.treeWorker;
    // Load the CommonJS wrapper which bootstraps the TypeScript worker
    const workerPath = path.join(__dirname, 'FileTreeWorker.cjs');
    const worker = new Worker(workerPath);
    worker.on('message', (message: { id?: number; children?: FileNode[]; error?: string }) => {
      const id = message?.id;
      if (typeof id !== 'number') return;
      if (!this.treePending.has(id)) return;
      if (message.error) this.finishTreeScan(id, new Error(message.error), null);
      else if (Array.isArray(message.children)) this.finishTreeScan(id, null, message.children);
      else this.finishTreeScan(id, new Error('File tree worker returned an invalid result'), null);
    });
    const teardown = (err: Error) => {
      // Defense-in-depth generation guard: events from an old, already-replaced
      // worker must never reject requests belonging to the current generation.
      // (The primary isolation is removeAllListeners below; this guard covers any
      // future listener re-attachment path. Not reachable via current events.)
      if (this.treeWorker !== worker) return;
      this.treeWorker = null;
      worker.removeAllListeners();
      // A dead EventEmitter must never crash main with an unhandled 'error'.
      worker.on('error', () => {});
      // No scan may hang on a dead worker: every pending and trailing caller rejects.
      const pending = [...this.treePending.values()];
      this.treePending.clear();
      this.treeRunningByPath.clear();
      const trailing = [...this.treeTrailing.values()].flat();
      this.treeTrailing.clear();
      for (const p of pending) for (const c of p.callers) c.reject(err);
      for (const c of trailing) c.reject(err);
    };
    worker.on('error', (err) => teardown(err instanceof Error ? err : new Error(String(err))));
    worker.once('exit', (code) => {
      if (code !== 0) teardown(new Error(`File tree worker stopped with exit status ${code}`));
      // The server worker never exits on its own; a clean exit with scans in
      // flight is still a failure for those callers, not a hang.
      else teardown(new Error('File tree worker exited without a result'));
    });
    // Never keep the main process alive just for an idle tree worker.
    worker.unref();
    this.treeWorker = worker;
    return worker;
  }

  private startTreeScan(dirPath: string, callers: { resolve: (n: FileNode[]) => void; reject: (e: Error) => void }[]): void {
    const id = ++this.treeReqId;
    this.treePending.set(id, { dirPath, callers });
    this.treeRunningByPath.set(dirPath, id);
    try {
      this.getTreeWorker().postMessage({ id, dirPath });
    } catch (err) {
      this.finishTreeScan(id, err instanceof Error ? err : new Error(String(err)), null);
    }
  }

  private finishTreeScan(id: number, err: Error | null, children: FileNode[] | null): void {
    const scan = this.treePending.get(id);
    if (!scan) return;
    this.treePending.delete(id);
    this.treeRunningByPath.delete(scan.dirPath);
    const failure = err ?? (children ? null : new Error('File tree worker returned an invalid result'));
    for (const c of scan.callers) {
      if (failure) c.reject(failure);
      else c.resolve(children as FileNode[]);
    }
    // Trailing callers get a FRESH scan started now, not the just-finished one:
    // its start time is after their requests, so it sees their filesystem state.
    const trailing = this.treeTrailing.get(scan.dirPath);
    if (trailing?.length) {
      this.treeTrailing.delete(scan.dirPath);
      this.startTreeScan(scan.dirPath, trailing);
    }
  }

  /** Terminate the shared tree worker (app shutdown, tests). Pending and trailing scans reject. */
  async disposeTreeWorker(): Promise<void> {
    const worker = this.treeWorker;
    this.treeWorker = null;
    const pending = [...this.treePending.values()];
    this.treePending.clear();
    this.treeRunningByPath.clear();
    const trailing = [...this.treeTrailing.values()].flat();
    this.treeTrailing.clear();
    for (const p of pending) for (const c of p.callers) c.reject(new Error('File tree worker disposed'));
    for (const c of trailing) c.reject(new Error('File tree worker disposed'));
    if (!worker) return;
    worker.removeAllListeners();
    worker.on('error', () => {});
    await worker.terminate();
  }

  async readFiles(dirPath: string): Promise<FileNode[]> {
    return new Promise((resolve, reject) => {
      const caller = { resolve, reject };
      if (this.treeRunningByPath.has(dirPath)) {
        // Same-root scan already running: join the trailing slot (coalesced).
        const t = this.treeTrailing.get(dirPath) ?? [];
        t.push(caller);
        this.treeTrailing.set(dirPath, t);
        return;
      }
      this.startTreeScan(dirPath, [caller]);
    });
  }

  async createFile(parentPath: string, fileName: string): Promise<string> {
    const resolvedParent = path.resolve(parentPath);
    const filePath = path.join(parentPath, fileName);
    const resolvedFile = path.resolve(filePath);

    const relative = path.relative(resolvedParent, resolvedFile);
    if (!relative || relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) {
      throw new Error("Security Violation: Path traversal attempt blocked");
    }

    // New File must never truncate an existing file, including a racing create.
    await fs.writeFile(filePath, '', { encoding: 'utf8', flag: 'wx' });
    return filePath;
  }

  async createFolder(parentPath: string, folderName: string): Promise<string> {
    const resolvedParent = path.resolve(parentPath);
    const folderPath = path.join(parentPath, folderName);
    const resolvedFolder = path.resolve(folderPath);

    const relative = path.relative(resolvedParent, resolvedFolder);
    if (!relative || relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) {
      throw new Error("Security Violation: Path traversal attempt blocked");
    }

    await fs.mkdir(folderPath, { recursive: true });
    return folderPath;
  }

  async rename(oldPath: string, newPath: string): Promise<string> {
    if (path.resolve(oldPath) === path.resolve(newPath)) return newPath;
    // Explorer does not offer Replace: an existing destination must be explicit,
    // including a dangling symlink that access() would report as missing.
    // Residual race: a destination created between this lstat and the rename
    // below is overwritten (window unmeasured). The current implementation has
    // no atomic no-replace rename available through the Node API used here;
    // that is a limitation of this implementation, not a proven impossibility.
    try {
      await fs.lstat(newPath);
      throw Object.assign(new Error('EEXIST: destination already exists; rename was not performed'), { code: 'EEXIST' });
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    }
    await fs.rename(oldPath, newPath);
    return newPath;
  }

  async deleteNode(targetPath: string): Promise<boolean> {
    await fs.rm(targetPath, { recursive: true, force: true });
    return true;
  }

  async realPath(filePath: string): Promise<string> {
    return await fs.realpath(filePath);
  }

  async fileIdentity(filePath: string): Promise<string> {
    const canonical = await fs.realpath(filePath);
    const stats = await fs.stat(canonical, { bigint: true });
    if (!stats.isFile() || stats.ino === 0n) throw new Error('File identity is unavailable');
    return `${stats.dev}:${stats.ino}`;
  }

  async readFileContent(filePath: string): Promise<string> {
    const buf = await fs.readFile(filePath);
    // A lossy utf8 read turns invalid bytes into U+FFFD; a later save would
    // silently rewrite the file with replacement bytes (the baseline guard
    // cannot catch it: it compares the same lossy decode). Refuse binary or
    // unsupported encodings instead of opening them in the text editor.
    if (buf.includes(0)) throw new Error('file looks binary (it contains NUL bytes) - not opening it in the text editor');
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(buf);
    } catch {
      throw new Error('file is not valid UTF-8 (binary or an unsupported encoding) - not opening it in the text editor');
    }
  }

  async writeFileContent(filePath: string, content: string): Promise<boolean> {
    await fs.writeFile(filePath, content, 'utf8');
    return true;
  }

  /**
   * Write only when the bytes on disk still match the caller's baseline (what
   * the tab last opened or saved). A missing file is written (save-to-recreate).
   * Read failures other than a genuinely missing file reject, so callers block
   * instead of assuming absence. The read+compare+write stays in one main-process
   * turn; the read/write race is still unclosed (no file lock available).
   */
  async writeFileIfBaseline(filePath: string, content: string, baseline: string): Promise<'written' | 'conflict'> {
    let disk: string | null = null;
    try {
      disk = await fs.readFile(filePath, 'utf8');
    } catch (err) {
      // A filename can contain ENOENT or 'no such file'. Only the actual
      // filesystem code establishes absence; every unreadable file must refuse.
      if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw err;
    }
    if (disk !== null && disk !== baseline) return 'conflict';
    await fs.writeFile(filePath, content, 'utf8');
    return 'written';
  }
}
