import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, act, cleanup } from '@testing-library/react';
import React from 'react';

vi.mock('@monaco-editor/react', () => ({
  __esModule: true,
  default: () => React.createElement('div', { 'data-testid': 'monaco-stub' }),
  loader: { init: async () => ({}), config: () => {} },
  useMonaco: () => null,
}));
vi.mock('xterm', () => ({
  Terminal: class { loadAddon() {} attachCustomKeyEventHandler() {} open() {} write() {} dispose() {} onData() {} },
}));
vi.mock('xterm-addon-fit', () => ({ FitAddon: class { fit() {} } }));
vi.mock('xterm/css/xterm.css', () => ({}));

import App from '../App';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { useEditorStore } from '../stores/useEditorStore';
import { useSettingsStore } from '../stores/useSettingsStore';

beforeEach(() => {
  cleanup();
  localStorage.clear();
  useSettingsStore.setState({ clangdEnabled: false });
  useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null, isSplit: false, rightTabPath: null });
  useWorkspaceStore.setState({ rootPath: '/repo' });
});
afterEach(() => { vi.restoreAllMocks(); });

function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r; }); return { promise, resolve }; }

describe('Close All invalidates in-flight opens', () => {
  it('an App-route open pending during Close All does not resurrect a tab; a later open still works', async () => {
    const d = deferred<string>();
    vi.spyOn(window.nexelAPI, 'readFileContent').mockImplementation(() => d.promise);
    useEditorStore.getState().openFile('/repo/existing.ts', 'existing.ts', 'x');
    render(<App />);
    // Start an open through the real nexel:open-at route; its read stays pending.
    act(() => { window.dispatchEvent(new CustomEvent('nexel:open-at', { detail: { path: '/repo/a.ts', line: 1, col: 1 } })); });
    await vi.waitFor(() => expect(window.nexelAPI.readFileContent).toHaveBeenCalledWith('/repo/a.ts'));
    act(() => { useEditorStore.getState().closeAllTabs(); });
    await act(async () => { d.resolve('late content'); await new Promise(r => setTimeout(r, 30)); });
    expect(useEditorStore.getState().tabs).toHaveLength(0); // no resurrected tab

    // A deliberate later open through the same route still works.
    vi.spyOn(window.nexelAPI, 'readFileContent').mockResolvedValue('fresh a content');
    await act(async () => {
      window.dispatchEvent(new CustomEvent('nexel:open-at', { detail: { path: '/repo/a.ts', line: 1, col: 1 } }));
      await new Promise(r => setTimeout(r, 50));
    });
    expect(useEditorStore.getState().tabs.map(t => t.filePath)).toEqual(['/repo/a.ts']);
    expect(useEditorStore.getState().tabs[0].content).toBe('fresh a content');
  });
});
