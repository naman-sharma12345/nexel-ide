import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, act, cleanup } from '@testing-library/react';
import React from 'react';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';

vi.mock('@monaco-editor/react', () => ({
  __esModule: true,
  default: () => React.createElement('div', { 'data-testid': 'monaco-stub' }),
  loader: { init: async () => ({}), config: () => {} },
  useMonaco: () => null,
}));
vi.mock('xterm', () => ({
  Terminal: class { loadAddon() {} attachCustomKeyEventHandler() {} open() {} write() {} dispose() {} onData() {} },
}));
vi.mock('xterm-addon-fit', () => ({ FitAddon: class { fit() {} } }));
vi.mock('xterm/css/xterm.css', () => ({}));

import App from '../App';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { useEditorStore } from '../stores/useEditorStore';
import { useSettingsStore } from '../stores/useSettingsStore';

let fixture: string | null = null;
beforeEach(() => {
  cleanup();
  localStorage.clear();
  useSettingsStore.setState({ clangdEnabled: false });
  useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null, isSplit: false, rightTabPath: null });
  useWorkspaceStore.setState({ rootPath: null });
});
afterEach(async () => {
  vi.restoreAllMocks();
  if (fixture) { await fs.rm(fixture, { recursive: true, force: true }); fixture = null; }
});

describe('alias-spelled opens dedupe to one tab', () => {
  it('a clangd-style open-at with a symlink-resolved spelling focuses the existing tab instead of duplicating', async () => {
    fixture = await fs.mkdtemp(path.join(os.tmpdir(), 'nexel-alias-app-'));
    const real = path.join(fixture, 'real'); await fs.mkdir(real);
    const file = path.join(real, 'a.cpp'); await fs.writeFile(file, 'int main(){}\n');
    const link = path.join(fixture, 'link'); await fs.symlink(real, link, 'dir');
    vi.spyOn(window.nexelAPI, 'realPath').mockImplementation((p: string) => fs.realpath(p));
    render(<App />);
    act(() => { useWorkspaceStore.setState({ rootPath: link }); });
    act(() => { useEditorStore.getState().openFile(path.join(link, 'a.cpp'), 'a.cpp', 'int main(){}\n'); });
    expect(useEditorStore.getState().tabs).toHaveLength(1);
    // A definition jumps in through the resolved (real-spelled) path.
    await act(async () => {
      window.dispatchEvent(new CustomEvent('nexel:open-at', { detail: { path: file, line: 1, col: 1 } }));
      await new Promise(r => setTimeout(r, 50));
    });
    const tabs = useEditorStore.getState().tabs;
    expect(tabs).toHaveLength(1);
    expect(tabs[0].filePath).toBe(path.join(link, 'a.cpp')); // existing spelling preserved
    expect(useEditorStore.getState().focusedTabPath).toBe(path.join(link, 'a.cpp'));
  });
});
