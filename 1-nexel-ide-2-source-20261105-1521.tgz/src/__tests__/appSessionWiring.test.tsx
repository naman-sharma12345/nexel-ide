import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, act, cleanup } from '@testing-library/react';
import React, { StrictMode } from 'react';

// Heavy third-party editor/terminal deps are stubbed; the shell itself renders for real.
vi.mock('@monaco-editor/react', () => ({
  __esModule: true,
  default: () => React.createElement('div', { 'data-testid': 'monaco-stub' }),
  loader: { init: async () => ({}), config: () => {} },
  useMonaco: () => null,
}));
vi.mock('xterm', () => ({
  Terminal: class { loadAddon() {} attachCustomKeyEventHandler() {} open() {} write() {} dispose() {} onData() {} },
}));
vi.mock('xterm-addon-fit', () => ({ FitAddon: class { fit() {} } }));
vi.mock('xterm/css/xterm.css', () => ({}));

import App from '../App';
import { useWorkspaceStore } from '../stores/useWorkspaceStore';
import { useSettingsStore } from '../stores/useSettingsStore';
import { useEditorStore } from '../stores/useEditorStore';
import { loadSession, saveSession } from '../lib/session';

const A = '/wkA';
const B = '/wkB';
const ALPHA = `${A}/alpha.cpp`;
const BETA = '/foreign/beta.cpp';

const settle = (ms = 500) => act(async () => { await new Promise(r => setTimeout(r, ms)); });

const openTabs = (...paths: string[]) => act(() => {
  for (const p of paths) useEditorStore.getState().openFile(p, p.split('/').pop() ?? p, '');
});

describe('App session save/clear wiring', () => {
  beforeEach(() => {
    cleanup();
    localStorage.clear();
    // Session save/clear wiring is independent of the language server; a live
    // clangd configure would instantiate real monaco standalone services, which
    // jsdom cannot host (no matchMedia).
    useSettingsStore.setState({ clangdEnabled: false });
    useEditorStore.setState({ tabs: [], activeTabPath: null, focusedTabPath: null, isSplit: false, rightTabPath: null });
    useWorkspaceStore.setState({ rootPath: null });
  });

  it('a root switch inside the save debounce cannot drop a pending deliberate-emptying clear', async () => {
    render(<App />);
    act(() => { useWorkspaceStore.setState({ rootPath: A }); });
    openTabs(ALPHA, BETA);
    await settle();
    expect(loadSession(A)?.paths).toEqual([ALPHA]);
    // Close the last in-root tab, then switch roots well inside the 400ms save
    // debounce: the earlier save already landed, so the clear must survive the
    // superseded debounce timer.
    act(() => { useEditorStore.getState().closeTab(ALPHA); });
    act(() => { useWorkspaceStore.setState({ rootPath: B }); });
    await settle();
    expect(loadSession(A)).toBeNull();
  });

  it('StrictMode double-invoked effects still clear on the deliberate close of the last in-root tab', async () => {
    render(<StrictMode><App /></StrictMode>);
    act(() => { useWorkspaceStore.setState({ rootPath: A }); });
    openTabs(ALPHA, BETA);
    await settle();
    expect(loadSession(A)?.paths).toEqual([ALPHA]);
    act(() => { useEditorStore.getState().closeTab(ALPHA); });
    await settle();
    expect(loadSession(A)).toBeNull();
  });

  it('switching into an all-foreign tab set preserves another root\'s stored session (StrictMode)', async () => {
    saveSession({ root: '/wkC', paths: ['/wkC/c.cpp'], active: '/wkC/c.cpp' });
    render(<StrictMode><App /></StrictMode>);
    act(() => { useWorkspaceStore.setState({ rootPath: A }); });
    openTabs(BETA);
    await settle();
    expect(loadSession('/wkC')?.paths).toEqual(['/wkC/c.cpp']);
    expect(loadSession(A)).toBeNull();
  });

  it('a tab reopened right after the deliberate close is saved again', async () => {
    render(<App />);
    act(() => { useWorkspaceStore.setState({ rootPath: A }); });
    openTabs(ALPHA);
    await settle();
    act(() => { useEditorStore.getState().closeTab(ALPHA); });
    expect(loadSession(A)).toBeNull();
    openTabs(ALPHA);
    await settle();
    expect(loadSession(A)?.paths).toEqual([ALPHA]);
  });
});

it('reports unreadable code-like filenames as failed restores, not confirmed missing',async()=>{
 cleanup();localStorage.clear();useSettingsStore.setState({clangdEnabled:false});useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});useWorkspaceStore.setState({rootPath:null});
 const {useStatusStore}=await import('../stores/useStatusStore');useStatusStore.setState({toasts:[]});
 saveSession({root:A,paths:[A+'/ENOENT.cpp',A+'/gone.cpp'],active:A+'/gone.cpp'});
 vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(async p=>{if(p.endsWith('ENOENT.cpp'))throw new Error(`Error invoking remote method 'fs:read-file-content': Error: EACCES: permission denied, open '${p}'`);throw Object.assign(new Error('ENOENT: missing'),{code:'ENOENT'});});
 render(<App/>);act(()=>useWorkspaceStore.setState({rootPath:A}));await settle(100);
 expect(useStatusStore.getState().toasts.some(t=>t.message.includes("1 no longer on disk, 1 couldn't be reopened"))).toBe(true);cleanup();vi.restoreAllMocks();
});
it('does not land a delayed session file or success notice after a workspace switch',async()=>{
 cleanup();localStorage.clear();useSettingsStore.setState({clangdEnabled:false});useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});useWorkspaceStore.setState({rootPath:null});
 const {useStatusStore}=await import('../stores/useStatusStore');useStatusStore.setState({toasts:[]});saveSession({root:A,paths:[ALPHA,A+'/later.cpp'],active:A+'/later.cpp'});
 let finish!:(s:string)=>void;const read=vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(()=>new Promise<string>(r=>finish=r));render(<App/>);act(()=>useWorkspaceStore.getState().setRootPath(A));await settle(30);expect(read).toHaveBeenCalledTimes(1);
 act(()=>useWorkspaceStore.getState().setRootPath(B));await act(async()=>finish('old session bytes'));await settle(30);expect(useEditorStore.getState().tabs).toHaveLength(0);expect(read).toHaveBeenCalledTimes(1);expect(useStatusStore.getState().toasts.some(t=>t.message.startsWith('Restored'))).toBe(false);cleanup();vi.restoreAllMocks();
});
it.each(['roundtrip','same-root','new-tab','unmount','late-failure'] as const)('abandons obsolete session work on %s',async mode=>{
 cleanup();localStorage.clear();useSettingsStore.setState({clangdEnabled:false});useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});useWorkspaceStore.setState({rootPath:null});
 const {useStatusStore}=await import('../stores/useStatusStore');useStatusStore.setState({toasts:[]});saveSession({root:A,paths:[ALPHA,A+'/later.cpp'],active:A+'/later.cpp'});
 let finish!:(s:string)=>void,fail!:(e:Error)=>void;const read=vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(()=>new Promise<string>((r,j)=>{finish=r;fail=j;}));const view=render(<App/>);act(()=>useWorkspaceStore.getState().setRootPath(A));await settle(30);expect(read).toHaveBeenCalledTimes(1);
 act(()=>{if(mode==='roundtrip'){useWorkspaceStore.getState().setRootPath(B);useWorkspaceStore.getState().setRootPath(A);}else if(mode==='same-root')useWorkspaceStore.getState().setRootPath(A);else if(mode==='new-tab')useEditorStore.getState().openFile(BETA,'beta.cpp','new intent');else if(mode==='unmount')view.unmount();else useWorkspaceStore.getState().setRootPath(B);});
 await act(async()=>{if(mode==='late-failure')fail(new Error('ENOENT: gone'));else finish('old session bytes');});await settle(30);expect(useEditorStore.getState().tabs.map(t=>t.filePath)).toEqual(mode==='new-tab'?[BETA]:[]);expect(read).toHaveBeenCalledTimes(1);expect(useStatusStore.getState().toasts).toHaveLength(0);cleanup();vi.restoreAllMocks();
});
it('keeps sequential session restore and active-last focus when navigation remains unchanged',async()=>{
 cleanup();localStorage.clear();useSettingsStore.setState({clangdEnabled:false});useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});useWorkspaceStore.setState({rootPath:null});
 const {useStatusStore}=await import('../stores/useStatusStore');useStatusStore.setState({toasts:[]});saveSession({root:A,paths:[ALPHA,A+'/later.cpp'],active:ALPHA});const read=vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(async p=>'bytes '+p);render(<App/>);act(()=>useWorkspaceStore.getState().setRootPath(A));await settle(40);
 expect(useEditorStore.getState().tabs.map(t=>t.filePath)).toEqual([A+'/later.cpp',ALPHA]);expect(useEditorStore.getState().activeTabPath).toBe(ALPHA);expect(useStatusStore.getState().toasts.map(t=>t.message)).toContain('Restored 2 tabs');expect(read).toHaveBeenCalledTimes(2);cleanup();vi.restoreAllMocks();
});
it.each(['new-tab','close-restored','typing','typing-undo','strict-typing'] as const)('retains only current intent when %s interrupts a partly restored session',async mode=>{
 cleanup();localStorage.clear();useSettingsStore.setState({clangdEnabled:false});useEditorStore.setState({tabs:[],activeTabPath:null,focusedTabPath:null,isSplit:false,rightTabPath:null});useWorkspaceStore.setState({rootPath:null});
 const {useStatusStore}=await import('../stores/useStatusStore');useStatusStore.setState({toasts:[]});const later=A+'/later.cpp';saveSession({root:A,paths:[ALPHA,later],active:later});let finish!:(s:string)=>void;const read=vi.spyOn(window.nexelAPI,'readFileContent').mockImplementation(async p=>p===ALPHA?'first restored':new Promise<string>(r=>finish=r));if(mode==='strict-typing'){act(()=>useWorkspaceStore.getState().setRootPath(A));render(<StrictMode><App/></StrictMode>);}else{render(<App/>);act(()=>useWorkspaceStore.getState().setRootPath(A));}await settle(30);expect(useEditorStore.getState().tabs.map(t=>t.filePath)).toEqual([ALPHA]);expect(read).toHaveBeenCalledTimes(2);
 act(()=>{if(mode==='new-tab')useEditorStore.getState().openFile(BETA,'beta.cpp','new intent');else if(mode==='typing'||mode==='typing-undo'||mode==='strict-typing'){useEditorStore.getState().updateTabContent(ALPHA,'new edit');if(mode==='typing-undo')useEditorStore.getState().updateTabContent(ALPHA,'first restored');}else useEditorStore.getState().closeTab(ALPHA);});await act(async()=>finish('late restore'));await settle(30);expect(useEditorStore.getState().tabs.map(t=>t.filePath)).toEqual(mode==='new-tab'?[ALPHA,BETA]:mode==='close-restored'?[]:[ALPHA]);expect(useEditorStore.getState().activeTabPath).toBe(mode==='new-tab'?BETA:mode==='close-restored'?null:ALPHA);expect(useStatusStore.getState().toasts).toHaveLength(0);cleanup();vi.restoreAllMocks();
});
