const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const ts = require('typescript');
const { spawn } = require('child_process');

// Register the on-the-fly TS loader for main process TypeScript support
require.extensions['.ts'] = function (module, filename) {
  const content = fs.readFileSync(filename, 'utf8');
  const result = ts.transpileModule(content, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      inlineSourceMap: true,
    },
  });
  module._compile(result.outputText, filename);
};

// Import TypeScript Services
const { startPipeShellWithHomeRetry } = require('./src/main/services/startPipeShell.ts');
const { resolveTerminalCwd } = require('./src/main/services/terminalCwd.ts');
const { spawnPtyWithHomeRetry } = require('./src/main/services/terminalPtySpawn.ts');
const { FileSystemService } = require('./src/main/services/FileSystemService.ts');
const { JudgeService } = require('./src/main/services/JudgeService.ts');
const { GitService } = require('./src/main/services/GitService.ts');
const { GitWatcher } = require('./src/main/services/GitWatcher.ts');
const { StoreService } = require('./src/main/services/StoreService.ts');
const { validateJudgeArgs } = require('./src/main/services/ipcValidate.ts');
const { LanguageServerManager } = require('./src/main/services/lsp/LanguageServerManager.ts');
const { resolveClangd, clangdArgs, findCompiler } = require('./src/main/services/lsp/resolveClangd.ts');
const { ensureWorkspaceConfig } = require('./src/main/services/lsp/workspaceConfig.ts');
const { validateClangdOptions } = require('./src/main/services/lsp/lspValidate.ts');
const { CompanionService } = require('./src/main/services/CompanionService.ts');
const { createCodeforcesLoader, openCodeforcesWindow } = require('./src/main/services/cfBrowserLoader.ts');

let pty;
try {
  pty = require('node-pty');
} catch (e) {
  console.warn("node-pty load failure, falling back to standard spawn:", e);
}

let mainWindow;
let ptyProcess = null;
let isNativePty = false;
let terminalGeneration = 0;

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 720,
    minHeight: 480,
    backgroundColor: '#0B0B0D',
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
  });

  // Hardening: deny popups and off-origin navigation
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (e, url) => {
    if (!/^(file:|http:\/\/localhost)/.test(url)) e.preventDefault();
  });

  mainWindow.setMenu(null);

  // Initialize service instances
  const fileSystemService = new FileSystemService();
  const judgeService = new JudgeService();
  const gitService = new GitService();
  const gitWatcher = new GitWatcher();
  judgeService.setPageLoader(createCodeforcesLoader(BrowserWindow, { parent: mainWindow }));
  const storeService = new StoreService();
  await storeService.initialize();

  // Competitive Companion: loopback-only HTTP listener (127.0.0.1:27121), forwards validated problems to the UI
  const companion = new CompanionService((problem) => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('companion:problem', problem);
  });
  companion.start();
  // will-quit, not before-quit: a canceled quit (dirty-tab close guard) must not
// stop services for the session that keeps running.
app.on('will-quit', () => {
  companion.stop(); if (lsp) lsp.stop(); try { ptyProcess && ptyProcess.kill(); } catch (err) {} ptyProcess = null;
  try { fileSystemService && void fileSystemService.disposeTreeWorker(); } catch (err) {}
});

  // clangd language server bridge. The renderer can only: start (workspace root + validated std/flags that end up in a
  // generated .clangd, never in argv), send allowlisted JSON-RPC, restart, stop. Binary path and argv are fixed here.
  let lsp = null;
  const fromMain = (event) => mainWindow && !mainWindow.isDestroyed() && event.sender === mainWindow.webContents;
  const sendStatus = (s) => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('lsp:status', s); };
  const shimDir = () => {
    const packaged = path.join(process.resourcesPath || '', 'nexel-include');
    return app.isPackaged && fs.existsSync(packaged) ? packaged : path.join(__dirname, 'resources', 'nexel-include');
  };
  ipcMain.handle('lsp:start', async (event, root, rawOpts) => {
    if (!fromMain(event)) return { ok: false, reason: 'bad-sender' };
    if (typeof root !== 'string' || root.length > 4096 || !path.isAbsolute(root) || root.includes('\0')) return { ok: false, reason: 'invalid-root' };
    let st; try { st = fs.statSync(root); } catch { st = null; }
    if (!st || !st.isDirectory()) return { ok: false, reason: 'invalid-root' };
    const opts = validateClangdOptions(rawOpts);
    if (lsp) { lsp.stop(); lsp = null; }
    const env = { platform: process.platform, arch: process.arch, resourcesPath: app.isPackaged ? process.resourcesPath : undefined, appRoot: __dirname, pathEnv: process.env.PATH };
    const bin = resolveClangd(env);
    if (!bin) { sendStatus('off'); return { ok: false, reason: 'clangd-not-found' }; }
    const compiler = findCompiler(env);
    // libstdc++ (Linux, MinGW) already has bits/stdc++.h; the shim is for libc++/MSVC toolchains.
    const includeDir = process.platform === 'linux' ? null : shimDir();
    const config = ensureWorkspaceConfig(root, { ...opts, includeDir, compiler });
    lsp = new LanguageServerManager(bin.path, clangdArgs({ queryDriver: compiler }), root,
      (m) => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('lsp:message', m); }, sendStatus);
    lsp.start();
    return { ok: true, source: bin.source, compiler: compiler ? path.basename(compiler) : null, config: config.action };
  });
  ipcMain.handle('lsp:send', async (event, msg) => { if (!fromMain(event) || !lsp) return false; try { lsp.send(msg); return true; } catch { return false; } });
  ipcMain.handle('lsp:restart', async (event) => { if (!fromMain(event) || !lsp) return false; lsp.restart(); return true; });
  ipcMain.handle('lsp:stop', async (event) => { if (!fromMain(event)) return false; if (lsp) lsp.stop(); lsp = null; return true; });
  // Never leave clangd behind: quit, window close, renderer crash.
  mainWindow.on('closed', () => { if (lsp) { lsp.stop(); lsp = null; } });
  mainWindow.webContents.on('render-process-gone', () => { if (lsp) { lsp.stop(); lsp = null; } });

  // Window frame control receivers
  ipcMain.on('window-control', (event, action) => {
    const win = BrowserWindow.getFocusedWindow();
    if (!win) return;
    if (action === 'minimize') win.minimize();
    if (action === 'maximize') win.isMaximized() ? win.unmaximize() : win.maximize();
    if (action === 'close') win.close();
  });

  // Terminal PTY process IPC receivers
  ipcMain.handle('terminal:create', async (event, requestedCwd) => {
    const generation = ++terminalGeneration;
    if (ptyProcess) {
      const previous = ptyProcess;
      ptyProcess = null; // Intentional restart: old exit cannot report the new session exited.
      try { previous.kill(); } catch (err) {}
    }

    const shell = process.platform === 'win32' ? 'powershell.exe' : 'bash';
    const termCwd = resolveTerminalCwd(requestedCwd, process.env.HOME || process.env.USERPROFILE);

    if (pty) {
      // Validation can race a removal before spawn (TOCTOU), so a spawn failure
      // with a validated cwd retries once in HOME before degrading to the pipe
      // shell (spawnPtyWithHomeRetry, unit-tested). If HOME itself is
      // unspawnable the error surfaces as before.
      const home = process.env.HOME || process.env.USERPROFILE;
      const spawned = spawnPtyWithHomeRetry(pty, shell, termCwd, home, {
        name: 'xterm-color',
        cols: 80,
        rows: 10,
        env: process.env
      });
      if (spawned) {
        if (spawned.cwdUsed !== termCwd) console.warn("Retried terminal spawn in HOME after workspace cwd failed.");
        ptyProcess = spawned.proc;
        const spawnedPty = ptyProcess;
        ptyProcess.onData((data) => {
          if (ptyProcess === spawnedPty && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', data);
        });
        ptyProcess.onExit(() => {
          if (ptyProcess === spawnedPty) {
            ptyProcess = null;
            if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', '\r\nShell exited. Use Restart Shell to start a new session.\r\n');
          }
        });
        isNativePty = true;
        return isNativePty;
      }
      console.warn("PTY native spawn failed, falling back to process spawn.");
    }

    // Process shell fallback. Same validated cwd, same single HOME retry on
    // stale-dir spawn failure as the PTY path (startPipeShellWithHomeRetry,
    // unit-tested); a null result surfaces as the startup error below.
    try {
      const args = shell === 'powershell.exe' ? ['-NoLogo', '-Interactive'] : [];
      const pipeSpawned = await startPipeShellWithHomeRetry(shell, args, {
        cwd: termCwd,
        env: process.env
      }, process.env.HOME || process.env.USERPROFILE, (error) => {
        console.error('Shell process error after startup:', error);
        if (generation === terminalGeneration && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', '\r\nShell process error. Use Restart Shell to try again.\r\n');
      });
      if (!pipeSpawned) throw new Error('Pipe shell spawn failed in the workspace cwd and in HOME');
      if (pipeSpawned.cwdUsed !== termCwd) console.warn("Retried pipe shell spawn in HOME after workspace cwd failed.");
      const started = pipeSpawned.child;
      if (generation !== terminalGeneration) {
        try { started.kill(); } catch {}
        throw new Error('Shell start was superseded by a newer session');
      }
      ptyProcess = started;
      isNativePty = false;

      ptyProcess.stdout.on('data', (data) => {
        if (ptyProcess === started && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', data.toString());
      });
      ptyProcess.stderr.on('data', (data) => {
        if (ptyProcess === started && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', data.toString());
      });

      const spawnedProc = ptyProcess;
      ptyProcess.on('close', () => {
        if (ptyProcess === spawnedProc) {
          ptyProcess = null;
          if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', '\r\nShell exited. Use Restart Shell to start a new session.\r\n');
        }
      });
    } catch (err) {
      if (generation === terminalGeneration) ptyProcess = null;
      console.error("Shell process spawn failure:", err);
      throw err;
    }

    return isNativePty;
  });

  ipcMain.on('terminal:write', (event, data) => {
    if (!ptyProcess) return;
    try {
      if (isNativePty) ptyProcess.write(data);
      else if (!ptyProcess.stdin.destroyed && ptyProcess.stdin.writable) ptyProcess.stdin.write(data);
    } catch (error) {
      console.error('Shell input write failed:', error);
      if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('terminal:data', '\r\nShell input failed. Use Restart Shell to try again.\r\n');
    }
  });

  ipcMain.on('terminal:resize', (event, cols, rows) => {
    if (ptyProcess && isNativePty) {
      try {
        ptyProcess.resize(cols, rows);
      } catch (err) {
        console.error("PTY resize failed:", err);
      }
    }
  });

  // Decoupled File System IPC Routes
  ipcMain.handle('fs:open-dir', async () => {
    return await fileSystemService.openDir();
  });

  ipcMain.handle('fs:read-files', async (event, dirPath) => {
    return await fileSystemService.readFiles(dirPath);
  });

  ipcMain.handle('fs:create-file', async (event, parentPath, fileName) => {
    return await fileSystemService.createFile(parentPath, fileName);
  });

  ipcMain.handle('fs:create-folder', async (event, parentPath, folderName) => {
    return await fileSystemService.createFolder(parentPath, folderName);
  });

  ipcMain.handle('fs:rename', async (event, oldPath, newPath) => {
    return await fileSystemService.rename(oldPath, newPath);
  });

  ipcMain.handle('fs:delete', async (event, targetPath) => {
    return await fileSystemService.deleteNode(targetPath);
  });

  ipcMain.handle('fs:file-identity', async (_event, filePath) => {
    return await fileSystemService.fileIdentity(filePath);
  });

  ipcMain.handle('fs:realpath', async (_event, filePath) => {
    return await fileSystemService.realPath(filePath);
  });

  ipcMain.handle('fs:read-file-content', async (event, filePath) => {
    return await fileSystemService.readFileContent(filePath);
  });

  ipcMain.handle('fs:write-file-content', async (event, filePath, content) => {
    return await fileSystemService.writeFileContent(filePath, content);
  });

  ipcMain.handle('fs:write-file-if-baseline', async (event, filePath, content, baseline) => {
    return await fileSystemService.writeFileIfBaseline(filePath, content, baseline);
  });

  // Decoupled Judge IPC Routes
  ipcMain.handle('judge:run', async (event, filePath, testCases, timeLimit, memoryLimit, runId) => {
    const v = validateJudgeArgs(filePath, testCases, timeLimit, memoryLimit); // renderer input is untrusted
    const runIdOk = typeof runId === 'string' && runId.length > 0 && runId.length <= 128 ? runId : undefined;
    return await judgeService.run(v.filePath, v.cases, v.timeLimit, v.memoryLimit, runIdOk);
  });
  ipcMain.handle('judge:cancel', async (event, runId) => {
    if (typeof runId === 'string' && runId.length > 0 && runId.length <= 128) judgeService.cancel(runId);
  });

  // Git integration: workspace-scoped CLI wrapper (no shell; arg arrays only).
  // Commit/stage happen only when the user clicks them in the Source Control panel.
  const gitRootOk = (root) => typeof root === 'string' && path.isAbsolute(root);
  ipcMain.handle('git:status', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { isRepo: false, branch: null, ahead: 0, behind: 0, entries: [] };
    return await gitService.status(root);
  });
  ipcMain.handle('git:init', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, error: 'bad-sender' };
    return await gitService.init(root);
  });
  ipcMain.handle('git:stage', async (event, root, paths) => {
    if (!fromMain(event) || !gitRootOk(root) || !Array.isArray(paths) || paths.some(p => typeof p !== 'string')) return { ok: false, error: 'bad-sender' };
    return await gitService.stage(root, paths);
  });
  ipcMain.handle('git:unstage', async (event, root, paths) => {
    if (!fromMain(event) || !gitRootOk(root) || !Array.isArray(paths) || paths.some(p => typeof p !== 'string')) return { ok: false, error: 'bad-sender' };
    return await gitService.unstage(root, paths);
  });
  ipcMain.handle('git:commit', async (event, root, message) => {
    if (!fromMain(event) || !gitRootOk(root) || typeof message !== 'string' || message.length > 10000) return { ok: false, error: 'bad-sender' };
    return await gitService.commit(root, message);
  });
  ipcMain.handle('git:branches', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, branches: [], error: 'bad-sender' };
    return await gitService.branches(root);
  });
  ipcMain.handle('git:diff', async (event, root, path, staged, origPath) => {
    if (!fromMain(event) || !gitRootOk(root) || typeof path !== 'string' || (origPath !== undefined && typeof origPath !== 'string')) return { ok: false, error: 'bad-sender' };
    return await gitService.diff(root, path, !!staged, origPath);
  });
  ipcMain.handle('git:switch', async (event, root, branch) => {
    if (!fromMain(event) || !gitRootOk(root) || typeof branch !== 'string') return { ok: false, error: 'bad-sender' };
    return await gitService.switchBranch(root, branch);
  });
  ipcMain.handle('git:fetch', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, error: 'bad-sender' };
    return await gitService.fetch(root);
  });
  ipcMain.handle('git:pull', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, error: 'bad-sender' };
    return await gitService.pull(root);
  });
  ipcMain.handle('git:log', async (event, root, limit) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, commits: [], error: 'bad-sender' };
    return await gitService.log(root, typeof limit === 'number' ? limit : 50);
  });
  ipcMain.handle('git:push', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, error: 'bad-sender' };
    return await gitService.push(root);
  });
  ipcMain.handle('git:remotes', async (event, root) => {
    if (!fromMain(event) || !gitRootOk(root)) return { ok: false, remotes: [], error: 'bad-sender' };
    return await gitService.remotes(root);
  });
  ipcMain.handle('git:publish', async (event, root, remote, branch) => {
    if (!fromMain(event) || !gitRootOk(root) || typeof remote !== 'string' || typeof branch !== 'string') return { ok: false, error: 'bad-sender' };
    return await gitService.publish(root, remote, branch);
  });
  // Read-only metadata watch: renderer asks to watch the open root's gitdir so
  // external git operations (terminal commit/checkout/stage/merge/fetch) can
  // invalidate the UI. Metadata only - working-tree edits are not watched.
  ipcMain.handle('git:watch', (event, root) => {
    if (!fromMain(event)) return { ok: false, error: 'bad-sender' };
    if (root === null) { gitWatcher.stop(); return { ok: true, watching: false }; }
    if (!gitRootOk(root)) return { ok: false, error: 'bad-sender' };
    const r = gitWatcher.start(root, (changedRoot) => {
      if (!event.sender.isDestroyed()) event.sender.send('git:externally-changed', changedRoot);
    });
    // Teardown only: renderer window destroyed or the app actually quitting.
    // NOT before-quit - a canceled quit (close guard) must keep the watch alive.
    event.sender.once('destroyed', () => gitWatcher.stop());
    return { ok: true, watching: r.watching };
  });
  app.on('quit', () => gitWatcher.stop());

  ipcMain.handle('git:create-branch', async (event, root, name) => {
    if (!fromMain(event) || !gitRootOk(root) || typeof name !== 'string') return { ok: false, error: 'bad-sender' };
    return await gitService.createBranch(root, name);
  });

  ipcMain.handle('judge:fetch-contests', async (event, workspaceDir) => {
    return await judgeService.fetchContests(workspaceDir);
  });

  ipcMain.handle('judge:fetch-problems', async (event, contestId) => {
    return await judgeService.fetchProblems(contestId);
  });

  ipcMain.handle('cf:open-session', async (event, url) => {
    const target = typeof url === 'string' ? url : 'https://codeforces.com/enter';
    openCodeforcesWindow(BrowserWindow, target, mainWindow);
    return true;
  });

  // Secure Electron Store IPC Routes (Synchronous)
  ipcMain.on('store:get-sync', (event, key) => {
    event.returnValue = storeService.getSync(key);
  });

  ipcMain.on('store:set-sync', (event, key, value) => {
    event.returnValue = storeService.setSync(key, value);
  });

  ipcMain.on('store:delete-sync', (event, key) => {
    event.returnValue = storeService.deleteSync(key);
  });

  // Packaged builds load the Vite bundle from disk; dev uses the Vite server.
  if (app.isPackaged && !process.env.ELECTRON_START_URL) mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  else mainWindow.loadURL(process.env.ELECTRON_START_URL || 'http://localhost:5173');

  if (process.env.ELECTRON_START_URL) {
    mainWindow.webContents.openDevTools();
  }

  // Unsaved editor buffers live only in the renderer: never destroy the window
  // without giving it a chance to confirm. The renderer answers
  // 'app:close-requested' with 'app:confirm-close' once no dirty tabs remain
  // (or after the user explicitly discards them).
  let allowClose = false;
  mainWindow.on('close', (event) => {
    if (allowClose) return;
    const wc = mainWindow && mainWindow.webContents;
    if (!wc || wc.isDestroyed() || wc.isLoading()) return; // renderer cannot answer yet
    event.preventDefault();
    wc.send('app:close-requested');
  });
  ipcMain.on('app:confirm-close', (event) => {
    if (!fromMain(event) || !mainWindow) return;
    allowClose = true;
    mainWindow.close();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
